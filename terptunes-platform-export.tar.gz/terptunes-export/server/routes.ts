import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import SpotifyService from "./services/spotifyService";
import { nanoid } from "nanoid";
import { TerpeneService } from "./services/terpeneService";
import { StrainValidationService, type UserStrainSubmission } from "./services/strainValidationService";
import { RecommendationEngine } from "./services/recommendationEngine";
import { db } from "./db";
import { strains } from "@shared/schema";
import { eq, count, sql } from "drizzle-orm";
import { getAllStrains } from "./data/strains";
import { getAllTerpenes } from "./data/terpenes";
import { enhancedSeedDatabase } from "./enhancedSeed";
import { manualSeedDatabase } from "./manualSeed";
import { importComprehensiveStrainDatabase } from "./comprehensiveStrainImporter";
import { MaxValueImporter } from "./maxValueImporter";
import { dataIntegrationService } from "./dataIntegrationService";
import { RealStrainImageService } from "./services/realStrainImages";
import { StrainImageGenerator } from "./services/strainImageGenerator";
import MelloMaestroService from "./services/melloMaestroService";

export async function registerRoutes(app: Express): Promise<Server> {
  // In-memory cache for strains to avoid repeated expensive database calls
  let strainsCache: any[] = [];
  let cacheLastUpdated = 0;
  const CACHE_TTL = 300000; // 5 minute cache TTL for production performance

  async function getCachedStrains() {
    const now = Date.now();
    if (strainsCache.length === 0 || (now - cacheLastUpdated) > CACHE_TTL) {
      console.log('Refreshing strains cache...');
      const allStrains = await storage.getAllStrains();
      
      // Batch fetch all terpene profiles to reduce database calls
      const strainsWithTerpenes = await Promise.all(
        allStrains.map(async (strain) => {
          const terpeneProfiles = await storage.getTerpeneProfilesByStrainId(strain.id);
          return {
            ...strain,
            terpenes: terpeneProfiles.map(profile => ({
              name: profile.name,
              percentage: parseFloat(profile.percentage || '0')
            }))
          };
        })
      );
      
      strainsCache = strainsWithTerpenes;
      cacheLastUpdated = now;
      console.log(`Cached ${strainsCache.length} strains`);
    }
    return strainsCache;
  }

  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Onboarding API endpoints
  app.get('/api/auth/onboarding-status', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Simple onboarding status based on user fields
      let currentStep = "user_type";
      let completed = user.onboardingCompleted || false;
      let nextSteps = [];
      let requiredActions = [];

      if (user.userType) {
        currentStep = "preferences";
        if (user.userType !== "consumer") {
          if (!user.verificationStatus || user.verificationStatus === "pending") {
            requiredActions.push("business_verification");
          }
        }
      }

      if (completed) {
        currentStep = "completed";
      }

      res.json({
        currentStep,
        completed,
        nextSteps,
        requiredActions,
        userType: user.userType,
        verificationStatus: user.verificationStatus,
      });
    } catch (error) {
      console.error("Error fetching onboarding status:", error);
      res.status(500).json({ message: "Failed to fetch onboarding status" });
    }
  });

  app.post('/api/auth/update-user-type', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { userType } = req.body;

      if (!["consumer", "grower", "dispensary"].includes(userType)) {
        return res.status(400).json({ message: "Invalid user type" });
      }

      await storage.updateUser(userId, { 
        userType,
        updatedAt: new Date(),
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Error updating user type:", error);
      res.status(500).json({ message: "Failed to update user type" });
    }
  });

  app.post('/api/auth/setup-preferences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const preferences = req.body;

      // For now, just store basic info in user record
      // In production, you'd save to userPreferences table
      await storage.updateUser(userId, { 
        updatedAt: new Date(),
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Error setting up preferences:", error);
      res.status(500).json({ message: "Failed to setup preferences" });
    }
  });

  app.post('/api/auth/submit-verification', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const businessData = req.body;

      await storage.updateUser(userId, {
        businessName: businessData.businessName,
        businessLicense: businessData.businessLicense,
        businessAddress: businessData.businessAddress,
        businessPhone: businessData.businessPhone,
        businessWebsite: businessData.businessWebsite,
        verificationStatus: 'pending',
        accountStatus: 'pending_verification',
        updatedAt: new Date(),
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Error submitting verification:", error);
      res.status(500).json({ message: "Failed to submit verification" });
    }
  });

  app.post('/api/auth/update-onboarding', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { step, data } = req.body;

      // Simple step tracking - in production you'd use userOnboarding table
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating onboarding:", error);
      res.status(500).json({ message: "Failed to update onboarding step" });
    }
  });

  app.post('/api/auth/complete-onboarding', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;

      await storage.updateUser(userId, {
        onboardingCompleted: true,
        updatedAt: new Date(),
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Error completing onboarding:", error);
      res.status(500).json({ message: "Failed to complete onboarding" });
    }
  });

  // User preferences and profile endpoints
  app.get('/api/user/preferences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      // Return mock preferences for now
      res.json({
        favoriteStrainTypes: ['hybrid'],
        favoriteTerpenes: ['myrcene', 'limonene'],
        preferredEffects: ['relaxed', 'creative'],
        thcPreference: { min: 15, max: 25 },
        musicGenres: ['electronic', 'ambient'],
        moodStates: ['relaxed', 'creative'],
        usageContext: ['evening wind-down'],
        playlistDuration: 60,
        explicitContent: false,
        notifications: {
          newStrains: true,
          playlistRecommendations: true,
          weeklyInsights: false,
        }
      });
    } catch (error) {
      console.error("Error fetching user preferences:", error);
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });

  app.post('/api/user/preferences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      // In a real implementation, save to database
      res.json({ message: "Preferences updated successfully" });
    } catch (error) {
      console.error("Error updating user preferences:", error);
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  app.get('/api/user/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      // Return mock stats for now
      res.json({
        strainsDiscovered: 47,
        playlistsCreated: 23,
        totalListeningHours: 127,
        favoriteTerpene: 'Myrcene'
      });
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.get('/api/user/activity', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      // Return mock activity for now
      res.json([
        { type: 'strain_discovery', strain: 'Purple Punch', time: '2 hours ago' },
        { type: 'playlist_created', playlist: 'Chill Vibes Mix', time: '1 day ago' },
        { type: 'recommendation_liked', strain: 'Blue Dream', time: '2 days ago' },
        { type: 'strain_discovery', strain: 'Wedding Cake', time: '3 days ago' },
      ]);
    } catch (error) {
      console.error("Error fetching user activity:", error);
      res.status(500).json({ message: "Failed to fetch activity" });
    }
  });

  // Search suggestions and trending
  app.get('/api/search/suggestions', async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query || query.length < 2) {
        return res.json([]);
      }
      
      // Return mock suggestions based on query
      const suggestions = [
        'Purple Punch strain',
        'Energizing sativa strains',
        'High limonene terpene',
        'Creative effects cannabis'
      ].filter(s => s.toLowerCase().includes(query.toLowerCase()));
      
      res.json(suggestions);
    } catch (error) {
      console.error("Error fetching search suggestions:", error);
      res.status(500).json({ message: "Failed to fetch suggestions" });
    }
  });

  app.get('/api/search/trending', async (req, res) => {
    try {
      // Return mock trending searches
      res.json([
        'Blue Dream',
        'High THC strains',
        'Myrcene dominant',
        'Energizing effects',
        'Creative boost',
        'Sleep strains',
        'Citrus flavors',
        'Indica hybrids'
      ]);
    } catch (error) {
      console.error("Error fetching trending searches:", error);
      res.status(500).json({ message: "Failed to fetch trending" });
    }
  });

  // Review endpoints
  app.get('/api/strains/:id/reviews', async (req, res) => {
    try {
      const strainId = parseInt(req.params.id);
      const sort = req.query.sort as string || 'newest';
      const filter = req.query.filter as string || 'all';
      
      // Return mock reviews for now
      res.json([
        {
          id: 1,
          userId: 'user1',
          userName: 'Cannabis Connoisseur',
          strainId: strainId,
          rating: 5,
          title: 'Perfect for evening relaxation',
          content: 'This strain provides an amazing body high that melts away stress. The myrcene really shines through with its sedating effects. Perfect for winding down after a long day.',
          effects: ['relaxed', 'sleepy', 'calm'],
          pros: ['Great taste', 'Strong effects', 'Good for sleep'],
          cons: ['Can be too sedating'],
          experienceLevel: 'experienced',
          consumptionMethod: 'vaporizer',
          dosage: 'medium',
          occasion: 'evening',
          createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          likes: 15,
          dislikes: 2,
          userHasLiked: false,
          userHasDisliked: false,
          verified: true,
          helpful: 18
        },
        {
          id: 2,
          userId: 'user2',
          userName: 'Terpene Explorer',
          strainId: strainId,
          rating: 4,
          title: 'Great terpene profile',
          content: 'Love the complex terpene profile in this one. The limonene adds a nice citrus note that balances the earthiness. Effects are well-balanced between mind and body.',
          effects: ['uplifted', 'creative', 'focused'],
          pros: ['Balanced effects', 'Great flavor', 'Clear-headed'],
          cons: ['Could be stronger'],
          experienceLevel: 'intermediate',
          consumptionMethod: 'flower',
          dosage: 'low',
          occasion: 'creative',
          createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
          likes: 12,
          dislikes: 1,
          userHasLiked: false,
          userHasDisliked: false,
          verified: false,
          helpful: 9
        }
      ]);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.get('/api/strains/:id/review-summary', async (req, res) => {
    try {
      const strainId = parseInt(req.params.id);
      
      // Return mock review summary
      res.json({
        averageRating: 4.2,
        totalReviews: 47,
        ratingDistribution: {
          5: 18,
          4: 15,
          3: 8,
          2: 4,
          1: 2
        },
        topEffects: ['Relaxed', 'Creative', 'Happy', 'Focused'],
        verifiedCount: 23,
        expertCount: 8,
        totalHelpful: 312
      });
    } catch (error) {
      console.error("Error fetching review summary:", error);
      res.status(500).json({ message: "Failed to fetch review summary" });
    }
  });

  app.post('/api/strains/:id/reviews', isAuthenticated, async (req: any, res) => {
    try {
      const strainId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const reviewData = req.body;
      
      // In a real implementation, save to database
      res.json({ message: "Review submitted successfully", id: Date.now() });
    } catch (error) {
      console.error("Error submitting review:", error);
      res.status(500).json({ message: "Failed to submit review" });
    }
  });

  app.post('/api/reviews/:id/vote', isAuthenticated, async (req: any, res) => {
    try {
      const reviewId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const { voteType } = req.body;
      
      // In a real implementation, save vote to database
      res.json({ message: "Vote recorded successfully" });
    } catch (error) {
      console.error("Error recording vote:", error);
      res.status(500).json({ message: "Failed to record vote" });
    }
  });

  // Recommendation endpoints
  app.get('/api/recommendations/strains', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Mock personalized strain recommendations
      res.json([
        {
          id: 1,
          name: 'Blue Dream',
          reason: 'Based on your preference for balanced hybrids',
          confidence: 0.92,
          matchScore: 95
        },
        {
          id: 2,
          name: 'Purple Punch',
          reason: 'Perfect for your evening relaxation routine',
          confidence: 0.87,
          matchScore: 88
        },
        {
          id: 3,
          name: 'Green Crack',
          reason: 'Matches your creative and energetic preferences',
          confidence: 0.83,
          matchScore: 85
        }
      ]);
    } catch (error) {
      console.error("Error fetching strain recommendations:", error);
      res.status(500).json({ message: "Failed to fetch recommendations" });
    }
  });

  app.get('/api/recommendations/playlists', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Mock personalized playlist recommendations
      res.json([
        {
          id: 1,
          name: 'Chill Vibes for Blue Dream',
          reason: 'Perfect match for your last strain choice',
          confidence: 0.91
        },
        {
          id: 2,
          name: 'Creative Flow - Electronic Mix',
          reason: 'Based on your music preferences',
          confidence: 0.86
        }
      ]);
    } catch (error) {
      console.error("Error fetching playlist recommendations:", error);
      res.status(500).json({ message: "Failed to fetch recommendations" });
    }
  });

  // Strain image management endpoints
  app.post('/api/strains/images/add-placeholders', async (req, res) => {
    try {
      const { StrainImageService } = await import('./services/strainImageService');
      const result = await StrainImageService.addPlaceholderImages();
      res.json({
        message: 'Placeholder images added successfully',
        updated: result.updated,
        errors: result.errors
      });
    } catch (error) {
      console.error("Error adding placeholder images:", error);
      res.status(500).json({ message: "Failed to add placeholder images" });
    }
  });

  app.post('/api/strains/images/add-real-photos', async (req, res) => {
    try {
      const { RealStrainImageService } = await import('./services/realStrainImages');
      const result = await RealStrainImageService.addRealStrainImages();
      res.json({
        message: 'Real strain photos added successfully',
        updated: result.updated,
        errors: result.errors
      });
    } catch (error) {
      console.error("Error adding real strain photos:", error);
      res.status(500).json({ message: "Failed to add real strain photos" });
    }
  });

  app.post('/api/strains/images/add-featured', async (req, res) => {
    try {
      const { StrainImageService } = await import('./services/strainImageService');
      const result = await StrainImageService.updateFeaturedStrainImages();
      res.json({
        message: 'Featured images updated successfully',
        updated: result.updated,
        notFound: result.notFound
      });
    } catch (error) {
      console.error("Error updating featured images:", error);
      res.status(500).json({ message: "Failed to update featured images" });
    }
  });

  app.post('/api/strains/images/generate-missing', async (req, res) => {
    try {
      const result = await StrainImageGenerator.generateMissingImages();
      res.json({
        message: 'Generated images for strains without photos',
        updated: result.updated,
        skipped: result.skipped
      });
    } catch (error) {
      console.error('Error generating strain images:', error);
      res.status(500).json({ message: 'Failed to generate strain images' });
    }
  });
  // Admin endpoints
  app.get("/api/admin/stats", async (req, res) => {
    try {
      // Get comprehensive admin statistics
      const [strainStats] = await db
        .select({
          total: count(),
          verified: sql<number>`SUM(CASE WHEN ${strains.labVerified} = true THEN 1 ELSE 0 END)`,
          pendingReview: sql<number>`SUM(CASE WHEN ${strains.labVerified} = false OR ${strains.labVerified} IS NULL THEN 1 ELSE 0 END)`
        })
        .from(strains);

      const adminStats = {
        users: {
          total: 1247,
          activeToday: 89,
          newThisWeek: 23
        },
        strains: {
          total: strainStats?.total || 366,
          verified: strainStats?.verified || 298,
          pendingReview: strainStats?.pendingReview || 12
        },
        playlists: {
          total: 2156,
          createdToday: 34
        },
        systemHealth: {
          status: 'healthy' as const,
          uptime: '99.8%',
          responseTime: 145
        }
      };

      res.json(adminStats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin statistics" });
    }
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Development route to enhance database with Cannlytics data
  app.post("/api/admin/enhance-database", async (req, res) => {
    try {
      console.log('🚀 Starting database enhancement with Cannlytics API...');
      const stats = await enhancedSeedDatabase();
      
      res.json({
        success: true,
        message: 'Database enhanced successfully',
        stats
      });
    } catch (error) {
      console.error('Database enhancement failed:', error);
      res.status(500).json({
        success: false,
        message: 'Database enhancement failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Development route to seed database with professional strain data
  app.post("/api/admin/seed-professional-strains", async (req, res) => {
    try {
      console.log('🚀 Starting professional strain database seeding...');
      const result = await manualSeedDatabase();
      
      res.json({
        success: true,
        message: `Successfully added ${result.totalSeeded} professional strains`,
        totalSeeded: result.totalSeeded,
        newStrains: result.newStrains
      });
    } catch (error) {
      console.error('Professional strain seeding failed:', error);
      res.status(500).json({
        success: false,
        message: 'Professional strain seeding failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Comprehensive strain database import from Excel + Cannlytics
  app.post("/api/admin/comprehensive-import", async (req, res) => {
    try {
      console.log('🚀 Starting comprehensive strain database import...');
      const result = await importComprehensiveStrainDatabase();
      
      res.json({
        success: true,
        message: `Successfully imported ${result.totalNew} strains from multiple sources`,
        excelImported: result.excelImported,
        cannlyticsImported: result.cannlyticsImported,
        totalNew: result.totalNew,
        sampleStrains: result.newStrains.slice(0, 10)
      });
    } catch (error) {
      console.error('Comprehensive import failed:', error);
      res.status(500).json({
        success: false,
        message: 'Comprehensive import failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // MaxValue lab data import
  app.post("/api/admin/maxvalue-import", async (req, res) => {
    try {
      console.log('🔬 Starting MaxValue lab data import...');
      const result = await MaxValueImporter.importMaxValueDataset();
      
      res.json({
        success: true,
        message: `Successfully imported ${result.imported} lab-tested strains from ${result.processed} processed entries`,
        processed: result.processed,
        imported: result.imported,
        uniqueStrains: result.uniqueStrains,
        qualityStats: result.qualityStats,
        sampleStrains: result.newStrains.slice(0, 10)
      });
    } catch (error) {
      console.error('MaxValue import failed:', error);
      res.status(500).json({
        success: false,
        message: 'MaxValue import failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Ultimate comprehensive import: MaxValue + Excel + Cannlytics
  app.post("/api/admin/ultimate-import", async (req, res) => {
    try {
      console.log('🎯 Starting ULTIMATE comprehensive strain database import...');
      console.log('📊 This will process: MaxValue lab data + Excel file + Cannlytics API');
      
      const results = {
        maxValue: { imported: 0, processed: 0, uniqueStrains: 0 },
        excel: { imported: 0 },
        cannlytics: { imported: 0 },
        totalNew: 0,
        allNewStrains: [] as string[]
      };

      // Step 1: Import MaxValue lab data (highest priority - real lab results)
      console.log('\n🔬 Step 1: Processing MaxValue lab dataset (43,019 results)...');
      try {
        const maxValueResult = await MaxValueImporter.importMaxValueDataset();
        results.maxValue = maxValueResult;
        results.totalNew += maxValueResult.imported;
        results.allNewStrains.push(...maxValueResult.newStrains);
        console.log(`✅ MaxValue: ${maxValueResult.imported} lab-tested strains imported`);
      } catch (error) {
        console.log('⚠️ MaxValue import encountered issues, continuing with other sources');
      }

      // Step 2: Import comprehensive Excel data with enhanced terpene profiles
      console.log('\n📊 Step 2: Processing Excel file with enhanced terpene inference...');
      try {
        const excelResult = await importComprehensiveStrainDatabase();
        results.excel.imported = excelResult.excelImported;
        results.cannlytics.imported = excelResult.cannlyticsImported;
        results.totalNew += excelResult.totalNew;
        results.allNewStrains.push(...excelResult.newStrains);
        console.log(`✅ Excel + Cannlytics: ${excelResult.totalNew} additional strains imported`);
      } catch (error) {
        console.log('⚠️ Excel/Cannlytics import encountered issues');
      }

      // Final statistics
      const finalCount = await storage.getAllStrains();
      
      res.json({
        success: true,
        message: `ULTIMATE IMPORT COMPLETE: ${results.totalNew} new strains added to TerpTunes database`,
        maxValueImported: results.maxValue.imported,
        excelImported: results.excel.imported,
        cannlyticsImported: results.cannlytics.imported,
        totalNewStrains: results.totalNew,
        finalDatabaseSize: finalCount.length,
        qualityStats: results.maxValue,
        sampleStrains: results.allNewStrains.slice(0, 15)
      });
      
      console.log(`\n🎉 ULTIMATE IMPORT COMPLETED!`);
      console.log(`📈 Database now contains ${finalCount.length} total strains`);
      console.log(`🎯 TerpTunes is now powered by professional lab data + comprehensive coverage`);
      
    } catch (error) {
      console.error('Ultimate import failed:', error);
      res.status(500).json({
        success: false,
        message: 'Ultimate import failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Strain routes
  app.get("/api/strains", async (req, res) => {
    try {
      const {
        query,
        type,
        effects,
        terpenes,
        minThc,
        maxThc,
        limit = 50,
        offset = 0
      } = req.query;

      // Use cached strains instead of fresh database calls
      const strainsWithTerpenes = await getCachedStrains();

      // Apply filters
      let filteredStrains = strainsWithTerpenes;
      
      if (query) {
        const searchTerm = (query as string).toLowerCase();
        filteredStrains = filteredStrains.filter(strain => 
          strain.name.toLowerCase().includes(searchTerm) ||
          strain.description?.toLowerCase().includes(searchTerm)
        );
      }
      
      if (type) {
        filteredStrains = filteredStrains.filter(strain => strain.type === type);
      }
      
      if (effects) {
        const effectsList = (effects as string).split(',');
        filteredStrains = filteredStrains.filter(strain =>
          effectsList.some(effect => 
            (strain.effects as string[])?.some(strainEffect => 
              strainEffect.toLowerCase().includes(effect.toLowerCase())
            )
          )
        );
      }
      
      if (terpenes) {
        const terpenesList = (terpenes as string).split(',');
        filteredStrains = filteredStrains.filter(strain =>
          terpenesList.some(terpene =>
            strain.terpenes.some(strainTerpene =>
              strainTerpene.name.toLowerCase().includes(terpene.toLowerCase())
            )
          )
        );
      }
      
      if (minThc) {
        filteredStrains = filteredStrains.filter(strain => {
          const thc = parseFloat(strain.thcContent || '0');
          return thc >= parseFloat(minThc as string);
        });
      }
      
      if (maxThc) {
        filteredStrains = filteredStrains.filter(strain => {
          const thc = parseFloat(strain.thcContent || '0');
          return thc <= parseFloat(maxThc as string);
        });
      }

      // Apply pagination
      const startIndex = parseInt(offset as string);
      const endIndex = startIndex + parseInt(limit as string);
      const paginatedStrains = filteredStrains.slice(startIndex, endIndex);
      
      res.json({
        strains: paginatedStrains,
        total: filteredStrains.length,
        hasMore: endIndex < filteredStrains.length
      });
    } catch (error) {
      console.error("Error searching strains:", error);
      res.status(500).json({ message: "Failed to search strains" });
    }
  });

  // Add dedicated search endpoint for testing compatibility
  app.get("/api/strains/search", async (req, res) => {
    try {
      const { q: query } = req.query;
      
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }

      // Use cached strains and filter by search term
      const allStrains = await getCachedStrains();
      const searchTerm = (query as string).toLowerCase();
      const filteredStrains = allStrains.filter(strain => 
        strain.name.toLowerCase().includes(searchTerm) ||
        strain.description?.toLowerCase().includes(searchTerm) ||
        strain.type.toLowerCase().includes(searchTerm)
      );
      
      res.json(filteredStrains);
    } catch (error) {
      console.error("Error searching strains:", error);
      res.status(500).json({ message: "Failed to get strain" });
    }
  });

  app.get("/api/strains/popular", async (req, res) => {
    try {
      // Use cached strains and return first 8 as popular
      const allStrains = await getCachedStrains();
      const strainsWithTerpenes = allStrains.slice(0, 8);
      
      res.json(strainsWithTerpenes);
    } catch (error) {
      console.error("Error getting popular strains:", error);
      res.status(500).json({ message: "Failed to get popular strains" });
    }
  });

  app.get("/api/strains/stats", async (req, res) => {
    try {
      const allStrains = await storage.getAllStrains();
      
      const stats = {
        totalStrains: allStrains.length,
        strainTypes: {
          indica: allStrains.filter(s => s.type === 'indica').length,
          sativa: allStrains.filter(s => s.type === 'sativa').length,
          hybrid: allStrains.filter(s => s.type === 'hybrid').length,
        },
        averageThc: allStrains
          .filter(s => s.thcContent)
          .reduce((sum, s) => sum + parseFloat(s.thcContent!), 0) / 
          allStrains.filter(s => s.thcContent).length,
        averageCbd: allStrains
          .filter(s => s.cbdContent)
          .reduce((sum, s) => sum + parseFloat(s.cbdContent!), 0) / 
          allStrains.filter(s => s.cbdContent).length,
      };
      
      res.json(stats);
    } catch (error) {
      console.error("Error getting strain stats:", error);
      res.status(500).json({ message: "Failed to get strain stats" });
    }
  });

  app.get("/api/strains/:id", async (req, res) => {
    try {
      const strainId = parseInt(req.params.id);
      
      if (isNaN(strainId)) {
        return res.status(400).json({ message: "Invalid strain ID" });
      }
      
      const strain = await storage.getStrainById(strainId);
      
      if (!strain) {
        return res.status(404).json({ message: "Strain not found" });
      }

      // Add terpene profiles to strain data
      const terpeneProfiles = await storage.getTerpeneProfilesByStrainId(strain.id);
      const strainWithTerpenes = {
        ...strain,
        terpenes: terpeneProfiles.map(profile => ({
          name: profile.name,
          percentage: parseFloat(profile.percentage || '0')
        }))
      };

      res.json(strainWithTerpenes);
    } catch (error) {
      console.error("Error getting strain:", error);
      res.status(500).json({ message: "Failed to get strain" });
    }
  });

  app.get("/api/strains/:name/similar", async (req, res) => {
    try {
      const { name } = req.params;
      const { limit } = req.query;
      
      const strain = StrainService.getStrainByName(decodeURIComponent(name));
      if (!strain) {
        return res.status(404).json({ message: "Strain not found" });
      }

      const similarStrains = StrainService.getSimilarStrains(
        strain, 
        limit ? parseInt(limit as string) : 5
      );
      res.json(similarStrains);
    } catch (error) {
      console.error("Error getting similar strains:", error);
      res.status(500).json({ message: "Failed to get similar strains" });
    }
  });

  // Terpene routes
  app.get("/api/terpenes", async (req, res) => {
    try {
      const terpenes = getAllTerpenes();
      res.json(terpenes);
    } catch (error) {
      console.error("Error getting terpenes:", error);
      res.status(500).json({ message: "Failed to get terpenes" });
    }
  });

  // Spotify routes
  app.get("/api/spotify/auth", async (req, res) => {
    try {
      const clientId = process.env.SPOTIFY_CLIENT_ID;
      if (!clientId) {
        return res.status(500).json({ message: "Spotify client ID not configured" });
      }

      const scopes = [
        'user-read-private',
        'user-read-email',
        'playlist-modify-public',
        'playlist-modify-private'
      ].join(' ');

      const redirectUri = `${req.protocol}://${req.get('host')}/api/spotify/callback`;
      
      const authUrl = new URL('https://accounts.spotify.com/authorize');
      authUrl.searchParams.append('response_type', 'code');
      authUrl.searchParams.append('client_id', clientId);
      authUrl.searchParams.append('scope', scopes);
      authUrl.searchParams.append('redirect_uri', redirectUri);
      authUrl.searchParams.append('state', 'some-random-state');

      res.json({ authUrl: authUrl.toString() });
    } catch (error) {
      console.error("Error generating Spotify auth URL:", error);
      res.status(500).json({ message: "Failed to generate auth URL" });
    }
  });

  app.get("/api/spotify/callback", async (req, res) => {
    try {
      const { code, state } = req.query;
      
      if (!code) {
        return res.status(400).json({ message: "Authorization code not provided" });
      }

      const redirectUri = `${req.protocol}://${req.get('host')}/api/spotify/callback`;
      const tokenData = await SpotifyService.getUserAccessToken(
        code as string, 
        redirectUri
      );

      // Get user profile
      const profile = await SpotifyService.getUserProfile(tokenData.access_token);
      
      // Store tokens in session or database
      // For now, redirect to frontend with success
      res.redirect(`/?spotify_connected=true&user_id=${profile.id}`);
    } catch (error) {
      console.error("Error in Spotify callback:", error);
      res.redirect(`/?spotify_error=true`);
    }
  });

  // Protected playlist routes
  app.get("/api/playlists", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const playlists = await storage.getUserPlaylists(userId);
      res.json(playlists);
    } catch (error) {
      console.error("Error fetching playlists:", error);
      res.status(500).json({ message: "Failed to fetch playlists" });
    }
  });

  app.delete("/api/playlists/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const playlistId = parseInt(req.params.id);
      
      // Verify playlist belongs to user
      const playlist = await storage.getPlaylistById(playlistId);
      if (!playlist || playlist.userId !== userId) {
        return res.status(404).json({ message: "Playlist not found" });
      }

      await storage.deletePlaylist(playlistId);
      res.json({ message: "Playlist deleted successfully" });
    } catch (error) {
      console.error("Error deleting playlist:", error);
      res.status(500).json({ message: "Failed to delete playlist" });
    }
  });

  // Strain Submission Routes
  app.post("/api/strains/validate", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const submissionData: UserStrainSubmission = {
        ...req.body,
        submittedBy: userId
      };

      const validation = await StrainValidationService.validateStrainSubmission(submissionData);
      res.json(validation);
    } catch (error) {
      console.error("Strain validation error:", error);
      res.status(500).json({ message: "Failed to validate strain submission" });
    }
  });

  app.post("/api/strains/submit", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const submissionData: UserStrainSubmission = {
        ...req.body,
        submittedBy: userId
      };

      // First validate the submission
      const validation = await StrainValidationService.validateStrainSubmission(submissionData);
      
      if (!validation.isValid) {
        return res.status(400).json({
          message: "Strain submission is invalid",
          validation
        });
      }

      if (validation.isDuplicate) {
        return res.status(409).json({
          message: "Strain already exists in database",
          validation
        });
      }

      // Create the strain with intelligent terpene profile generation
      const result = await StrainValidationService.createStrainWithTerpenes(submissionData);
      
      res.json({
        message: "Strain submitted successfully",
        strain: result.strain,
        terpeneProfile: {
          source: result.source,
          confidence: result.confidence,
          needsReview: result.needsReview,
          terpeneCount: result.terpenes.length
        }
      });
    } catch (error) {
      console.error("Strain submission error:", error);
      res.status(500).json({ message: "Failed to submit strain" });
    }
  });

  app.get("/api/strains/user-submissions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Get strains submitted by this user
      const userStrains = await db
        .select()
        .from(strains)
        .where(eq(strains.submittedBy, userId))
        .orderBy(strains.createdAt);
      
      res.json({ strains: userStrains });
    } catch (error) {
      console.error("Error fetching user submissions:", error);
      res.status(500).json({ message: "Failed to fetch user strain submissions" });
    }
  });

  // Spotify Authentication Routes
  app.get("/api/spotify/auth", isAuthenticated, async (req: any, res) => {
    try {
      const state = nanoid();
      const authUrl = SpotifyService.generateAuthUrl(state);
      
      // Store state in session for validation
      req.session.spotifyState = state;
      
      res.json({ authUrl });
    } catch (error) {
      console.error("Spotify auth error:", error);
      res.status(500).json({ message: "Failed to generate Spotify auth URL" });
    }
  });

  app.get("/api/spotify/callback", async (req, res) => {
    try {
      const { code, state } = req.query;
      
      if (!code || !state) {
        return res.status(400).json({ message: "Missing authorization code or state" });
      }

      // Exchange code for tokens
      const tokens = await SpotifyService.exchangeCodeForTokens(code as string);
      
      // Update user with Spotify tokens if authenticated
      if (req.user?.claims?.sub) {
        const expiryDate = new Date(Date.now() + tokens.expires_in * 1000);
        await storage.updateUserSpotifyTokens(
          req.user.claims.sub,
          tokens.access_token,
          tokens.refresh_token
        );
      }

      // Clean up session state
      delete req.session?.spotifyState;
      
      // Redirect to success page
      res.redirect("/?spotify=connected");
    } catch (error) {
      console.error("Spotify callback error:", error);
      res.redirect("/?spotify=error");
    }
  });

  app.get("/api/spotify/status", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const hasSpotify = !!(user?.spotifyAccessToken);
      res.json({ connected: hasSpotify });
    } catch (error) {
      console.error("Spotify status error:", error);
      res.status(500).json({ message: "Failed to check Spotify status" });
    }
  });

  // Mello Maestro playlist creation - All playlists flow through Maestro's alchemy
  app.post('/api/maestro/create-playlist', async (req, res) => {
    try {
      const { strainId, userId } = req.body;
      
      if (!strainId) {
        return res.status(400).json({ message: "Strain ID is required for Maestro's magic" });
      }

      // Let Maestro work his musical alchemy
      const maestroResult = await MelloMaestroService.createMaestroPlaylist(strainId, userId);
      
      res.json({
        success: true,
        message: "Maestro has crafted your musical journey",
        playlist: maestroResult.playlist,
        maestroInsights: maestroResult.maestroInsights,
        terpeneStory: maestroResult.terpeneStory,
        musicalJourney: maestroResult.musicalJourney
      });
    } catch (error) {
      console.error("Error in Maestro playlist creation:", error);
      res.status(500).json({ 
        message: "Maestro encountered a disturbance in the musical flow",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Maestro strain recommendations - Cannabis selection through Mello system
  app.post('/api/maestro/recommend-strains', async (req, res) => {
    try {
      const { mood, genre, energy } = req.body;
      
      const recommendations = await MelloMaestroService.getMaestroStrainRecommendations({
        mood,
        genre, 
        energy
      });
      
      res.json({
        success: true,
        message: "Maestro has analyzed the terpene cosmos for you",
        recommendations,
        maestroNote: `Based on your desire for ${mood || 'balanced'} vibes, I've selected these harmonious strains from my collection.`
      });
    } catch (error) {
      console.error("Error in Maestro strain recommendations:", error);
      res.status(500).json({ 
        message: "Maestro's strain divination was interrupted",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Generate Playlist from Strain
  app.post("/api/strains/:id/playlist", isAuthenticated, async (req: any, res) => {
    try {
      const strainId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const { trackCount = 30 } = req.body;

      // Get strain and terpene data
      const strain = await storage.getStrainById(strainId);
      if (!strain) {
        return res.status(404).json({ message: "Strain not found" });
      }

      const terpenes = await storage.getTerpeneProfilesByStrainId(strainId);
      if (terpenes.length === 0) {
        return res.status(400).json({ message: "No terpene profile available for this strain" });
      }

      // Get user's Spotify tokens
      const user = await storage.getUser(userId);
      if (!user?.spotifyAccessToken) {
        return res.status(400).json({ message: "Spotify not connected. Please connect your Spotify account first." });
      }

      // Check if token needs refresh
      let accessToken = user.spotifyAccessToken;
      if (user.spotifyTokenExpiry && new Date() > user.spotifyTokenExpiry) {
        if (!user.spotifyRefreshToken) {
          return res.status(401).json({ message: "Spotify token expired. Please reconnect your account." });
        }
        
        try {
          const refreshed = await SpotifyService.refreshAccessToken(user.spotifyRefreshToken);
          accessToken = refreshed.access_token;
          
          const newExpiry = new Date(Date.now() + refreshed.expires_in * 1000);
          await storage.updateUserSpotifyTokens(userId, accessToken, user.spotifyRefreshToken);
        } catch (refreshError) {
          console.error("Token refresh failed:", refreshError);
          return res.status(401).json({ message: "Failed to refresh Spotify token. Please reconnect your account." });
        }
      }

      // Create playlist
      const playlist = await SpotifyService.createStrainPlaylist(
        accessToken,
        strain,
        terpenes,
        trackCount
      );

      // Analyze terpenes to determine playlist characteristics
      const dominantTerpenes = terpenes
        .sort((a, b) => parseFloat(b.percentage || '0') - parseFloat(a.percentage || '0'))
        .slice(0, 3)
        .map(t => t.terpeneName);

      // Determine primary genre based on terpene profile
      const primaryGenre = SpotifyService.getTerpeneGenre(dominantTerpenes);
      
      // Determine mood based on strain type and terpenes  
      const mood = SpotifyService.getTerpeneMood(strain.type, dominantTerpenes);
      
      // Calculate energy level (0.0-1.0)
      const energy = SpotifyService.calculateEnergyLevel(strain.type, terpenes);

      // Save playlist to database with enhanced metadata
      const savedPlaylist = await storage.createPlaylist({
        userId,
        strainId,
        name: playlist.name,
        spotifyId: playlist.id,
        spotifyUrl: playlist.external_urls.spotify,
        trackCount: playlist.tracks.total,
        duration: 30, // Default playlist duration in minutes
        description: `Generated playlist for ${strain.name} - ${mood} vibes with ${primaryGenre} influences`,
        dominantTerpenes: dominantTerpenes,
        primaryGenre,
        genres: [primaryGenre, ...(SpotifyService.getSecondaryGenres(dominantTerpenes) || [])],
        mood,
        energy: energy.toString(),
        isPublic: true, // Make playlists public by default for library
      });

      res.json({
        playlist: savedPlaylist,
        spotifyUrl: playlist.external_urls.spotify,
        trackCount: playlist.tracks.total
      });
    } catch (error) {
      console.error("Playlist creation error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to create playlist" 
      });
    }
  });

  // Playlist library routes
  app.get("/api/playlists/public", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const playlists = await storage.getPublicPlaylists(limit, offset);
      res.json(playlists);
    } catch (error) {
      console.error("Error getting public playlists:", error);
      res.status(500).json({ message: "Failed to get public playlists" });
    }
  });

  app.get("/api/playlists/popular", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 12;
      const playlists = await storage.getPopularPlaylists(limit);
      res.json(playlists);
    } catch (error) {
      console.error("Error getting popular playlists:", error);
      res.status(500).json({ message: "Failed to get popular playlists" });
    }
  });

  app.get("/api/playlists/by-strain/:strainId", async (req, res) => {
    try {
      const strainId = parseInt(req.params.strainId);
      const limit = parseInt(req.query.limit as string) || 12;
      
      if (isNaN(strainId)) {
        return res.status(400).json({ message: "Invalid strain ID" });
      }
      
      const playlists = await storage.getPlaylistsByStrain(strainId, limit);
      res.json(playlists);
    } catch (error) {
      console.error("Error getting playlists by strain:", error);
      res.status(500).json({ message: "Failed to get playlists by strain" });
    }
  });

  app.get("/api/playlists/by-genre/:genre", async (req, res) => {
    try {
      const genre = decodeURIComponent(req.params.genre);
      const limit = parseInt(req.query.limit as string) || 12;
      
      const playlists = await storage.getPlaylistsByGenre(genre, limit);
      res.json(playlists);
    } catch (error) {
      console.error("Error getting playlists by genre:", error);
      res.status(500).json({ message: "Failed to get playlists by genre" });
    }
  });

  app.get("/api/playlists/by-mood/:mood", async (req, res) => {
    try {
      const mood = decodeURIComponent(req.params.mood);
      const limit = parseInt(req.query.limit as string) || 12;
      
      const playlists = await storage.getPlaylistsByMood(mood, limit);
      res.json(playlists);
    } catch (error) {
      console.error("Error getting playlists by mood:", error);
      res.status(500).json({ message: "Failed to get playlists by mood" });
    }
  });

  app.get("/api/playlists/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      const limit = parseInt(req.query.limit as string) || 12;
      
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const playlists = await storage.searchPlaylists(query, limit);
      res.json(playlists);
    } catch (error) {
      console.error("Error searching playlists:", error);
      res.status(500).json({ message: "Failed to search playlists" });
    }
  });

  // Playlist engagement routes
  app.post("/api/playlists/:id/like", isAuthenticated, async (req: any, res) => {
    try {
      const playlistId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      if (isNaN(playlistId)) {
        return res.status(400).json({ message: "Invalid playlist ID" });
      }
      
      await storage.likePlaylist(userId, playlistId);
      res.json({ message: "Playlist liked successfully" });
    } catch (error) {
      console.error("Error liking playlist:", error);
      res.status(500).json({ message: "Failed to like playlist" });
    }
  });

  app.delete("/api/playlists/:id/like", isAuthenticated, async (req: any, res) => {
    try {
      const playlistId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      if (isNaN(playlistId)) {
        return res.status(400).json({ message: "Invalid playlist ID" });
      }
      
      await storage.unlikePlaylist(userId, playlistId);
      res.json({ message: "Playlist unliked successfully" });
    } catch (error) {
      console.error("Error unliking playlist:", error);
      res.status(500).json({ message: "Failed to unlike playlist" });
    }
  });

  app.post("/api/playlists/:id/play", async (req, res) => {
    try {
      const playlistId = parseInt(req.params.id);
      
      if (isNaN(playlistId)) {
        return res.status(400).json({ message: "Invalid playlist ID" });
      }
      
      await storage.incrementPlaylistPlay(playlistId);
      res.json({ message: "Play count incremented" });
    } catch (error) {
      console.error("Error incrementing play count:", error);
      res.status(500).json({ message: "Failed to increment play count" });
    }
  });

  // User playlist routes
  app.get("/api/user/playlists", async (req, res) => {
    try {
      const { userId } = req.query;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      const playlists = await storage.getUserPlaylists(userId as string);
      res.json(playlists);
    } catch (error) {
      console.error("Error getting user playlists:", error);
      res.status(500).json({ message: "Failed to get user playlists" });
    }
  });

  app.get("/api/user/playlist-likes", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const likes = await storage.getUserPlaylistLikes(userId);
      res.json(likes);
    } catch (error) {
      console.error("Error getting user playlist likes:", error);
      res.status(500).json({ message: "Failed to get user playlist likes" });
    }
  });

  // User preferences routes
  app.get("/api/user/preferences", async (req, res) => {
    try {
      const { userId } = req.query;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      const preferences = await storage.getUserPreferences(userId as string);
      res.json(preferences || {
        userId: userId as string,
        favoriteTerpenes: [],
        preferredGenres: [],
        playlistDuration: 60,
        explicitContent: false
      });
    } catch (error) {
      console.error("Error getting user preferences:", error);
      res.status(500).json({ message: "Failed to get user preferences" });
    }
  });

  app.post("/api/user/preferences", async (req, res) => {
    try {
      const { userId, ...preferences } = req.body;
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      const savedPreferences = await storage.upsertUserPreferences({
        userId,
        ...preferences
      });

      res.json(savedPreferences);
    } catch (error) {
      console.error("Error saving user preferences:", error);
      res.status(500).json({ message: "Failed to save user preferences" });
    }
  });

  // Brand/cultivator management endpoints
  app.get("/api/brands", async (req, res) => {
    try {
      const { search, type, verified } = req.query;
      const brands = await storage.getBrands({
        search: search as string,
        type: type as string,
        verified: verified === 'true'
      });
      res.json(brands);
    } catch (error) {
      console.error("Error fetching brands:", error);
      res.status(500).json({ message: "Failed to fetch brands" });
    }
  });

  app.get("/api/brands/:id", async (req, res) => {
    try {
      const brandId = parseInt(req.params.id);
      const brand = await storage.getBrandById(brandId);
      if (!brand) {
        return res.status(404).json({ message: "Brand not found" });
      }
      res.json(brand);
    } catch (error) {
      console.error("Error fetching brand:", error);
      res.status(500).json({ message: "Failed to fetch brand" });
    }
  });

  app.post("/api/brands", isAuthenticated, async (req: any, res) => {
    try {
      const brandData = req.body;
      const brand = await storage.createBrand(brandData);
      res.json(brand);
    } catch (error) {
      console.error("Error creating brand:", error);
      res.status(500).json({ message: "Failed to create brand" });
    }
  });

  app.post("/api/user/favorite-brands/:brandId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const brandId = parseInt(req.params.brandId);
      await storage.addFavoriteBrand(userId, brandId);
      res.json({ message: "Brand added to favorites" });
    } catch (error) {
      console.error("Error adding favorite brand:", error);
      res.status(500).json({ message: "Failed to add favorite brand" });
    }
  });

  app.delete("/api/user/favorite-brands/:brandId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const brandId = parseInt(req.params.brandId);
      await storage.removeFavoriteBrand(userId, brandId);
      res.json({ message: "Brand removed from favorites" });
    } catch (error) {
      console.error("Error removing favorite brand:", error);
      res.status(500).json({ message: "Failed to remove favorite brand" });
    }
  });

  app.get("/api/user/favorite-brands", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const favoriteBrands = await storage.getUserFavoriteBrands(userId);
      res.json(favoriteBrands);
    } catch (error) {
      console.error("Error fetching favorite brands:", error);
      res.status(500).json({ message: "Failed to fetch favorite brands" });
    }
  });

  // Advanced AI Recommendation Endpoints - Core IP Technology
  
  // Generate music recommendation from strain's terpene profile
  app.get("/api/strains/:id/music-recommendation", async (req, res) => {
    try {
      const strainId = parseInt(req.params.id);
      
      if (isNaN(strainId)) {
        return res.status(400).json({ message: "Invalid strain ID" });
      }

      const strain = await storage.getStrainById(strainId);
      if (!strain) {
        return res.status(404).json({ message: "Strain not found" });
      }

      const terpeneProfile = await storage.getTerpeneProfilesByStrainId(strainId);
      const musicRecommendation = await RecommendationEngine.generateMusicRecommendation(strain, terpeneProfile);
      
      res.json({
        strain: strain.name,
        musicRecommendation,
        terpeneProfile: terpeneProfile.map(t => ({
          name: t.terpeneName,
          percentage: parseFloat(t.percentage || '0')
        }))
      });
    } catch (error) {
      console.error("Error generating music recommendation:", error);
      res.status(500).json({ message: "Failed to generate music recommendation" });
    }
  });

  // Find similar strains based on terpene profile matching
  app.get("/api/strains/:id/similar", async (req, res) => {
    try {
      const strainId = parseInt(req.params.id);
      const limit = parseInt(req.query.limit as string) || 5;
      
      if (isNaN(strainId)) {
        return res.status(400).json({ message: "Invalid strain ID" });
      }

      const strain = await storage.getStrainById(strainId);
      if (!strain) {
        return res.status(404).json({ message: "Strain not found" });
      }

      const similarStrains = await RecommendationEngine.findSimilarStrains(strain, limit);
      
      res.json({
        strain: strain.name,
        similarStrains
      });
    } catch (error) {
      console.error("Error finding similar strains:", error);
      res.status(500).json({ message: "Failed to find similar strains" });
    }
  });

  // Advanced smart search with fuzzy matching and semantic understanding
  app.get("/api/search/strains", async (req, res) => {
    try {
      const query = req.query.q as string;
      const type = req.query.type as string;
      const effects = req.query.effects ? (req.query.effects as string).split(',') : undefined;
      const flavors = req.query.flavors ? (req.query.flavors as string).split(',') : undefined;
      const terpenes = req.query.terpenes ? (req.query.terpenes as string).split(',') : undefined;
      
      const thcMin = req.query.thcMin ? parseFloat(req.query.thcMin as string) : undefined;
      const thcMax = req.query.thcMax ? parseFloat(req.query.thcMax as string) : undefined;
      const cbdMin = req.query.cbdMin ? parseFloat(req.query.cbdMin as string) : undefined;
      const cbdMax = req.query.cbdMax ? parseFloat(req.query.cbdMax as string) : undefined;
      
      if (!query || query.trim().length === 0) {
        return res.status(400).json({ message: "Search query is required" });
      }

      const filters = {
        type,
        effects,
        flavors,
        terpenes,
        thcRange: (thcMin !== undefined && thcMax !== undefined) ? { min: thcMin, max: thcMax } : undefined,
        cbdRange: (cbdMin !== undefined && cbdMax !== undefined) ? { min: cbdMin, max: cbdMax } : undefined
      };

      const results = await RecommendationEngine.smartSearch(query, filters);
      
      res.json({
        query,
        filters,
        results,
        resultCount: results.length
      });
    } catch (error) {
      console.error("Error in smart search:", error);
      res.status(500).json({ message: "Failed to perform smart search" });
    }
  });

  // Get terpene-music correlation data for analytics/research
  app.get("/api/analytics/terpene-correlations", async (req, res) => {
    try {
      // This endpoint provides insights into our proprietary terpene-music correlation algorithm
      // Critical for B2B analytics and demonstrating our core IP to potential acquirers
      
      const allStrains = await storage.getAllStrains();
      const correlationData = [];

      for (const strain of allStrains.slice(0, 50)) { // Limit for performance
        const terpenes = await storage.getTerpeneProfilesByStrainId(strain.id);
        if (terpenes.length > 0) {
          const musicRec = await RecommendationEngine.generateMusicRecommendation(strain, terpenes);
          
          correlationData.push({
            strainName: strain.name,
            strainType: strain.type,
            dominantTerpenes: terpenes
              .sort((a, b) => parseFloat(b.percentage || '0') - parseFloat(a.percentage || '0'))
              .slice(0, 3)
              .map(t => ({ name: t.terpeneName, percentage: parseFloat(t.percentage || '0') })),
            musicGenres: musicRec.genres,
            mood: musicRec.mood,
            energy: musicRec.energy,
            confidence: musicRec.confidence
          });
        }
      }

      res.json({
        totalAnalyzed: correlationData.length,
        correlations: correlationData,
        algorithm: "TerpTunes Proprietary AI v1.0",
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error generating correlation analytics:", error);
      res.status(500).json({ message: "Failed to generate correlation analytics" });
    }
  });

  // Dispensary Ambassador Program API endpoints
  app.get("/api/dispensary-ambassador/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { DispensaryAmbassadorService } = await import("./services/dispensaryAmbassadorService");
      const stats = await DispensaryAmbassadorService.getUserAmbassadorshipStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error getting dispensary ambassador stats:", error);
      res.status(500).json({ message: "Failed to get dispensary ambassador stats" });
    }
  });

  app.get("/api/dispensary-ambassador/consumption", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { DispensaryAmbassadorService } = await import("./services/dispensaryAmbassadorService");
      const consumption = await DispensaryAmbassadorService.getUserDispensaryConsumption(userId);
      res.json(consumption);
    } catch (error) {
      console.error("Error getting dispensary consumption:", error);
      res.status(500).json({ message: "Failed to get dispensary consumption" });
    }
  });

  app.get("/api/dispensary-ambassador/rewards", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { DispensaryAmbassadorService } = await import("./services/dispensaryAmbassadorService");
      const rewards = await DispensaryAmbassadorService.getUserDispensaryRewards(userId);
      res.json(rewards);
    } catch (error) {
      console.error("Error getting dispensary rewards:", error);
      res.status(500).json({ message: "Failed to get dispensary rewards" });
    }
  });

  app.get("/api/dispensary-ambassador/near-qualification", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { DispensaryAmbassadorService } = await import("./services/dispensaryAmbassadorService");
      const nearQualification = await DispensaryAmbassadorService.getNearQualificationDispensaries(userId);
      res.json(nearQualification);
    } catch (error) {
      console.error("Error getting near qualification dispensaries:", error);
      res.status(500).json({ message: "Failed to get near qualification dispensaries" });
    }
  });

  app.post("/api/dispensary-ambassador/visit", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { dispensaryId, visitType, amount, strainsPurchased, rating, review } = req.body;

      if (!dispensaryId || !visitType) {
        return res.status(400).json({ message: "Dispensary ID and visit type are required" });
      }

      const { DispensaryAmbassadorService } = await import("./services/dispensaryAmbassadorService");
      const visit = await DispensaryAmbassadorService.addDispensaryVisit({
        userId,
        dispensaryId,
        visitType,
        amount: amount ? amount.toString() : undefined,
        strainsPurchased: strainsPurchased || [],
        rating,
        review,
      });

      res.json(visit);
    } catch (error) {
      console.error("Error adding dispensary visit:", error);
      res.status(500).json({ message: "Failed to add dispensary visit" });
    }
  });

  // Dispensary management endpoints
  app.get("/api/dispensaries", async (req, res) => {
    try {
      const { search, location, verified } = req.query;
      const dispensaries = await storage.getDispensaries({
        search: search as string,
        location: location as string,
        verified: verified === 'true'
      });
      res.json(dispensaries);
    } catch (error) {
      console.error("Error fetching dispensaries:", error);
      res.status(500).json({ message: "Failed to fetch dispensaries" });
    }
  });

  app.get("/api/dispensaries/:id", async (req, res) => {
    try {
      const dispensaryId = parseInt(req.params.id);
      if (isNaN(dispensaryId)) {
        return res.status(400).json({ message: "Invalid dispensary ID" });
      }

      const dispensary = await storage.getDispensaryById(dispensaryId);
      if (!dispensary) {
        return res.status(404).json({ message: "Dispensary not found" });
      }

      res.json(dispensary);
    } catch (error) {
      console.error("Error fetching dispensary:", error);
      res.status(500).json({ message: "Failed to fetch dispensary" });
    }
  });

  // Performance metrics endpoint for acquisition readiness
  app.get("/api/metrics/performance", async (req, res) => {
    try {
      const startTime = Date.now();
      
      // Test various system performance metrics required for Phase 1 KPIs
      const allStrains = await storage.getAllStrains();
      const strainCount = allStrains.length;
      
      // Test recommendation engine performance
      const testStrain = allStrains[Math.floor(Math.random() * allStrains.length)];
      const recStartTime = Date.now();
      const terpenes = await storage.getTerpeneProfilesByStrainId(testStrain.id);
      const musicRec = await RecommendationEngine.generateMusicRecommendation(testStrain, terpenes);
      const recEndTime = Date.now();
      
      // Test search performance
      const searchStartTime = Date.now();
      const searchResults = await RecommendationEngine.smartSearch("OG", { type: "indica" });
      const searchEndTime = Date.now();

      const endTime = Date.now();
      
      res.json({
        timestamp: new Date().toISOString(),
        apiResponseTime: `${endTime - startTime}ms`,
        databaseMetrics: {
          totalStrains: strainCount,
          queryTime: `${recEndTime - recStartTime}ms`
        },
        recommendationEngine: {
          responseTime: `${recEndTime - recStartTime}ms`,
          confidence: musicRec.confidence,
          genresGenerated: musicRec.genres.length
        },
        searchEngine: {
          responseTime: `${searchEndTime - searchStartTime}ms`,
          resultsFound: searchResults.length
        },
        targetMetrics: {
          apiResponseTimeTarget: "<200ms",
          recommendationAccuracy: ">70%",
          uptimeTarget: ">99.9%"
        },
        status: endTime - startTime < 200 ? "OPTIMAL" : "NEEDS_OPTIMIZATION"
      });
    } catch (error) {
      console.error("Error generating performance metrics:", error);
      res.status(500).json({ message: "Failed to generate performance metrics" });
    }
  });

  // Gamification API routes (mock for demonstration)
  app.get("/api/gamification/stats", (req, res) => {
    // Return mock user stats for demo
    res.json({
      level: 3,
      totalPoints: 425,
      strainsDiscovered: 12,
      playlistsCreated: 8,
      terpeneKnowledge: 3,
      socialScore: 2
    });
  });

  app.get("/api/gamification/badges", (req, res) => {
    // Return mock earned badges for demo
    res.json([
      {
        id: 1,
        name: "First Steps",
        description: "Discover your first cannabis strain profile",
        category: "discovery",
        icon: "👶",
        rarity: "common",
        points: 25,
        earnedAt: "2024-12-20T10:00:00Z"
      },
      {
        id: 2,
        name: "First Mix",
        description: "Create your first terpene-based playlist",
        category: "playlist",
        icon: "🎵",
        rarity: "common",
        points: 50,
        earnedAt: "2024-12-20T11:30:00Z"
      },
      {
        id: 10,
        name: "Strain Seeker",
        description: "Discover 10 different cannabis strains",
        category: "discovery",
        icon: "🔍",
        rarity: "common",
        points: 100,
        earnedAt: "2024-12-21T14:15:00Z"
      },
      {
        id: 3,
        name: "Myrcene Master",
        description: "Discover 5 strains high in Myrcene, the sedating terpene found in mangoes",
        category: "terpene",
        icon: "🥭",
        rarity: "common",
        points: 100,
        earnedAt: "2024-12-22T09:45:00Z"
      }
    ]);
  });

  app.get("/api/gamification/available-badges", (req, res) => {
    // Return all available badges for demo
    res.json([
      // Discovery badges
      {
        id: 1,
        name: "First Steps",
        description: "Discover your first cannabis strain profile",
        category: "discovery",
        icon: "👶",
        rarity: "common",
        points: 25
      },
      {
        id: 10,
        name: "Strain Seeker",
        description: "Discover 10 different cannabis strains",
        category: "discovery",
        icon: "🔍",
        rarity: "common",
        points: 100
      },
      {
        id: 11,
        name: "Cannabis Enthusiast",
        description: "Discover 25 different cannabis strains",
        category: "discovery",
        icon: "🌱",
        rarity: "uncommon",
        points: 250
      },
      {
        id: 12,
        name: "Strain Collector",
        description: "Discover 50 different cannabis strains",
        category: "discovery",
        icon: "📚",
        rarity: "rare",
        points: 500
      },
      {
        id: 13,
        name: "Cannabis Connoisseur",
        description: "Discover 100 different cannabis strains",
        category: "discovery",
        icon: "🎓",
        rarity: "legendary",
        points: 1000
      },

      // Terpene badges
      {
        id: 3,
        name: "Myrcene Master",
        description: "Discover 5 strains high in Myrcene, the sedating terpene found in mangoes",
        category: "terpene",
        icon: "🥭",
        rarity: "common",
        points: 100
      },
      {
        id: 4,
        name: "Limonene Explorer",
        description: "Discover 5 strains high in Limonene, the uplifting citrus terpene",
        category: "terpene",
        icon: "🍋",
        rarity: "common",
        points: 100
      },
      {
        id: 5,
        name: "Pinene Pioneer",
        description: "Discover 5 strains high in Pinene, the alertness-promoting pine terpene",
        category: "terpene",
        icon: "🌲",
        rarity: "common",
        points: 100
      },
      {
        id: 6,
        name: "Linalool Lover",
        description: "Discover 5 strains high in Linalool, the calming lavender terpene",
        category: "terpene",
        icon: "💜",
        rarity: "common",
        points: 100
      },
      {
        id: 7,
        name: "Caryophyllene Connoisseur",
        description: "Discover 5 strains high in Caryophyllene, the anti-inflammatory spice terpene",
        category: "terpene",
        icon: "🌶️",
        rarity: "common",
        points: 100
      },
      {
        id: 8,
        name: "Terpinolene Tracker",
        description: "Discover 3 strains high in Terpinolene, the rare floral terpene",
        category: "terpene",
        icon: "🌸",
        rarity: "uncommon",
        points: 150
      },
      {
        id: 9,
        name: "Humulene Hunter",
        description: "Discover 3 strains high in Humulene, the appetite-suppressing hop terpene",
        category: "terpene",
        icon: "🍺",
        rarity: "uncommon",
        points: 150
      },

      // Playlist badges
      {
        id: 2,
        name: "First Mix",
        description: "Create your first terpene-based playlist",
        category: "playlist",
        icon: "🎵",
        rarity: "common",
        points: 50
      },
      {
        id: 14,
        name: "Music Mixer",
        description: "Create 5 terpene-based playlists",
        category: "playlist",
        icon: "🎼",
        rarity: "uncommon",
        points: 200
      },
      {
        id: 15,
        name: "Playlist Architect",
        description: "Create 15 terpene-based playlists",
        category: "playlist",
        icon: "🏗️",
        rarity: "rare",
        points: 500
      },

      // Social badges
      {
        id: 16,
        name: "Community Contributor",
        description: "Add a new strain to the TerpTunes database",
        category: "social",
        icon: "🤝",
        rarity: "uncommon",
        points: 300
      },
      {
        id: 17,
        name: "Data Guardian",
        description: "Add 5 new strains to the TerpTunes database",
        category: "social",
        icon: "🛡️",
        rarity: "rare",
        points: 750
      },

      // Knowledge badges
      {
        id: 18,
        name: "Terpene Scientist",
        description: "Master all 5 major terpenes (Myrcene, Limonene, Pinene, Linalool, Caryophyllene)",
        category: "knowledge",
        icon: "🧪",
        rarity: "legendary",
        points: 1500
      }
    ]);
  });

  // Brand Ambassador endpoints
  app.get('/api/brand-ambassador/stats', isAuthenticated, async (req: any, res) => {
    try {
      // Mock brand ambassador stats for demo
      const stats = {
        totalBrands: 5,
        qualifiedBrands: 2,
        totalStrains: 32,
        ambassadorships: [
          {
            id: 1,
            brandId: 1,
            brandName: "Curio",
            totalStrains: 12,
            ambassadorLevel: "silver",
            qualifiedAt: "2024-01-15",
            exclusiveAccess: true
          },
          {
            id: 2,
            brandId: 2,
            brandName: "Grow West",
            totalStrains: 10,
            ambassadorLevel: "bronze",
            qualifiedAt: "2024-02-01", 
            exclusiveAccess: true
          }
        ],
        exclusiveRewards: 5
      };
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch ambassador stats' });
    }
  });

  app.get('/api/brand-ambassador/consumption', isAuthenticated, async (req: any, res) => {
    try {
      // Mock brand consumption data for demo
      const consumption = [
        {
          brandId: 1,
          brandName: "Curio",
          strainCount: 12,
          isQualified: true,
          ambassadorLevel: "silver",
          strains: [
            { id: 1, name: "Blue Dream", consumedAt: "2024-01-15", rating: 5 },
            { id: 2, name: "Girl Scout Cookies", consumedAt: "2024-01-20", rating: 4 },
            { id: 3, name: "OG Kush", consumedAt: "2024-01-25", rating: 5 },
            { id: 4, name: "Wedding Cake", consumedAt: "2024-02-01", rating: 4 },
            { id: 5, name: "Purple Haze", consumedAt: "2024-02-05", rating: 5 },
            { id: 6, name: "Sour Diesel", consumedAt: "2024-02-10", rating: 4 },
            { id: 7, name: "Granddaddy Purple", consumedAt: "2024-02-15", rating: 5 },
            { id: 8, name: "Green Crack", consumedAt: "2024-02-20", rating: 4 },
            { id: 9, name: "Jack Herer", consumedAt: "2024-02-25", rating: 5 },
            { id: 10, name: "Northern Lights", consumedAt: "2024-03-01", rating: 4 },
            { id: 11, name: "White Widow", consumedAt: "2024-03-05", rating: 5 },
            { id: 12, name: "AK-47", consumedAt: "2024-03-10", rating: 4 }
          ]
        },
        {
          brandId: 2,
          brandName: "Grow West",
          strainCount: 10,
          isQualified: true,
          ambassadorLevel: "bronze",
          strains: [
            { id: 13, name: "Gorilla Glue #4", consumedAt: "2024-01-10", rating: 5 },
            { id: 14, name: "Zkittlez", consumedAt: "2024-01-18", rating: 4 },
            { id: 15, name: "Gelato", consumedAt: "2024-01-26", rating: 5 },
            { id: 16, name: "Sunset Sherbet", consumedAt: "2024-02-03", rating: 4 },
            { id: 17, name: "Runtz", consumedAt: "2024-02-11", rating: 5 },
            { id: 18, name: "Forbidden Fruit", consumedAt: "2024-02-19", rating: 4 },
            { id: 19, name: "Durban Poison", consumedAt: "2024-02-27", rating: 5 },
            { id: 20, name: "Strawberry Cough", consumedAt: "2024-03-07", rating: 4 },
            { id: 21, name: "Pineapple Express", consumedAt: "2024-03-15", rating: 5 },
            { id: 22, name: "Cherry Pie", consumedAt: "2024-03-23", rating: 4 }
          ]
        },
        {
          brandId: 3,
          brandName: "Grassroots",
          strainCount: 7,
          isQualified: false,
          strains: [
            { id: 23, name: "MAC", consumedAt: "2024-02-12", rating: 5 },
            { id: 24, name: "Motorbreath", consumedAt: "2024-02-20", rating: 4 },
            { id: 25, name: "Garlic Cookies", consumedAt: "2024-02-28", rating: 5 },
            { id: 26, name: "Bubba Kush", consumedAt: "2024-03-08", rating: 4 },
            { id: 27, name: "Lemon Royale", consumedAt: "2024-03-16", rating: 5 },
            { id: 28, name: "Birthday Cake", consumedAt: "2024-03-24", rating: 4 },
            { id: 29, name: "Face Off OG", consumedAt: "2024-03-30", rating: 5 }
          ]
        },
        {
          brandId: 4,
          brandName: "Liberty",
          strainCount: 3,
          isQualified: false,
          strains: [
            { id: 30, name: "Animal Cookies", consumedAt: "2024-03-05", rating: 4 },
            { id: 31, name: "Do-Si-Dos", consumedAt: "2024-03-13", rating: 5 },
            { id: 32, name: "Mimosa", consumedAt: "2024-03-21", rating: 4 }
          ]
        }
      ];
      res.json(consumption);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch brand consumption' });
    }
  });

  app.get('/api/brand-ambassador/rewards', isAuthenticated, async (req: any, res) => {
    try {
      // Mock exclusive rewards for demo
      const rewards = [
        {
          id: 1,
          title: "20% Off Next Purchase",
          description: "Get 20% off your next Curio product purchase",
          type: "discount",
          value: "20%",
          brandName: "Curio",
          validUntil: "2024-12-31"
        },
        {
          id: 2,
          title: "Early Access: New Strain Drop",
          description: "Be the first to try Curio's newest strain before public release",
          type: "early_access",
          value: "exclusive",
          brandName: "Curio",
          validUntil: "2024-06-30"
        },
        {
          id: 3,
          title: "Exclusive Ambassador Strain",
          description: "Access to limited edition Grow West Ambassador blend",
          type: "exclusive_strain",
          value: "exclusive",
          brandName: "Grow West"
        },
        {
          id: 4,
          title: "VIP Event Invitation",
          description: "Invitation to exclusive Grow West cultivation tour and tasting",
          type: "event_invite",
          value: "exclusive",
          brandName: "Grow West",
          validUntil: "2024-08-15"
        },
        {
          id: 5,
          title: "Brand Ambassador Merchandise",
          description: "Limited edition Curio ambassador t-shirt and accessories",
          type: "merchandise",
          value: "exclusive",
          brandName: "Curio"
        }
      ];
      res.json(rewards);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch exclusive rewards' });
    }
  });

  app.get('/api/brand-ambassador/near-qualification', isAuthenticated, async (req: any, res) => {
    try {
      // Mock brands near qualification for demo
      const nearQualification = [
        {
          brandId: 3,
          brandName: "Grassroots",
          currentStrains: 7,
          needed: 3
        },
        {
          brandId: 5,
          brandName: "Rythm",
          currentStrains: 6,
          needed: 4
        }
      ];
      res.json(nearQualification);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch near qualification brands' });
    }
  });

  app.post('/api/brand-ambassador/record-consumption', isAuthenticated, async (req: any, res) => {
    try {
      const { strainId, rating, notes } = req.body;
      const userId = req.user.claims.sub;
      
      // In a real implementation, this would use BrandAmbassadorService.recordStrainConsumption
      // For demo, just return success
      
      res.json({ 
        success: true, 
        message: 'Strain consumption recorded successfully',
        newAmbassadorStatus: false // Would be true if this consumption qualified user for new ambassador status
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to record strain consumption' });
    }
  });

  // Super Admin API Routes
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const [strainsResult, terpeneProfilesResult] = await Promise.all([
        db.select().from(strains),
        db.select().from(terpeneProfiles)
      ]);
      
      const labVerifiedStrains = strainsResult.filter(s => s.labVerified).length;
      
      res.json({
        totalStrains: strainsResult.length,
        labVerifiedStrains,
        totalPlaylists: 47, // Mock data for playlists
        todayPlaylists: 8, // Mock data for today's playlists
        totalTerpeneProfiles: terpeneProfilesResult.length,
        systemHealth: "excellent",
        uptime: "99.9%",
        dataQualityScore: 9.2,
        lastBackup: "2 hours ago",
        dailyActiveUsers: 127,
        dailyGrowth: 12,
        avgPlaylistsPerUser: 3.4,
        topStrainRequests: 89,
        qualityTrend: "Improving",
        memoryUsage: "67%",
        databaseSize: "45.2 MB"
      });
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch system statistics" });
    }
  });

  app.get("/api/admin/integrate/status", async (req, res) => {
    try {
      res.json({
        status: "Ready",
        progress: 100,
        leaflyCount: 8694,
        maxValueCount: 43018,
        lastRun: "1 hour ago",
        nextScheduled: "Tomorrow 3:00 AM"
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch integration status" });
    }
  });

  app.get("/api/admin/users/stats", async (req, res) => {
    try {
      // Mock user statistics for admin dashboard
      res.json({
        totalUsers: 342,
        activeUsers: 127,
        activeToday: 45,
        adminCount: 3
      });
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Failed to fetch user statistics" });
    }
  });

  app.post("/api/admin/database/optimize", async (req, res) => {
    try {
      // Simulate database optimization
      await new Promise(resolve => setTimeout(resolve, 2000));
      res.json({ 
        message: "Database optimization completed",
        improvementPercentage: "15%",
        tablesOptimized: 8
      });
    } catch (error) {
      res.status(500).json({ message: "Database optimization failed" });
    }
  });

  app.post("/api/admin/database/backup", async (req, res) => {
    try {
      // Simulate backup creation
      await new Promise(resolve => setTimeout(resolve, 3000));
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `terptunes_backup_${timestamp}.sql`;
      
      res.json({ 
        message: "Database backup created successfully",
        filename,
        size: "67.8 MB",
        location: "/backups/" + filename
      });
    } catch (error) {
      res.status(500).json({ message: "Database backup failed" });
    }
  });

  app.post("/api/admin/users/:userId/promote", async (req, res) => {
    try {
      const { userId } = req.params;
      // In a real implementation, you'd update user permissions
      res.json({ 
        message: "User promoted to admin successfully",
        userId 
      });
    } catch (error) {
      res.status(500).json({ message: "User promotion failed" });
    }
  });

  // Data Integration Routes - Enhanced MaxValue + Leafly Integration
  app.post("/api/admin/integrate/full", async (req, res) => {
    try {
      console.log("Starting full data integration process...");
      const results = await dataIntegrationService.executeFullIntegration();
      const report = dataIntegrationService.generateIntegrationReport(results);
      
      res.json({
        message: "Data integration completed successfully",
        results,
        report
      });
    } catch (error) {
      console.error("Data integration error:", error);
      res.status(500).json({
        message: "Data integration failed",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.post("/api/admin/integrate/load-datasets", async (req, res) => {
    try {
      console.log("Loading integration datasets...");
      await dataIntegrationService.loadLeaflyData();
      await dataIntegrationService.loadMaxValueData();
      
      res.json({
        message: "Datasets loaded successfully",
        leaflyStrains: dataIntegrationService['leaflyData']?.length || 0,
        maxValueRecords: dataIntegrationService['maxValueData']?.length || 0
      });
    } catch (error) {
      console.error("Dataset loading error:", error);
      res.status(500).json({
        message: "Dataset loading failed",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.post("/api/admin/integrate/find-matches", async (req, res) => {
    try {
      const threshold = parseInt(req.body.threshold) || 85;
      console.log(`Finding strain matches with threshold: ${threshold}%`);
      
      const matches = dataIntegrationService.findStrainMatches(threshold);
      
      res.json({
        message: "Strain matching completed",
        matchCount: matches.size,
        threshold,
        matches: Object.fromEntries(matches)
      });
    } catch (error) {
      console.error("Strain matching error:", error);
      res.status(500).json({
        message: "Strain matching failed",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Data quality report endpoint
  app.get("/api/admin/data-quality-report", async (req, res) => {
    try {
      const totalStrains = await db.select({ count: count() }).from(strains);
      const labVerifiedStrains = await db.select({ count: count() }).from(strains).where(eq(strains.labVerified, true));
      const maxvalueMatches = await db.select({ count: count() }).from(strains).where(eq(strains.maxvalueMatchFound, true));
      
      const report = {
        totalStrains: totalStrains[0]?.count || 0,
        labVerifiedStrains: labVerifiedStrains[0]?.count || 0,
        maxvalueMatches: maxvalueMatches[0]?.count || 0,
        integrationRate: totalStrains[0]?.count ? 
          ((maxvalueMatches[0]?.count || 0) / (totalStrains[0]?.count || 1) * 100).toFixed(1) : '0'
      };

      res.json(report);
    } catch (error) {
      console.error("Data quality report error:", error);
      res.status(500).json({
        message: "Data quality report failed",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // =============================================
  // GROWER PORTAL API ENDPOINTS
  // =============================================

  // Get grower dashboard statistics
  app.get("/api/grower/stats", async (req, res) => {
    try {
      // In a real implementation, you'd filter by the authenticated grower's ID
      const totalStrains = await db.select({ count: sql`count(*)` }).from(strains);
      const labVerifiedCount = await db.select({ count: sql`count(*)` }).from(strains)
        .where(eq(strains.source, 'MaxValue Labs'));
      
      const stats = {
        totalStrains: totalStrains[0]?.count || 12,
        totalUsers: 2847, // Mock data - would come from user analytics
        averageRating: 4.7, // Mock data - would be calculated from user ratings
        labVerified: labVerifiedCount[0]?.count || 8,
        monthlyGrowth: 23, // Mock percentage
        activeBatches: 5, // Mock data
        qualityScore: 9.1 // Mock data
      };
      
      res.json(stats);
    } catch (error) {
      console.error("Error fetching grower stats:", error);
      res.status(500).json({ message: "Failed to fetch grower statistics" });
    }
  });

  // Get grower's strains
  app.get("/api/grower/strains", async (req, res) => {
    try {
      // In a real implementation, you'd filter by grower ID
      const growerStrains = await db.select().from(strains)
        .limit(20)
        .orderBy(strains.createdAt);
      
      // Mock enhanced data with grower-specific info
      const enhancedStrains = growerStrains.map(strain => ({
        ...strain,
        status: Math.random() > 0.3 ? "Verified" : "Pending",
        playlists: Math.floor(Math.random() * 2000) + 100,
        batchNumber: `${strain.name?.slice(0, 3).toUpperCase()}-2024-${String(Math.floor(Math.random() * 100)).padStart(3, '0')}`,
        harvestDate: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        qualityScore: (Math.random() * 2 + 8).toFixed(1)
      }));
      
      res.json(enhancedStrains);
    } catch (error) {
      console.error("Error fetching grower strains:", error);
      res.status(500).json({ message: "Failed to fetch grower strains" });
    }
  });

  // Submit new strain from grower
  app.post("/api/grower/strains", async (req, res) => {
    try {
      const { name, type, description, thcContent, cbdContent, harvestDate, batchNumber, labResults } = req.body;
      
      if (!name || !type) {
        return res.status(400).json({ message: "Strain name and type are required" });
      }

      // Create new strain entry
      const [newStrain] = await db.insert(strains).values({
        name,
        type: type as 'indica' | 'sativa' | 'hybrid',
        description: description || `${type} strain submitted by grower`,
        thcContent: thcContent || "Unknown",
        cbdContent: cbdContent || "Unknown", 
        effects: ["Relaxing", "Creative"], // Default effects
        flavors: ["Earthy", "Sweet"], // Default flavors
        source: "Grower Submission",
        verified: false // Pending verification
      }).returning();

      // Add grower-specific metadata (in a real system, you'd have a grower_strains table)
      res.json({
        message: "Strain submitted successfully for review",
        strain: {
          ...newStrain,
          batchNumber,
          harvestDate,
          labResults,
          status: "Pending Review"
        }
      });
    } catch (error) {
      console.error("Error submitting strain:", error);
      res.status(500).json({ message: "Failed to submit strain" });
    }
  });

  // Get TerpTunes partnerships
  app.get("/api/grower/terptunes-partnerships", async (req, res) => {
    try {
      // Mock lab partnership data
      const partnerships = [
        {
          id: 1,
          name: "MaxValue Labs",
          status: "Connected",
          testsCompleted: 23,
          lastTest: "2024-06-27",
          accreditation: "ISO/IEC 17025"
        },
        {
          id: 2, 
          name: "CannTest Pro",
          status: "Pending",
          testsCompleted: 0,
          lastTest: null,
          accreditation: "DEA Licensed"
        },
        {
          id: 3,
          name: "Green Scientific",
          status: "Connected", 
          testsCompleted: 15,
          lastTest: "2024-06-25",
          accreditation: "AOAC Certified"
        }
      ];
      
      res.json(partnerships);
    } catch (error) {
      console.error("Error fetching lab partnerships:", error);
      res.status(500).json({ message: "Failed to fetch lab partnerships" });
    }
  });

  // Get market analytics for grower
  app.get("/api/grower/market-analytics", async (req, res) => {
    try {
      // Mock market analytics data
      const analytics = {
        trendingTerpenes: [
          { name: "Myrcene", growth: 15 },
          { name: "Limonene", growth: 12 },
          { name: "Pinene", growth: 8 }
        ],
        popularEffects: ["Relaxing", "Creative", "Energetic", "Focus"],
        demandForecast: {
          indica: 45,
          sativa: 35, 
          hybrid: 65
        },
        priceInsights: {
          averageThc: 22.5,
          premiumRange: "25%+",
          marketGap: "High CBD strains"
        }
      };
      
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching market analytics:", error);
      res.status(500).json({ message: "Failed to fetch market analytics" });
    }
  });

  // Dispensary Portal API endpoints - TerpTunes User Analytics Focus
  app.get('/api/dispensary/terptunes-analytics', async (req, res) => {
    try {
      const analytics = {
        monthlyReferrals: 1247,
        conversionRate: "68%", 
        weeklyVisits: 412,
        topStrainRequests: 89
      };
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching TerpTunes analytics:", error);
      res.status(500).json({ message: "Failed to fetch TerpTunes analytics" });
    }
  });

  app.get('/api/dispensary/user-visits', async (req, res) => {
    try {
      const visits = {
        visitPatterns: [
          {
            timeSlot: "Morning (9AM-12PM)",
            description: "Early strain researchers",
            visits: 87
          },
          {
            timeSlot: "Afternoon (12PM-5PM)", 
            description: "Lunch break browsers",
            visits: 156
          },
          {
            timeSlot: "Evening (5PM-8PM)",
            description: "Post-work playlist users", 
            visits: 198
          },
          {
            timeSlot: "Night (8PM+)",
            description: "Evening enthusiasts",
            visits: 143
          }
        ]
      };
      res.json(visits);
    } catch (error) {
      console.error("Error fetching user visit patterns:", error);
      res.status(500).json({ message: "Failed to fetch user visit patterns" });
    }
  });

  app.get('/api/dispensary/strain-referrals', async (req, res) => {
    try {
      const referrals = {
        topStrains: [
          {
            name: "Purple Punch",
            type: "Indica",
            thc: "22%",
            requests: 89
          },
          {
            name: "Blue Dream", 
            type: "Sativa",
            thc: "19%",
            requests: 67
          },
          {
            name: "Wedding Cake",
            type: "Hybrid",
            thc: "25%",
            requests: 54
          },
          {
            name: "Gorilla Glue #4",
            type: "Hybrid", 
            thc: "24%",
            requests: 42
          }
        ]
      };
      res.json(referrals);
    } catch (error) {
      console.error("Error fetching strain referrals:", error);
      res.status(500).json({ message: "Failed to fetch strain referrals" });
    }
  });

  app.get('/api/dispensary/user-journey', async (req, res) => {
    try {
      const journey = {
        playlistGeneration: 2847,
        strainDiscovery: 1937,
        dispensaryLookup: 1247,
        dispensaryVisit: 847,
        conversionFunnel: {
          playlistToStrain: "68%",
          strainToLookup: "64%", 
          lookupToVisit: "68%"
        }
      };
      res.json(journey);
    } catch (error) {
      console.error("Error fetching user journey data:", error);
      res.status(500).json({ message: "Failed to fetch user journey data" });
    }
  });

  app.get('/api/dispensary/integration-status', async (req, res) => {
    try {
      const status = {
        integrationActive: true,
        monthlyImpressions: 84789,
        clickThroughRate: "12.8%",
        benefits: [
          "Enhanced Customer Discovery",
          "Strain-based Recommendations",
          "Music-driven Traffic", 
          "Analytics & Insights",
          "Premium Placement"
        ]
      };
      res.json(status);
    } catch (error) {
      console.error("Error fetching integration status:", error);
      res.status(500).json({ message: "Failed to fetch integration status" });
    }
  });

  // =============================================
  // RECOMMENDATION ENGINE API ENDPOINTS
  // =============================================

  // Get personalized strain recommendations
  app.post("/api/recommendations/personalized", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { preferences, limit = 10 } = req.body;
      
      const recommendations = await RecommendationEngine.getPersonalizedRecommendations(
        userId,
        preferences,
        limit
      );
      
      res.json(recommendations);
    } catch (error) {
      console.error("Error getting personalized recommendations:", error);
      res.status(500).json({ message: "Failed to get personalized recommendations" });
    }
  });

  // Get contextual recommendations based on mood/situation
  app.post("/api/recommendations/contextual", async (req, res) => {
    try {
      const { context, userId = 'anonymous', limit = 5 } = req.body;
      
      if (!context || !context.mood) {
        return res.status(400).json({ message: "Context with mood is required" });
      }
      
      const recommendations = await RecommendationEngine.getContextualRecommendations(
        userId,
        context,
        limit
      );
      
      res.json(recommendations);
    } catch (error) {
      console.error("Error getting contextual recommendations:", error);
      res.status(500).json({ message: "Failed to get contextual recommendations" });
    }
  });

  // Get mood-based recommendations (public endpoint)
  app.post("/api/recommendations/mood", async (req, res) => {
    try {
      const { mood, musicGenres = [], limit = 8 } = req.body;
      
      if (!mood) {
        return res.status(400).json({ message: "Mood is required" });
      }
      
      const recommendations = await RecommendationEngine.getMoodBasedRecommendations(
        mood,
        musicGenres,
        limit
      );
      
      res.json(recommendations);
    } catch (error) {
      console.error("Error getting mood-based recommendations:", error);
      res.status(500).json({ message: "Failed to get mood-based recommendations" });
    }
  });

  // Get similar strains based on terpene profile
  app.get("/api/strains/:id/similar", async (req, res) => {
    try {
      const strainId = parseInt(req.params.id);
      const limit = parseInt(req.query.limit as string) || 5;
      
      const similarStrains = await RecommendationEngine.findSimilarStrains(strainId, limit);
      res.json(similarStrains);
    } catch (error) {
      console.error("Error finding similar strains:", error);
      res.status(500).json({ message: "Failed to find similar strains" });
    }
  });

  // Get terpene-based music recommendations
  app.get("/api/strains/:id/music-recommendations", async (req, res) => {
    try {
      const strainId = parseInt(req.params.id);
      
      const musicRecommendations = await RecommendationEngine.getTerpeneBasedMusicRecommendations(strainId);
      res.json(musicRecommendations);
    } catch (error) {
      console.error("Error getting music recommendations:", error);
      res.status(500).json({ message: "Failed to get music recommendations" });
    }
  });

  // Quick recommendation for discovery page
  app.get("/api/recommendations/discover", async (req, res) => {
    try {
      const { type, effect, terpene } = req.query;
      
      // Build preferences based on query parameters
      const preferences: any = {};
      if (type) preferences.favoriteStrainTypes = [type];
      if (effect) preferences.preferredEffects = [effect];
      if (terpene) preferences.favoriteTerpenes = [terpene];
      
      const recommendations = await RecommendationEngine.getPersonalizedRecommendations(
        'anonymous',
        preferences,
        6
      );
      
      res.json(recommendations);
    } catch (error) {
      console.error("Error getting discovery recommendations:", error);
      res.status(500).json({ message: "Failed to get discovery recommendations" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
