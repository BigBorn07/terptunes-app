import {
  users,
  strains,
  terpeneProfiles,
  playlists,
  playlistLikes,
  userPreferences,
  brands,
  userFavoriteBrands,
  dispensaries,
  userFavoriteDispensaries,
  type User,
  type UpsertUser,
  type Strain,
  type InsertStrain,
  type TerpeneProfile,
  type InsertTerpeneProfile,
  type Playlist,
  type InsertPlaylist,
  type PlaylistLike,
  type InsertPlaylistLike,
  type UserPreferences,
  type InsertUserPreferences,
  type Brand,
  type InsertBrand,
  type Dispensary,
  type InsertDispensary,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc, ilike, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;
  updateUserSpotifyTokens(userId: string, accessToken: string | null, refreshToken: string | null, expiryDate?: Date | null): Promise<void>;

  // Strain operations
  getAllStrains(): Promise<Strain[]>;
  getStrainById(id: number): Promise<Strain | undefined>;
  createStrain(strain: InsertStrain): Promise<Strain>;
  
  // Terpene profile operations
  getTerpeneProfilesByStrainId(strainId: number): Promise<TerpeneProfile[]>;
  createTerpeneProfile(profile: InsertTerpeneProfile): Promise<TerpeneProfile>;
  
  // Playlist operations
  getUserPlaylists(userId: string): Promise<Playlist[]>;
  getPlaylistById(id: number): Promise<Playlist | undefined>;
  createPlaylist(playlist: InsertPlaylist): Promise<Playlist>;
  updatePlaylist(id: number, updates: Partial<Playlist>): Promise<Playlist>;
  deletePlaylist(id: number): Promise<void>;
  incrementPlaylistPlay(id: number): Promise<void>;
  
  // Playlist library operations
  getPlaylistsByStrain(strainId: number, limit?: number): Promise<Playlist[]>;
  getPlaylistsByGenre(genre: string, limit?: number): Promise<Playlist[]>;
  getPlaylistsByMood(mood: string, limit?: number): Promise<Playlist[]>;
  getPublicPlaylists(limit?: number, offset?: number): Promise<Playlist[]>;
  getPopularPlaylists(limit?: number): Promise<Playlist[]>;
  searchPlaylists(query: string, limit?: number): Promise<Playlist[]>;
  
  // Playlist engagement operations
  likePlaylist(userId: string, playlistId: number): Promise<void>;
  unlikePlaylist(userId: string, playlistId: number): Promise<void>;
  getUserPlaylistLikes(userId: string): Promise<PlaylistLike[]>;
  isPlaylistLikedByUser(userId: string, playlistId: number): Promise<boolean>;
  
  // User preferences operations
  getUserPreferences(userId: string): Promise<UserPreferences | undefined>;
  upsertUserPreferences(preferences: InsertUserPreferences): Promise<UserPreferences>;

  // Brand/cultivator operations
  getBrands(filters?: { search?: string; type?: string; verified?: boolean }): Promise<Brand[]>;
  getBrandById(id: number): Promise<Brand | undefined>;
  createBrand(brand: InsertBrand): Promise<Brand>;
  addFavoriteBrand(userId: string, brandId: number): Promise<void>;
  removeFavoriteBrand(userId: string, brandId: number): Promise<void>;
  getUserFavoriteBrands(userId: string): Promise<Brand[]>;

  // Dispensary operations
  getDispensaries(filters?: { search?: string; location?: string; verified?: boolean }): Promise<Dispensary[]>;
  getDispensaryById(id: number): Promise<Dispensary | undefined>;
  createDispensary(dispensary: InsertDispensary): Promise<Dispensary>;
  addFavoriteDispensary(userId: string, dispensaryId: number): Promise<void>;
  removeFavoriteDispensary(userId: string, dispensaryId: number): Promise<void>;
  getUserFavoriteDispensaries(userId: string): Promise<Dispensary[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        email: userData.email || null,
        firstName: userData.firstName || null,
        lastName: userData.lastName || null,
        profileImageUrl: userData.profileImageUrl || null,
        spotifyId: userData.spotifyId || null,
        spotifyAccessToken: userData.spotifyAccessToken || null,
        spotifyRefreshToken: userData.spotifyRefreshToken || null,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: users.id,
        set: {
          email: userData.email || null,
          firstName: userData.firstName || null,
          lastName: userData.lastName || null,
          profileImageUrl: userData.profileImageUrl || null,
          spotifyId: userData.spotifyId || null,
          spotifyAccessToken: userData.spotifyAccessToken || null,
          spotifyRefreshToken: userData.spotifyRefreshToken || null,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    
    if (!user) {
      throw new Error('User not found');
    }
    
    return user;
  }

  async updateUserSpotifyTokens(userId: string, accessToken: string | null, refreshToken: string | null, expiryDate?: Date | null): Promise<void> {
    await db
      .update(users)
      .set({
        spotifyAccessToken: accessToken,
        spotifyRefreshToken: refreshToken,
        spotifyTokenExpiry: expiryDate,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  // Strain operations
  async getAllStrains(): Promise<Strain[]> {
    return await db.select().from(strains);
  }

  async getStrainById(id: number): Promise<Strain | undefined> {
    const [strain] = await db.select().from(strains).where(eq(strains.id, id));
    return strain || undefined;
  }

  async createStrain(strainData: InsertStrain): Promise<Strain> {
    const [strain] = await db
      .insert(strains)
      .values({
        ...strainData,
        thcContent: strainData.thcContent || null,
        cbdContent: strainData.cbdContent || null,
        description: strainData.description || null,
        effects: strainData.effects || [],
        flavors: strainData.flavors || [],
        imageUrl: strainData.imageUrl || null,
      })
      .returning();
    return strain;
  }

  // Terpene profile operations
  async getTerpeneProfilesByStrainId(strainId: number): Promise<TerpeneProfile[]> {
    return await db.select().from(terpeneProfiles).where(eq(terpeneProfiles.strainId, strainId));
  }

  async createTerpeneProfile(profileData: InsertTerpeneProfile): Promise<TerpeneProfile> {
    const [profile] = await db
      .insert(terpeneProfiles)
      .values({
        ...profileData,
        strainId: profileData.strainId || null,
        percentage: profileData.percentage || null,
      })
      .returning();
    return profile;
  }

  // Playlist operations
  async getUserPlaylists(userId: string): Promise<Playlist[]> {
    return await db.select().from(playlists).where(eq(playlists.userId, userId));
  }

  async getPlaylistById(id: number): Promise<Playlist | undefined> {
    const [playlist] = await db.select().from(playlists).where(eq(playlists.id, id));
    return playlist || undefined;
  }

  async createPlaylist(playlistData: InsertPlaylist): Promise<Playlist> {
    const [playlist] = await db
      .insert(playlists)
      .values({
        ...playlistData,
        description: playlistData.description || null,
        userId: playlistData.userId || null,
        strainId: playlistData.strainId || null,
        spotifyPlaylistId: playlistData.spotifyPlaylistId || null,
        trackCount: playlistData.trackCount || null,
        duration: playlistData.duration || null,
        dominantTerpenes: playlistData.dominantTerpenes || [],
      })
      .returning();
    return playlist;
  }

  async updatePlaylist(id: number, updates: Partial<Playlist>): Promise<Playlist> {
    const [playlist] = await db
      .update(playlists)
      .set(updates)
      .where(eq(playlists.id, id))
      .returning();
    
    if (!playlist) {
      throw new Error('Playlist not found');
    }
    
    return playlist;
  }

  async deletePlaylist(id: number): Promise<void> {
    await db.delete(playlists).where(eq(playlists.id, id));
  }

  async incrementPlaylistPlay(id: number): Promise<void> {
    await db
      .update(playlists)
      .set({ 
        playCount: sql`${playlists.playCount} + 1`,
        updatedAt: new Date()
      })
      .where(eq(playlists.id, id));
  }

  // Playlist library operations
  async getPlaylistsByStrain(strainId: number, limit: number = 12): Promise<Playlist[]> {
    try {
      return await db
        .select()
        .from(playlists)
        .where(eq(playlists.strainId, strainId))
        .orderBy(desc(playlists.likeCount), desc(playlists.playCount))
        .limit(limit);
    } catch (error) {
      console.log("Error getting playlists by strain:", error);
      return []; // Return empty array if error
    }
  }

  async getPlaylistsByGenre(genre: string, limit: number = 12): Promise<Playlist[]> {
    try {
      return await db
        .select()
        .from(playlists)
        .where(eq(playlists.primaryGenre, genre))
        .orderBy(desc(playlists.likeCount), desc(playlists.createdAt))
        .limit(limit);
    } catch (error) {
      console.log("Error getting playlists by genre:", error);
      return []; // Return empty array if error
    }
  }

  async getPlaylistsByMood(mood: string, limit: number = 12): Promise<Playlist[]> {
    try {
      return await db
        .select()
        .from(playlists)
        .where(eq(playlists.mood, mood))
        .orderBy(desc(playlists.likeCount), desc(playlists.playCount))
        .limit(limit);
    } catch (error) {
      console.log("Error getting playlists by mood:", error);
      return []; // Return empty array if error
    }
  }

  async getPublicPlaylists(limit: number = 20, offset: number = 0): Promise<Playlist[]> {
    try {
      return await db
        .select()
        .from(playlists)
        .orderBy(desc(playlists.createdAt))
        .limit(limit)
        .offset(offset);
    } catch (error) {
      console.log("Error getting public playlists:", error);
      return []; // Return empty array if error
    }
  }

  async getPopularPlaylists(limit: number = 12): Promise<Playlist[]> {
    try {
      return await db
        .select()
        .from(playlists)
        .orderBy(desc(playlists.likeCount), desc(playlists.playCount))
        .limit(limit);
    } catch (error) {
      console.log("Error getting popular playlists:", error);
      return []; // Return empty array if error
    }
  }

  async searchPlaylists(query: string, limit: number = 12): Promise<Playlist[]> {
    return await db
      .select()
      .from(playlists)
      .where(
        and(
          eq(playlists.isPublic, true),
          or(
            ilike(playlists.name, `%${query}%`),
            ilike(playlists.description, `%${query}%`),
            ilike(playlists.primaryGenre, `%${query}%`),
            ilike(playlists.mood, `%${query}%`)
          )
        )
      )
      .orderBy(desc(playlists.likeCount), desc(playlists.playCount))
      .limit(limit);
  }

  // Playlist engagement operations
  async likePlaylist(userId: string, playlistId: number): Promise<void> {
    // Check if already liked
    const [existing] = await db
      .select()
      .from(playlistLikes)
      .where(and(eq(playlistLikes.userId, userId), eq(playlistLikes.playlistId, playlistId)));

    if (!existing) {
      // Add like
      await db.insert(playlistLikes).values({ userId, playlistId });
      
      // Increment like count
      await db
        .update(playlists)
        .set({ 
          likeCount: sql`${playlists.likeCount} + 1`,
          updatedAt: new Date()
        })
        .where(eq(playlists.id, playlistId));
    }
  }

  async unlikePlaylist(userId: string, playlistId: number): Promise<void> {
    // Remove like
    const deleted = await db
      .delete(playlistLikes)
      .where(and(eq(playlistLikes.userId, userId), eq(playlistLikes.playlistId, playlistId)));
    
    // Decrement like count if like was removed
    if (deleted) {
      await db
        .update(playlists)
        .set({ 
          likeCount: sql`GREATEST(${playlists.likeCount} - 1, 0)`,
          updatedAt: new Date()
        })
        .where(eq(playlists.id, playlistId));
    }
  }

  async getUserPlaylistLikes(userId: string): Promise<PlaylistLike[]> {
    return await db
      .select()
      .from(playlistLikes)
      .where(eq(playlistLikes.userId, userId));
  }

  async isPlaylistLikedByUser(userId: string, playlistId: number): Promise<boolean> {
    const [like] = await db
      .select()
      .from(playlistLikes)
      .where(and(eq(playlistLikes.userId, userId), eq(playlistLikes.playlistId, playlistId)));
    
    return !!like;
  }

  // User preferences operations
  async getUserPreferences(userId: string): Promise<UserPreferences | undefined> {
    const [preferences] = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId));
    return preferences || undefined;
  }

  async upsertUserPreferences(preferencesData: InsertUserPreferences): Promise<UserPreferences> {
    const [preferences] = await db
      .insert(userPreferences)
      .values({
        ...preferencesData,
        userId: preferencesData.userId || null,
        favoriteTerpenes: preferencesData.favoriteTerpenes || [],
        preferredGenres: preferencesData.preferredGenres || [],
        playlistDuration: preferencesData.playlistDuration || null,
        explicitContent: preferencesData.explicitContent || null,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: userPreferences.userId,
        set: {
          favoriteTerpenes: preferencesData.favoriteTerpenes || [],
          preferredGenres: preferencesData.preferredGenres || [],
          playlistDuration: preferencesData.playlistDuration || null,
          explicitContent: preferencesData.explicitContent || null,
          updatedAt: new Date(),
        },
      })
      .returning();
    return preferences;
  }

  // Brand/cultivator operations
  async getBrands(filters?: { search?: string; type?: string; verified?: boolean }): Promise<Brand[]> {
    const conditions = [];

    if (filters?.search) {
      conditions.push(ilike(brands.name, `%${filters.search}%`));
    }
    if (filters?.type) {
      conditions.push(eq(brands.type, filters.type));
    }
    if (filters?.verified !== undefined) {
      conditions.push(eq(brands.verified, filters.verified));
    }

    if (conditions.length > 0) {
      return await db
        .select()
        .from(brands)
        .where(and(...conditions))
        .orderBy(desc(brands.strainCount), desc(brands.userFavorites));
    } else {
      return await db
        .select()
        .from(brands)
        .orderBy(desc(brands.strainCount), desc(brands.userFavorites));
    }
  }

  async getBrandById(id: number): Promise<Brand | undefined> {
    const [brand] = await db.select().from(brands).where(eq(brands.id, id));
    return brand || undefined;
  }

  async createBrand(brandData: InsertBrand): Promise<Brand> {
    const [brand] = await db
      .insert(brands)
      .values({
        ...brandData,
        verified: brandData.verified || false,
        strainCount: brandData.strainCount || 0,
        userFavorites: brandData.userFavorites || 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();
    return brand;
  }

  async addFavoriteBrand(userId: string, brandId: number): Promise<void> {
    // Update user preferences to add favorite brand
    const preferences = await this.getUserPreferences(userId);
    const favoriteBrands = (preferences?.favoriteBrands as number[]) || [];
    
    if (!favoriteBrands.includes(brandId)) {
      favoriteBrands.push(brandId);
      await this.upsertUserPreferences({
        userId,
        favoriteBrands,
        favoriteTerpenes: preferences?.favoriteTerpenes,
        preferredGenres: preferences?.preferredGenres,
        favoriteGrowers: preferences?.favoriteGrowers,
        preferredStrainTypes: preferences?.preferredStrainTypes,
        playlistDuration: preferences?.playlistDuration,
        explicitContent: preferences?.explicitContent,
      });

      // Increment brand's user favorites count
      await db
        .update(brands)
        .set({
          userFavorites: sql`${brands.userFavorites} + 1`,
          updatedAt: new Date(),
        })
        .where(eq(brands.id, brandId));
    }
  }

  async removeFavoriteBrand(userId: string, brandId: number): Promise<void> {
    // Update user preferences to remove favorite brand
    const preferences = await this.getUserPreferences(userId);
    const favoriteBrands = (preferences?.favoriteBrands as number[]) || [];
    
    const index = favoriteBrands.indexOf(brandId);
    if (index > -1) {
      favoriteBrands.splice(index, 1);
      await this.upsertUserPreferences({
        userId,
        favoriteBrands,
        favoriteTerpenes: preferences?.favoriteTerpenes,
        preferredGenres: preferences?.preferredGenres,
        favoriteGrowers: preferences?.favoriteGrowers,
        preferredStrainTypes: preferences?.preferredStrainTypes,
        playlistDuration: preferences?.playlistDuration,
        explicitContent: preferences?.explicitContent,
      });

      // Decrement brand's user favorites count
      await db
        .update(brands)
        .set({
          userFavorites: sql`${brands.userFavorites} - 1`,
          updatedAt: new Date(),
        })
        .where(eq(brands.id, brandId));
    }
  }

  async getUserFavoriteBrands(userId: string): Promise<Brand[]> {
    const preferences = await this.getUserPreferences(userId);
    const favoriteBrandIds = (preferences?.favoriteBrands as number[]) || [];
    
    if (favoriteBrandIds.length === 0) {
      return [];
    }

    return await db
      .select()
      .from(brands)
      .where(sql`${brands.id} = ANY(${favoriteBrandIds})`);
  }

  // Dispensary operations
  async getDispensaries(filters?: { search?: string; location?: string; verified?: boolean }): Promise<Dispensary[]> {
    let query = db.select().from(dispensaries);

    if (filters?.search) {
      query = query.where(
        or(
          ilike(dispensaries.name, `%${filters.search}%`),
          ilike(dispensaries.location, `%${filters.search}%`)
        )
      );
    }

    if (filters?.location) {
      query = query.where(ilike(dispensaries.location, `%${filters.location}%`));
    }

    if (filters?.verified !== undefined) {
      query = query.where(eq(dispensaries.verified, filters.verified));
    }

    return await query.orderBy(desc(dispensaries.rating));
  }

  async getDispensaryById(id: number): Promise<Dispensary | undefined> {
    const [dispensary] = await db
      .select()
      .from(dispensaries)
      .where(eq(dispensaries.id, id))
      .limit(1);
    return dispensary;
  }

  async createDispensary(dispensaryData: InsertDispensary): Promise<Dispensary> {
    const [dispensary] = await db
      .insert(dispensaries)
      .values({
        ...dispensaryData,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();
    return dispensary;
  }

  async addFavoriteDispensary(userId: string, dispensaryId: number): Promise<void> {
    await db
      .insert(userFavoriteDispensaries)
      .values({ userId, dispensaryId })
      .onConflictDoNothing();
  }

  async removeFavoriteDispensary(userId: string, dispensaryId: number): Promise<void> {
    await db
      .delete(userFavoriteDispensaries)
      .where(
        and(
          eq(userFavoriteDispensaries.userId, userId),
          eq(userFavoriteDispensaries.dispensaryId, dispensaryId)
        )
      );
  }

  async getUserFavoriteDispensaries(userId: string): Promise<Dispensary[]> {
    const favoriteDispensaryIds = await db
      .select({ dispensaryId: userFavoriteDispensaries.dispensaryId })
      .from(userFavoriteDispensaries)
      .where(eq(userFavoriteDispensaries.userId, userId))
      .then(results => results.map(r => r.dispensaryId));
    
    if (favoriteDispensaryIds.length === 0) {
      return [];
    }

    return await db
      .select()
      .from(dispensaries)
      .where(sql`${dispensaries.id} = ANY(${favoriteDispensaryIds})`);
  }
}

export const storage = new DatabaseStorage();
