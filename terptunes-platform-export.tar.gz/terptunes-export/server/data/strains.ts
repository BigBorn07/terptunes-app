import { Strain, TerpeneProfile } from '@shared/schema';

export interface StrainWithTerpenes extends Omit<Strain, 'id' | 'createdAt'> {
  terpenes: Array<{
    name: string;
    percentage: number;
  }>;
}

export const strainDatabase: StrainWithTerpenes[] = [
  {
    name: "Purple Kush",
    type: "indica",
    thcContent: "19.5",
    cbdContent: "0.8",
    description: "A pure indica strain with deep relaxation and sedating effects, perfect for evening use.",
    effects: ["relaxing", "sleepy", "euphoric", "happy", "hungry"],
    flavors: ["grape", "sweet", "earthy", "berry", "woody"],
    imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop",
    terpenes: [
      { name: "myrcene", percentage: 1.2 },
      { name: "linalool", percentage: 0.8 },
      { name: "caryophyllene", percentage: 0.5 }
    ]
  },
  {
    name: "Sour Diesel",
    type: "sativa",
    thcContent: "22.0",
    cbdContent: "0.2",
    description: "An energizing sativa strain known for its uplifting and creative effects.",
    effects: ["energizing", "creative", "uplifting", "focused", "happy"],
    flavors: ["diesel", "citrus", "pungent", "earthy", "lemon"],
    imageUrl: "https://images.unsplash.com/photo-1544131750-2985dd95c65d?w=400&h=300&fit=crop",
    terpenes: [
      { name: "limonene", percentage: 0.9 },
      { name: "caryophyllene", percentage: 0.7 },
      { name: "myrcene", percentage: 0.3 }
    ]
  },
  {
    name: "OG Kush",
    type: "hybrid",
    thcContent: "22.5",
    cbdContent: "0.3",
    description: "A legendary hybrid strain with balanced effects and a complex terpene profile.",
    effects: ["balanced", "euphoric", "relaxing", "uplifting", "creative"],
    flavors: ["earthy", "pine", "woody", "citrus", "diesel"],
    imageUrl: "https://images.unsplash.com/photo-1536431311719-398b6704d4cc?w=400&h=300&fit=crop",
    terpenes: [
      { name: "myrcene", percentage: 1.0 },
      { name: "limonene", percentage: 0.6 },
      { name: "pinene", percentage: 0.4 }
    ]
  },
  {
    name: "Blue Dream",
    type: "hybrid",
    thcContent: "17.0",
    cbdContent: "0.1",
    description: "A popular hybrid strain offering gentle euphoria and creative focus.",
    effects: ["euphoric", "creative", "relaxing", "happy", "uplifting"],
    flavors: ["berry", "sweet", "vanilla", "citrus", "earthy"],
    imageUrl: "https://images.unsplash.com/photo-1605552055503-d7bca87caa79?w=400&h=300&fit=crop",
    terpenes: [
      { name: "myrcene", percentage: 0.8 },
      { name: "pinene", percentage: 0.6 },
      { name: "limonene", percentage: 0.4 }
    ]
  },
  {
    name: "Granddaddy Purple",
    type: "indica",
    thcContent: "20.0",
    cbdContent: "0.1",
    description: "A potent indica strain known for its deep purple coloration and relaxing effects.",
    effects: ["relaxing", "sleepy", "euphoric", "happy", "hungry"],
    flavors: ["grape", "berry", "sweet", "earthy", "woody"],
    imageUrl: "https://images.unsplash.com/photo-1583336663277-620dc1996580?w=400&h=300&fit=crop",
    terpenes: [
      { name: "myrcene", percentage: 1.1 },
      { name: "linalool", percentage: 0.7 },
      { name: "caryophyllene", percentage: 0.3 }
    ]
  },
  {
    name: "Jack Herer",
    type: "sativa",
    thcContent: "18.0",
    cbdContent: "0.03",
    description: "A renowned sativa strain providing clear-headed and creative effects.",
    effects: ["energizing", "creative", "uplifting", "focused", "euphoric"],
    flavors: ["pine", "woody", "earthy", "citrus", "spicy"],
    imageUrl: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=400&h=300&fit=crop",
    terpenes: [
      { name: "pinene", percentage: 0.8 },
      { name: "limonene", percentage: 0.5 },
      { name: "terpinolene", percentage: 0.4 }
    ]
  },
  {
    name: "White Widow",
    type: "hybrid",
    thcContent: "20.0",
    cbdContent: "0.2",
    description: "A balanced hybrid strain known for its resinous white trichomes and energizing effects.",
    effects: ["energizing", "euphoric", "creative", "uplifting", "focused"],
    flavors: ["earthy", "woody", "pine", "citrus", "sweet"],
    imageUrl: "https://images.unsplash.com/photo-1576321046488-dd7849b58a0d?w=400&h=300&fit=crop",
    terpenes: [
      { name: "myrcene", percentage: 0.6 },
      { name: "limonene", percentage: 0.5 },
      { name: "pinene", percentage: 0.4 }
    ]
  },
  {
    name: "Northern Lights",
    type: "indica",
    thcContent: "16.0",
    cbdContent: "0.1",
    description: "A classic indica strain with powerful relaxing effects and a sweet flavor profile.",
    effects: ["relaxing", "sleepy", "euphoric", "happy", "hungry"],
    flavors: ["sweet", "earthy", "pine", "woody", "citrus"],
    imageUrl: "https://images.unsplash.com/photo-1558618666-7ea8c6b5b2e5?w=400&h=300&fit=crop",
    terpenes: [
      { name: "myrcene", percentage: 1.3 },
      { name: "caryophyllene", percentage: 0.6 },
      { name: "linalool", percentage: 0.3 }
    ]
  }
];

export const getStrainByName = (name: string): StrainWithTerpenes | undefined => {
  return strainDatabase.find(strain => 
    strain.name.toLowerCase() === name.toLowerCase()
  );
};

export const searchStrains = (query: string): StrainWithTerpenes[] => {
  const lowerQuery = query.toLowerCase();
  return strainDatabase.filter(strain => 
    strain.name.toLowerCase().includes(lowerQuery) ||
    strain.type.toLowerCase().includes(lowerQuery) ||
    strain.effects.some(effect => effect.toLowerCase().includes(lowerQuery)) ||
    strain.flavors.some(flavor => flavor.toLowerCase().includes(lowerQuery)) ||
    strain.terpenes.some(terpene => terpene.name.toLowerCase().includes(lowerQuery))
  );
};

export const getStrainsByType = (type: string): StrainWithTerpenes[] => {
  return strainDatabase.filter(strain => 
    strain.type.toLowerCase() === type.toLowerCase()
  );
};

export const getStrainsByTerpene = (terpeneName: string): StrainWithTerpenes[] => {
  return strainDatabase.filter(strain =>
    strain.terpenes.some(terpene => 
      terpene.name.toLowerCase() === terpeneName.toLowerCase()
    )
  );
};

export const getAllStrains = (): StrainWithTerpenes[] => {
  return strainDatabase;
};
