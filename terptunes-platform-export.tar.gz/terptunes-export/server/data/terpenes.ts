export interface TerpeneInfo {
  name: string;
  effects: string[];
  description: string;
  musicalCharacteristics: string[];
  color: string;
}

export const terpeneDatabase: Record<string, TerpeneInfo> = {
  myrcene: {
    name: "Myrcene",
    effects: ["sedating", "relaxing", "muscle-relaxant", "sleep-inducing"],
    description: "The most common terpene in cannabis, known for its deeply relaxing and sedating effects.",
    musicalCharacteristics: ["ambient", "downtempo", "chill", "lo-fi", "meditation", "spa"],
    color: "#22c55e"
  },
  limonene: {
    name: "Limonene",
    effects: ["uplifting", "mood-boosting", "energizing", "anti-anxiety"],
    description: "A citrusy terpene that provides uplifting and mood-enhancing effects.",
    musicalCharacteristics: ["upbeat", "pop", "electronic", "dance", "tropical", "happy"],
    color: "#a855f7"
  },
  pinene: {
    name: "Pinene",
    effects: ["alertness", "focus", "memory-retention", "anti-inflammatory"],
    description: "A pine-scented terpene that promotes alertness and mental clarity.",
    musicalCharacteristics: ["instrumental", "focus", "study", "classical", "ambient-focus", "productivity"],
    color: "#3b82f6"
  },
  linalool: {
    name: "Linalool",
    effects: ["calming", "anti-anxiety", "sedating", "anti-inflammatory"],
    description: "A floral terpene with calming and anti-anxiety properties.",
    musicalCharacteristics: ["meditation", "spa", "relaxing", "acoustic", "nature-sounds", "healing"],
    color: "#6366f1"
  },
  caryophyllene: {
    name: "Caryophyllene",
    effects: ["anti-inflammatory", "pain-relief", "stress-relief", "grounding"],
    description: "A spicy terpene that provides anti-inflammatory and pain-relieving effects.",
    musicalCharacteristics: ["jazz", "blues", "rock", "alternative", "grounding", "earthy"],
    color: "#f59e0b"
  },
  terpinolene: {
    name: "Terpinolene",
    effects: ["sedating", "antioxidant", "antibacterial", "calming"],
    description: "A complex terpene with sedating and antioxidant properties.",
    musicalCharacteristics: ["indie", "alternative", "experimental", "psychedelic", "atmospheric"],
    color: "#ec4899"
  },
  humulene: {
    name: "Humulene",
    effects: ["appetite-suppressant", "anti-inflammatory", "antibacterial"],
    description: "An earthy terpene found in hops and cannabis with anti-inflammatory properties.",
    musicalCharacteristics: ["folk", "country", "acoustic", "earthy", "organic", "traditional"],
    color: "#84cc16"
  },
  ocimene: {
    name: "Ocimene",
    effects: ["uplifting", "energizing", "decongestant", "antifungal"],
    description: "A sweet, herbaceous terpene with uplifting and energizing effects.",
    musicalCharacteristics: ["reggae", "world", "tropical", "uplifting", "ethnic", "spiritual"],
    color: "#06b6d4"
  }
};

export const getTerpeneInfo = (terpeneName: string): TerpeneInfo | null => {
  return terpeneDatabase[terpeneName.toLowerCase()] || null;
};

export const getAllTerpenes = (): TerpeneInfo[] => {
  return Object.values(terpeneDatabase);
};
