import { db } from "./db";
import { strains, terpeneProfiles } from "@shared/schema";
import * as fs from 'fs';
import * as path from 'path';

interface StrainCSVRow {
  id: string;
  strain_name: string;
  sample_type: string;
  lab_name: string;
  test_date: string;
  batch_number: string;
  thc_percent: string;
  cbd_percent: string;
  cbg_percent: string;
  cbn_percent: string;
  cbc_percent: string;
  myrcene_mg_g: string;
  limonene_mg_g: string;
  pinene_mg_g: string;
  linalool_mg_g: string;
  caryophyllene_mg_g: string;
  total_terpenes: string;
  notes: string;
  created_at: string;
  updated_at: string;
  product_type: string;
}

function parseCSV(csvContent: string): StrainCSVRow[] {
  const lines = csvContent.trim().split('\n');
  const headers = lines[0].split(',');
  
  return lines.slice(1).map(line => {
    const values = line.split(',');
    const row: any = {};
    
    headers.forEach((header, index) => {
      row[header] = values[index] || '';
    });
    
    return row as StrainCSVRow;
  });
}

function determineStrainType(strainName: string): 'indica' | 'sativa' | 'hybrid' {
  const name = strainName.toLowerCase();
  
  // Common indica strains
  const indicaStrains = ['granddaddy purple', 'northern lights', 'bubba kush', 'master kush', 'hindu kush', 'afghani'];
  // Common sativa strains  
  const sativaStrains = ['jack herer', 'sour diesel', 'amnesia haze', 'super silver haze', 'maui wowie', 'ak-47'];
  
  if (indicaStrains.some(indica => name.includes(indica))) {
    return 'indica';
  }
  
  if (sativaStrains.some(sativa => name.includes(sativa))) {
    return 'sativa';
  }
  
  // Default to hybrid for most strains
  return 'hybrid';
}

function generateEffects(strainType: 'indica' | 'sativa' | 'hybrid', terpenes: any): string[] {
  const effects: string[] = [];
  
  if (strainType === 'indica') {
    effects.push('Relaxed', 'Sleepy', 'Happy');
  } else if (strainType === 'sativa') {
    effects.push('Energetic', 'Creative', 'Uplifted');
  } else {
    effects.push('Balanced', 'Happy', 'Relaxed');
  }
  
  // Add effects based on dominant terpenes
  if (terpenes.myrcene > 5) effects.push('Sedating');
  if (terpenes.limonene > 3) effects.push('Euphoric');
  if (terpenes.pinene > 2) effects.push('Alert');
  if (terpenes.linalool > 2) effects.push('Calming');
  if (terpenes.caryophyllene > 3) effects.push('Anti-inflammatory');
  
  return [...new Set(effects)]; // Remove duplicates
}

function generateFlavors(strainName: string, terpenes: any): string[] {
  const flavors: string[] = [];
  const name = strainName.toLowerCase();
  
  // Name-based flavors
  if (name.includes('lemon')) flavors.push('Citrus', 'Lemon');
  if (name.includes('berry') || name.includes('strawberry')) flavors.push('Berry', 'Sweet');
  if (name.includes('cheese') || name.includes('skunk')) flavors.push('Pungent', 'Skunky');
  if (name.includes('diesel')) flavors.push('Diesel', 'Pungent');
  if (name.includes('pine')) flavors.push('Pine', 'Woody');
  if (name.includes('mint')) flavors.push('Mint', 'Cool');
  if (name.includes('chocolate') || name.includes('cake')) flavors.push('Sweet', 'Dessert');
  
  // Terpene-based flavors
  if (terpenes.limonene > 3) flavors.push('Citrus', 'Zesty');
  if (terpenes.myrcene > 5) flavors.push('Earthy', 'Herbal');
  if (terpenes.pinene > 2) flavors.push('Pine', 'Fresh');
  if (terpenes.linalool > 2) flavors.push('Floral', 'Lavender');
  if (terpenes.caryophyllene > 3) flavors.push('Spicy', 'Pepper');
  
  // Default flavors if none detected
  if (flavors.length === 0) {
    flavors.push('Earthy', 'Herbal');
  }
  
  return [...new Set(flavors)]; // Remove duplicates
}

export async function seedDatabase() {
  console.log("🌱 Seeding database with real strain data from CSV...");
  
  try {
    // Read the CSV file
    const csvPath = path.join(process.cwd(), 'attached_assets', 'terptunes_cleaned_data_1751034614935.csv');
    const csvContent = fs.readFileSync(csvPath, 'utf-8');
    const strainRows = parseCSV(csvContent);
    
    console.log(`📊 Found ${strainRows.length} strain records in CSV`);
    
    // Group by strain name to avoid duplicates
    const strainMap = new Map<string, StrainCSVRow[]>();
    
    for (const row of strainRows) {
      // Clean up strain name and filter only flower products
      const cleanName = row.strain_name
        .replace(/\s+(Bud|Flower|Hash Oil|Live Resin|Rosin|Salve|Balm|Gummies|Brownie|Candy|Blunt|Vape)$/i, '')
        .replace(/\s+#\d+$/, '') // Remove sample numbers
        .trim();
      
      // Only process flower samples for now
      if (row.sample_type === 'Flower' && cleanName) {
        if (!strainMap.has(cleanName)) {
          strainMap.set(cleanName, []);
        }
        strainMap.get(cleanName)!.push(row);
      }
    }
    
    console.log(`🌿 Processing ${strainMap.size} unique strain names`);
    
    let processedCount = 0;
    
    for (const [strainName, samples] of strainMap) {
      // Use the sample with the most complete data
      const bestSample = samples.reduce((best, current) => {
        const bestScore = (best.thc_percent ? 1 : 0) + 
                         (best.cbd_percent ? 1 : 0) + 
                         (best.myrcene_mg_g ? 1 : 0) + 
                         (best.limonene_mg_g ? 1 : 0) + 
                         (best.pinene_mg_g ? 1 : 0);
        
        const currentScore = (current.thc_percent ? 1 : 0) + 
                            (current.cbd_percent ? 1 : 0) + 
                            (current.myrcene_mg_g ? 1 : 0) + 
                            (current.limonene_mg_g ? 1 : 0) + 
                            (current.pinene_mg_g ? 1 : 0);
        
        return currentScore > bestScore ? current : best;
      });
      
      // Extract terpene data
      const terpenes = {
        myrcene: parseFloat(bestSample.myrcene_mg_g) || 0,
        limonene: parseFloat(bestSample.limonene_mg_g) || 0,
        pinene: parseFloat(bestSample.pinene_mg_g) || 0,
        linalool: parseFloat(bestSample.linalool_mg_g) || 0,
        caryophyllene: parseFloat(bestSample.caryophyllene_mg_g) || 0,
      };
      
      const strainType = determineStrainType(strainName);
      const effects = generateEffects(strainType, terpenes);
      const flavors = generateFlavors(strainName, terpenes);
      
      // Create strain description
      const description = `${strainName} is a ${strainType} strain with ${bestSample.thc_percent ? bestSample.thc_percent + '% THC' : 'unknown THC'}${bestSample.cbd_percent ? ' and ' + bestSample.cbd_percent + '% CBD' : ''}. Known for its ${effects.join(', ').toLowerCase()} effects and ${flavors.join(', ').toLowerCase()} flavor profile.`;
      
      // Insert strain
      const [strain] = await db
        .insert(strains)
        .values({
          name: strainName,
          type: strainType,
          thcContent: bestSample.thc_percent || null,
          cbdContent: bestSample.cbd_percent || null,
          description: description,
          effects: effects,
          flavors: flavors,
          imageUrl: null,
        })
        .onConflictDoNothing()
        .returning();
      
      if (strain) {
        // Insert terpene profiles
        const terpeneInserts = [];
        
        if (terpenes.myrcene > 0) {
          terpeneInserts.push({
            strainId: strain.id,
            terpeneName: 'Myrcene',
            percentage: terpenes.myrcene.toString(),
          });
        }
        
        if (terpenes.limonene > 0) {
          terpeneInserts.push({
            strainId: strain.id,
            terpeneName: 'Limonene',
            percentage: terpenes.limonene.toString(),
          });
        }
        
        if (terpenes.pinene > 0) {
          terpeneInserts.push({
            strainId: strain.id,
            terpeneName: 'Pinene',
            percentage: terpenes.pinene.toString(),
          });
        }
        
        if (terpenes.linalool > 0) {
          terpeneInserts.push({
            strainId: strain.id,
            terpeneName: 'Linalool',
            percentage: terpenes.linalool.toString(),
          });
        }
        
        if (terpenes.caryophyllene > 0) {
          terpeneInserts.push({
            strainId: strain.id,
            terpeneName: 'Caryophyllene',
            percentage: terpenes.caryophyllene.toString(),
          });
        }
        
        if (terpeneInserts.length > 0) {
          await db.insert(terpeneProfiles).values(terpeneInserts).onConflictDoNothing();
        }
        
        processedCount++;
        console.log(`✓ Added strain: ${strain.name} (${strainType}) with ${terpeneInserts.length} terpenes`);
      }
    }
    
    console.log(`🎉 Database seeding completed! Processed ${processedCount} strains from real cannabis lab data.`);
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

// Run seeding if this file is executed directly
const isMainModule = import.meta.url === `file://${process.argv[1]}`;
if (isMainModule) {
  seedDatabase()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}