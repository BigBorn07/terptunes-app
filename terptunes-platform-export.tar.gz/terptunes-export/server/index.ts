import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

const app = express();

// Ultra-fast health check endpoint with enhanced deployment platform compatibility
app.get("/health", (req, res) => {
  // Set explicit timeout to prevent hanging requests
  const timeout = setTimeout(() => {
    if (!res.headersSent) {
      res.status(503).send("TIMEOUT");
    }
  }, 500); // Reduced timeout for faster failure detection

  // Comprehensive network diagnostic logging for deployment troubleshooting
  console.log("WHAT IS THE req.ip: " + req.ip);
  const clientIP =
    req.ip ||
    req.connection.remoteAddress ||
    req.socket.remoteAddress ||
    "unknown";
  const userAgent = req.headers["user-agent"] || "unknown";
  const forwardedFor = req.headers["x-forwarded-for"] || "none";
  const host = req.headers.host || "unknown";
  const xRealIP = req.headers["x-real-ip"] || "none";
  const via = req.headers.via || "none";

  // Enhanced deployment platform detection for comprehensive logging
  const isDeploymentCheck =
    userAgent.includes("kube-probe") ||
    userAgent.includes("Go-http-client") ||
    userAgent.includes("curl") ||
    userAgent.includes("wget") ||
    userAgent.includes("GoogleHC") ||
    userAgent.includes("ELB-HealthChecker") ||
    userAgent.includes("Amazon") ||
    userAgent.toLowerCase().includes("health") ||
    userAgent.toLowerCase().includes("probe") ||
    userAgent.toLowerCase().includes("check") ||
    !req.headers.accept?.includes("text/html");

  if (isDeploymentCheck) {
    console.log(
      `[PROXY-DEBUG] /health - Host: ${host}, Client: ${clientIP}, UA: ${userAgent}`,
    );
    console.log(
      `[PROXY-HEADERS] XFF: ${forwardedFor}, X-Real-IP: ${xRealIP}, Via: ${via}`,
    );
  }

  // Enhanced response headers for maximum proxy compatibility
  res.set({
    Connection: "close",
    "Cache-Control": "no-cache, no-store, must-revalidate",
    Pragma: "no-cache",
    Expires: "0",
    "X-Health-Status": "OK",
    "X-Server-Binding": "0.0.0.0:5000",
    "X-Proxy-Compatible": "true",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
    "Access-Control-Allow-Headers": "*",
  });

  // Fastest possible response for deployment health checks
  res.status(200).send("OK");
  clearTimeout(timeout);
});

// Additional readiness endpoint with enhanced deployment platform compatibility
app.get("/ready", (req, res) => {
  const timeout = setTimeout(() => {
    if (!res.headersSent) {
      res.status(503).send("NOT_READY");
    }
  }, 500);

  // Network diagnostic logging
  const clientIP = req.ip || req.connection.remoteAddress || "unknown";
  const userAgent = req.headers["user-agent"] || "unknown";
  const host = req.headers.host || "unknown";

  const isDeploymentCheck =
    userAgent.includes("kube-probe") ||
    userAgent.includes("Go-http-client") ||
    userAgent.includes("curl") ||
    userAgent.includes("wget") ||
    userAgent.includes("GoogleHC") ||
    userAgent.includes("ELB-HealthChecker") ||
    userAgent.includes("Amazon") ||
    userAgent.toLowerCase().includes("health") ||
    userAgent.toLowerCase().includes("probe") ||
    userAgent.toLowerCase().includes("check") ||
    !req.headers.accept?.includes("text/html");

  if (isDeploymentCheck) {
    console.log(
      `[PROXY-DEBUG] /ready - Host: ${host}, Client: ${clientIP}, UA: ${userAgent}`,
    );
  }

  // Enhanced response headers for proxy compatibility
  res.set({
    Connection: "close",
    "Cache-Control": "no-cache, no-store, must-revalidate",
    Pragma: "no-cache",
    Expires: "0",
    "X-Ready-Status": "READY",
    "X-Server-Binding": "0.0.0.0:5000",
    "X-Proxy-Compatible": "true",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
    "Access-Control-Allow-Headers": "*",
  });

  // Simple text response for readiness checks
  res.status(200).send("READY");
  clearTimeout(timeout);
});

// Liveness probe endpoint with enhanced deployment platform compatibility
app.get("/alive", (req, res) => {
  const timeout = setTimeout(() => {
    if (!res.headersSent) {
      res.status(503).send("NOT_ALIVE");
    }
  }, 500);

  // Network diagnostic logging
  const clientIP = req.ip || req.connection.remoteAddress || "unknown";
  const userAgent = req.headers["user-agent"] || "unknown";
  const host = req.headers.host || "unknown";

  const isDeploymentCheck =
    userAgent.includes("kube-probe") ||
    userAgent.includes("Go-http-client") ||
    userAgent.includes("curl") ||
    userAgent.includes("wget") ||
    userAgent.includes("GoogleHC") ||
    userAgent.includes("ELB-HealthChecker") ||
    userAgent.includes("Amazon") ||
    userAgent.toLowerCase().includes("health") ||
    userAgent.toLowerCase().includes("probe") ||
    userAgent.toLowerCase().includes("check") ||
    !req.headers.accept?.includes("text/html");

  if (isDeploymentCheck) {
    console.log(
      `[PROXY-DEBUG] /alive - Host: ${host}, Client: ${clientIP}, UA: ${userAgent}`,
    );
  }

  // Enhanced response headers for proxy compatibility
  res.set({
    Connection: "close",
    "Cache-Control": "no-cache, no-store, must-revalidate",
    Pragma: "no-cache",
    Expires: "0",
    "X-Alive-Status": "ALIVE",
    "X-Server-Binding": "0.0.0.0:5000",
    "X-Proxy-Compatible": "true",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
    "Access-Control-Allow-Headers": "*",
  });

  // Ultra-fast response for liveness checks
  res.status(200).send("ALIVE");
  clearTimeout(timeout);
});

// Root endpoint - immediate response for health checks with enhanced proxy compatibility
app.get("/", (req, res, next) => {
  // Ultra-fast health check detection for deployment platforms
  const userAgent = req.headers["user-agent"] || "";
  const acceptHeader = req.headers.accept || "";
  const clientIP =
    req.ip ||
    req.connection.remoteAddress ||
    req.socket.remoteAddress ||
    "unknown";
  const forwardedFor = req.headers["x-forwarded-for"] || "none";
  const host = req.headers.host || "unknown";
  const xRealIP = req.headers["x-real-ip"] || "none";
  const via = req.headers.via || "none";

  // Enhanced deployment platform detection patterns
  const isHealthCheck =
    !acceptHeader.includes("text/html") ||
    userAgent.includes("kube-probe") ||
    userAgent.includes("Go-http-client") ||
    userAgent.includes("curl") ||
    userAgent.includes("wget") ||
    userAgent.includes("Googlebot") ||
    userAgent.includes("GoogleHC") ||
    userAgent.includes("ELB-HealthChecker") ||
    userAgent.includes("Amazon") ||
    userAgent.toLowerCase().includes("health") ||
    userAgent.toLowerCase().includes("probe") ||
    userAgent.toLowerCase().includes("check");

  if (isHealthCheck) {
    // Comprehensive network diagnostic logging for deployment proxy troubleshooting
    console.log(
      `[PROXY-DEBUG] / (root) - Host: ${host}, Client: ${clientIP}, UA: ${userAgent}`,
    );
    console.log(
      `[PROXY-HEADERS] XFF: ${forwardedFor}, X-Real-IP: ${xRealIP}, Via: ${via}`,
    );
    console.log(
      `[PROXY-VERIFICATION] Server bound to 0.0.0.0:5000, accepting external connections`,
    );

    // Enhanced headers for deployment platform proxy compatibility
    res.set({
      Connection: "close",
      "Cache-Control": "no-cache, no-store, must-revalidate",
      Pragma: "no-cache",
      Expires: "0",
      "X-Health-Check": "OK",
      "X-Server-Status": "Running",
      "X-Server-Binding": "0.0.0.0:5000",
      "X-Proxy-Compatible": "true",
      "X-Connection-Test": "SUCCESS",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
      "Access-Control-Allow-Headers": "*",
    });

    res.status(200).send("OK");
    return;
  }

  // Otherwise, continue to regular frontend routing
  next();
});

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  try {
    // Start server immediately without waiting for database initialization
    const server = await registerRoutes(app);

    app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
      const status = err.status || err.statusCode || 500;
      const message = err.message || "Internal Server Error";

      res.status(status).json({ message });
      log(`Error: ${status} - ${message}`);
      // Don't throw error to prevent process exit
    });

    // importantly only setup vite in development and after
    // setting up all the other routes so the catch-all route
    // doesn't interfere with the other routes
    if (app.get("env") === "development") {
      await setupVite(app, server);
    } else {
      serveStatic(app);
    }

    // Use PORT environment variable for deployment compatibility, fallback to 5000
    const port = parseInt(process.env.PORT || "5000", 10);
    const host = "0.0.0.0"; // Listen on all interfaces for deployment compatibility

    // Novel solution: Port conflict detection and automatic cleanup
    server.on("error", (error: any) => {
      if (error.code === "EADDRINUSE") {
        log(
          `❌ Port ${port} is already in use. Detecting and cleaning up duplicate processes...`,
        );

        // Find and terminate conflicting processes
        import("child_process").then(({ exec }) => {
          exec(`lsof -ti:${port}`, (err, stdout) => {
            if (stdout) {
              const pids = stdout
                .trim()
                .split("\n")
                .filter((pid) => pid !== process.pid.toString());
              if (pids.length > 0) {
                log(
                  `🔧 Found conflicting processes: ${pids.join(", ")}. Attempting cleanup...`,
                );
                exec(`kill -9 ${pids.join(" ")}`, (killErr) => {
                  if (!killErr) {
                    log(`✅ Cleanup successful. Retrying server startup...`);
                    setTimeout(() => {
                      server.listen(port, host, () => {
                        log(
                          `🌟 TerpTunes server started successfully after cleanup!`,
                        );
                        log(`🔗 Server listening on ${host}:${port}`);
                      });
                    }, 1000);
                  } else {
                    log(`❌ Cleanup failed: ${killErr.message}`);
                  }
                });
              }
            }
          });
        });
      } else {
        log(`❌ Server error: ${error.message}`);
      }
    });

    // Enhanced proxy configuration for deployment platform compatibility
    server.keepAliveTimeout = 65000; // Longer than most load balancers (60s)
    server.headersTimeout = 66000; // Slightly longer than keepAliveTimeout
    server.requestTimeout = 30000; // 30 second request timeout
    server.timeout = 30000; // 30 second socket timeout

    // Additional deployment platform proxy optimizations
    server.maxHeadersCount = 2000; // Handle proxy headers
    server.maxRequestsPerSocket = 0; // Unlimited requests per socket for proxy reuse

    server.listen(port, host, () => {
      log(`🌟 TerpTunes server started successfully!`);
      log(`🔗 Server listening on ${host}:${port}`);
      log(`📊 Health checks available at /health, /ready, /alive`);
      log(`🎵 TerpTunes API ready to serve requests`);
      log(`🚀 Environment: ${process.env.NODE_ENV || 'development'}`);
      log(`🌐 PORT variable: ${process.env.PORT || 'not set (using 5000)'}`);
      log(`📦 Deployment mode: ${process.env.NODE_ENV === 'production' ? 'PRODUCTION' : 'DEVELOPMENT'}`);

      // Enhanced host binding verification for deployment platforms
      log(`✅ Host binding verification: ${host}:${port}`);
      log(`🌍 External interface binding confirmed (not localhost/127.0.0.1)`);
      log(`🔗 Deployment proxy should connect to: ${host}:${port}`);

      // Comprehensive proxy debugging information
      log(`[PROXY-CONFIG] Server binding: ${host}:${port}`);
      log(`[PROXY-CONFIG] Accept external connections: YES`);
      log(`[PROXY-CONFIG] Health check endpoints: /health, /ready, /alive, /`);
      log(`[PROXY-CONFIG] Response headers include proxy compatibility flags`);
      log(`[PROXY-CONFIG] Network diagnostic logging: ENABLED`);

      // Verify server is actually listening externally
      const testBinding = server.address();
      if (testBinding && typeof testBinding === "object") {
        log(
          `[BINDING-VERIFICATION] Actual server address: ${testBinding.address}:${testBinding.port}`,
        );
        log(`[BINDING-VERIFICATION] Family: ${testBinding.family}`);
        if (testBinding.address === "::" || testBinding.address === "0.0.0.0") {
          log(
            `[BINDING-SUCCESS] ✅ Server bound to external interface - proxy connections will work`,
          );
        } else {
          log(
            `[BINDING-WARNING] ⚠️ Server may not be accessible to external proxy - bound to ${testBinding.address}`,
          );
        }
      }

      // Network diagnostic information for troubleshooting
      const networkInfo = {
        host: host,
        port: port,
        actualBinding: server.address(),
        nodeEnv: process.env.NODE_ENV || "development",
        platform: process.platform,
        pid: process.pid,
      };
      log(`📋 Network diagnostic info: ${JSON.stringify(networkInfo)}`);

      // Initialize database in background - completely non-blocking
      // Use Promise.resolve() instead of setImmediate for better deployment compatibility
      Promise.resolve()
        .then(async () => {
          if (process.env.NODE_ENV !== "production") {
            log("Starting background database initialization...");
            try {
              const { initializeDatabase } = await import("./startup");
              await initializeDatabase({ skipSeeding: false });
              log("✅ Database initialization completed");
            } catch (error: any) {
              log(`❌ Database initialization failed: ${error.message}`);
            }
          } else {
            // In production, just verify database connection without seeding
            try {
              const { quickDatabaseCheck } = await import("./startup");
              const connected = await quickDatabaseCheck();
              log(
                `📊 Database connection check: ${connected ? "OK" : "Failed"}`,
              );
            } catch (error: any) {
              log(`❌ Database check failed: ${error.message}`);
            }
          }
        })
        .catch((error) => {
          log(`❌ Background database initialization error: ${error.message}`);
        });
    });

    // Minimal error handling - let deployment platform manage lifecycle
    process.on("uncaughtException", (error) => {
      log(`Uncaught Exception: ${error.message}`);
      // Continue running - deployment platform handles process lifecycle
    });

    process.on("unhandledRejection", (reason, promise) => {
      log(`Unhandled Rejection: ${reason}`);
      // Continue running - deployment platform handles process lifecycle
    });
  } catch (error: any) {
    log(`Failed to start server: ${error?.message || String(error)}`);
    // In production, exit cleanly on startup failure
    if (process.env.NODE_ENV === "production") {
      process.exit(1);
    } else {
      // In development, keep alive for debugging
      setTimeout(() => {
        log("Server startup failed, but keeping process alive for debugging");
      }, 1000);
    }
  }
})();
