import { db } from "../db";
import { strains } from "@shared/schema";
import { eq } from "drizzle-orm";

/**
 * Service for managing strain images
 */
export class StrainImageService {
  
  /**
   * Generate placeholder strain images using a consistent system
   */
  static generatePlaceholderImageUrl(strainName: string, strainType: string): string {
    // Use a placeholder service that generates cannabis-themed images
    const encodedName = encodeURIComponent(strainName);
    const colorScheme = this.getColorSchemeForType(strainType);
    
    // Using picsum.photos with seed for consistent images
    const seed = this.generateSeedFromName(strainName);
    return `https://picsum.photos/seed/${seed}/400/300`;
  }

  /**
   * Generate SVG placeholder for strains
   */
  static generateSVGPlaceholder(strainName: string, strainType: string): string {
    const colors = this.getColorSchemeForType(strainType);
    const initials = strainName.split(' ').map(word => word[0]).join('').toUpperCase().slice(0, 2);
    
    return `data:image/svg+xml;charset=UTF-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='300' viewBox='0 0 400 300'%3E%3Cdefs%3E%3ClinearGradient id='grad' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:${colors.primary};stop-opacity:1' /%3E%3Cstop offset='100%25' style='stop-color:${colors.secondary};stop-opacity:1' /%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='400' height='300' fill='url(%23grad)'/%3E%3Ctext x='200' y='130' font-family='Arial, sans-serif' font-size='24' fill='white' text-anchor='middle' font-weight='bold'%3E${initials}%3C/text%3E%3Ctext x='200' y='160' font-family='Arial, sans-serif' font-size='14' fill='white' text-anchor='middle' opacity='0.8'%3E${strainType.toUpperCase()}%3C/text%3E%3Cpath d='M180 180 Q200 160 220 180 Q240 200 220 220 Q200 240 180 220 Q160 200 180 180' fill='white' opacity='0.3'/%3E%3C/svg%3E`;
  }

  /**
   * Get color scheme based on strain type
   */
  private static getColorSchemeForType(strainType: string): { primary: string; secondary: string } {
    switch (strainType.toLowerCase()) {
      case 'indica':
        return { primary: '%23642ca3', secondary: '%239333ea' }; // Purple gradient
      case 'sativa':
        return { primary: '%2316a34a', secondary: '%2322c55e' }; // Green gradient
      case 'hybrid':
      default:
        return { primary: '%232563eb', secondary: '%233b82f6' }; // Blue gradient
    }
  }

  /**
   * Generate consistent seed from strain name
   */
  private static generateSeedFromName(strainName: string): string {
    let hash = 0;
    for (let i = 0; i < strainName.length; i++) {
      const char = strainName.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString();
  }

  /**
   * Update all strains with placeholder images
   */
  static async addPlaceholderImages(): Promise<{ updated: number; errors: number }> {
    try {
      const allStrains = await db.select({
        id: strains.id,
        name: strains.name,
        type: strains.type
      }).from(strains);

      let updated = 0;
      let errors = 0;

      for (const strain of allStrains) {
        try {
          const imageUrl = this.generateSVGPlaceholder(strain.name, strain.type);
          
          await db
            .update(strains)
            .set({ imageUrl })
            .where(eq(strains.id, strain.id));
          
          updated++;
        } catch (error) {
          console.error(`Failed to update image for strain ${strain.name}:`, error);
          errors++;
        }
      }

      return { updated, errors };
    } catch (error) {
      console.error('Failed to add placeholder images:', error);
      throw error;
    }
  }

  /**
   * Update specific strain with custom image URL
   */
  static async updateStrainImage(strainId: number, imageUrl: string): Promise<void> {
    await db
      .update(strains)
      .set({ imageUrl })
      .where(eq(strains.id, strainId));
  }

  /**
   * Get featured strain images for popular strains
   */
  static getFeaturedStrainImages(): Record<string, string> {
    return {
      'Blue Dream': 'https://images.unsplash.com/photo-1595017594839-78a6c6a0defe?w=400&h=300&fit=crop',
      'Purple Punch': 'https://images.unsplash.com/photo-1618255566002-4a4a4fdfaa58?w=400&h=300&fit=crop',
      'Wedding Cake': 'https://images.unsplash.com/photo-1604829568980-c7aa6a3d12e1?w=400&h=300&fit=crop',
      'Green Crack': 'https://images.unsplash.com/photo-1585146919979-7ad1ead2a9b7?w=400&h=300&fit=crop',
      'OG Kush': 'https://images.unsplash.com/photo-1582497669556-d3dc6b4c7b1b?w=400&h=300&fit=crop',
      'Girl Scout Cookies': 'https://images.unsplash.com/photo-1609065881700-18429ca32c65?w=400&h=300&fit=crop',
      'White Widow': 'https://images.unsplash.com/photo-1605127036077-2ea47fef7c70?w=400&h=300&fit=crop',
      'Granddaddy Purple': 'https://images.unsplash.com/photo-1613244111993-ca9ba0e2e972?w=400&h=300&fit=crop'
    };
  }

  /**
   * Update popular strains with curated images
   */
  static async updateFeaturedStrainImages(): Promise<{ updated: number; notFound: number }> {
    const featuredImages = this.getFeaturedStrainImages();
    let updated = 0;
    let notFound = 0;

    for (const [strainName, imageUrl] of Object.entries(featuredImages)) {
      try {
        const [strain] = await db
          .select({ id: strains.id })
          .from(strains)
          .where(eq(strains.name, strainName))
          .limit(1);

        if (strain) {
          await this.updateStrainImage(strain.id, imageUrl);
          updated++;
        } else {
          notFound++;
        }
      } catch (error) {
        console.error(`Failed to update featured image for ${strainName}:`, error);
      }
    }

    return { updated, notFound };
  }
}