import { getTerpeneInfo, getAllTerpenes, TerpeneInfo } from '../data/terpenes';

export interface TerpeneMapping {
  terpene: string;
  percentage: number;
  effects: string[];
  musicalCharacteristics: string[];
  weight: number;
}

export class TerpeneService {
  // Map terpene profile to musical characteristics
  public static mapTerpenesToMusic(terpenes: Array<{name: string, percentage: number}>): {
    primaryGenres: string[];
    secondaryGenres: string[];
    mood: string;
    energy: number;
    tempo: string;
  } {
    const mappings: TerpeneMapping[] = [];
    let totalWeight = 0;

    // Create weighted mappings for each terpene
    terpenes.forEach(terpene => {
      const info = getTerpeneInfo(terpene.name);
      if (info) {
        const weight = terpene.percentage * 100; // Convert to weight
        mappings.push({
          terpene: terpene.name,
          percentage: terpene.percentage,
          effects: info.effects,
          musicalCharacteristics: info.musicalCharacteristics,
          weight
        });
        totalWeight += weight;
      }
    });

    // Determine primary and secondary genres based on weighted terpenes
    const genreWeights: Record<string, number> = {};
    const effectWeights: Record<string, number> = {};

    mappings.forEach(mapping => {
      const normalizedWeight = mapping.weight / totalWeight;
      
      // Weight musical characteristics
      mapping.musicalCharacteristics.forEach(genre => {
        genreWeights[genre] = (genreWeights[genre] || 0) + normalizedWeight;
      });

      // Weight effects for mood determination
      mapping.effects.forEach(effect => {
        effectWeights[effect] = (effectWeights[effect] || 0) + normalizedWeight;
      });
    });

    // Sort genres by weight
    const sortedGenres = Object.entries(genreWeights)
      .sort(([, a], [, b]) => b - a)
      .map(([genre]) => genre);

    // Determine mood based on dominant effects
    const mood = this.determineMood(effectWeights);
    
    // Determine energy level (0-100)
    const energy = this.calculateEnergyLevel(effectWeights);
    
    // Determine tempo
    const tempo = this.determineTempo(energy);

    return {
      primaryGenres: sortedGenres.slice(0, 3),
      secondaryGenres: sortedGenres.slice(3, 6),
      mood,
      energy,
      tempo
    };
  }

  private static determineMood(effectWeights: Record<string, number>): string {
    const relaxingEffects = ['sedating', 'relaxing', 'calming', 'sleep-inducing'];
    const upliftingEffects = ['uplifting', 'energizing', 'mood-boosting', 'euphoric'];
    const focusEffects = ['alertness', 'focus', 'memory-retention'];

    let relaxingScore = 0;
    let upliftingScore = 0;
    let focusScore = 0;

    Object.entries(effectWeights).forEach(([effect, weight]) => {
      if (relaxingEffects.includes(effect)) relaxingScore += weight;
      if (upliftingEffects.includes(effect)) upliftingScore += weight;
      if (focusEffects.includes(effect)) focusScore += weight;
    });

    if (relaxingScore > upliftingScore && relaxingScore > focusScore) {
      return 'relaxing';
    } else if (upliftingScore > focusScore) {
      return 'uplifting';
    } else {
      return 'focused';
    }
  }

  private static calculateEnergyLevel(effectWeights: Record<string, number>): number {
    const energizingEffects = ['energizing', 'uplifting', 'alertness', 'focus'];
    const relaxingEffects = ['sedating', 'relaxing', 'calming', 'sleep-inducing'];

    let energyScore = 0;
    let relaxationScore = 0;

    Object.entries(effectWeights).forEach(([effect, weight]) => {
      if (energizingEffects.includes(effect)) energyScore += weight;
      if (relaxingEffects.includes(effect)) relaxationScore += weight;
    });

    // Convert to 0-100 scale
    const netEnergy = energyScore - relaxationScore;
    return Math.max(0, Math.min(100, 50 + (netEnergy * 50)));
  }

  private static determineTempo(energy: number): string {
    if (energy < 30) return 'slow';
    if (energy < 70) return 'medium';
    return 'fast';
  }

  // Get Spotify genre seeds based on terpene profile
  public static getSpotifyGenreSeeds(terpenes: Array<{name: string, percentage: number}>): string[] {
    const mapping = this.mapTerpenesToMusic(terpenes);
    
    // Map our genres to Spotify's available genre seeds
    const spotifyGenreMap: Record<string, string[]> = {
      'ambient': ['ambient', 'chill'],
      'downtempo': ['downtempo', 'chill'],
      'chill': ['chill', 'ambient'],
      'lo-fi': ['chill', 'indie'],
      'meditation': ['ambient', 'new-age'],
      'spa': ['ambient', 'new-age'],
      'upbeat': ['pop', 'dance'],
      'pop': ['pop', 'dance-pop'],
      'electronic': ['electronic', 'electro'],
      'dance': ['dance', 'edm'],
      'tropical': ['tropical-house', 'latin'],
      'happy': ['pop', 'funk'],
      'instrumental': ['instrumental', 'classical'],
      'focus': ['focus', 'study'],
      'study': ['study', 'classical'],
      'classical': ['classical', 'piano'],
      'jazz': ['jazz', 'smooth-jazz'],
      'blues': ['blues', 'r-n-b'],
      'rock': ['rock', 'alternative'],
      'alternative': ['alternative', 'indie'],
      'indie': ['indie', 'indie-pop'],
      'folk': ['folk', 'acoustic'],
      'country': ['country', 'bluegrass'],
      'acoustic': ['acoustic', 'singer-songwriter'],
      'reggae': ['reggae', 'dub'],
      'world': ['world-music', 'latin']
    };

    const spotifyGenres = new Set<string>();
    
    // Add genres from primary characteristics
    mapping.primaryGenres.forEach(genre => {
      const spotifyEquivalents = spotifyGenreMap[genre];
      if (spotifyEquivalents) {
        spotifyEquivalents.forEach(sg => spotifyGenres.add(sg));
      }
    });

    // Limit to 5 genres (Spotify API limit)
    return Array.from(spotifyGenres).slice(0, 5);
  }

  // Get audio features for Spotify recommendations
  public static getSpotifyAudioFeatures(terpenes: Array<{name: string, percentage: number}>): {
    acousticness?: number;
    danceability?: number;
    energy?: number;
    instrumentalness?: number;
    liveness?: number;
    speechiness?: number;
    valence?: number;
  } {
    const mapping = this.mapTerpenesToMusic(terpenes);
    
    return {
      energy: mapping.energy / 100,
      valence: mapping.mood === 'uplifting' ? 0.8 : mapping.mood === 'relaxing' ? 0.3 : 0.5,
      danceability: mapping.energy > 70 ? 0.8 : mapping.energy < 30 ? 0.2 : 0.5,
      acousticness: mapping.primaryGenres.includes('acoustic') ? 0.8 : 0.3,
      instrumentalness: mapping.primaryGenres.includes('instrumental') ? 0.8 : 0.1,
      liveness: 0.1,
      speechiness: 0.1
    };
  }
}
