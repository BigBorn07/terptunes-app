import { db } from "../db";
import { badges, userBadges, userStats, terpeneProfiles, strains } from "@shared/schema";
import { eq, and, count, desc, sql } from "drizzle-orm";
import type { Badge, UserBadge, UserStats, InsertUserStats } from "@shared/schema";

interface BadgeRequirement {
  type: 'strain_discovery' | 'terpene_expert' | 'playlist_creator' | 'social_engagement' | 'knowledge_test';
  criteria: any;
}

interface TerpeneProgress {
  [terpeneName: string]: {
    discovered: number;
    required: number;
    strains: string[];
  };
}

export class GamificationService {
  /**
   * Initialize user stats when they first join
   */
  static async initializeUserStats(userId: string): Promise<UserStats> {
    const existingStats = await db.select().from(userStats).where(eq(userStats.userId, userId));
    
    if (existingStats.length > 0) {
      return existingStats[0];
    }

    const [newStats] = await db.insert(userStats).values({
      userId,
      level: 1,
      totalPoints: 0,
      strainsDiscovered: 0,
      playlistsCreated: 0,
      terpeneKnowledge: 0,
      socialScore: 0,
    }).returning();

    return newStats;
  }

  /**
   * Award a badge to a user and update their stats
   */
  static async awardBadge(userId: string, badgeId: number): Promise<boolean> {
    // Check if user already has this badge
    const existingBadge = await db.select().from(userBadges)
      .where(and(eq(userBadges.userId, userId), eq(userBadges.badgeId, badgeId)));
    
    if (existingBadge.length > 0) {
      return false; // Already has badge
    }

    // Get badge details
    const [badge] = await db.select().from(badges).where(eq(badges.id, badgeId));
    if (!badge) return false;

    // Award the badge
    await db.insert(userBadges).values({
      userId,
      badgeId,
    });

    // Update user stats with points
    await this.addPoints(userId, badge.points);
    
    return true;
  }

  /**
   * Add points to user and check for level up
   */
  static async addPoints(userId: string, points: number): Promise<{ leveledUp: boolean; newLevel?: number }> {
    const [stats] = await db.select().from(userStats).where(eq(userStats.userId, userId));
    if (!stats) {
      await this.initializeUserStats(userId);
      return { leveledUp: false };
    }

    const newTotalPoints = stats.totalPoints + points;
    const currentLevel = stats.level;
    const newLevel = this.calculateLevel(newTotalPoints);
    
    await db.update(userStats)
      .set({ 
        totalPoints: newTotalPoints,
        level: newLevel,
        lastActivityAt: new Date()
      })
      .where(eq(userStats.userId, userId));

    return {
      leveledUp: newLevel > currentLevel,
      newLevel: newLevel > currentLevel ? newLevel : undefined
    };
  }

  /**
   * Calculate user level based on total points
   */
  static calculateLevel(totalPoints: number): number {
    // Level formula: level = floor(sqrt(points/100)) + 1
    // This creates a curved progression: 100pts=level2, 400pts=level3, 900pts=level4, etc.
    return Math.floor(Math.sqrt(totalPoints / 100)) + 1;
  }

  /**
   * Track strain discovery and check for terpene badges
   */
  static async trackStrainDiscovery(userId: string, strainId: number): Promise<Badge[]> {
    const newBadges: Badge[] = [];
    
    // Update strain discovery count
    await db.update(userStats)
      .set({ 
        strainsDiscovered: sql`strains_discovered + 1`,
        lastActivityAt: new Date()
      })
      .where(eq(userStats.userId, userId));

    // Award points for strain discovery
    await this.addPoints(userId, 10);

    // Check for terpene-specific badges
    const terpeneProgress = await this.calculateTerpeneProgress(userId);
    const earnedBadges = await this.checkTerpeneBadges(userId, terpeneProgress);
    
    for (const badge of earnedBadges) {
      const awarded = await this.awardBadge(userId, badge.id);
      if (awarded) {
        newBadges.push(badge);
      }
    }

    // Check milestone badges
    const milestoneBadges = await this.checkMilestoneBadges(userId);
    for (const badge of milestoneBadges) {
      const awarded = await this.awardBadge(userId, badge.id);
      if (awarded) {
        newBadges.push(badge);
      }
    }

    return newBadges;
  }

  /**
   * Calculate user's progress on terpene discovery
   */
  static async calculateTerpeneProgress(userId: string): Promise<TerpeneProgress> {
    // Get all strains user has discovered (through playlist creation or viewing)
    // For now, we'll simulate this based on playlist data
    const userPlaylists = await db.query.playlists.findMany({
      where: (playlists, { eq }) => eq(playlists.userId, userId),
      with: {
        strain: {
          with: {
            terpeneProfiles: true
          }
        }
      }
    });

    const terpeneProgress: TerpeneProgress = {};
    const discoveredStrains = new Set<string>();

    // Process each playlist's strain
    for (const playlist of userPlaylists) {
      if (playlist.strain && playlist.strain.terpeneProfiles) {
        discoveredStrains.add(playlist.strain.name);
        
        for (const terpene of playlist.strain.terpeneProfiles) {
          const terpeneName = terpene.terpeneName;
          if (!terpeneProgress[terpeneName]) {
            terpeneProgress[terpeneName] = {
              discovered: 0,
              required: this.getTerpeneRequirement(terpeneName),
              strains: []
            };
          }
          
          if (!terpeneProgress[terpeneName].strains.includes(playlist.strain.name)) {
            terpeneProgress[terpeneName].discovered++;
            terpeneProgress[terpeneName].strains.push(playlist.strain.name);
          }
        }
      }
    }

    return terpeneProgress;
  }

  /**
   * Get the requirement threshold for terpene badges
   */
  static getTerpeneRequirement(terpeneName: string): number {
    const majorTerpenes = ['Myrcene', 'Limonene', 'Pinene', 'Linalool', 'Caryophyllene'];
    return majorTerpenes.includes(terpeneName) ? 5 : 3; // Major terpenes need 5 strains, others need 3
  }

  /**
   * Check which terpene badges the user has earned
   */
  static async checkTerpeneBadges(userId: string, progress: TerpeneProgress): Promise<Badge[]> {
    const earnedBadges: Badge[] = [];
    const allBadges = await db.select().from(badges).where(eq(badges.category, 'terpene'));
    
    for (const badge of allBadges) {
      const requirement = badge.requirement as BadgeRequirement;
      if (requirement.type === 'terpene_expert') {
        const terpeneName = requirement.criteria.terpene;
        const requiredCount = requirement.criteria.count;
        
        if (progress[terpeneName] && progress[terpeneName].discovered >= requiredCount) {
          earnedBadges.push(badge);
        }
      }
    }

    return earnedBadges;
  }

  /**
   * Check milestone badges (strain count, level, etc.)
   */
  static async checkMilestoneBadges(userId: string): Promise<Badge[]> {
    const earnedBadges: Badge[] = [];
    const [stats] = await db.select().from(userStats).where(eq(userStats.userId, userId));
    if (!stats) return earnedBadges;

    const allBadges = await db.select().from(badges).where(eq(badges.category, 'discovery'));
    
    for (const badge of allBadges) {
      const requirement = badge.requirement as BadgeRequirement;
      if (requirement.type === 'strain_discovery') {
        const requiredCount = requirement.criteria.count;
        
        if (stats.strainsDiscovered >= requiredCount) {
          earnedBadges.push(badge);
        }
      }
    }

    return earnedBadges;
  }

  /**
   * Get user's badges with details
   */
  static async getUserBadges(userId: string): Promise<(UserBadge & { badge: Badge })[]> {
    return await db.query.userBadges.findMany({
      where: eq(userBadges.userId, userId),
      with: {
        badge: true
      },
      orderBy: [desc(userBadges.earnedAt)]
    });
  }

  /**
   * Get user stats
   */
  static async getUserStats(userId: string): Promise<UserStats | null> {
    const [stats] = await db.select().from(userStats).where(eq(userStats.userId, userId));
    return stats || null;
  }

  /**
   * Get leaderboard
   */
  static async getLeaderboard(limit: number = 10): Promise<(UserStats & { badgeCount: number })[]> {
    const leaderboard = await db.select({
      ...userStats,
      badgeCount: count(userBadges.id)
    })
    .from(userStats)
    .leftJoin(userBadges, eq(userStats.userId, userBadges.userId))
    .groupBy(userStats.id)
    .orderBy(desc(userStats.totalPoints))
    .limit(limit);

    return leaderboard as any;
  }

  /**
   * Track playlist creation
   */
  static async trackPlaylistCreation(userId: string): Promise<Badge[]> {
    const newBadges: Badge[] = [];
    
    // Update playlist creation count
    await db.update(userStats)
      .set({ 
        playlistsCreated: sql`playlists_created + 1`,
        lastActivityAt: new Date()
      })
      .where(eq(userStats.userId, userId));

    // Award points for playlist creation
    await this.addPoints(userId, 25);

    // Check for playlist creation badges
    const milestoneBadges = await this.checkPlaylistBadges(userId);
    for (const badge of milestoneBadges) {
      const awarded = await this.awardBadge(userId, badge.id);
      if (awarded) {
        newBadges.push(badge);
      }
    }

    return newBadges;
  }

  /**
   * Check playlist creation milestone badges
   */
  static async checkPlaylistBadges(userId: string): Promise<Badge[]> {
    const earnedBadges: Badge[] = [];
    const [stats] = await db.select().from(userStats).where(eq(userStats.userId, userId));
    if (!stats) return earnedBadges;

    const allBadges = await db.select().from(badges).where(eq(badges.category, 'playlist'));
    
    for (const badge of allBadges) {
      const requirement = badge.requirement as BadgeRequirement;
      if (requirement.type === 'playlist_creator') {
        const requiredCount = requirement.criteria.count;
        
        if (stats.playlistsCreated >= requiredCount) {
          earnedBadges.push(badge);
        }
      }
    }

    return earnedBadges;
  }
}