import { db } from '../db';
import { strains } from '@shared/schema';
import { eq, isNull, or } from 'drizzle-orm';

export class StrainImageGenerator {
  /**
   * Generate high-quality placeholders for strains without images
   */
  static async generateMissingImages(): Promise<{ updated: number; skipped: number }> {
    let updated = 0;
    let skipped = 0;

    // Get strains without proper images
    const strainsWithoutImages = await db
      .select()
      .from(strains)
      .where(or(
        isNull(strains.imageUrl),
        eq(strains.imageUrl, '')
      ));

    console.log(`Found ${strainsWithoutImages.length} strains without images`);

    for (const strain of strainsWithoutImages) {
      try {
        const imageUrl = this.createStrainImage(strain.type as 'indica' | 'sativa' | 'hybrid', strain.name);
        
        await db
          .update(strains)
          .set({ imageUrl })
          .where(eq(strains.id, strain.id));
        
        updated++;
        console.log(`✅ Generated image for ${strain.name}`);
      } catch (error) {
        console.error(`Failed to generate image for ${strain.name}:`, error);
        skipped++;
      }
    }

    return { updated, skipped };
  }

  /**
   * Create high-quality cannabis bud SVG image
   */
  private static createStrainImage(type: 'indica' | 'sativa' | 'hybrid', name: string): string {
    const config = this.getStrainConfig(type);
    
    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300">
        <defs>
          <radialGradient id="mainBud" cx="50%" cy="45%" r="70%">
            <stop offset="0%" style="stop-color:${config.primary};stop-opacity:1" />
            <stop offset="40%" style="stop-color:${config.secondary};stop-opacity:1" />
            <stop offset="80%" style="stop-color:${config.dark};stop-opacity:1" />
            <stop offset="100%" style="stop-color:${config.darkest};stop-opacity:1" />
          </radialGradient>
          <radialGradient id="crystal" cx="30%" cy="30%" r="50%">
            <stop offset="0%" style="stop-color:#ffffff;stop-opacity:0.9" />
            <stop offset="100%" style="stop-color:#ffffff;stop-opacity:0.1" />
          </radialGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge> 
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        
        <!-- Background -->
        <rect width="400" height="300" fill="#0a0a0a"/>
        
        <!-- Main cannabis bud -->
        <ellipse cx="200" cy="150" rx="${config.width}" ry="${config.height}" fill="url(#mainBud)" filter="url(#glow)"/>
        
        <!-- Secondary buds -->
        <ellipse cx="${170 + config.offset}" cy="${130 - config.offset/2}" rx="${config.width * 0.55}" ry="${config.height * 0.5}" fill="${config.secondary}" opacity="0.9"/>
        <ellipse cx="${230 - config.offset}" cy="${170 + config.offset/2}" rx="${config.width * 0.45}" ry="${config.height * 0.4}" fill="${config.primary}" opacity="0.8"/>
        
        <!-- Trichomes (crystals) -->
        <ellipse cx="200" cy="135" rx="25" ry="20" fill="url(#crystal)"/>
        <ellipse cx="180" cy="155" rx="18" ry="15" fill="url(#crystal)"/>
        <ellipse cx="220" cy="145" rx="15" ry="12" fill="url(#crystal)"/>
        <ellipse cx="195" cy="170" rx="12" ry="10" fill="url(#crystal)"/>
        <ellipse cx="215" cy="165" rx="10" ry="8" fill="url(#crystal)"/>
        
        <!-- Orange pistils -->
        <path d="M185 140 Q190 135 195 140 Q200 145 195 150" stroke="#ff6b35" stroke-width="2" fill="none" opacity="0.7"/>
        <path d="M210 150 Q215 145 220 150 Q225 155 220 160" stroke="#ff8c42" stroke-width="1.5" fill="none" opacity="0.6"/>
        <path d="M175 160 Q180 155 185 160 Q190 165 185 170" stroke="#ff6b35" stroke-width="1.5" fill="none" opacity="0.5"/>
        
        <!-- Strain type label -->
        <text x="200" y="260" font-family="Arial, sans-serif" font-size="14" fill="${config.primary}" text-anchor="middle" font-weight="bold">${type.toUpperCase()}</text>
        
        <!-- Strain name (if space allows) -->
        <text x="200" y="280" font-family="Arial, sans-serif" font-size="10" fill="#888" text-anchor="middle" opacity="0.7">${name.length > 15 ? name.substring(0, 15) + '...' : name}</text>
      </svg>
    `;

    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
  }

  private static getStrainConfig(type: 'indica' | 'sativa' | 'hybrid') {
    switch (type) {
      case 'indica':
        return {
          primary: '#8b5cf6',
          secondary: '#7c3aed', 
          dark: '#6d28d9',
          darkest: '#581c87',
          width: 95,
          height: 80,
          offset: 15
        };
      case 'sativa':
        return {
          primary: '#22c55e',
          secondary: '#16a34a',
          dark: '#15803d', 
          darkest: '#166534',
          width: 85,
          height: 65,
          offset: 20
        };
      case 'hybrid':
        return {
          primary: '#10b981',
          secondary: '#3b82f6',
          dark: '#059669',
          darkest: '#047857',
          width: 90,
          height: 70,
          offset: 18
        };
    }
  }

  /**
   * Add featured strain images for popular strains
   */
  static async addFeaturedImages(): Promise<{ updated: number; failed: number }> {
    const featuredStrains = [
      { name: 'Blue Dream', url: '/strain-images/blue-dream.png' },
      { name: 'Purple Punch', url: 'https://images.leafly.com/flower-images/purple-punch.png' },
      { name: 'Wedding Cake', url: 'https://images.leafly.com/flower-images/wedding-cake.png' },
      { name: 'Girl Scout Cookies', url: 'https://images.leafly.com/flower-images/girl-scout-cookies.png' },
      { name: 'Gelato', url: 'https://images.leafly.com/flower-images/gelato.png' }
    ];

    let updated = 0;
    let failed = 0;

    for (const featured of featuredStrains) {
      try {
        const result = await db
          .update(strains)
          .set({ imageUrl: featured.url })
          .where(eq(strains.name, featured.name));
        
        if (result.rowCount && result.rowCount > 0) {
          updated++;
          console.log(`✅ Updated ${featured.name} with featured image`);
        } else {
          failed++;
          console.log(`❌ Strain not found: ${featured.name}`);
        }
      } catch (error) {
        failed++;
        console.error(`Failed to update ${featured.name}:`, error);
      }
    }

    return { updated, failed };
  }
}