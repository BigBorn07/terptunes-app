export interface CannlyticsStrain {
  id?: string;
  name: string;
  strain_type?: string;
  product_type?: string;
  sample_type?: string;
  
  // Cannabinoids
  cbc?: number;
  cbd?: number;
  cbda?: number;
  cbg?: number;
  cbga?: number;
  cbn?: number;
  delta_8_thc?: number;
  delta_9_thc?: number;
  thca?: number;
  thcv?: number;
  total_cannabinoids?: number;
  total_cbd?: number;
  total_cbg?: number;
  total_thc?: number;
  
  // Major Terpenes
  alpha_bisabolol?: number;
  alpha_pinene?: number;
  alpha_terpinene?: number;
  beta_caryophyllene?: number;
  beta_myrcene?: number;
  beta_pinene?: number;
  camphene?: number;
  carene?: number;
  caryophyllene_oxide?: number;
  d_limonene?: number;
  eucalyptol?: number;
  gamma_terpinene?: number;
  geraniol?: number;
  guaiol?: number;
  humulene?: number;
  isopulegol?: number;
  linalool?: number;
  nerolidol?: number;
  ocimene?: number;
  p_cymene?: number;
  terpinene?: number;
  terpinolene?: number;
  total_terpenes?: number;
  
  // Metadata
  lab?: string;
  date_tested?: string;
  batch?: string;
  producer?: string;
  created_at?: string;
  updated_at?: string;
}

export interface CannlyticsResponse {
  success: boolean;
  data: CannlyticsStrain[];
  next?: string;
  previous?: string;
  count?: number;
}

export class CannlyticsService {
  private static readonly API_BASE = 'https://cannlytics.com/api/data/strains';
  
  public static async getStrains(options: {
    limit?: number;
    offset?: number;
    strain_type?: string;
    min_total_thc?: number;
    max_total_thc?: number;
    min_total_cbd?: number;
    max_total_cbd?: number;
    has_terpenes?: boolean;
  } = {}): Promise<CannlyticsStrain[]> {
    try {
      const params = new URLSearchParams();
      
      if (options.limit) params.append('limit', options.limit.toString());
      if (options.offset) params.append('offset', options.offset.toString());
      if (options.strain_type) params.append('strain_type', options.strain_type);
      if (options.min_total_thc) params.append('total_thc', `g${options.min_total_thc}`);
      if (options.max_total_thc) params.append('total_thc', `l${options.max_total_thc}`);
      if (options.min_total_cbd) params.append('total_cbd', `g${options.min_total_cbd}`);
      if (options.max_total_cbd) params.append('total_cbd', `l${options.max_total_cbd}`);
      
      const url = `${this.API_BASE}?${params.toString()}`;
      console.log('Fetching strains from Cannlytics:', url);
      
      const response = await fetch(url, {
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'TerpTunes/1.0'
        }
      });
      
      if (!response.ok) {
        console.error('Cannlytics API error:', response.status, response.statusText);
        return [];
      }
      
      const result: CannlyticsResponse = await response.json();
      
      if (result.success && result.data) {
        console.log(`Successfully fetched ${result.data.length} strains from Cannlytics`);
        // Debug: log first strain to see data structure
        if (result.data.length > 0) {
          console.log('Sample strain data:', JSON.stringify(result.data[0], null, 2));
        }
        return result.data;
      }
      
      return [];
    } catch (error) {
      console.error('Error fetching from Cannlytics API:', error);
      return [];
    }
  }
  
  public static async getStrainByName(name: string): Promise<CannlyticsStrain | null> {
    try {
      const url = `${this.API_BASE}/${encodeURIComponent(name)}`;
      
      const response = await fetch(url, {
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'TerpTunes/1.0'
        }
      });
      
      if (!response.ok) {
        return null;
      }
      
      const result: CannlyticsResponse = await response.json();
      
      if (result.success && result.data && result.data.length > 0) {
        return result.data[0];
      }
      
      return null;
    } catch (error) {
      console.error('Error fetching strain from Cannlytics:', error);
      return null;
    }
  }
  
  public static mapToTerpTunesStrain(cannlyticsStrain: CannlyticsStrain): {
    strain: any;
    terpenes: Array<{ name: string; percentage: number }>;
  } {
    // Map strain type
    let type: 'indica' | 'sativa' | 'hybrid' = 'hybrid';
    if (cannlyticsStrain.strain_type) {
      const strainType = cannlyticsStrain.strain_type.toLowerCase();
      if (strainType.includes('indica')) type = 'indica';
      else if (strainType.includes('sativa')) type = 'sativa';
    }
    
    // Extract terpenes with their percentages
    const terpenes: Array<{ name: string; percentage: number }> = [];
    const terpeneMap = {
      'alpha_bisabolol': 'Alpha-Bisabolol',
      'alpha_pinene': 'Alpha-Pinene',
      'alpha_terpinene': 'Alpha-Terpinene',
      'beta_caryophyllene': 'Beta-Caryophyllene',
      'beta_myrcene': 'Myrcene',
      'beta_pinene': 'Beta-Pinene',
      'camphene': 'Camphene',
      'carene': 'Carene',
      'caryophyllene_oxide': 'Caryophyllene Oxide',
      'd_limonene': 'Limonene',
      'eucalyptol': 'Eucalyptol',
      'gamma_terpinene': 'Gamma-Terpinene',
      'geraniol': 'Geraniol',
      'guaiol': 'Guaiol',
      'humulene': 'Humulene',
      'isopulegol': 'Isopulegol',
      'linalool': 'Linalool',
      'nerolidol': 'Nerolidol',
      'ocimene': 'Ocimene',
      'p_cymene': 'P-Cymene',
      'terpinene': 'Terpinene',
      'terpinolene': 'Terpinolene'
    };
    
    Object.entries(terpeneMap).forEach(([key, name]) => {
      const value = (cannlyticsStrain as any)[key];
      if (value && value > 0) {
        terpenes.push({
          name,
          percentage: parseFloat(value.toString())
        });
      }
    });
    
    // Sort terpenes by percentage, highest first
    terpenes.sort((a, b) => b.percentage - a.percentage);
    
    // Generate effects based on strain type and dominant terpenes
    const effects = this.generateEffectsFromTerpenes(type, terpenes);
    const flavors = this.generateFlavorsFromTerpenes(terpenes);
    
    const strain = {
      name: cannlyticsStrain.name,
      type,
      thcContent: cannlyticsStrain.total_thc?.toFixed(2) || '0',
      cbdContent: cannlyticsStrain.total_cbd?.toFixed(2) || '0',
      description: this.generateDescription(cannlyticsStrain.name, type, terpenes),
      effects,
      flavors,
      imageUrl: null
    };
    
    return { strain, terpenes };
  }
  
  private static generateEffectsFromTerpenes(type: 'indica' | 'sativa' | 'hybrid', terpenes: Array<{ name: string; percentage: number }>): string[] {
    const effects: string[] = [];
    
    // Base effects by strain type
    if (type === 'indica') {
      effects.push('Relaxed', 'Sleepy', 'Happy');
    } else if (type === 'sativa') {
      effects.push('Energetic', 'Uplifted', 'Creative');
    } else {
      effects.push('Balanced', 'Happy', 'Relaxed');
    }
    
    // Add effects based on dominant terpenes
    const dominantTerpenes = terpenes.slice(0, 3);
    dominantTerpenes.forEach(terpene => {
      switch (terpene.name.toLowerCase()) {
        case 'myrcene':
          if (!effects.includes('Sedating')) effects.push('Sedating');
          break;
        case 'limonene':
          if (!effects.includes('Euphoric')) effects.push('Euphoric');
          break;
        case 'beta-caryophyllene':
          if (!effects.includes('Anti-inflammatory')) effects.push('Anti-inflammatory');
          break;
        case 'linalool':
          if (!effects.includes('Calming')) effects.push('Calming');
          break;
        case 'alpha-pinene':
          if (!effects.includes('Focused')) effects.push('Focused');
          break;
        case 'humulene':
          if (!effects.includes('Appetite Suppressant')) effects.push('Appetite Suppressant');
          break;
      }
    });
    
    return effects.slice(0, 5); // Limit to 5 effects
  }
  
  private static generateFlavorsFromTerpenes(terpenes: Array<{ name: string; percentage: number }>): string[] {
    const flavors: string[] = [];
    
    terpenes.slice(0, 5).forEach(terpene => {
      switch (terpene.name.toLowerCase()) {
        case 'myrcene':
          flavors.push('Earthy', 'Musky');
          break;
        case 'limonene':
          flavors.push('Citrus', 'Lemon');
          break;
        case 'beta-caryophyllene':
          flavors.push('Spicy', 'Peppery');
          break;
        case 'linalool':
          flavors.push('Floral', 'Lavender');
          break;
        case 'alpha-pinene':
          flavors.push('Pine', 'Fresh');
          break;
        case 'beta-pinene':
          flavors.push('Pine', 'Woody');
          break;
        case 'humulene':
          flavors.push('Hoppy', 'Woody');
          break;
        case 'terpinolene':
          flavors.push('Herbal', 'Floral');
          break;
        case 'ocimene':
          flavors.push('Sweet', 'Herbal');
          break;
      }
    });
    
    // Remove duplicates and limit to 4 flavors
    return Array.from(new Set(flavors)).slice(0, 4);
  }
  
  private static generateDescription(name: string, type: string, terpenes: Array<{ name: string; percentage: number }>): string {
    const dominantTerpene = terpenes[0]?.name || 'terpenes';
    const typeDescription = type === 'indica' ? 'relaxing indica' : 
                           type === 'sativa' ? 'energizing sativa' : 
                           'balanced hybrid';
    
    return `${name} is a ${typeDescription} strain with a dominant ${dominantTerpene.toLowerCase()} profile. This strain offers a unique terpene combination that creates distinctive effects and flavors, making it perfect for personalized music playlist generation.`;
  }
}