import { db } from '../db';
import { userStrainHistory, brandAmbassadors, brandExclusives, brands, strains } from '@shared/schema';
import { eq, desc, count, sql } from 'drizzle-orm';
import type { BrandAmbassador, InsertBrandAmbassador, BrandExclusive } from '@shared/schema';

interface BrandConsumption {
  brandId: number;
  brandName: string;
  strainCount: number;
  isQualified: boolean;
  ambassadorLevel?: string;
  strains: Array<{
    id: number;
    name: string;
    consumedAt: Date;
    rating?: number;
  }>;
}

interface AmbassadorStats {
  totalBrands: number;
  qualifiedBrands: number;
  totalStrains: number;
  ambassadorships: BrandAmbassador[];
  exclusiveRewards: number;
}

interface ExclusiveReward {
  id: number;
  title: string;
  description: string;
  type: string;
  value: string;
  brandName: string;
  validUntil?: Date;
}

export class BrandAmbassadorService {
  
  /**
   * Record a user consuming a strain, tracking brand consumption
   */
  static async recordStrainConsumption(
    userId: string, 
    strainId: number, 
    rating?: number, 
    notes?: string
  ): Promise<void> {
    try {
      // Get strain details including brand
      const strain = await db
        .select({
          id: strains.id,
          brandId: strains.brandId,
        })
        .from(strains)
        .where(eq(strains.id, strainId))
        .limit(1);

      if (!strain[0] || !strain[0].brandId) {
        console.log(`Strain ${strainId} not found or has no brand`);
        return;
      }

      // Record consumption
      await db.insert(userStrainHistory).values({
        userId,
        strainId,
        brandId: strain[0].brandId,
        rating,
        notes,
        consumedAt: new Date(),
      });

      // Check if user qualifies for brand ambassador status
      await this.checkAndUpdateAmbassadorStatus(userId, strain[0].brandId);
      
    } catch (error) {
      console.error('Error recording strain consumption:', error);
      throw error;
    }
  }

  /**
   * Check if user qualifies for brand ambassador status and update accordingly
   */
  static async checkAndUpdateAmbassadorStatus(userId: string, brandId: number): Promise<void> {
    try {
      // Count unique strains from this brand
      const strainCount = await db
        .select({ count: count() })
        .from(userStrainHistory)
        .where(
          sql`${userStrainHistory.userId} = ${userId} AND ${userStrainHistory.brandId} = ${brandId}`
        );

      const totalStrains = strainCount[0]?.count || 0;

      // Check if user already has ambassador status for this brand
      const existingAmbassador = await db
        .select()
        .from(brandAmbassadors)
        .where(
          sql`${brandAmbassadors.userId} = ${userId} AND ${brandAmbassadors.brandId} = ${brandId}`
        )
        .limit(1);

      if (totalStrains >= 10) {
        // Determine ambassador level based on strain count
        const level = this.calculateAmbassadorLevel(totalStrains);
        
        if (existingAmbassador.length > 0) {
          // Update existing ambassador status
          await db
            .update(brandAmbassadors)
            .set({
              totalStrains,
              ambassadorLevel: level,
              exclusiveAccess: true,
              updatedAt: new Date(),
            })
            .where(eq(brandAmbassadors.id, existingAmbassador[0].id));
        } else {
          // Create new ambassador status
          await db.insert(brandAmbassadors).values({
            userId,
            brandId,
            totalStrains,
            ambassadorLevel: level,
            exclusiveAccess: true,
            status: 'active',
          });
        }
      }
    } catch (error) {
      console.error('Error checking ambassador status:', error);
      throw error;
    }
  }

  /**
   * Calculate ambassador level based on strain count
   */
  private static calculateAmbassadorLevel(strainCount: number): string {
    if (strainCount >= 50) return 'platinum';
    if (strainCount >= 30) return 'gold';
    if (strainCount >= 20) return 'silver';
    return 'bronze';
  }

  /**
   * Get user's brand consumption summary
   */
  static async getUserBrandConsumption(userId: string): Promise<BrandConsumption[]> {
    try {
      // Get all brands user has consumed strains from
      const brandConsumption = await db
        .select({
          brandId: userStrainHistory.brandId,
          brandName: brands.name,
          strainId: strains.id,
          strainName: strains.name,
          consumedAt: userStrainHistory.consumedAt,
          rating: userStrainHistory.rating,
        })
        .from(userStrainHistory)
        .innerJoin(brands, eq(userStrainHistory.brandId, brands.id))
        .innerJoin(strains, eq(userStrainHistory.strainId, strains.id))
        .where(eq(userStrainHistory.userId, userId))
        .orderBy(desc(userStrainHistory.consumedAt));

      // Group by brand and calculate counts
      const brandMap = new Map<number, BrandConsumption>();
      
      for (const record of brandConsumption) {
        if (!record.brandId) continue;
        
        if (!brandMap.has(record.brandId)) {
          brandMap.set(record.brandId, {
            brandId: record.brandId,
            brandName: record.brandName,
            strainCount: 0,
            isQualified: false,
            strains: [],
          });
        }
        
        const brand = brandMap.get(record.brandId)!;
        brand.strainCount++;
        brand.strains.push({
          id: record.strainId,
          name: record.strainName,
          consumedAt: record.consumedAt || new Date(),
          rating: record.rating || undefined,
        });
        
        // Check if qualified for ambassador status
        brand.isQualified = brand.strainCount >= 10;
        if (brand.isQualified) {
          brand.ambassadorLevel = this.calculateAmbassadorLevel(brand.strainCount);
        }
      }

      return Array.from(brandMap.values());
    } catch (error) {
      console.error('Error getting brand consumption:', error);
      throw error;
    }
  }

  /**
   * Get user's ambassador status and stats
   */
  static async getUserAmbassadorStats(userId: string): Promise<AmbassadorStats> {
    try {
      // Get ambassador statuses
      const ambassadorships = await db
        .select({
          id: brandAmbassadors.id,
          userId: brandAmbassadors.userId,
          brandId: brandAmbassadors.brandId,
          status: brandAmbassadors.status,
          totalStrains: brandAmbassadors.totalStrains,
          ambassadorLevel: brandAmbassadors.ambassadorLevel,
          exclusiveAccess: brandAmbassadors.exclusiveAccess,
          qualifiedAt: brandAmbassadors.qualifiedAt,
          createdAt: brandAmbassadors.createdAt,
          updatedAt: brandAmbassadors.updatedAt,
        })
        .from(brandAmbassadors)
        .where(eq(brandAmbassadors.userId, userId));

      // Get total unique brands consumed
      const totalBrands = await db
        .selectDistinct({ brandId: userStrainHistory.brandId })
        .from(userStrainHistory)
        .where(eq(userStrainHistory.userId, userId));

      // Get total strains consumed
      const totalStrains = await db
        .select({ count: count() })
        .from(userStrainHistory)
        .where(eq(userStrainHistory.userId, userId));

      // Count available exclusive rewards
      const exclusiveCount = await db
        .select({ count: count() })
        .from(brandExclusives)
        .innerJoin(brandAmbassadors, eq(brandExclusives.brandId, brandAmbassadors.brandId))
        .where(
          sql`${brandAmbassadors.userId} = ${userId} AND ${brandExclusives.isActive} = true`
        );

      return {
        totalBrands: totalBrands.length,
        qualifiedBrands: ambassadorships.length,
        totalStrains: totalStrains[0]?.count || 0,
        ambassadorships,
        exclusiveRewards: exclusiveCount[0]?.count || 0,
      };
    } catch (error) {
      console.error('Error getting ambassador stats:', error);
      throw error;
    }
  }

  /**
   * Get exclusive rewards for user's ambassador brands
   */
  static async getUserExclusiveRewards(userId: string): Promise<ExclusiveReward[]> {
    try {
      const rewards = await db
        .select({
          id: brandExclusives.id,
          title: brandExclusives.title,
          description: brandExclusives.description,
          type: brandExclusives.type,
          value: brandExclusives.value,
          brandName: brands.name,
          validUntil: brandExclusives.validUntil,
          minimumLevel: brandExclusives.minimumLevel,
          ambassadorLevel: brandAmbassadors.ambassadorLevel,
        })
        .from(brandExclusives)
        .innerJoin(brandAmbassadors, eq(brandExclusives.brandId, brandAmbassadors.brandId))
        .innerJoin(brands, eq(brandExclusives.brandId, brands.id))
        .where(
          sql`${brandAmbassadors.userId} = ${userId} 
              AND ${brandExclusives.isActive} = true
              AND ${brandAmbassadors.exclusiveAccess} = true`
        )
        .orderBy(desc(brandExclusives.createdAt));

      return rewards
        .filter(reward => this.meetsLevelRequirement(reward.ambassadorLevel, reward.minimumLevel))
        .map(reward => ({
          id: reward.id,
          title: reward.title,
          description: reward.description || '',
          type: reward.type,
          value: reward.value || '',
          brandName: reward.brandName,
          validUntil: reward.validUntil || undefined,
        }));
    } catch (error) {
      console.error('Error getting exclusive rewards:', error);
      throw error;
    }
  }

  /**
   * Check if user's ambassador level meets reward requirement
   */
  private static meetsLevelRequirement(userLevel: string | null, requiredLevel: string | null): boolean {
    const levels = ['bronze', 'silver', 'gold', 'platinum'];
    const userLevelIndex = levels.indexOf(userLevel || 'bronze');
    const requiredLevelIndex = levels.indexOf(requiredLevel || 'bronze');
    return userLevelIndex >= requiredLevelIndex;
  }

  /**
   * Get brands that need strains for ambassador qualification
   */
  static async getNearQualificationBrands(userId: string): Promise<Array<{
    brandId: number;
    brandName: string;
    currentStrains: number;
    needed: number;
  }>> {
    try {
      const consumption = await this.getUserBrandConsumption(userId);
      
      return consumption
        .filter(brand => !brand.isQualified && brand.strainCount >= 5) // Show brands with 5+ strains
        .map(brand => ({
          brandId: brand.brandId,
          brandName: brand.brandName,
          currentStrains: brand.strainCount,
          needed: 10 - brand.strainCount,
        }))
        .sort((a, b) => a.needed - b.needed); // Sort by closest to qualification
    } catch (error) {
      console.error('Error getting near qualification brands:', error);
      throw error;
    }
  }
}