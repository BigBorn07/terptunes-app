/**
 * Role-based Access Control Service
 * Manages user permissions and verification status for TerpTunes platform
 */

import { db } from "../db";
import { users, userOnboarding } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import type { User } from "@shared/schema";

export interface AccessPermissions {
  canAccessGrowerPortal: boolean;
  canAccessDispensaryPortal: boolean;
  canUploadStrains: boolean;
  canCreatePlaylists: boolean;
  canAccessAdminPanel: boolean;
  canVerifyUsers: boolean;
  requiresVerification: boolean;
}

export class RoleAccessService {
  /**
   * Get user permissions based on their role and verification status
   */
  static getUserPermissions(user: User): AccessPermissions {
    const userType = user.userType || 'consumer';
    const isVerified = user.verificationStatus === 'verified';
    const onboardingComplete = user.onboardingCompleted || false;

    const basePermissions: AccessPermissions = {
      canAccessGrowerPortal: false,
      canAccessDispensaryPortal: false,
      canUploadStrains: false,
      canCreatePlaylists: true, // All users can create playlists
      canAccessAdminPanel: false,
      canVerifyUsers: false,
      requiresVerification: false,
    };

    switch (userType) {
      case 'consumer':
        return {
          ...basePermissions,
          canCreatePlaylists: onboardingComplete,
        };

      case 'grower':
        return {
          ...basePermissions,
          canAccessGrowerPortal: onboardingComplete,
          canUploadStrains: isVerified && onboardingComplete,
          requiresVerification: !isVerified,
        };

      case 'dispensary':
        return {
          ...basePermissions,
          canAccessDispensaryPortal: onboardingComplete,
          requiresVerification: !isVerified,
        };

      case 'admin':
        return {
          ...basePermissions,
          canAccessGrowerPortal: true,
          canAccessDispensaryPortal: true,
          canUploadStrains: true,
          canAccessAdminPanel: true,
          canVerifyUsers: true,
        };

      default:
        return basePermissions;
    }
  }

  /**
   * Check if user can access a specific resource
   */
  static async canAccessResource(userId: string, resource: string): Promise<boolean> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    if (!user) return false;

    const permissions = this.getUserPermissions(user);

    switch (resource) {
      case 'grower-portal':
        return permissions.canAccessGrowerPortal;
      case 'dispensary-portal':
        return permissions.canAccessDispensaryPortal;
      case 'strain-upload':
        return permissions.canUploadStrains;
      case 'admin-panel':
        return permissions.canAccessAdminPanel;
      default:
        return true; // Allow access to public resources
    }
  }

  /**
   * Get user's onboarding status and next steps
   */
  static async getOnboardingStatus(userId: string): Promise<{
    currentStep: string;
    completed: boolean;
    nextSteps: string[];
    requiredActions: string[];
  }> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    if (!user) {
      throw new Error('User not found');
    }

    const onboardingSteps = await db
      .select()
      .from(userOnboarding)
      .where(eq(userOnboarding.userId, userId));

    const completedSteps = onboardingSteps
      .filter(step => step.completed)
      .map(step => step.step);

    const allSteps = ['user_type', 'preferences', 'verification', 'tutorial'];
    const nextSteps = allSteps.filter(step => !completedSteps.includes(step));
    
    const userType = user.userType || 'consumer';
    const requiresVerification = ['grower', 'dispensary'].includes(userType);
    const requiredActions: string[] = [];

    if (requiresVerification && user.verificationStatus !== 'verified') {
      requiredActions.push('business_verification');
    }

    return {
      currentStep: nextSteps[0] || 'completed',
      completed: user.onboardingCompleted || false,
      nextSteps,
      requiredActions,
    };
  }

  /**
   * Update user's onboarding progress
   */
  static async updateOnboardingStep(
    userId: string, 
    step: string, 
    data?: any
  ): Promise<void> {
    await db
      .insert(userOnboarding)
      .values({
        userId,
        step,
        completed: true,
        completedAt: new Date(),
        data: data || null,
      })
      .onConflictDoUpdate({
        target: [userOnboarding.userId, userOnboarding.step],
        set: {
          completed: true,
          completedAt: new Date(),
          data: data || null,
        },
      });

    // Check if all steps are completed
    const onboardingSteps = await db
      .select()
      .from(userOnboarding)
      .where(and(
        eq(userOnboarding.userId, userId),
        eq(userOnboarding.completed, true)
      ));

    const requiredSteps = ['user_type', 'preferences', 'tutorial'];
    const completedStepNames = onboardingSteps.map(s => s.step);
    const allRequired = requiredSteps.every(step => completedStepNames.includes(step));

    if (allRequired) {
      await db
        .update(users)
        .set({ 
          onboardingCompleted: true,
          updatedAt: new Date(),
        })
        .where(eq(users.id, userId));
    }
  }

  /**
   * Submit verification request for business users
   */
  static async submitVerificationRequest(
    userId: string,
    businessData: {
      businessName: string;
      businessLicense: string;
      businessAddress: string;
      businessPhone: string;
      businessWebsite?: string;
      documents?: string[];
    }
  ): Promise<void> {
    await db
      .update(users)
      .set({
        businessName: businessData.businessName,
        businessLicense: businessData.businessLicense,
        businessAddress: businessData.businessAddress,
        businessPhone: businessData.businessPhone,
        businessWebsite: businessData.businessWebsite,
        verificationDocuments: businessData.documents || [],
        verificationStatus: 'pending',
        accountStatus: 'pending_verification',
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));

    // Mark verification step as completed
    await this.updateOnboardingStep(userId, 'verification', businessData);
  }

  /**
   * Update user type during onboarding
   */
  static async updateUserType(userId: string, userType: 'consumer' | 'grower' | 'dispensary'): Promise<void> {
    await db
      .update(users)
      .set({
        userType,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));

    await this.updateOnboardingStep(userId, 'user_type', { userType });
  }

  /**
   * Admin function to verify/reject business users
   */
  static async updateVerificationStatus(
    userId: string,
    status: 'verified' | 'rejected',
    notes?: string,
    verifiedBy?: string
  ): Promise<void> {
    await db
      .update(users)
      .set({
        verificationStatus: status,
        verificationNotes: notes,
        verifiedBy,
        verifiedAt: status === 'verified' ? new Date() : null,
        accountStatus: status === 'verified' ? 'active' : 'suspended',
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }
}