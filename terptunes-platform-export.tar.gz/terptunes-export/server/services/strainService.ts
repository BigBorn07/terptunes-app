import { 
  getAllStrains, 
  searchStrains, 
  getStrainsByType, 
  getStrainsByTerpene, 
  getStrainByName,
  StrainWithTerpenes 
} from '../data/strains';

export interface StrainSearchParams {
  query?: string;
  type?: 'indica' | 'sativa' | 'hybrid';
  effects?: string[];
  terpenes?: string[];
  minThc?: number;
  maxThc?: number;
  limit?: number;
  offset?: number;
}

export interface StrainSearchResult {
  strains: StrainWithTerpenes[];
  total: number;
  hasMore: boolean;
}

export class StrainService {
  // Search strains with filters
  public static searchStrains(params: StrainSearchParams): StrainSearchResult {
    let results = getAllStrains();

    // Apply text search
    if (params.query) {
      results = searchStrains(params.query);
    }

    // Apply type filter
    if (params.type) {
      results = results.filter(strain => strain.type === params.type);
    }

    // Apply effects filter
    if (params.effects && params.effects.length > 0) {
      results = results.filter(strain => 
        params.effects!.some(effect => 
          strain.effects.includes(effect)
        )
      );
    }

    // Apply terpenes filter
    if (params.terpenes && params.terpenes.length > 0) {
      results = results.filter(strain => 
        params.terpenes!.some(terpene => 
          strain.terpenes.some(t => t.name === terpene)
        )
      );
    }

    // Apply THC range filter
    if (params.minThc !== undefined) {
      results = results.filter(strain => 
        parseFloat(strain.thcContent || '0') >= params.minThc!
      );
    }

    if (params.maxThc !== undefined) {
      results = results.filter(strain => 
        parseFloat(strain.thcContent || '0') <= params.maxThc!
      );
    }

    // Calculate pagination
    const total = results.length;
    const limit = params.limit || 20;
    const offset = params.offset || 0;
    
    const paginatedResults = results.slice(offset, offset + limit);
    const hasMore = offset + limit < total;

    return {
      strains: paginatedResults,
      total,
      hasMore
    };
  }

  // Get strain by name
  public static getStrainByName(name: string): StrainWithTerpenes | null {
    return getStrainByName(name) || null;
  }

  // Get popular strains (top 8 by THC content)
  public static getPopularStrains(): StrainWithTerpenes[] {
    return getAllStrains()
      .sort((a, b) => parseFloat(b.thcContent || '0') - parseFloat(a.thcContent || '0'))
      .slice(0, 8);
  }

  // Get strains by type
  public static getStrainsByType(type: 'indica' | 'sativa' | 'hybrid'): StrainWithTerpenes[] {
    return getStrainsByType(type);
  }

  // Get strains by dominant terpene
  public static getStrainsByTerpene(terpeneName: string): StrainWithTerpenes[] {
    return getStrainsByTerpene(terpeneName);
  }

  // Get strain statistics
  public static getStrainStats(): {
    totalStrains: number;
    indicaCount: number;
    sativaCount: number;
    hybridCount: number;
    avgThc: number;
    topTerpenes: Array<{name: string, count: number}>;
  } {
    const strains = getAllStrains();
    const total = strains.length;
    
    const indicaCount = strains.filter(s => s.type === 'indica').length;
    const sativaCount = strains.filter(s => s.type === 'sativa').length;
    const hybridCount = strains.filter(s => s.type === 'hybrid').length;
    
    const avgThc = strains.reduce((sum, strain) => 
      sum + parseFloat(strain.thcContent || '0'), 0
    ) / total;

    // Count terpene occurrences
    const terpeneCount: Record<string, number> = {};
    strains.forEach(strain => {
      strain.terpenes.forEach(terpene => {
        terpeneCount[terpene.name] = (terpeneCount[terpene.name] || 0) + 1;
      });
    });

    const topTerpenes = Object.entries(terpeneCount)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5)
      .map(([name, count]) => ({ name, count }));

    return {
      totalStrains: total,
      indicaCount,
      sativaCount,
      hybridCount,
      avgThc: Math.round(avgThc * 10) / 10,
      topTerpenes
    };
  }

  // Get similar strains based on terpene profile
  public static getSimilarStrains(strain: StrainWithTerpenes, limit: number = 5): StrainWithTerpenes[] {
    const allStrains = getAllStrains().filter(s => s.name !== strain.name);
    
    // Calculate similarity scores based on terpene profiles
    const similarities = allStrains.map(otherStrain => {
      let similarity = 0;
      
      // Compare terpenes
      strain.terpenes.forEach(terpene => {
        const otherTerpene = otherStrain.terpenes.find(t => t.name === terpene.name);
        if (otherTerpene) {
          // Calculate similarity based on percentage difference
          const diff = Math.abs(terpene.percentage - otherTerpene.percentage);
          similarity += Math.max(0, 1 - diff); // Higher similarity for smaller differences
        }
      });

      // Bonus for same type
      if (strain.type === otherStrain.type) {
        similarity += 0.5;
      }

      // Bonus for similar effects
      const sharedEffects = strain.effects.filter(effect => 
        otherStrain.effects.includes(effect)
      ).length;
      similarity += sharedEffects * 0.1;

      return {
        strain: otherStrain,
        similarity
      };
    });

    // Sort by similarity and return top results
    return similarities
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, limit)
      .map(item => item.strain);
  }
}
