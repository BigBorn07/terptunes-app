import { db } from "../db";
import { strains, terpeneProfiles, userStats, playlists } from "@shared/schema";
import { eq, and, desc, sql, inArray, gt } from "drizzle-orm";
import type { Strain, TerpeneProfile } from "@shared/schema";

interface UserPreferences {
  favoriteStrainTypes: ('indica' | 'sativa' | 'hybrid')[];
  favoriteTerpenes: string[];
  preferredEffects: string[];
  thcPreference: { min: number; max: number };
  musicGenres: string[];
  moodStates: string[];
  usageContext: string[]; // work, party, sleep, exercise, etc.
}

interface StrainRecommendation {
  strain: Strain;
  matchScore: number;
  matchReasons: string[];
  confidence: number;
  terpenes: TerpeneProfile[];
  predictedEffects: string[];
  recommendedPlaylist?: any;
}

interface TerpenePersonality {
  name: string;
  musicCharacteristics: string[];
  moodEffects: string[];
  energyLevel: number; // 1-10 scale
  creativityBoost: number; // 1-10 scale
  relaxationLevel: number; // 1-10 scale
}

export class RecommendationEngine {
  private static readonly TERPENE_PERSONALITIES: Record<string, TerpenePersonality> = {
    myrcene: {
      name: 'myrcene',
      musicCharacteristics: ['ambient', 'chill', 'downtempo', 'lofi'],
      moodEffects: ['relaxed', 'sedating', 'sleepy'],
      energyLevel: 2,
      creativityBoost: 3,
      relaxationLevel: 9
    },
    limonene: {
      name: 'limonene',
      musicCharacteristics: ['upbeat', 'electronic', 'pop', 'funk'],
      moodEffects: ['uplifting', 'energetic', 'euphoric'],
      energyLevel: 8,
      creativityBoost: 7,
      relaxationLevel: 3
    },
    pinene: {
      name: 'pinene',
      musicCharacteristics: ['indie', 'acoustic', 'folk', 'nature'],
      moodEffects: ['focused', 'alert', 'clear-headed'],
      energyLevel: 6,
      creativityBoost: 8,
      relaxationLevel: 4
    },
    linalool: {
      name: 'linalool',
      musicCharacteristics: ['classical', 'meditation', 'spa', 'ambient'],
      moodEffects: ['calming', 'anti-anxiety', 'peaceful'],
      energyLevel: 3,
      creativityBoost: 5,
      relaxationLevel: 9
    },
    caryophyllene: {
      name: 'caryophyllene',
      musicCharacteristics: ['jazz', 'blues', 'soul', 'r&b'],
      moodEffects: ['balanced', 'therapeutic', 'grounding'],
      energyLevel: 5,
      creativityBoost: 6,
      relaxationLevel: 6
    },
    terpinolene: {
      name: 'terpinolene',
      musicCharacteristics: ['psychedelic', 'experimental', 'progressive'],
      moodEffects: ['dreamy', 'contemplative', 'introspective'],
      energyLevel: 4,
      creativityBoost: 9,
      relaxationLevel: 5
    },
    humulene: {
      name: 'humulene',
      musicCharacteristics: ['rock', 'alternative', 'indie'],
      moodEffects: ['focused', 'motivated', 'appetite-suppressing'],
      energyLevel: 7,
      creativityBoost: 6,
      relaxationLevel: 4
    },
    ocimene: {
      name: 'ocimene',
      musicCharacteristics: ['tropical', 'reggae', 'world', 'upbeat'],
      moodEffects: ['uplifting', 'energizing', 'social'],
      energyLevel: 7,
      creativityBoost: 7,
      relaxationLevel: 3
    }
  };

  /**
   * Get personalized strain recommendations for a user
   */
  static async getPersonalizedRecommendations(
    userId: string,
    preferences: Partial<UserPreferences>,
    limit: number = 10
  ): Promise<StrainRecommendation[]> {
    try {
      // Get user's historical data
      const userHistory = await this.getUserHistory(userId);
      
      // Merge explicit preferences with inferred preferences
      const fullPreferences = await this.mergePreferences(preferences, userHistory);
      
      // Get all strains with terpene profiles
      const allStrains = await this.getStrainsWithTerpenes();
      
      // Score each strain
      const scoredStrains = await Promise.all(
        allStrains.map(strain => this.scoreStrain(strain, fullPreferences, userHistory))
      );
      
      // Sort by match score and return top recommendations
      return scoredStrains
        .sort((a, b) => b.matchScore - a.matchScore)
        .slice(0, limit);
        
    } catch (error) {
      console.error('Error generating recommendations:', error);
      return [];
    }
  }

  /**
   * Get contextual recommendations based on current mood/situation
   */
  static async getContextualRecommendations(
    userId: string,
    context: {
      mood: string; // happy, stressed, tired, creative, social
      activity: string; // work, party, sleep, exercise, study
      timeOfDay: string; // morning, afternoon, evening, night
      company: string; // alone, friends, partner, family
    },
    limit: number = 5
  ): Promise<StrainRecommendation[]> {
    const contextPreferences = this.mapContextToPreferences(context);
    return this.getPersonalizedRecommendations(userId, contextPreferences, limit);
  }

  /**
   * Get terpene-based music recommendations
   */
  static async getTerpeneBasedMusicRecommendations(
    strainId: number
  ): Promise<{
    genres: string[];
    musicCharacteristics: string[];
    energyLevel: number;
    recommendedPlaylists: any[];
  }> {
    try {
      // Get strain's terpene profile
      const terpenes = await db
        .select()
        .from(terpeneProfiles)
        .where(eq(terpeneProfiles.strainId, strainId));

      if (terpenes.length === 0) {
        return {
          genres: ['ambient', 'chill'],
          musicCharacteristics: ['relaxing'],
          energyLevel: 5,
          recommendedPlaylists: []
        };
      }

      // Calculate weighted music characteristics
      let totalWeight = 0;
      let weightedEnergy = 0;
      let weightedCreativity = 0;
      let weightedRelaxation = 0;
      const allGenres = new Set<string>();
      const allCharacteristics = new Set<string>();

      for (const terpene of terpenes) {
        const personality = this.TERPENE_PERSONALITIES[terpene.name.toLowerCase()];
        if (personality && terpene.percentage) {
          const weight = parseFloat(terpene.percentage);
          totalWeight += weight;
          
          weightedEnergy += personality.energyLevel * weight;
          weightedCreativity += personality.creativityBoost * weight;
          weightedRelaxation += personality.relaxationLevel * weight;
          
          personality.musicCharacteristics.forEach(char => allCharacteristics.add(char));
        }
      }

      const avgEnergy = totalWeight > 0 ? weightedEnergy / totalWeight : 5;
      const avgCreativity = totalWeight > 0 ? weightedCreativity / totalWeight : 5;
      const avgRelaxation = totalWeight > 0 ? weightedRelaxation / totalWeight : 5;

      // Map to specific genres based on characteristics
      const genres = this.mapCharacteristicsToGenres(Array.from(allCharacteristics), avgEnergy);

      // Get matching playlists
      const matchingPlaylists = await db
        .select()
        .from(playlists)
        .where(eq(playlists.strainId, strainId))
        .limit(3);

      return {
        genres,
        musicCharacteristics: Array.from(allCharacteristics),
        energyLevel: Math.round(avgEnergy),
        recommendedPlaylists: matchingPlaylists
      };

    } catch (error) {
      console.error('Error getting terpene-based music recommendations:', error);
      return {
        genres: ['ambient'],
        musicCharacteristics: ['relaxing'],
        energyLevel: 5,
        recommendedPlaylists: []
      };
    }
  }

  /**
   * Find similar strains based on terpene profiles
   */
  static async findSimilarStrains(
    strainId: number,
    limit: number = 5
  ): Promise<{ strain: Strain; similarity: number }[]> {
    try {
      // Get target strain's terpene profile
      const targetTerpenes = await db
        .select()
        .from(terpeneProfiles)
        .where(eq(terpeneProfiles.strainId, strainId));

      if (targetTerpenes.length === 0) return [];

      // Get all other strains with terpenes
      const allStrains = await this.getStrainsWithTerpenes();
      const otherStrains = allStrains.filter(s => s.strain.id !== strainId);

      // Calculate similarity scores
      const similarities = otherStrains.map(({ strain, terpenes }) => ({
        strain,
        similarity: this.calculateTerpeneSimilarity(targetTerpenes, terpenes)
      }));

      // Sort by similarity and return top matches
      return similarities
        .sort((a, b) => b.similarity - a.similarity)
        .slice(0, limit);

    } catch (error) {
      console.error('Error finding similar strains:', error);
      return [];
    }
  }

  /**
   * Get strain recommendations based on mood and music preferences
   */
  static async getMoodBasedRecommendations(
    mood: string,
    musicGenres: string[],
    limit: number = 8
  ): Promise<StrainRecommendation[]> {
    const moodPreferences = this.mapMoodToPreferences(mood, musicGenres);
    return this.getPersonalizedRecommendations('anonymous', moodPreferences, limit);
  }

  // Private helper methods

  private static async getUserHistory(userId: string) {
    // Get user's strain interaction history, playlist creation, etc.
    const userStatsData = await db
      .select()
      .from(userStats)
      .where(eq(userStats.userId, userId));

    return userStatsData[0] || null;
  }

  private static async mergePreferences(
    explicit: Partial<UserPreferences>,
    history: any
  ): Promise<UserPreferences> {
    // Merge explicit preferences with inferred preferences from history
    return {
      favoriteStrainTypes: explicit.favoriteStrainTypes || ['hybrid'],
      favoriteTerpenes: explicit.favoriteTerpenes || ['myrcene', 'limonene'],
      preferredEffects: explicit.preferredEffects || ['relaxed', 'happy'],
      thcPreference: explicit.thcPreference || { min: 10, max: 25 },
      musicGenres: explicit.musicGenres || ['chill', 'electronic'],
      moodStates: explicit.moodStates || ['relaxed'],
      usageContext: explicit.usageContext || ['evening']
    };
  }

  private static async getStrainsWithTerpenes() {
    const strainsWithTerpenes = await db
      .select({
        strain: strains,
        terpenes: terpeneProfiles
      })
      .from(strains)
      .leftJoin(terpeneProfiles, eq(strains.id, terpeneProfiles.strainId));

    // Group terpenes by strain
    const grouped = new Map();
    strainsWithTerpenes.forEach(({ strain, terpenes }) => {
      if (!grouped.has(strain.id)) {
        grouped.set(strain.id, { strain, terpenes: [] });
      }
      if (terpenes) {
        grouped.get(strain.id).terpenes.push(terpenes);
      }
    });

    return Array.from(grouped.values());
  }

  private static async scoreStrain(
    { strain, terpenes }: { strain: Strain; terpenes: TerpeneProfile[] },
    preferences: UserPreferences,
    userHistory: any
  ): Promise<StrainRecommendation> {
    let score = 0;
    const matchReasons: string[] = [];
    let confidence = 0.5;

    // Type preference scoring
    if (preferences.favoriteStrainTypes.includes(strain.type as any)) {
      score += 20;
      matchReasons.push(`Matches your preferred ${strain.type} type`);
      confidence += 0.1;
    }

    // THC content scoring
    const thcValue = parseFloat(strain.thcContent || '0');
    if (thcValue >= preferences.thcPreference.min && thcValue <= preferences.thcPreference.max) {
      score += 15;
      matchReasons.push(`THC level (${strain.thcContent}) fits your preference`);
      confidence += 0.1;
    }

    // Terpene profile scoring
    let terpeneScore = 0;
    const strainTerpeneNames = terpenes.map(t => t.name.toLowerCase());
    
    for (const favTerpene of preferences.favoriteTerpenes) {
      if (strainTerpeneNames.includes(favTerpene.toLowerCase())) {
        const terpeneData = terpenes.find(t => t.name.toLowerCase() === favTerpene.toLowerCase());
        const percentage = terpeneData ? parseFloat(terpeneData.percentage || '0') : 0;
        terpeneScore += percentage * 2; // Weight by percentage
        matchReasons.push(`Contains ${favTerpene} (${percentage.toFixed(1)}%)`);
        confidence += 0.05;
      }
    }
    score += Math.min(terpeneScore, 30); // Cap terpene contribution

    // Effects prediction and scoring
    const predictedEffects = this.predictEffectsFromTerpenes(terpenes);
    const effectMatches = predictedEffects.filter(effect => 
      preferences.preferredEffects.includes(effect)
    );
    score += effectMatches.length * 8;
    if (effectMatches.length > 0) {
      matchReasons.push(`Predicted effects: ${effectMatches.join(', ')}`);
      confidence += 0.1;
    }

    // Popularity boost (slight)
    if (userHistory && userHistory.strainsDiscovered > 50) {
      score += 5; // Boost for experienced users
    }

    return {
      strain,
      matchScore: Math.round(score),
      matchReasons,
      confidence: Math.min(confidence, 0.95),
      terpenes,
      predictedEffects
    };
  }

  private static mapContextToPreferences(context: any): Partial<UserPreferences> {
    const preferences: Partial<UserPreferences> = {};

    // Map mood to terpenes and effects
    switch (context.mood) {
      case 'stressed':
        preferences.favoriteTerpenes = ['linalool', 'myrcene', 'caryophyllene'];
        preferences.preferredEffects = ['relaxed', 'calming', 'stress-relief'];
        break;
      case 'creative':
        preferences.favoriteTerpenes = ['pinene', 'terpinolene', 'limonene'];
        preferences.preferredEffects = ['creative', 'focused', 'euphoric'];
        break;
      case 'social':
        preferences.favoriteTerpenes = ['limonene', 'ocimene', 'pinene'];
        preferences.preferredEffects = ['happy', 'social', 'talkative'];
        break;
      case 'tired':
        preferences.favoriteTerpenes = ['myrcene', 'linalool'];
        preferences.preferredEffects = ['sleepy', 'relaxed', 'sedating'];
        break;
    }

    // Map activity to strain types
    switch (context.activity) {
      case 'work':
      case 'study':
        preferences.favoriteStrainTypes = ['sativa', 'hybrid'];
        break;
      case 'sleep':
        preferences.favoriteStrainTypes = ['indica'];
        break;
      case 'party':
      case 'social':
        preferences.favoriteStrainTypes = ['sativa', 'hybrid'];
        break;
    }

    return preferences;
  }

  private static mapMoodToPreferences(mood: string, musicGenres: string[]): Partial<UserPreferences> {
    const moodTerpeneMap: Record<string, string[]> = {
      happy: ['limonene', 'pinene', 'ocimene'],
      relaxed: ['myrcene', 'linalool', 'caryophyllene'],
      energetic: ['limonene', 'pinene', 'humulene'],
      creative: ['terpinolene', 'pinene', 'limonene'],
      focused: ['pinene', 'humulene', 'caryophyllene'],
      sleepy: ['myrcene', 'linalool'],
      social: ['limonene', 'ocimene', 'pinene']
    };

    return {
      favoriteTerpenes: moodTerpeneMap[mood] || ['myrcene', 'limonene'],
      musicGenres: musicGenres || ['chill'],
      moodStates: [mood]
    };
  }

  private static mapCharacteristicsToGenres(characteristics: string[], energyLevel: number): string[] {
    const genreMap: Record<string, string[]> = {
      ambient: ['ambient', 'meditation', 'spa'],
      chill: ['chill', 'lofi', 'downtempo'],
      electronic: ['electronic', 'edm', 'house'],
      indie: ['indie', 'alternative', 'indie-rock'],
      jazz: ['jazz', 'smooth jazz', 'blues'],
      rock: ['rock', 'alternative rock', 'indie rock'],
      classical: ['classical', 'orchestral', 'piano']
    };

    let genres = new Set<string>();
    
    characteristics.forEach(char => {
      if (genreMap[char]) {
        genreMap[char].forEach(genre => genres.add(genre));
      }
    });

    // Add energy-based genres
    if (energyLevel >= 7) {
      genres.add('upbeat');
      genres.add('energetic');
    } else if (energyLevel <= 3) {
      genres.add('relaxing');
      genres.add('peaceful');
    }

    return Array.from(genres);
  }

  private static predictEffectsFromTerpenes(terpenes: TerpeneProfile[]): string[] {
    const effects = new Set<string>();
    
    terpenes.forEach(terpene => {
      const personality = this.TERPENE_PERSONALITIES[terpene.name.toLowerCase()];
      if (personality) {
        personality.moodEffects.forEach(effect => effects.add(effect));
      }
    });

    return Array.from(effects);
  }

  private static calculateTerpeneSimilarity(
    terpenes1: TerpeneProfile[],
    terpenes2: TerpeneProfile[]
  ): number {
    // Create terpene maps for easier comparison
    const map1 = new Map(terpenes1.map(t => [t.name.toLowerCase(), parseFloat(t.percentage || '0')]));
    const map2 = new Map(terpenes2.map(t => [t.name.toLowerCase(), parseFloat(t.percentage || '0')]));

    // Get all unique terpene names
    const allTerpenes = new Set([...map1.keys(), ...map2.keys()]);
    
    let similarity = 0;
    let totalWeight = 0;

    for (const terpene of allTerpenes) {
      const val1 = map1.get(terpene) || 0;
      const val2 = map2.get(terpene) || 0;
      const weight = Math.max(val1, val2);
      
      // Calculate percentage difference (0-1, where 1 is identical)
      const maxDiff = Math.max(val1, val2);
      const actualDiff = Math.abs(val1 - val2);
      const terpeneScore = maxDiff > 0 ? 1 - (actualDiff / maxDiff) : 1;
      
      similarity += terpeneScore * weight;
      totalWeight += weight;
    }

    return totalWeight > 0 ? similarity / totalWeight : 0;
  }
}