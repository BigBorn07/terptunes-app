import { db } from '../db';
import { strains, terpeneProfiles } from '@shared/schema';
import { eq, ilike, or } from 'drizzle-orm';
import { TerpeneService } from './terpeneService';

export interface StrainValidationResult {
  isValid: boolean;
  isDuplicate: boolean;
  duplicateId?: number;
  duplicateName?: string;
  similarityScore?: number;
  suggestions?: string[];
  issues: string[];
  needsReview?: boolean;
}

export interface UserStrainSubmission {
  name: string;
  type: 'indica' | 'sativa' | 'hybrid';
  thcContent?: string;
  cbdContent?: string;
  description?: string;
  effects?: string[];
  flavors?: string[];
  submittedBy: string;
  providedTerpenes?: Array<{ name: string; percentage: number }>;
}

export interface StrainWithTerpenes {
  strain: any;
  terpenes: any[];
  source: 'existing' | 'generated' | 'api';
  confidence: number;
  needsReview: boolean;
}

export class StrainValidationService {
  
  /**
   * Comprehensive strain validation and duplicate detection
   */
  static async validateStrainSubmission(submission: UserStrainSubmission): Promise<StrainValidationResult> {
    const result: StrainValidationResult = {
      isValid: true,
      isDuplicate: false,
      issues: []
    };

    // 1. Check for exact name duplicates
    const exactDuplicate = await this.findExactDuplicate(submission.name);
    if (exactDuplicate) {
      result.isDuplicate = true;
      result.duplicateId = exactDuplicate.id;
      result.duplicateName = exactDuplicate.name;
      result.issues.push(`Strain "${submission.name}" already exists in database`);
      return result;
    }

    // 2. Check for similar names with fuzzy matching
    const similarStrains = await this.findSimilarStrains(submission.name);
    if (similarStrains.length > 0) {
      result.suggestions = similarStrains.map(s => s.name);
      result.similarityScore = this.calculateSimilarity(submission.name, similarStrains[0].name);
      
      if (result.similarityScore > 0.8) {
        result.issues.push(`Very similar strain "${similarStrains[0].name}" already exists. Consider if this is the same strain.`);
        result.needsReview = true;
      }
    }

    // 3. Validate required fields
    if (!submission.name || submission.name.trim().length < 2) {
      result.isValid = false;
      result.issues.push('Strain name must be at least 2 characters long');
    }

    if (!['indica', 'sativa', 'hybrid'].includes(submission.type)) {
      result.isValid = false;
      result.issues.push('Strain type must be indica, sativa, or hybrid');
    }

    // 4. Validate THC/CBD content format
    if (submission.thcContent && !this.isValidPercentage(submission.thcContent)) {
      result.isValid = false;
      result.issues.push('THC content must be a valid percentage (e.g., "15.5" or "15.5%")');
    }

    if (submission.cbdContent && !this.isValidPercentage(submission.cbdContent)) {
      result.isValid = false;
      result.issues.push('CBD content must be a valid percentage (e.g., "1.2" or "1.2%")');
    }

    // 5. Validate terpene profiles if provided
    if (submission.providedTerpenes && submission.providedTerpenes.length > 0) {
      const terpeneValidation = this.validateTerpeneProfile(submission.providedTerpenes);
      if (!terpeneValidation.isValid) {
        result.issues.push(...terpeneValidation.issues);
      }
    }

    return result;
  }

  /**
   * Create strain with comprehensive terpene profile management
   */
  static async createStrainWithTerpenes(submission: UserStrainSubmission): Promise<StrainWithTerpenes> {
    // Step 1: Create the strain record
    const strainData = {
      name: submission.name.trim(),
      type: submission.type,
      thcContent: submission.thcContent ? this.parsePercentage(submission.thcContent) : null,
      cbdContent: submission.cbdContent ? this.parsePercentage(submission.cbdContent) : null,
      description: submission.description || null,
      effects: submission.effects || [],
      flavors: submission.flavors || [],
      source: 'user',
      labVerified: false,
      submittedBy: submission.submittedBy,
      qualityScore: 5.0 // Starting quality score for user submissions
    };

    const [strain] = await db.insert(strains).values({
      ...strainData,
      qualityScore: strainData.qualityScore.toString()
    }).returning();

    // Step 2: Handle terpene profiles with intelligent data sourcing
    let terpenes: any[] = [];
    let source: 'existing' | 'generated' | 'api' = 'generated';
    let confidence = 0.5;
    let needsReview = true;

    if (submission.providedTerpenes && submission.providedTerpenes.length > 0) {
      // User provided terpenes - validate and use them
      terpenes = await this.createTerpeneProfiles(strain.id, submission.providedTerpenes);
      source = 'existing';
      confidence = 0.8;
      needsReview = false;
    } else {
      // No terpenes provided - generate intelligent profile
      const generatedProfile = await this.generateIntelligentTerpeneProfile(strain);
      terpenes = await this.createTerpeneProfiles(strain.id, generatedProfile.terpenes);
      source = 'generated';
      confidence = generatedProfile.confidence;
      needsReview = true;
    }

    return {
      strain,
      terpenes,
      source,
      confidence,
      needsReview
    };
  }

  /**
   * Generate intelligent terpene profile using multiple data sources
   */
  private static async generateIntelligentTerpeneProfile(strain: any): Promise<{
    terpenes: Array<{ name: string; percentage: number }>;
    confidence: number;
    source: string;
  }> {
    // Strategy 1: Look for similar strains with lab data
    const similarStrains = await this.findSimilarStrainsWithTerpenes(strain);
    if (similarStrains.length > 0) {
      const avgTerpenes = this.averageTerpeneProfiles(similarStrains);
      return {
        terpenes: avgTerpenes,
        confidence: 0.7,
        source: 'similar_strains_analysis'
      };
    }

    // Strategy 2: Use TerpeneService to generate profile based on strain characteristics
    const terpeneMapping = TerpeneService.mapTerpenesToMusic([]);
    const generatedTerpenes = this.generateTerpenesFromStrainData(strain);
    
    return {
      terpenes: generatedTerpenes,
      confidence: 0.5,
      source: 'strain_characteristics_inference'
    };
  }

  /**
   * Find existing strains with terpene profiles similar to this one
   */
  private static async findSimilarStrainsWithTerpenes(strain: any) {
    const similarStrains = await db
      .select({
        strain: strains,
        terpenes: terpeneProfiles
      })
      .from(strains)
      .leftJoin(terpeneProfiles, eq(strains.id, terpeneProfiles.strainId))
      .where(
        or(
          eq(strains.type, strain.type),
          ilike(strains.name, `%${strain.name.split(' ')[0]}%`)
        )
      )
      .limit(10);

    return similarStrains.filter(s => s.terpenes !== null);
  }

  /**
   * Average terpene profiles from similar strains
   */
  private static averageTerpeneProfiles(similarStrains: any[]): Array<{ name: string; percentage: number }> {
    const terpeneMap = new Map<string, number[]>();
    
    similarStrains.forEach(s => {
      if (s.terpenes) {
        const name = s.terpenes.terpeneName;
        const percentage = parseFloat(s.terpenes.percentage);
        
        if (!terpeneMap.has(name)) {
          terpeneMap.set(name, []);
        }
        terpeneMap.get(name)!.push(percentage);
      }
    });

    // Calculate averages
    const avgTerpenes: Array<{ name: string; percentage: number }> = [];
    terpeneMap.forEach((percentages, name) => {
      const avg = percentages.reduce((sum, p) => sum + p, 0) / percentages.length;
      avgTerpenes.push({ name, percentage: avg });
    });

    return avgTerpenes.sort((a, b) => b.percentage - a.percentage).slice(0, 8);
  }

  /**
   * Generate terpenes based on strain name and characteristics
   */
  private static generateTerpenesFromStrainData(strain: any): Array<{ name: string; percentage: number }> {
    const typeBasedTerpenes = {
      indica: [
        { name: 'Myrcene', percentage: 0.8 + Math.random() * 0.4 },
        { name: 'Linalool', percentage: 0.3 + Math.random() * 0.3 },
        { name: 'Caryophyllene', percentage: 0.2 + Math.random() * 0.3 }
      ],
      sativa: [
        { name: 'Limonene', percentage: 0.6 + Math.random() * 0.4 },
        { name: 'Pinene', percentage: 0.3 + Math.random() * 0.3 },
        { name: 'Terpinolene', percentage: 0.2 + Math.random() * 0.2 }
      ],
      hybrid: [
        { name: 'Myrcene', percentage: 0.4 + Math.random() * 0.3 },
        { name: 'Limonene', percentage: 0.3 + Math.random() * 0.3 },
        { name: 'Caryophyllene', percentage: 0.2 + Math.random() * 0.2 }
      ]
    };

    const baseTerpenes = typeBasedTerpenes[strain.type as keyof typeof typeBasedTerpenes] || typeBasedTerpenes.hybrid;
    
    // Add secondary terpenes based on name patterns
    const secondaryTerpenes = this.inferTerpenesFromName(strain.name);
    
    return [...baseTerpenes, ...secondaryTerpenes]
      .sort((a, b) => b.percentage - a.percentage)
      .slice(0, 6);
  }

  /**
   * Infer additional terpenes from strain name patterns
   */
  private static inferTerpenesFromName(name: string): Array<{ name: string; percentage: number }> {
    const namePatterns = {
      'OG': [{ name: 'Humulene', percentage: 0.15 + Math.random() * 0.15 }],
      'Kush': [{ name: 'Humulene', percentage: 0.2 + Math.random() * 0.2 }],
      'Diesel': [{ name: 'Terpinolene', percentage: 0.2 + Math.random() * 0.2 }],
      'Haze': [{ name: 'Terpinolene', percentage: 0.25 + Math.random() * 0.2 }],
      'Cheese': [{ name: 'Caryophyllene', percentage: 0.3 + Math.random() * 0.2 }],
      'Berry': [{ name: 'Linalool', percentage: 0.2 + Math.random() * 0.2 }]
    };

    const additionalTerpenes: Array<{ name: string; percentage: number }> = [];
    
    Object.entries(namePatterns).forEach(([pattern, terpenes]) => {
      if (name.toLowerCase().includes(pattern.toLowerCase())) {
        additionalTerpenes.push(...terpenes);
      }
    });

    return additionalTerpenes;
  }

  /**
   * Create terpene profile records in database
   */
  private static async createTerpeneProfiles(strainId: number, terpenes: Array<{ name: string; percentage: number }>) {
    const terpeneRecords = terpenes.map(t => ({
      strainId,
      terpeneName: t.name,
      percentage: t.percentage.toString()
    }));

    return await db.insert(terpeneProfiles).values(terpeneRecords).returning();
  }

  // Utility methods
  private static async findExactDuplicate(name: string) {
    const [duplicate] = await db
      .select()
      .from(strains)
      .where(eq(strains.name, name.trim()))
      .limit(1);
    
    return duplicate;
  }

  private static async findSimilarStrains(name: string) {
    return await db
      .select()
      .from(strains)
      .where(ilike(strains.name, `%${name.trim()}%`))
      .limit(5);
  }

  private static calculateSimilarity(str1: string, str2: string): number {
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    
    if (longer.length === 0) return 1.0;
    
    const distance = this.levenshteinDistance(longer, shorter);
    return (longer.length - distance) / longer.length;
  }

  private static levenshteinDistance(str1: string, str2: string): number {
    const matrix = Array(str2.length + 1).fill(null).map(() => Array(str1.length + 1).fill(null));

    for (let i = 0; i <= str1.length; i++) matrix[0][i] = i;
    for (let j = 0; j <= str2.length; j++) matrix[j][0] = j;

    for (let j = 1; j <= str2.length; j++) {
      for (let i = 1; i <= str1.length; i++) {
        const cost = str1[i - 1] === str2[j - 1] ? 0 : 1;
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1,
          matrix[j - 1][i] + 1,
          matrix[j - 1][i - 1] + cost
        );
      }
    }

    return matrix[str2.length][str1.length];
  }

  private static isValidPercentage(value: string): boolean {
    const cleanValue = value.replace('%', '').trim();
    const num = parseFloat(cleanValue);
    return !isNaN(num) && num >= 0 && num <= 100;
  }

  private static parsePercentage(value: string): string {
    return value.replace('%', '').trim();
  }

  private static validateTerpeneProfile(terpenes: Array<{ name: string; percentage: number }>): {
    isValid: boolean;
    issues: string[];
  } {
    const issues: string[] = [];
    
    // Check total percentage doesn't exceed reasonable limits
    const totalPercentage = terpenes.reduce((sum, t) => sum + t.percentage, 0);
    if (totalPercentage > 5.0) {
      issues.push('Total terpene percentage exceeds 5% - this seems unusually high');
    }

    // Validate individual terpene percentages
    terpenes.forEach(t => {
      if (t.percentage < 0 || t.percentage > 3.0) {
        issues.push(`${t.name} percentage (${t.percentage}%) is outside normal range (0-3%)`);
      }
    });

    return {
      isValid: issues.length === 0,
      issues
    };
  }
}