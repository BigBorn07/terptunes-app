import { db } from "../db";
import { 
  dispensaries, 
  userDispensaryHistory, 
  dispensaryAmbassadors, 
  dispensaryExclusives,
  userFavoriteDispensaries,
  type Dispensary,
  type UserDispensaryHistory,
  type DispensaryAmbassador,
  type DispensaryExclusive,
  type InsertUserDispensaryHistory,
  type InsertDispensaryAmbassador
} from "@shared/schema";
import { eq, and, desc, sum, count } from "drizzle-orm";

interface DispensaryConsumption {
  dispensaryId: number;
  dispensaryName: string;
  location: string;
  totalVisits: number;
  totalSpent: number;
  loyaltyPoints: number;
  isQualified: boolean;
  ambassadorLevel?: string;
  visits: Array<{
    id: number;
    visitType: string;
    amount: number;
    visitDate: string;
    rating?: number;
    review?: string;
  }>;
}

interface DispensaryAmbassadorshipStats {
  totalDispensaries: number;
  qualifiedDispensaries: number;
  totalVisits: number;
  totalSpent: number;
  loyaltyPoints: number;
  ambassadorships: Array<{
    id: number;
    dispensaryId: number;
    dispensaryName: string;
    location: string;
    totalVisits: number;
    totalSpent: number;
    ambassadorLevel: string;
    qualifiedAt: string;
    exclusiveAccess: boolean;
    loyaltyPoints: number;
  }>;
  exclusiveRewards: number;
}

export class DispensaryAmbassadorService {
  
  /**
   * Get user's dispensary consumption and ambassador status
   */
  static async getUserDispensaryConsumption(userId: string): Promise<DispensaryConsumption[]> {
    // Get all dispensary visit history for user
    const visits = await db
      .select({
        dispensaryId: userDispensaryHistory.dispensaryId,
        dispensaryName: dispensaries.name,
        location: dispensaries.location,
        visitId: userDispensaryHistory.id,
        visitType: userDispensaryHistory.visitType,
        amount: userDispensaryHistory.amount,
        visitDate: userDispensaryHistory.visitDate,
        rating: userDispensaryHistory.rating,
        review: userDispensaryHistory.review,
      })
      .from(userDispensaryHistory)
      .innerJoin(dispensaries, eq(userDispensaryHistory.dispensaryId, dispensaries.id))
      .where(eq(userDispensaryHistory.userId, userId))
      .orderBy(desc(userDispensaryHistory.visitDate));

    // Group by dispensary and calculate stats
    const dispensaryMap = new Map<number, DispensaryConsumption>();

    for (const visit of visits) {
      const dispensaryId = visit.dispensaryId;
      
      if (!dispensaryMap.has(dispensaryId)) {
        dispensaryMap.set(dispensaryId, {
          dispensaryId,
          dispensaryName: visit.dispensaryName,
          location: visit.location,
          totalVisits: 0,
          totalSpent: 0,
          loyaltyPoints: 0,
          isQualified: false,
          visits: []
        });
      }

      const dispensaryData = dispensaryMap.get(dispensaryId)!;
      dispensaryData.totalVisits++;
      dispensaryData.totalSpent += Number(visit.amount || 0);
      dispensaryData.loyaltyPoints += this.calculateLoyaltyPoints(visit.visitType, Number(visit.amount || 0));
      
      dispensaryData.visits.push({
        id: visit.visitId,
        visitType: visit.visitType,
        amount: Number(visit.amount || 0),
        visitDate: visit.visitDate?.toISOString() || '',
        rating: visit.rating || undefined,
        review: visit.review || undefined,
      });
    }

    // Check ambassador qualifications and get existing ambassador status
    const dispensaryConsumption: DispensaryConsumption[] = [];
    
    for (const [dispensaryId, data] of dispensaryMap) {
      // Check if already an ambassador
      const existingAmbassador = await db
        .select()
        .from(dispensaryAmbassadors)
        .where(and(
          eq(dispensaryAmbassadors.userId, userId),
          eq(dispensaryAmbassadors.dispensaryId, dispensaryId)
        ))
        .limit(1);

      if (existingAmbassador.length > 0) {
        data.isQualified = true;
        data.ambassadorLevel = existingAmbassador[0].ambassadorLevel;
        data.loyaltyPoints = existingAmbassador[0].loyaltyPoints;
      } else {
        // Check qualification criteria: 5+ visits OR $200+ spent
        data.isQualified = data.totalVisits >= 5 || data.totalSpent >= 200;
        if (data.isQualified) {
          data.ambassadorLevel = this.determineAmbassadorLevel(data.totalVisits, data.totalSpent);
        }
      }

      dispensaryConsumption.push(data);
    }

    return dispensaryConsumption.sort((a, b) => b.totalSpent - a.totalSpent);
  }

  /**
   * Get user's dispensary ambassadorship statistics
   */
  static async getUserAmbassadorshipStats(userId: string): Promise<DispensaryAmbassadorshipStats> {
    // Get all dispensary visits
    const visits = await db
      .select({
        dispensaryCount: count(userDispensaryHistory.dispensaryId),
        totalVisits: count(userDispensaryHistory.id),
        totalSpent: sum(userDispensaryHistory.amount),
      })
      .from(userDispensaryHistory)
      .where(eq(userDispensaryHistory.userId, userId));

    // Get ambassador status
    const ambassadorships = await db
      .select({
        id: dispensaryAmbassadors.id,
        dispensaryId: dispensaryAmbassadors.dispensaryId,
        dispensaryName: dispensaries.name,
        location: dispensaries.location,
        totalVisits: dispensaryAmbassadors.totalVisits,
        totalSpent: dispensaryAmbassadors.totalSpent,
        ambassadorLevel: dispensaryAmbassadors.ambassadorLevel,
        qualifiedAt: dispensaryAmbassadors.qualifiedAt,
        exclusiveAccess: dispensaryAmbassadors.exclusiveAccess,
        loyaltyPoints: dispensaryAmbassadors.loyaltyPoints,
      })
      .from(dispensaryAmbassadors)
      .innerJoin(dispensaries, eq(dispensaryAmbassadors.dispensaryId, dispensaries.id))
      .where(eq(dispensaryAmbassadors.userId, userId));

    // Count exclusive rewards
    const exclusiveRewards = ambassadorships.length > 0 ? await db
      .select({ count: count() })
      .from(dispensaryExclusives)
      .where(eq(dispensaryExclusives.isActive, true))
      .then(result => result[0]?.count || 0) : 0;

    // Get unique dispensary count
    const uniqueDispensaries = await db
      .selectDistinct({ dispensaryId: userDispensaryHistory.dispensaryId })
      .from(userDispensaryHistory)
      .where(eq(userDispensaryHistory.userId, userId));

    return {
      totalDispensaries: uniqueDispensaries.length,
      qualifiedDispensaries: ambassadorships.length,
      totalVisits: Number(visits[0]?.totalVisits || 0),
      totalSpent: Number(visits[0]?.totalSpent || 0),
      loyaltyPoints: ambassadorships.reduce((sum, amb) => sum + amb.loyaltyPoints, 0),
      ambassadorships: ambassadorships.map(amb => ({
        id: amb.id,
        dispensaryId: amb.dispensaryId,
        dispensaryName: amb.dispensaryName,
        location: amb.location,
        totalVisits: amb.totalVisits,
        totalSpent: Number(amb.totalSpent),
        ambassadorLevel: amb.ambassadorLevel,
        qualifiedAt: amb.qualifiedAt?.toISOString() || '',
        exclusiveAccess: amb.exclusiveAccess,
        loyaltyPoints: amb.loyaltyPoints,
      })),
      exclusiveRewards
    };
  }

  /**
   * Get available exclusive rewards for user's ambassador levels
   */
  static async getUserDispensaryRewards(userId: string): Promise<DispensaryExclusive[]> {
    const ambassadorships = await db
      .select({
        dispensaryId: dispensaryAmbassadors.dispensaryId,
        ambassadorLevel: dispensaryAmbassadors.ambassadorLevel,
      })
      .from(dispensaryAmbassadors)
      .where(eq(dispensaryAmbassadors.userId, userId));

    if (ambassadorships.length === 0) {
      return [];
    }

    const rewards = await db
      .select({
        id: dispensaryExclusives.id,
        dispensaryId: dispensaryExclusives.dispensaryId,
        dispensaryName: dispensaries.name,
        title: dispensaryExclusives.title,
        description: dispensaryExclusives.description,
        type: dispensaryExclusives.type,
        value: dispensaryExclusives.value,
        requiredLevel: dispensaryExclusives.requiredLevel,
        validUntil: dispensaryExclusives.validUntil,
      })
      .from(dispensaryExclusives)
      .innerJoin(dispensaries, eq(dispensaryExclusives.dispensaryId, dispensaries.id))
      .where(eq(dispensaryExclusives.isActive, true));

    // Filter rewards based on user's ambassador levels
    const userLevels = new Map(ambassadorships.map(amb => [amb.dispensaryId, amb.ambassadorLevel]));
    
    return rewards.filter(reward => {
      const userLevel = userLevels.get(reward.dispensaryId);
      if (!userLevel) return false;
      
      return this.hasRequiredLevel(userLevel, reward.requiredLevel);
    }).map(reward => ({
      id: reward.id,
      dispensaryId: reward.dispensaryId,
      title: reward.title,
      description: reward.description,
      type: reward.type,
      value: reward.value,
      requiredLevel: reward.requiredLevel,
      validUntil: reward.validUntil,
      isActive: true,
      createdAt: new Date(),
      dispensaryName: reward.dispensaryName,
    }));
  }

  /**
   * Get dispensaries user is close to qualifying for ambassador status
   */
  static async getNearQualificationDispensaries(userId: string): Promise<Array<{
    dispensaryId: number;
    dispensaryName: string;
    location: string;
    currentVisits: number;
    currentSpent: number;
    visitsNeeded: number;
    spendingNeeded: number;
  }>> {
    const consumption = await this.getUserDispensaryConsumption(userId);
    
    return consumption
      .filter(disp => !disp.isQualified && (disp.totalVisits >= 2 || disp.totalSpent >= 50))
      .map(disp => ({
        dispensaryId: disp.dispensaryId,
        dispensaryName: disp.dispensaryName,
        location: disp.location,
        currentVisits: disp.totalVisits,
        currentSpent: disp.totalSpent,
        visitsNeeded: Math.max(0, 5 - disp.totalVisits),
        spendingNeeded: Math.max(0, 200 - disp.totalSpent),
      }))
      .slice(0, 5);
  }

  /**
   * Add a dispensary visit/purchase
   */
  static async addDispensaryVisit(visitData: InsertUserDispensaryHistory): Promise<UserDispensaryHistory> {
    const [visit] = await db
      .insert(userDispensaryHistory)
      .values(visitData)
      .returning();

    // Check if this qualifies user for ambassador status
    await this.checkAndUpdateAmbassadorQualification(visitData.userId, visitData.dispensaryId);

    return visit;
  }

  /**
   * Check if user qualifies for ambassador status and update accordingly
   */
  static async checkAndUpdateAmbassadorQualification(userId: string, dispensaryId: number): Promise<void> {
    // Get user's stats for this dispensary
    const stats = await db
      .select({
        totalVisits: count(userDispensaryHistory.id),
        totalSpent: sum(userDispensaryHistory.amount),
      })
      .from(userDispensaryHistory)
      .where(and(
        eq(userDispensaryHistory.userId, userId),
        eq(userDispensaryHistory.dispensaryId, dispensaryId)
      ));

    const totalVisits = Number(stats[0]?.totalVisits || 0);
    const totalSpent = Number(stats[0]?.totalSpent || 0);

    // Check if qualifies (5+ visits OR $200+ spent)
    if (totalVisits >= 5 || totalSpent >= 200) {
      // Check if already ambassador
      const existing = await db
        .select()
        .from(dispensaryAmbassadors)
        .where(and(
          eq(dispensaryAmbassadors.userId, userId),
          eq(dispensaryAmbassadors.dispensaryId, dispensaryId)
        ))
        .limit(1);

      if (existing.length === 0) {
        // Create new ambassador record
        const ambassadorLevel = this.determineAmbassadorLevel(totalVisits, totalSpent);
        const loyaltyPoints = this.calculateTotalLoyaltyPoints(totalVisits, totalSpent);

        await db
          .insert(dispensaryAmbassadors)
          .values({
            userId,
            dispensaryId,
            totalVisits,
            totalSpent: totalSpent.toString(),
            ambassadorLevel,
            loyaltyPoints,
            exclusiveAccess: true,
          });
      } else {
        // Update existing ambassador
        const ambassadorLevel = this.determineAmbassadorLevel(totalVisits, totalSpent);
        const loyaltyPoints = this.calculateTotalLoyaltyPoints(totalVisits, totalSpent);

        await db
          .update(dispensaryAmbassadors)
          .set({
            totalVisits,
            totalSpent: totalSpent.toString(),
            ambassadorLevel,
            loyaltyPoints,
            updatedAt: new Date(),
          })
          .where(and(
            eq(dispensaryAmbassadors.userId, userId),
            eq(dispensaryAmbassadors.dispensaryId, dispensaryId)
          ));
      }
    }
  }

  /**
   * Determine ambassador level based on visits and spending
   */
  private static determineAmbassadorLevel(totalVisits: number, totalSpent: number): string {
    if (totalVisits >= 20 || totalSpent >= 1000) return 'platinum';
    if (totalVisits >= 15 || totalSpent >= 750) return 'gold';
    if (totalVisits >= 10 || totalSpent >= 500) return 'silver';
    return 'bronze';
  }

  /**
   * Calculate loyalty points for a visit
   */
  private static calculateLoyaltyPoints(visitType: string, amount: number): number {
    const basePoints = {
      'purchase': Math.floor(amount / 10), // 1 point per $10 spent
      'visit': 5, // 5 points for just visiting
      'order': Math.floor(amount / 10), // Same as purchase
    };

    return basePoints[visitType as keyof typeof basePoints] || 0;
  }

  /**
   * Calculate total loyalty points
   */
  private static calculateTotalLoyaltyPoints(totalVisits: number, totalSpent: number): number {
    return Math.floor(totalSpent / 10) + (totalVisits * 5);
  }

  /**
   * Check if user has required ambassador level
   */
  private static hasRequiredLevel(userLevel: string, requiredLevel: string): boolean {
    const levels = { bronze: 1, silver: 2, gold: 3, platinum: 4 };
    return levels[userLevel as keyof typeof levels] >= levels[requiredLevel as keyof typeof levels];
  }
}