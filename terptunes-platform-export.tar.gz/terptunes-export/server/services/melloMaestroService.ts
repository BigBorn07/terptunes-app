import { db } from "../db";
import { strains, terpeneProfiles, playlists } from "@shared/schema";
import { eq } from "drizzle-orm";
import SpotifyService from "./spotifyService";

/**
 * Mello Maestro Service - The Cannabis Music Alchemist
 * 
 * Mello Maestro is TerpTunes' AI-powered cannabis sommelier and music curator.
 * Every playlist flows through Maestro's unique "Euphonic Algorithm" that
 * combines deep cannabis knowledge with musical intuition.
 */
export class MelloMaestroService {
  /**
   * Maestro's Euphonic Algorithm - Transforms terpenes into musical experiences
   */
  static async createMaestroPlaylist(strainId: number, userId?: string): Promise<{
    playlist: any;
    maestroInsights: string;
    terpeneStory: string;
    musicalJourney: string[];
  }> {
    // Get strain and terpene profile through Maestro's lens
    const strain = await this.getMaestroStrainAnalysis(strainId);
    
    // Maestro's terpene interpretation
    const terpeneStory = this.generateTerpeneStory(strain);
    
    // Maestro's musical alchemy
    const musicalProfile = this.createMusicalProfile(strain.terpenes);
    
    // Generate playlist with Maestro's touch
    const playlist = await this.generateMaestroPlaylist(strain, musicalProfile, userId);
    
    // Maestro's insights for the user
    const maestroInsights = this.generateMaestroInsights(strain, musicalProfile);
    
    return {
      playlist,
      maestroInsights,
      terpeneStory,
      musicalJourney: musicalProfile.journey
    };
  }

  /**
   * Maestro's strain analysis - Deep cannabis knowledge meets musical intuition
   */
  private static async getMaestroStrainAnalysis(strainId: number) {
    const [strain] = await db
      .select()
      .from(strains)
      .where(eq(strains.id, strainId));

    const terpenes = await db
      .select()
      .from(terpeneProfiles)
      .where(eq(terpeneProfiles.strainId, strainId));

    return {
      ...strain,
      terpenes: terpenes.map(t => ({
        name: t.name,
        percentage: parseFloat(t.percentage || '0'),
        maestroNote: this.getMaestroTerpeneNote(t.name, parseFloat(t.percentage || '0'))
      }))
    };
  }

  /**
   * Maestro's terpene wisdom - Each terpene tells a story
   */
  private static getMaestroTerpeneNote(terpeneName: string, percentage: number): string {
    const notes: Record<string, string[]> = {
      'Myrcene': [
        'The Dreamweaver - guides you into deep relaxation',
        'Ancient sedative powers flowing through your being',
        'The bridge between earth and ethereal realms'
      ],
      'Limonene': [
        'The Mood Alchemist - lifting spirits skyward',
        'Citrus sunshine bursting with creative energy',
        'The key to unlocking euphoric dimensions'
      ],
      'Pinene': [
        'The Forest Sage - bringing clarity and focus',
        'Pine wisdom sharpening mental acuity',
        'Mountain air clearing the mental pathways'
      ],
      'Linalool': [
        'The Peaceful Healer - calming storms within',
        'Lavender fields of tranquil meditation',
        'The gentle embrace of inner harmony'
      ],
      'Caryophyllene': [
        'The Spice Master - adding complexity and depth',
        'Peppery warmth awakening the senses',
        'The guardian of pain relief and balance'
      ]
    };

    const terpeneNotes = notes[terpeneName] || ['A mysterious essence awaiting discovery'];
    const intensity = percentage > 1.5 ? 'powerfully' : percentage > 0.5 ? 'gently' : 'subtly';
    
    return `${intensity} ${terpeneNotes[Math.floor(Math.random() * terpeneNotes.length)]}`;
  }

  /**
   * Generate Maestro's terpene story - The narrative behind the strain
   */
  private static generateTerpeneStory(strain: any): string {
    const dominantTerpene = strain.terpenes.reduce((prev: any, current: any) => 
      (prev.percentage > current.percentage) ? prev : current
    );

    const stories: Record<string, string> = {
      'Myrcene': `In the depths of ${strain.name}'s essence, Myrcene reigns supreme at ${dominantTerpene.percentage}%. Like an ancient sleeping potion, it beckons you toward the realm of deep relaxation where time moves like honey and thoughts drift like clouds.`,
      
      'Limonene': `${strain.name} sparkles with Limonene's effervescent magic at ${dominantTerpene.percentage}%. This citrus alchemist transforms ordinary moments into extraordinary adventures, painting your world in vibrant hues of joy and creativity.`,
      
      'Pinene': `Sharp and focused, ${strain.name} carries Pinene's alpine wisdom at ${dominantTerpene.percentage}%. Like morning mist through pine forests, it clears mental fog and sharpens perception, revealing hidden truths in familiar melodies.`,
      
      'Linalool': `Wrapped in Linalool's gentle embrace at ${dominantTerpene.percentage}%, ${strain.name} whispers secrets of serenity. This lavender guardian dissolves tension and opens pathways to peaceful introspection.`,
      
      'Caryophyllene': `${strain.name} pulses with Caryophyllene's complex rhythm at ${dominantTerpene.percentage}%. This spicy conductor orchestrates relief and balance, adding layers of sophisticated depth to your musical journey.`
    };

    return stories[dominantTerpene.name] || `${strain.name} holds mysterious terpene secrets waiting to unfold through Maestro's musical interpretation.`;
  }

  /**
   * Create Maestro's musical profile - Translating chemistry to harmony
   */
  private static createMusicalProfile(terpenes: any[]) {
    const profile = {
      primaryMood: 'balanced',
      energy: 0.5,
      complexity: 0.5,
      genres: [] as string[],
      journey: [] as string[],
      maestroElements: [] as string[]
    };

    // Analyze terpene composition for musical direction
    for (const terpene of terpenes) {
      switch (terpene.name) {
        case 'Myrcene':
          if (terpene.percentage > 1.0) {
            profile.primaryMood = 'relaxed';
            profile.energy -= 0.3;
            profile.genres.push('ambient', 'downtempo', 'chillout');
            profile.journey.push('Descent into tranquil depths');
            profile.maestroElements.push('Ethereal pads and floating melodies');
          }
          break;
          
        case 'Limonene':
          if (terpene.percentage > 1.0) {
            profile.primaryMood = 'uplifting';
            profile.energy += 0.4;
            profile.genres.push('tropical house', 'nu-disco', 'indie pop');
            profile.journey.push('Burst of euphoric energy');
            profile.maestroElements.push('Bright synths and uplifting progressions');
          }
          break;
          
        case 'Pinene':
          if (terpene.percentage > 0.8) {
            profile.primaryMood = 'focused';
            profile.complexity += 0.3;
            profile.genres.push('minimal techno', 'progressive house', 'instrumental hip-hop');
            profile.journey.push('Sharpening of mental clarity');
            profile.maestroElements.push('Precise rhythms and crystalline textures');
          }
          break;
          
        case 'Linalool':
          if (terpene.percentage > 0.5) {
            profile.primaryMood = 'peaceful';
            profile.energy -= 0.2;
            profile.genres.push('neoclassical', 'meditation', 'soft jazz');
            profile.journey.push('Gentle embrace of serenity');
            profile.maestroElements.push('Warm harmonies and flowing arrangements');
          }
          break;
          
        case 'Caryophyllene':
          if (terpene.percentage > 0.5) {
            profile.complexity += 0.4;
            profile.genres.push('jazz fusion', 'world music', 'experimental');
            profile.journey.push('Layers of sophisticated complexity');
            profile.maestroElements.push('Rich harmonic textures and intricate rhythms');
          }
          break;
      }
    }

    // Ensure energy and complexity are within bounds
    profile.energy = Math.max(0.1, Math.min(1.0, profile.energy));
    profile.complexity = Math.max(0.1, Math.min(1.0, profile.complexity));

    // Default fallbacks
    if (profile.genres.length === 0) {
      profile.genres = ['electronic', 'ambient', 'chillout'];
      profile.journey.push('A mysterious musical exploration');
      profile.maestroElements.push('Enigmatic soundscapes awaiting discovery');
    }

    return profile;
  }

  /**
   * Generate Maestro's curated playlist with special algorithm
   */
  private static async generateMaestroPlaylist(strain: any, musicalProfile: any, userId?: string) {
    try {
      // Use Spotify service but enhance with Maestro's touch
      const spotifyService = new SpotifyService();
      
      // Create base playlist
      const basePlaylist = await spotifyService.createStrainPlaylist(strain.id, userId);
      
      // Add Maestro's enhancements
      const maestroPlaylist = {
        ...basePlaylist,
        name: `Maestro's ${strain.name} Experience`,
        description: `Curated by Mello Maestro - A musical journey through ${strain.name}'s terpene profile. ${musicalProfile.journey.join('. ')}.`,
        maestroSignature: true,
        terpeneMapping: strain.terpenes,
        musicalElements: musicalProfile.maestroElements,
        energyLevel: musicalProfile.energy,
        complexityScore: musicalProfile.complexity
      };

      // Store in database with Maestro attribution
      if (userId) {
        await db.insert(playlists).values({
          name: maestroPlaylist.name,
          description: maestroPlaylist.description,
          strainId: strain.id,
          userId: userId,
          spotifyId: maestroPlaylist.id,
          trackCount: maestroPlaylist.tracks?.length || 0,
          genre: musicalProfile.genres[0] || 'ambient',
          mood: musicalProfile.primaryMood,
          energyLevel: Math.round(musicalProfile.energy * 100),
          isMaestroCreated: true
        });
      }

      return maestroPlaylist;
    } catch (error) {
      console.error('Maestro playlist creation error:', error);
      
      // Maestro's fallback - never fails to deliver
      return {
        name: `Maestro's ${strain.name} Journey`,
        description: `A mystical musical exploration crafted by Mello Maestro`,
        maestroSignature: true,
        tracks: [],
        terpeneMapping: strain.terpenes,
        energyLevel: musicalProfile.energy,
        complexityScore: musicalProfile.complexity
      };
    }
  }

  /**
   * Generate Maestro's insights - Wisdom for the user
   */
  private static generateMaestroInsights(strain: any, musicalProfile: any): string {
    const insights = [
      `🎵 *Maestro's Musical Alchemy*`,
      `${strain.name} speaks to me in ${musicalProfile.primaryMood} frequencies...`,
      ``,
      `The terpene symphony reveals:`,
      ...strain.terpenes.slice(0, 3).map((t: any) => `• ${t.name} (${t.percentage}%) - ${t.maestroNote}`),
      ``,
      `*Musical Direction:* ${musicalProfile.journey.join(' → ')}`,
      `*Sonic Elements:* ${musicalProfile.maestroElements.join(', ')}`,
      ``,
      `*Maestro's Recommendation:* Best experienced ${this.getListeningContext(musicalProfile.primaryMood)} with quality headphones for maximum terpene-music synergy.`
    ];

    return insights.join('\n');
  }

  /**
   * Get Maestro's listening context recommendation
   */
  private static getListeningContext(mood: string): string {
    const contexts: Record<string, string> = {
      'relaxed': 'during golden hour or evening wind-down',
      'uplifting': 'in natural sunlight or during creative sessions',
      'focused': 'in a quiet space with minimal distractions',
      'peaceful': 'in meditation or contemplative moments',
      'balanced': 'anytime your spirit needs musical nourishment'
    };

    return contexts[mood] || 'when your soul calls for musical exploration';
  }

  /**
   * Maestro's strain recommendation system
   */
  static async getMaestroStrainRecommendations(userPreferences: {
    mood?: string;
    genre?: string;
    energy?: number;
  }): Promise<any[]> {
    try {
      // Get all strains and let Maestro analyze them
      const allStrains = await db.select().from(strains).limit(50);
      
      const recommendations = [];
      
      for (const strain of allStrains) {
        const terpenes = await db
          .select()
          .from(terpeneProfiles)
          .where(eq(terpeneProfiles.strainId, strain.id));

        const musicalProfile = this.createMusicalProfile(
          terpenes.map(t => ({
            name: t.name,
            percentage: parseFloat(t.percentage || '0')
          }))
        );

        // Maestro's matching algorithm
        let compatibilityScore = 0;

        if (userPreferences.mood && musicalProfile.primaryMood === userPreferences.mood) {
          compatibilityScore += 0.4;
        }

        if (userPreferences.energy) {
          const energyDiff = Math.abs(musicalProfile.energy - userPreferences.energy);
          compatibilityScore += (1 - energyDiff) * 0.3;
        }

        if (userPreferences.genre && musicalProfile.genres.includes(userPreferences.genre)) {
          compatibilityScore += 0.3;
        }

        if (compatibilityScore > 0.5) {
          recommendations.push({
            ...strain,
            maestroScore: Math.round(compatibilityScore * 100),
            musicalProfile,
            maestroNote: this.generateMaestroRecommendationNote(strain, musicalProfile)
          });
        }
      }

      // Sort by Maestro's compatibility score
      return recommendations
        .sort((a, b) => b.maestroScore - a.maestroScore)
        .slice(0, 6);
        
    } catch (error) {
      console.error('Maestro recommendation error:', error);
      return [];
    }
  }

  /**
   * Generate Maestro's recommendation note
   */
  private static generateMaestroRecommendationNote(strain: any, musicalProfile: any): string {
    const notes = [
      `Perfect for ${musicalProfile.primaryMood} vibes with ${musicalProfile.genres[0]} undertones`,
      `Maestro senses strong musical potential in this ${strain.type} blend`,
      `The terpene harmony here creates exceptional ${musicalProfile.primaryMood} frequencies`,
      `A hidden gem in Maestro's collection - ideal for ${musicalProfile.primaryMood} sessions`
    ];

    return notes[Math.floor(Math.random() * notes.length)];
  }
}

export default MelloMaestroService;