// Spotify Web API Integration for TerpTunes
import { Strain, TerpeneProfile } from "@shared/schema";

interface SpotifyTrack {
  id: string;
  name: string;
  artists: Array<{ name: string }>;
  uri: string;
  external_urls: { spotify: string };
  duration_ms: number;
  preview_url?: string;
}

interface SpotifyPlaylist {
  id: string;
  name: string;
  external_urls: { spotify: string };
  tracks: { total: number };
}

interface SpotifyUser {
  id: string;
  display_name: string;
  email: string;
  country: string;
}

interface TerpeneToMusicMapping {
  genres: string[];
  moods: string[];
  energy: number; // 0.0 - 1.0
  valence: number; // 0.0 - 1.0
  danceability: number; // 0.0 - 1.0
  acousticness: number; // 0.0 - 1.0
  instrumentalness: number; // 0.0 - 1.0
}

export class SpotifyService {
  private static readonly API_BASE = 'https://api.spotify.com/v1';
  private static readonly AUTH_BASE = 'https://accounts.spotify.com';

  /**
   * Terpene to music characteristic mappings based on scientific research
   */
  private static readonly TERPENE_MUSIC_MAP: Record<string, TerpeneToMusicMapping> = {
    'Myrcene': {
      genres: ['ambient', 'chill', 'lo-fi', 'downtempo', 'reggae'],
      moods: ['relaxed', 'mellow', 'peaceful'],
      energy: 0.3,
      valence: 0.4,
      danceability: 0.3,
      acousticness: 0.7,
      instrumentalness: 0.5
    },
    'Limonene': {
      genres: ['pop', 'indie-pop', 'electronic', 'funk', 'disco'],
      moods: ['happy', 'uplifting', 'energetic'],
      energy: 0.8,
      valence: 0.8,
      danceability: 0.7,
      acousticness: 0.3,
      instrumentalness: 0.2
    },
    'Beta-Caryophyllene': {
      genres: ['rock', 'alternative', 'grunge', 'punk'],
      moods: ['intense', 'powerful', 'edgy'],
      energy: 0.9,
      valence: 0.6,
      danceability: 0.6,
      acousticness: 0.2,
      instrumentalness: 0.3
    },
    'Alpha-Pinene': {
      genres: ['folk', 'acoustic', 'country', 'indie-folk'],
      moods: ['focused', 'clear', 'natural'],
      energy: 0.5,
      valence: 0.6,
      danceability: 0.4,
      acousticness: 0.8,
      instrumentalness: 0.4
    },
    'Linalool': {
      genres: ['classical', 'new-age', 'meditation', 'spa'],
      moods: ['calm', 'serene', 'peaceful'],
      energy: 0.2,
      valence: 0.5,
      danceability: 0.2,
      acousticness: 0.9,
      instrumentalness: 0.8
    },
    'Beta-Pinene': {
      genres: ['world-music', 'nature', 'acoustic'],
      moods: ['fresh', 'natural', 'clear'],
      energy: 0.4,
      valence: 0.7,
      danceability: 0.3,
      acousticness: 0.8,
      instrumentalness: 0.6
    },
    'Humulene': {
      genres: ['blues', 'jazz', 'soul', 'r-n-b'],
      moods: ['earthy', 'deep', 'sophisticated'],
      energy: 0.6,
      valence: 0.5,
      danceability: 0.5,
      acousticness: 0.5,
      instrumentalness: 0.3
    },
    'Terpinolene': {
      genres: ['experimental', 'electronic', 'synth-pop'],
      moods: ['creative', 'inspiring', 'unique'],
      energy: 0.7,
      valence: 0.7,
      danceability: 0.6,
      acousticness: 0.3,
      instrumentalness: 0.4
    }
  };

  /**
   * Generate Spotify authorization URL
   */
  static generateAuthUrl(state: string): string {
    const scopes = [
      'playlist-modify-public',
      'playlist-modify-private',
      'user-read-private',
      'user-read-email'
    ].join(' ');

    const params = new URLSearchParams({
      response_type: 'code',
      client_id: process.env.SPOTIFY_CLIENT_ID!,
      scope: scopes,
      redirect_uri: this.getRedirectUri(),
      state
    });

    return `${this.AUTH_BASE}/authorize?${params.toString()}`;
  }

  /**
   * Exchange authorization code for access token
   */
  static async exchangeCodeForTokens(code: string): Promise<{
    access_token: string;
    refresh_token: string;
    expires_in: number;
  }> {
    const response = await fetch(`${this.AUTH_BASE}/api/token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${Buffer.from(`${process.env.SPOTIFY_CLIENT_ID}:${process.env.SPOTIFY_CLIENT_SECRET}`).toString('base64')}`
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: this.getRedirectUri()
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Spotify token exchange failed: ${error}`);
    }

    return await response.json();
  }

  /**
   * Refresh access token
   */
  static async refreshAccessToken(refreshToken: string): Promise<{
    access_token: string;
    expires_in: number;
  }> {
    const response = await fetch(`${this.AUTH_BASE}/api/token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${Buffer.from(`${process.env.SPOTIFY_CLIENT_ID}:${process.env.SPOTIFY_CLIENT_SECRET}`).toString('base64')}`
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: refreshToken
      })
    });

    if (!response.ok) {
      throw new Error('Failed to refresh Spotify token');
    }

    return await response.json();
  }

  /**
   * Get user profile
   */
  static async getUserProfile(accessToken: string): Promise<SpotifyUser> {
    const response = await this.spotifyRequest('/me', accessToken);
    return response;
  }

  /**
   * Create playlist based on strain's terpene profile
   */
  static async createStrainPlaylist(
    accessToken: string,
    strain: Strain,
    terpenes: TerpeneProfile[],
    trackCount: number = 30
  ): Promise<SpotifyPlaylist> {
    // Get user profile for playlist creation
    const user = await this.getUserProfile(accessToken);
    
    // Generate musical characteristics from terpene profile
    const musicProfile = this.generateMusicProfileFromTerpenes(terpenes);
    
    // Search for tracks based on the musical profile
    const tracks = await this.searchTracksForProfile(accessToken, musicProfile, trackCount);
    
    if (tracks.length === 0) {
      throw new Error('No suitable tracks found for this strain profile');
    }

    // Create the playlist
    const playlistName = `${strain.name} Vibes`;
    const playlistDescription = `Curated by TerpTunes based on ${strain.name}'s terpene profile. ${this.generatePlaylistDescription(strain, terpenes, musicProfile)}`;

    const playlist = await this.createPlaylist(
      accessToken,
      user.id,
      playlistName,
      playlistDescription
    );

    // Add tracks to playlist
    await this.addTracksToPlaylist(
      accessToken,
      playlist.id,
      tracks.map(track => track.uri)
    );

    return playlist;
  }

  /**
   * Generate musical profile from terpene data
   */
  private static generateMusicProfileFromTerpenes(terpenes: TerpeneProfile[]): {
    genres: string[];
    audioFeatures: Record<string, number>;
    searchTerms: string[];
  } {
    const genreWeights: Record<string, number> = {};
    let totalEnergy = 0;
    let totalValence = 0;
    let totalDanceability = 0;
    let totalAcousticness = 0;
    let totalInstrumentalness = 0;
    let totalWeight = 0;

    // Process each terpene's contribution
    for (const terpene of terpenes) {
      const mapping = this.TERPENE_MUSIC_MAP[terpene.terpeneName];
      if (!mapping) continue;

      const weight = parseFloat(terpene.percentage || '0');
      totalWeight += weight;

      // Accumulate genre preferences
      mapping.genres.forEach(genre => {
        genreWeights[genre] = (genreWeights[genre] || 0) + weight;
      });

      // Accumulate audio features
      totalEnergy += mapping.energy * weight;
      totalValence += mapping.valence * weight;
      totalDanceability += mapping.danceability * weight;
      totalAcousticness += mapping.acousticness * weight;
      totalInstrumentalness += mapping.instrumentalness * weight;
    }

    // Normalize values
    const normalize = (value: number) => totalWeight > 0 ? value / totalWeight : 0.5;

    // Select top genres
    const sortedGenres = Object.entries(genreWeights)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3)
      .map(([genre]) => genre);

    return {
      genres: sortedGenres,
      audioFeatures: {
        energy: normalize(totalEnergy),
        valence: normalize(totalValence),
        danceability: normalize(totalDanceability),
        acousticness: normalize(totalAcousticness),
        instrumentalness: normalize(totalInstrumentalness)
      },
      searchTerms: [
        ...sortedGenres,
        totalEnergy / totalWeight > 0.6 ? 'energetic' : 'calm',
        totalValence / totalWeight > 0.6 ? 'happy' : 'chill'
      ]
    };
  }

  /**
   * Search for tracks matching the musical profile
   */
  private static async searchTracksForProfile(
    accessToken: string,
    profile: { genres: string[]; audioFeatures: Record<string, number>; searchTerms: string[] },
    limit: number
  ): Promise<SpotifyTrack[]> {
    const tracks: SpotifyTrack[] = [];
    const trackIds = new Set<string>();

    // Search using different strategies
    const searchStrategies = [
      // Genre-based searches
      ...profile.genres.map(genre => `genre:"${genre}"`),
      // Mood-based searches
      ...profile.searchTerms.slice(0, 3),
      // Year ranges for variety
      'year:2020-2024',
      'year:2015-2019',
      'year:2010-2014'
    ];

    for (const searchQuery of searchStrategies) {
      if (tracks.length >= limit) break;

      try {
        const searchResults = await this.spotifyRequest(
          `/search?q=${encodeURIComponent(searchQuery)}&type=track&limit=50`,
          accessToken
        );

        for (const track of searchResults.tracks.items) {
          if (trackIds.has(track.id) || tracks.length >= limit) continue;
          
          // Filter out explicit tracks and very short/long tracks
          if (!track.explicit && track.duration_ms > 30000 && track.duration_ms < 600000) {
            tracks.push(track);
            trackIds.add(track.id);
          }
        }
      } catch (error) {
        console.warn(`Search failed for query: ${searchQuery}`, error);
      }
    }

    // If we still need more tracks, do a recommendations call
    if (tracks.length < limit && tracks.length > 0) {
      try {
        const seedTracks = tracks.slice(0, 5).map(t => t.id);
        const recommendations = await this.spotifyRequest(
          `/recommendations?seed_tracks=${seedTracks.join(',')}&limit=${limit - tracks.length}&target_energy=${profile.audioFeatures.energy}&target_valence=${profile.audioFeatures.valence}`,
          accessToken
        );

        for (const track of recommendations.tracks) {
          if (!trackIds.has(track.id) && tracks.length < limit) {
            tracks.push(track);
            trackIds.add(track.id);
          }
        }
      } catch (error) {
        console.warn('Recommendations failed', error);
      }
    }

    return tracks;
  }

  /**
   * Create a new playlist
   */
  private static async createPlaylist(
    accessToken: string,
    userId: string,
    name: string,
    description: string
  ): Promise<SpotifyPlaylist> {
    return await this.spotifyRequest(`/users/${userId}/playlists`, accessToken, {
      method: 'POST',
      body: JSON.stringify({
        name,
        description,
        public: false
      })
    });
  }

  /**
   * Add tracks to playlist
   */
  private static async addTracksToPlaylist(
    accessToken: string,
    playlistId: string,
    trackUris: string[]
  ): Promise<void> {
    // Add tracks in batches of 100 (Spotify's limit)
    for (let i = 0; i < trackUris.length; i += 100) {
      const batch = trackUris.slice(i, i + 100);
      
      await this.spotifyRequest(`/playlists/${playlistId}/tracks`, accessToken, {
        method: 'POST',
        body: JSON.stringify({
          uris: batch
        })
      });
    }
  }

  /**
   * Make authenticated request to Spotify API
   */
  private static async spotifyRequest(
    endpoint: string, 
    accessToken: string, 
    options: RequestInit = {}
  ): Promise<any> {
    const response = await fetch(`${this.API_BASE}${endpoint}`, {
      ...options,
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        ...options.headers
      }
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Spotify API error: ${response.status} ${error}`);
    }

    return await response.json();
  }

  /**
   * Generate playlist description
   */
  private static generatePlaylistDescription(
    strain: Strain,
    terpenes: TerpeneProfile[],
    musicProfile: any
  ): string {
    const topTerpenes = terpenes
      .sort((a, b) => parseFloat(b.percentage || '0') - parseFloat(a.percentage || '0'))
      .slice(0, 3)
      .map(t => t.terpeneName);

    return `${strain.type?.charAt(0).toUpperCase() + strain.type?.slice(1)} strain featuring ${topTerpenes.join(', ')}. Musical mood: ${musicProfile.genres.join(', ')}.`;
  }

  /**
   * Determine primary genre based on dominant terpenes
   */
  static getTerpeneGenre(dominantTerpenes: string[]): string {
    const terpeneGenres: { [key: string]: string } = {
      'Myrcene': 'ambient',
      'Limonene': 'electronic', 
      'Caryophyllene': 'rock',
      'Linalool': 'classical',
      'Pinene': 'folk',
      'Terpinolene': 'jazz',
      'Humulene': 'blues',
      'Ocimene': 'reggae',
      'Geraniol': 'indie',
      'Eucalyptol': 'techno'
    };

    // Find the most relevant genre based on dominant terpenes
    for (const terpene of dominantTerpenes) {
      if (terpeneGenres[terpene]) {
        return terpeneGenres[terpene];
      }
    }

    return 'chill'; // Default fallback using Spotify genre
  }

  /**
   * Get secondary genres for playlist diversity
   */
  static getSecondaryGenres(dominantTerpenes: string[]): string[] {
    const genreMap: { [key: string]: string[] } = {
      'Myrcene': ['chill', 'lo-fi'],
      'Limonene': ['pop', 'funk'],
      'Caryophyllene': ['indie', 'rock'],
      'Linalool': ['classical', 'ambient'],
      'Pinene': ['folk', 'country'],
      'Terpinolene': ['soul', 'r-n-b'],
      'Humulene': ['punk', 'metal'],
      'Ocimene': ['dance', 'world'],
      'Geraniol': ['indie', 'pop'],
      'Eucalyptol': ['house', 'trance']
    };

    const secondaryGenres: string[] = [];
    dominantTerpenes.forEach(terpene => {
      if (genreMap[terpene]) {
        secondaryGenres.push(...genreMap[terpene]);
      }
    });

    return Array.from(new Set(secondaryGenres)).slice(0, 3);
  }

  /**
   * Determine mood based on strain type and terpenes
   */
  static getTerpeneMood(strainType: string, dominantTerpenes: string[]): string {
    const terpeneMoods: { [key: string]: string } = {
      'Myrcene': 'relaxing',
      'Limonene': 'uplifting',
      'Caryophyllene': 'calming',
      'Linalool': 'meditative',
      'Pinene': 'focused',
      'Terpinolene': 'euphoric',
      'Humulene': 'energetic',
      'Ocimene': 'creative',
      'Geraniol': 'dreamy',
      'Eucalyptol': 'motivating'
    };

    // Start with terpene-based mood
    for (const terpene of dominantTerpenes) {
      if (terpeneMoods[terpene]) {
        let mood = terpeneMoods[terpene];
        
        // Modify based on strain type
        if (strainType === 'indica' && mood === 'energetic') {
          mood = 'calming';
        } else if (strainType === 'sativa' && mood === 'relaxing') {
          mood = 'focused';
        }
        
        return mood;
      }
    }

    // Fallback based on strain type
    switch (strainType) {
      case 'indica': return 'relaxing';
      case 'sativa': return 'energetic';
      case 'hybrid': return 'balanced';
      default: return 'chill';
    }
  }

  /**
   * Calculate energy level based on strain characteristics
   */
  static calculateEnergyLevel(strainType: string, terpenes: any[]): number {
    let baseEnergy = 0.5; // Default neutral energy

    // Adjust base energy by strain type
    switch (strainType) {
      case 'sativa': baseEnergy = 0.7; break;
      case 'indica': baseEnergy = 0.3; break;
      case 'hybrid': baseEnergy = 0.5; break;
    }

    // Adjust by terpene influence
    const energyTerpenes: { [key: string]: number } = {
      'Limonene': 0.2,    // Uplifting boost
      'Pinene': 0.15,     // Focus boost  
      'Terpinolene': 0.1, // Mild energy
      'Humulene': 0.05,   // Slight energy
      'Myrcene': -0.2,    // Sedating effect
      'Linalool': -0.15,  // Calming effect
      'Caryophyllene': -0.1 // Mild relaxation
    };

    terpenes.forEach(terpene => {
      const influence = energyTerpenes[terpene.name];
      if (influence !== undefined) {
        const percentage = parseFloat(terpene.percentage || '0') / 100;
        baseEnergy += influence * percentage;
      }
    });

    // Clamp between 0.1 and 0.9
    return Math.max(0.1, Math.min(0.9, baseEnergy));
  }

  /**
   * Get redirect URI
   */
  private static getRedirectUri(): string {
    // Use environment variable or construct from current domain
    return process.env.SPOTIFY_REDIRECT_URI || 
           `${process.env.REPLIT_DEV_DOMAIN || 'http://localhost:5000'}/api/spotify/callback`;
  }
}

export default SpotifyService;