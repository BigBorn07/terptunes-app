import { storage } from './storage.js';

// High-quality strain data based on the research recommendations
interface ManualStrainData {
  name: string;
  type: 'indica' | 'sativa' | 'hybrid';
  thcContent: string;
  cbdContent: string;
  description: string;
  effects: string[];
  flavors: string[];
  terpenes: Array<{ name: string; percentage: number }>;
}

// Professional-grade strain database based on lab testing data
const professionalStrains: ManualStrainData[] = [
  {
    name: "Girl Scout Cookies",
    type: "hybrid",
    thcContent: "19.8",
    cbdContent: "0.2",
    description: "Girl Scout Cookies is a popular hybrid strain known for its euphoric effects and sweet, earthy flavor profile. This strain offers a balanced high perfect for creative activities.",
    effects: ["Euphoric", "Creative", "Happy", "Relaxed", "Uplifted"],
    flavors: ["Sweet", "Earthy", "Peppery", "Vanilla"],
    terpenes: [
      { name: "Beta-Caryophyllene", percentage: 0.8 },
      { name: "Limonene", percentage: 0.6 },
      { name: "Myrcene", percentage: 0.5 },
      { name: "Linalool", percentage: 0.3 },
      { name: "Alpha-Pinene", percentage: 0.2 }
    ]
  },
  {
    name: "Gorilla Glue #4",
    type: "hybrid",
    thcContent: "24.2",
    cbdContent: "0.1",
    description: "Gorilla Glue #4 is a potent hybrid strain that delivers heavy-handed euphoria and relaxation. Known for its resinous buds and earthy, sour aroma with chocolate and coffee undertones.",
    effects: ["Relaxed", "Euphoric", "Happy", "Uplifted", "Sleepy"],
    flavors: ["Earthy", "Sour", "Chocolate", "Coffee"],
    terpenes: [
      { name: "Beta-Caryophyllene", percentage: 0.9 },
      { name: "Myrcene", percentage: 0.7 },
      { name: "Limonene", percentage: 0.4 },
      { name: "Humulene", percentage: 0.3 },
      { name: "Alpha-Pinene", percentage: 0.2 }
    ]
  },
  {
    name: "Wedding Cake",
    type: "indica",
    thcContent: "22.5",
    cbdContent: "0.3",
    description: "Wedding Cake is an indica-dominant hybrid known for its relaxing effects and sweet, vanilla flavor. This strain provides calming effects perfect for evening use.",
    effects: ["Relaxed", "Happy", "Euphoric", "Sedating", "Calming"],
    flavors: ["Sweet", "Vanilla", "Earthy", "Spicy"],
    terpenes: [
      { name: "Limonene", percentage: 0.8 },
      { name: "Beta-Caryophyllene", percentage: 0.6 },
      { name: "Myrcene", percentage: 0.5 },
      { name: "Linalool", percentage: 0.4 },
      { name: "Humulene", percentage: 0.2 }
    ]
  },
  {
    name: "Jack Herer",
    type: "sativa",
    thcContent: "18.9",
    cbdContent: "0.1",
    description: "Jack Herer is a renowned sativa strain that offers clear-headed, creative effects. Named after the cannabis activist, this strain is perfect for daytime use and creative endeavors.",
    effects: ["Energetic", "Creative", "Uplifted", "Focused", "Happy"],
    flavors: ["Spicy", "Pine", "Earthy", "Woody"],
    terpenes: [
      { name: "Alpha-Pinene", percentage: 1.0 },
      { name: "Beta-Pinene", percentage: 0.7 },
      { name: "Terpinolene", percentage: 0.6 },
      { name: "Beta-Caryophyllene", percentage: 0.4 },
      { name: "Myrcene", percentage: 0.3 }
    ]
  },
  {
    name: "White Widow",
    type: "hybrid",
    thcContent: "20.1",
    cbdContent: "0.2",
    description: "White Widow is a balanced hybrid strain that delivers a powerful burst of euphoria and energy. This classic strain is known for its white, crystalline buds and energizing effects.",
    effects: ["Energetic", "Euphoric", "Creative", "Happy", "Uplifted"],
    flavors: ["Earthy", "Woody", "Spicy", "Herbal"],
    terpenes: [
      { name: "Myrcene", percentage: 0.9 },
      { name: "Beta-Caryophyllene", percentage: 0.6 },
      { name: "Alpha-Pinene", percentage: 0.5 },
      { name: "Limonene", percentage: 0.4 },
      { name: "Terpinolene", percentage: 0.3 }
    ]
  },
  {
    name: "Purple Haze",
    type: "sativa",
    thcContent: "17.8",
    cbdContent: "0.1",
    description: "Purple Haze is a legendary sativa strain made famous by Jimi Hendrix. This strain offers uplifting, energetic effects with a sweet, berry flavor profile.",
    effects: ["Energetic", "Creative", "Euphoric", "Uplifted", "Happy"],
    flavors: ["Sweet", "Berry", "Earthy", "Spicy"],
    terpenes: [
      { name: "Beta-Caryophyllene", percentage: 0.8 },
      { name: "Alpha-Pinene", percentage: 0.7 },
      { name: "Myrcene", percentage: 0.5 },
      { name: "Linalool", percentage: 0.4 },
      { name: "Limonene", percentage: 0.3 }
    ]
  },
  {
    name: "Granddaddy Purple",
    type: "indica",
    thcContent: "21.3",
    cbdContent: "0.1",
    description: "Granddaddy Purple is a famous indica strain known for its deep relaxation and grape, berry flavors. This strain is perfect for evening use and stress relief.",
    effects: ["Relaxed", "Happy", "Sleepy", "Euphoric", "Sedating"],
    flavors: ["Grape", "Berry", "Sweet", "Earthy"],
    terpenes: [
      { name: "Myrcene", percentage: 1.2 },
      { name: "Beta-Caryophyllene", percentage: 0.5 },
      { name: "Alpha-Pinene", percentage: 0.4 },
      { name: "Linalool", percentage: 0.6 },
      { name: "Humulene", percentage: 0.2 }
    ]
  },
  {
    name: "Sour Diesel",
    type: "sativa",
    thcContent: "19.6",
    cbdContent: "0.1",
    description: "Sour Diesel is an energizing sativa strain known for its diesel-like aroma and fast-acting effects. This strain provides creative, uplifting effects perfect for daytime use.",
    effects: ["Energetic", "Creative", "Uplifted", "Happy", "Focused"],
    flavors: ["Diesel", "Pungent", "Earthy", "Citrus"],
    terpenes: [
      { name: "Beta-Caryophyllene", percentage: 0.9 },
      { name: "Limonene", percentage: 0.8 },
      { name: "Myrcene", percentage: 0.4 },
      { name: "Alpha-Pinene", percentage: 0.3 },
      { name: "Humulene", percentage: 0.2 }
    ]
  },
  {
    name: "Zkittlez",
    type: "indica",
    thcContent: "18.7",
    cbdContent: "0.1",
    description: "Zkittlez is an indica-dominant strain known for its tropical fruit flavors and relaxing effects. This strain offers a sweet, fruity experience with calming properties.",
    effects: ["Relaxed", "Happy", "Euphoric", "Calming", "Creative"],
    flavors: ["Tropical", "Fruity", "Sweet", "Berry"],
    terpenes: [
      { name: "Limonene", percentage: 1.1 },
      { name: "Beta-Caryophyllene", percentage: 0.7 },
      { name: "Linalool", percentage: 0.5 },
      { name: "Myrcene", percentage: 0.4 },
      { name: "Alpha-Pinene", percentage: 0.2 }
    ]
  },
  {
    name: "Gelato",
    type: "hybrid",
    thcContent: "20.8",
    cbdContent: "0.1",
    description: "Gelato is a dessert-inspired hybrid strain known for its sweet, creamy flavor and balanced effects. This strain offers euphoric relaxation perfect for social situations.",
    effects: ["Euphoric", "Relaxed", "Happy", "Creative", "Uplifted"],
    flavors: ["Sweet", "Creamy", "Berry", "Citrus"],
    terpenes: [
      { name: "Beta-Caryophyllene", percentage: 0.8 },
      { name: "Limonene", percentage: 0.6 },
      { name: "Linalool", percentage: 0.5 },
      { name: "Humulene", percentage: 0.3 },
      { name: "Myrcene", percentage: 0.4 }
    ]
  },
  {
    name: "Trainwreck",
    type: "hybrid",
    thcContent: "19.2",
    cbdContent: "0.1",
    description: "Trainwreck is a mind-bending hybrid strain with potent sativa effects that hit like a freight train. Known for its spicy pine scent and euphoric, energizing high.",
    effects: ["Euphoric", "Creative", "Happy", "Energetic", "Uplifted"],
    flavors: ["Spicy", "Pine", "Earthy", "Lemon"],
    terpenes: [
      { name: "Terpinolene", percentage: 0.9 },
      { name: "Myrcene", percentage: 0.7 },
      { name: "Alpha-Pinene", percentage: 0.6 },
      { name: "Beta-Caryophyllene", percentage: 0.4 },
      { name: "Limonene", percentage: 0.3 }
    ]
  },
  {
    name: "Pineapple Express",
    type: "hybrid",
    thcContent: "17.9",
    cbdContent: "0.1",
    description: "Pineapple Express is a hybrid strain that combines the potent and flavorful forces of parent strains Trainwreck and Hawaiian. Known for its tropical, citrus flavors.",
    effects: ["Energetic", "Happy", "Creative", "Euphoric", "Focused"],
    flavors: ["Tropical", "Pineapple", "Citrus", "Sweet"],
    terpenes: [
      { name: "Beta-Caryophyllene", percentage: 0.7 },
      { name: "Limonene", percentage: 1.0 },
      { name: "Alpha-Pinene", percentage: 0.5 },
      { name: "Myrcene", percentage: 0.3 },
      { name: "Terpinolene", percentage: 0.4 }
    ]
  },
  {
    name: "Sunset Sherbet",
    type: "indica",
    thcContent: "18.5",
    cbdContent: "0.1",
    description: "Sunset Sherbet is an indica-leaning hybrid that provides stress relief and physical relaxation. Known for its sweet, fruity flavor reminiscent of sherbet ice cream.",
    effects: ["Relaxed", "Happy", "Euphoric", "Uplifted", "Creative"],
    flavors: ["Sweet", "Fruity", "Citrus", "Berry"],
    terpenes: [
      { name: "Limonene", percentage: 0.9 },
      { name: "Beta-Caryophyllene", percentage: 0.6 },
      { name: "Linalool", percentage: 0.4 },
      { name: "Myrcene", percentage: 0.5 },
      { name: "Alpha-Pinene", percentage: 0.2 }
    ]
  },
  {
    name: "Strawberry Cough",
    type: "sativa",
    thcContent: "16.8",
    cbdContent: "0.1",
    description: "Strawberry Cough is a potent sativa strain known for its sweet strawberry scent and uplifting effects. This strain provides energetic, social effects perfect for daytime use.",
    effects: ["Energetic", "Happy", "Euphoric", "Creative", "Social"],
    flavors: ["Strawberry", "Sweet", "Berry", "Earthy"],
    terpenes: [
      { name: "Myrcene", percentage: 0.8 },
      { name: "Beta-Caryophyllene", percentage: 0.5 },
      { name: "Alpha-Pinene", percentage: 0.6 },
      { name: "Limonene", percentage: 0.4 },
      { name: "Terpinolene", percentage: 0.3 }
    ]
  },
  {
    name: "Critical Kush",
    type: "indica",
    thcContent: "23.1",
    cbdContent: "0.2",
    description: "Critical Kush is a heavily indica-dominant strain that provides deep physical relaxation and sedating effects. Perfect for evening use and managing stress.",
    effects: ["Relaxed", "Sleepy", "Happy", "Euphoric", "Sedating"],
    flavors: ["Earthy", "Woody", "Spicy", "Hash"],
    terpenes: [
      { name: "Myrcene", percentage: 1.3 },
      { name: "Beta-Caryophyllene", percentage: 0.7 },
      { name: "Linalool", percentage: 0.6 },
      { name: "Humulene", percentage: 0.4 },
      { name: "Alpha-Pinene", percentage: 0.2 }
    ]
  }
];

export async function manualSeedDatabase(): Promise<{ totalSeeded: number; newStrains: string[] }> {
  console.log('🌿 Starting manual database seeding with professional strain data...');
  
  const newStrains: string[] = [];
  let totalSeeded = 0;

  try {
    // Get existing strains to avoid duplicates
    const existingStrains = await storage.getAllStrains();
    const existingNames = new Set(existingStrains.map(s => s.name.toLowerCase()));
    
    console.log(`📊 Found ${existingStrains.length} existing strains in database`);

    for (const strainData of professionalStrains) {
      try {
        // Skip if strain already exists
        if (existingNames.has(strainData.name.toLowerCase())) {
          console.log(`⏭️  Skipping ${strainData.name} (already exists)`);
          continue;
        }

        // Create strain in database
        const createdStrain = await storage.createStrain({
          name: strainData.name,
          type: strainData.type,
          thcContent: strainData.thcContent,
          cbdContent: strainData.cbdContent,
          description: strainData.description,
          effects: strainData.effects,
          flavors: strainData.flavors,
          imageUrl: null
        });
        
        // Create terpene profiles
        for (const terpene of strainData.terpenes) {
          await storage.createTerpeneProfile({
            strainId: createdStrain.id,
            terpeneName: terpene.name,
            percentage: terpene.percentage.toString()
          });
        }
        
        totalSeeded++;
        newStrains.push(strainData.name);
        existingNames.add(strainData.name.toLowerCase());
        
        console.log(`✅ Seeded: ${strainData.name} (${strainData.terpenes.length} terpenes)`);
        
      } catch (error) {
        console.error(`❌ Error seeding ${strainData.name}:`, error);
      }
    }

    console.log('\n🎉 Manual seeding completed!');
    console.log(`📈 Statistics:`);
    console.log(`   - Successfully seeded: ${totalSeeded} strains`);
    console.log(`\n🌟 New strains added:`);
    newStrains.forEach(name => console.log(`   - ${name}`));

    return { totalSeeded, newStrains };
    
  } catch (error) {
    console.error('💥 Manual seeding failed:', error);
    throw error;
  }
}

// Run seeding if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  manualSeedDatabase()
    .then(result => {
      console.log(`\n🏁 Seeding process completed successfully - ${result.totalSeeded} strains added`);
      process.exit(0);
    })
    .catch(error => {
      console.error('💥 Seeding process failed:', error);
      process.exit(1);
    });
}