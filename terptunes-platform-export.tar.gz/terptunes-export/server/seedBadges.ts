import { db } from "./db";
import { badges } from "@shared/schema";
import type { InsertBadge } from "@shared/schema";

export async function seedBadges(): Promise<void> {
  console.log("🏆 Seeding badge system...");
  
  const badgeData: InsertBadge[] = [
    // Terpene Discovery Badges
    {
      name: "Myrcene Master",
      description: "Discover 5 strains high in Myrcene, the sedating terpene found in mangoes",
      category: "terpene",
      icon: "🥭",
      requirement: {
        type: "terpene_expert",
        criteria: { terpene: "Myrcene", count: 5 }
      },
      rarity: "common",
      points: 100
    },
    {
      name: "Limonene Explorer",
      description: "Discover 5 strains high in Limonene, the uplifting citrus terpene",
      category: "terpene",
      icon: "🍋",
      requirement: {
        type: "terpene_expert",
        criteria: { terpene: "Limonene", count: 5 }
      },
      rarity: "common",
      points: 100
    },
    {
      name: "Pinene Pioneer",
      description: "Discover 5 strains high in Pinene, the alertness-promoting pine terpene",
      category: "terpene",
      icon: "🌲",
      requirement: {
        type: "terpene_expert",
        criteria: { terpene: "Pinene", count: 5 }
      },
      rarity: "common",
      points: 100
    },
    {
      name: "Linalool Lover",
      description: "Discover 5 strains high in Linalool, the calming lavender terpene",
      category: "terpene",
      icon: "💜",
      requirement: {
        type: "terpene_expert",
        criteria: { terpene: "Linalool", count: 5 }
      },
      rarity: "common",
      points: 100
    },
    {
      name: "Caryophyllene Connoisseur",
      description: "Discover 5 strains high in Caryophyllene, the anti-inflammatory spice terpene",
      category: "terpene",
      icon: "🌶️",
      requirement: {
        type: "terpene_expert",
        criteria: { terpene: "Caryophyllene", count: 5 }
      },
      rarity: "common",
      points: 100
    },
    {
      name: "Terpinolene Tracker",
      description: "Discover 3 strains high in Terpinolene, the rare floral terpene",
      category: "terpene",
      icon: "🌸",
      requirement: {
        type: "terpene_expert",
        criteria: { terpene: "Terpinolene", count: 3 }
      },
      rarity: "uncommon",
      points: 150
    },
    {
      name: "Humulene Hunter",
      description: "Discover 3 strains high in Humulene, the appetite-suppressing hop terpene",
      category: "terpene",
      icon: "🍺",
      requirement: {
        type: "terpene_expert",
        criteria: { terpene: "Humulene", count: 3 }
      },
      rarity: "uncommon",
      points: 150
    },
    {
      name: "Ocimene Oracle",
      description: "Discover 3 strains high in Ocimene, the sweet herbal terpene",
      category: "terpene",
      icon: "🌿",
      requirement: {
        type: "terpene_expert",
        criteria: { terpene: "Ocimene", count: 3 }
      },
      rarity: "rare",
      points: 200
    },

    // Strain Discovery Milestone Badges
    {
      name: "First Steps",
      description: "Discover your first cannabis strain profile",
      category: "discovery",
      icon: "👶",
      requirement: {
        type: "strain_discovery",
        criteria: { count: 1 }
      },
      rarity: "common",
      points: 25
    },
    {
      name: "Strain Seeker",
      description: "Discover 10 different cannabis strains",
      category: "discovery",
      icon: "🔍",
      requirement: {
        type: "strain_discovery",
        criteria: { count: 10 }
      },
      rarity: "common",
      points: 100
    },
    {
      name: "Cannabis Enthusiast",
      description: "Discover 25 different cannabis strains",
      category: "discovery",
      icon: "🌱",
      requirement: {
        type: "strain_discovery",
        criteria: { count: 25 }
      },
      rarity: "uncommon",
      points: 250
    },
    {
      name: "Strain Collector",
      description: "Discover 50 different cannabis strains",
      category: "discovery",
      icon: "📚",
      requirement: {
        type: "strain_discovery",
        criteria: { count: 50 }
      },
      rarity: "rare",
      points: 500
    },
    {
      name: "Cannabis Connoisseur",
      description: "Discover 100 different cannabis strains",
      category: "discovery",
      icon: "🎓",
      requirement: {
        type: "strain_discovery",
        criteria: { count: 100 }
      },
      rarity: "legendary",
      points: 1000
    },

    // Playlist Creation Badges
    {
      name: "First Mix",
      description: "Create your first terpene-based playlist",
      category: "playlist",
      icon: "🎵",
      requirement: {
        type: "playlist_creator",
        criteria: { count: 1 }
      },
      rarity: "common",
      points: 50
    },
    {
      name: "Music Mixer",
      description: "Create 5 terpene-based playlists",
      category: "playlist",
      icon: "🎼",
      requirement: {
        type: "playlist_creator",
        criteria: { count: 5 }
      },
      rarity: "uncommon",
      points: 200
    },
    {
      name: "Playlist Architect",
      description: "Create 15 terpene-based playlists",
      category: "playlist",
      icon: "🏗️",
      requirement: {
        type: "playlist_creator",
        criteria: { count: 15 }
      },
      rarity: "rare",
      points: 500
    },
    {
      name: "Music Curator",
      description: "Create 30 terpene-based playlists",
      category: "playlist",
      icon: "🎨",
      requirement: {
        type: "playlist_creator",
        criteria: { count: 30 }
      },
      rarity: "legendary",
      points: 1000
    },

    // Special Achievement Badges
    {
      name: "Terpene Scientist",
      description: "Master all 5 major terpenes (Myrcene, Limonene, Pinene, Linalool, Caryophyllene)",
      category: "knowledge",
      icon: "🧪",
      requirement: {
        type: "knowledge_test",
        criteria: { all_major_terpenes: true }
      },
      rarity: "legendary",
      points: 1500
    },
    {
      name: "Community Contributor",
      description: "Add a new strain to the TerpTunes database",
      category: "social",
      icon: "🤝",
      requirement: {
        type: "social_engagement",
        criteria: { strain_submission: 1 }
      },
      rarity: "uncommon",
      points: 300
    },
    {
      name: "Data Guardian",
      description: "Add 5 new strains to the TerpTunes database",
      category: "social",
      icon: "🛡️",
      requirement: {
        type: "social_engagement",
        criteria: { strain_submission: 5 }
      },
      rarity: "rare",
      points: 750
    }
  ];

  try {
    // Clear existing badges for clean slate
    await db.delete(badges);
    
    // Insert new badges
    await db.insert(badges).values(badgeData);
    
    console.log(`✅ Successfully seeded ${badgeData.length} badges`);
    console.log("Badge categories:");
    console.log("🧬 Terpene badges: 8 (teaching cannabis science)");
    console.log("🔍 Discovery badges: 5 (milestone achievements)");
    console.log("🎵 Playlist badges: 4 (music creation rewards)");
    console.log("🏆 Special badges: 3 (community & expertise)");
    
  } catch (error) {
    console.error("❌ Error seeding badges:", error);
    throw error;
  }
}

// Run if called directly
if (import.meta.main) {
  seedBadges()
    .then(() => {
      console.log("🎯 Badge seeding complete!");
      process.exit(0);
    })
    .catch((error) => {
      console.error("💥 Badge seeding failed:", error);
      process.exit(1);
    });
}