/**
 * Database startup and initialization script
 * Handles seeding and database setup separately from main application startup
 */

import { db } from "./db";
import { strains } from "@shared/schema";
import { count } from "drizzle-orm";
import { manualSeedDatabase } from "./manualSeed";

interface StartupOptions {
  forceReseed?: boolean;
  skipSeeding?: boolean;
}

export async function initializeDatabase(options: StartupOptions = {}): Promise<void> {
  console.log('🔧 Initializing database...');
  
  try {
    // Test database connection
    await db.select({ count: count() }).from(strains);
    console.log('✅ Database connection established');
    
    if (options.skipSeeding) {
      console.log('⏭️ Skipping database seeding');
      return;
    }
    
    // Check if database needs seeding
    const [strainCount] = await db.select({ count: count() }).from(strains);
    const hasData = strainCount.count > 0;
    
    if (hasData && !options.forceReseed) {
      console.log(`📊 Database already contains ${strainCount.count} strains, skipping seeding`);
      return;
    }
    
    if (options.forceReseed) {
      console.log('🔄 Force reseeding requested');
    }
    
    // Only seed if database is empty or force reseed is requested
    if (!hasData || options.forceReseed) {
      console.log('🌱 Database is empty, starting seeding process...');
      const result = await manualSeedDatabase();
      console.log(`✅ Database seeding completed: ${result.totalSeeded} strains added`);
    }
    
  } catch (error) {
    console.error('❌ Database initialization failed:', error);
    throw error;
  }
}

export async function quickDatabaseCheck(): Promise<boolean> {
  try {
    // Quick health check - just verify we can connect
    await db.select({ count: count() }).from(strains).limit(1);
    return true;
  } catch (error) {
    console.error('Database health check failed:', error);
    return false;
  }
}

// ES module execution detection - compatible with dynamic imports
function isExecutedDirectly(): boolean {
  try {
    // Multiple detection methods for robust ES module detection
    const isMain = import.meta.url === `file://${process.argv[1]}`;
    const isDirectExecution = process.argv[1]?.includes('startup');
    return isMain || isDirectExecution;
  } catch {
    return false;
  }
}

// Only run if executed directly (not imported)
if (isExecutedDirectly()) {
  console.log('[startup.ts] Running as standalone script');
  const args = process.argv.slice(2);
  const forceReseed = args.includes('--force');
  const skipSeeding = args.includes('--skip-seeding');
  
  initializeDatabase({ forceReseed, skipSeeding })
    .then(() => {
      console.log('🏁 Database initialization completed successfully');
      process.exit(0);
    })
    .catch(error => {
      console.error('💥 Database initialization failed:', error);
      process.exit(1);
    });
}