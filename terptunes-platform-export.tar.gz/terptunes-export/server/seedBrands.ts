import { db } from "./db";
import { brands } from "@shared/schema";

const popularBrands = [
  // Top California Cultivators
  {
    name: "Cookies",
    type: "cultivator",
    location: "California",
    website: "https://cookies.co/",
    description: "Premium cannabis company founded by rapper Berner and Jai, known for Girl Scout Cookies and other hybrid strains.",
    verified: true,
    strainCount: 45,
    userFavorites: 0,
  },
  {
    name: "Jungle Boys",
    type: "cultivator", 
    location: "California",
    website: "https://jungleboysstore.com/",
    description: "Los Angeles-based cultivator famous for Wedding Cake, Mimosa, and other premium indoor flower.",
    verified: true,
    strainCount: 32,
    userFavorites: 0,
  },
  {
    name: "Connected Cannabis Co",
    type: "cultivator",
    location: "California", 
    website: "https://connectedcannabis.com/",
    description: "High-end cultivator known for Alien Labs partnership and premium indoor cultivation.",
    verified: true,
    strainCount: 28,
    userFavorites: 0,
  },
  {
    name: "Alien Labs",
    type: "cultivator",
    location: "California",
    website: "https://alien-labs.com/",
    description: "Premium cannabis genetics and cultivation, creators of Atomic Apple and Xeno strains.",
    verified: true,
    strainCount: 24,
    userFavorites: 0,
  },
  {
    name: "Raw Garden",
    type: "processor",
    location: "California",
    website: "https://rawgarden.com/",
    description: "Leading California cannabis processor specializing in live resin vape cartridges and concentrates.",
    verified: true,
    strainCount: 67,
    userFavorites: 0,
  },
  
  // Colorado Brands
  {
    name: "Good Chemistry",
    type: "dispensary",
    location: "Colorado",
    website: "https://goodchem.com/",
    description: "Colorado-based dispensary chain with in-house cultivation and product lines.",
    verified: true,
    strainCount: 18,
    userFavorites: 0,
  },
  {
    name: "14er Boulder",
    type: "cultivator",
    location: "Colorado",
    website: "https://14erboulder.com/",
    description: "Boulder-based cultivator known for high-altitude growing and premium flower.",
    verified: true,
    strainCount: 15,
    userFavorites: 0,
  },

  // Other States
  {
    name: "Cresco Labs",
    type: "brand",
    location: "Illinois",
    website: "https://crescolabs.com/",
    description: "Multi-state operator with cultivation, processing, and retail operations.",
    verified: true,
    strainCount: 41,
    userFavorites: 0,
  },
  {
    name: "Curaleaf",
    type: "brand",
    location: "Massachusetts",
    website: "https://curaleaf.com/",
    description: "One of the largest cannabis companies in the US with operations across multiple states.",
    verified: true,
    strainCount: 35,
    userFavorites: 0,
  },
  {
    name: "Trulieve",
    type: "dispensary",
    location: "Florida",
    website: "https://trulieve.com/",
    description: "Leading medical cannabis dispensary chain in Florida with extensive product lines.",
    verified: true,
    strainCount: 52,
    userFavorites: 0,
  },

  // Craft/Boutique Cultivators
  {
    name: "710 Labs",
    type: "cultivator",
    location: "Colorado",
    website: "https://710labs.com/",
    description: "Boutique hash and flower producer known for artisanal quality and exclusive genetics.",
    verified: true,
    strainCount: 19,
    userFavorites: 0,
  },
  {
    name: "Phinest",
    type: "cultivator",
    location: "California",
    description: "Premium indoor cultivator known for Pink Runtz and other high-end strains.",
    verified: true,
    strainCount: 12,
    userFavorites: 0,
  },
];

export async function seedBrands(): Promise<void> {
  console.log("Seeding brands database...");
  
  try {
    // Check if brands already exist
    const existingBrands = await db.select().from(brands).limit(1);
    
    if (existingBrands.length > 0) {
      console.log("Brands already exist in database, skipping seed...");
      return;
    }

    // Insert brands
    const insertedBrands = await db
      .insert(brands)
      .values(popularBrands.map(brand => ({
        ...brand,
        createdAt: new Date(),
        updatedAt: new Date(),
      })))
      .returning();

    console.log(`Successfully seeded ${insertedBrands.length} brands`);
    
    // Show some examples
    console.log("Sample brands added:");
    insertedBrands.slice(0, 3).forEach(brand => {
      console.log(`- ${brand.name} (${brand.type}) - ${brand.location}`);
    });
    
  } catch (error) {
    console.error("Error seeding brands:", error);
    throw error;
  }
}

// Run seeding if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedBrands()
    .then(() => {
      console.log("Brand seeding completed");
      process.exit(0);
    })
    .catch((error) => {
      console.error("Brand seeding failed:", error);
      process.exit(1);
    });
}