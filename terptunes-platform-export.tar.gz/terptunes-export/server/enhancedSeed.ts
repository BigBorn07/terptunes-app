import { CannlyticsService } from './services/cannlyticsService.js';
import { storage } from './storage.js';
import fs from 'fs';

interface SeedStats {
  totalFetched: number;
  totalSeeded: number;
  skipped: number;
  errors: number;
  newStrains: string[];
  errorStrains: string[];
}

export async function enhancedSeedDatabase(): Promise<SeedStats> {
  console.log('🌿 Starting enhanced database seeding with Cannlytics API...');
  
  const stats: SeedStats = {
    totalFetched: 0,
    totalSeeded: 0,
    skipped: 0,
    errors: 0,
    newStrains: [],
    errorStrains: []
  };

  try {
    // Get existing strains to avoid duplicates
    const existingStrains = await storage.getAllStrains();
    const existingNames = new Set(existingStrains.map(s => s.name.toLowerCase()));
    
    console.log(`📊 Found ${existingStrains.length} existing strains in database`);

    // Fetch strains in batches to get comprehensive data
    const fetchBatches = [
      // Get high-quality strains with good terpene profiles
      { limit: 50, has_terpenes: true, min_total_thc: 10 },
      // Get popular indica strains
      { limit: 25, strain_type: 'indica', has_terpenes: true },
      // Get popular sativa strains  
      { limit: 25, strain_type: 'sativa', has_terpenes: true },
      // Get CBD-rich strains
      { limit: 20, min_total_cbd: 5, has_terpenes: true },
      // Get general high-quality strains
      { limit: 30, min_total_thc: 15, has_terpenes: true }
    ];

    for (const batchOptions of fetchBatches) {
      console.log(`\n🔍 Fetching batch: ${JSON.stringify(batchOptions)}`);
      
      try {
        const cannlyticsStrains = await CannlyticsService.getStrains(batchOptions);
        stats.totalFetched += cannlyticsStrains.length;
        
        console.log(`✅ Fetched ${cannlyticsStrains.length} strains from Cannlytics`);
        
        for (const cannlyticsStrain of cannlyticsStrains) {
          try {
            // Skip if strain has no name or invalid data
            if (!cannlyticsStrain.name || typeof cannlyticsStrain.name !== 'string') {
              stats.skipped++;
              continue;
            }

            // Skip if strain already exists
            if (existingNames.has(cannlyticsStrain.name.toLowerCase())) {
              stats.skipped++;
              continue;
            }

            // Map Cannlytics data to our format
            const { strain, terpenes } = CannlyticsService.mapToTerpTunesStrain(cannlyticsStrain);
            
            // Only seed strains with meaningful terpene profiles
            if (terpenes.length < 2) {
              stats.skipped++;
              continue;
            }

            // Create strain in database
            const createdStrain = await storage.createStrain(strain);
            
            // Create terpene profiles
            for (const terpene of terpenes) {
              await storage.createTerpeneProfile({
                strainId: createdStrain.id,
                terpeneName: terpene.name,
                percentage: terpene.percentage.toString()
              });
            }
            
            stats.totalSeeded++;
            stats.newStrains.push(strain.name);
            existingNames.add(strain.name.toLowerCase());
            
            console.log(`✅ Seeded: ${strain.name} (${terpenes.length} terpenes)`);
            
          } catch (error) {
            stats.errors++;
            const strainName = cannlyticsStrain.name || 'unnamed strain';
            stats.errorStrains.push(strainName);
            console.error(`❌ Error seeding ${strainName}:`, error);
          }
        }
        
        // Rate limiting - wait between batches
        await new Promise(resolve => setTimeout(resolve, 1000));
        
      } catch (error) {
        console.error('❌ Error fetching batch:', error);
      }
    }

    // Save seeding report
    const report = {
      timestamp: new Date().toISOString(),
      stats,
      source: 'Cannlytics API',
      summary: `Seeded ${stats.totalSeeded} new strains from ${stats.totalFetched} fetched strains`
    };
    
    fs.writeFileSync('seed-report.json', JSON.stringify(report, null, 2));
    
    console.log('\n🎉 Enhanced seeding completed!');
    console.log(`📈 Statistics:`);
    console.log(`   - Total fetched: ${stats.totalFetched}`);
    console.log(`   - Successfully seeded: ${stats.totalSeeded}`);
    console.log(`   - Skipped (duplicates/insufficient data): ${stats.skipped}`);
    console.log(`   - Errors: ${stats.errors}`);
    console.log(`\n🌟 New strains added:`);
    stats.newStrains.slice(0, 10).forEach(name => console.log(`   - ${name}`));
    if (stats.newStrains.length > 10) {
      console.log(`   ... and ${stats.newStrains.length - 10} more`);
    }

    return stats;
    
  } catch (error) {
    console.error('💥 Enhanced seeding failed:', error);
    throw error;
  }
}

// Run seeding if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  enhancedSeedDatabase()
    .then(stats => {
      console.log('\n🏁 Seeding process completed successfully');
      process.exit(0);
    })
    .catch(error => {
      console.error('💥 Seeding process failed:', error);
      process.exit(1);
    });
}