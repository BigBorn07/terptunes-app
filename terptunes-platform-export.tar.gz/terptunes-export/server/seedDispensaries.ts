import { db } from "./db";
import { dispensaries, dispensaryExclusives, userDispensaryHistory } from "@shared/schema";

export async function seedDispensaries(): Promise<void> {
  console.log("🏪 Seeding dispensaries...");

  // Sample dispensary data for Maryland (matches TerpTunes Maryland focus)
  const dispensariesData = [
    {
      name: "Culta",
      location: "Baltimore, MD",
      address: "949 Elkridge Landing Rd, Linthicum Heights, MD 21090",
      phone: "(410) 636-5380",
      website: "https://cultacannabis.com",
      hours: JSON.stringify({
        monday: "9:00 AM - 9:00 PM",
        tuesday: "9:00 AM - 9:00 PM",
        wednesday: "9:00 AM - 9:00 PM",
        thursday: "9:00 AM - 9:00 PM",
        friday: "9:00 AM - 9:00 PM",
        saturday: "9:00 AM - 9:00 PM",
        sunday: "9:00 AM - 8:00 PM"
      }),
      amenities: JSON.stringify(["delivery", "curbside", "online_ordering", "rewards_program"]),
      verified: true,
      rating: "4.6",
      description: "Maryland's premier cannabis dispensary offering premium flower, concentrates, and edibles from top cultivators like Curio and Grow West.",
    },
    {
      name: "Remedy Columbia",
      location: "Columbia, MD",
      address: "6950 Freetown Rd, Columbia, MD 21044",
      phone: "(410) 381-9400",
      website: "https://remedycolumbia.com",
      hours: JSON.stringify({
        monday: "8:00 AM - 9:00 PM",
        tuesday: "8:00 AM - 9:00 PM",
        wednesday: "8:00 AM - 9:00 PM",
        thursday: "8:00 AM - 9:00 PM",
        friday: "8:00 AM - 9:00 PM",
        saturday: "8:00 AM - 9:00 PM",
        sunday: "10:00 AM - 7:00 PM"
      }),
      amenities: JSON.stringify(["delivery", "curbside", "online_ordering", "consultation"]),
      verified: true,
      rating: "4.4",
      description: "Family-owned dispensary serving Columbia with a focus on education and customer service. Wide selection of flower, edibles, and wellness products.",
    },
    {
      name: "Zen Leaf",
      location: "Towson, MD",
      address: "1822 York Rd, Timonium, MD 21093",
      phone: "(410) 252-8420",
      website: "https://zenleafmd.com",
      hours: JSON.stringify({
        monday: "9:00 AM - 8:00 PM",
        tuesday: "9:00 AM - 8:00 PM",
        wednesday: "9:00 AM - 8:00 PM",
        thursday: "9:00 AM - 8:00 PM",
        friday: "9:00 AM - 8:00 PM",
        saturday: "9:00 AM - 8:00 PM",
        sunday: "10:00 AM - 6:00 PM"
      }),
      amenities: JSON.stringify(["curbside", "online_ordering", "rewards_program", "first_time_discount"]),
      verified: true,
      rating: "4.3",
      description: "Multi-state operator with a focus on quality and consistency. Offering a curated selection of cannabis products with competitive pricing.",
    },
    {
      name: "Health for Life",
      location: "Crisfield, MD",
      address: "26730 Mariners Rd, Crisfield, MD 21817",
      phone: "(443) 968-4420",
      website: "https://h4lmd.com",
      hours: JSON.stringify({
        monday: "9:00 AM - 8:00 PM",
        tuesday: "9:00 AM - 8:00 PM",
        wednesday: "9:00 AM - 8:00 PM",
        thursday: "9:00 AM - 8:00 PM",
        friday: "9:00 AM - 8:00 PM",
        saturday: "9:00 AM - 8:00 PM",
        sunday: "11:00 AM - 6:00 PM"
      }),
      amenities: JSON.stringify(["delivery", "online_ordering", "consultation", "veterans_discount"]),
      verified: true,
      rating: "4.5",
      description: "Serving the Eastern Shore with a commitment to wellness and community. Extensive product knowledge and personalized recommendations.",
    },
    {
      name: "Liberty Cannabis",
      location: "Rockville, MD",
      address: "15921 Shady Grove Rd, Gaithersburg, MD 20877",
      phone: "(301) 987-9333",
      website: "https://libertycannabis.com",
      hours: JSON.stringify({
        monday: "9:00 AM - 9:00 PM",
        tuesday: "9:00 AM - 9:00 PM",
        wednesday: "9:00 AM - 9:00 PM",
        thursday: "9:00 AM - 9:00 PM",
        friday: "9:00 AM - 9:00 PM",
        saturday: "9:00 AM - 9:00 PM",
        sunday: "10:00 AM - 7:00 PM"
      }),
      amenities: JSON.stringify(["delivery", "curbside", "online_ordering", "express_pickup"]),
      verified: true,
      rating: "4.2",
      description: "Montgomery County's trusted cannabis destination with a wide variety of products and knowledgeable staff ready to help find your perfect match.",
    }
  ];

  // Insert dispensaries
  const insertedDispensaries = await db
    .insert(dispensaries)
    .values(dispensariesData)
    .onConflictDoNothing()
    .returning();

  console.log(`✅ Seeded ${insertedDispensaries.length} dispensaries`);

  // Create sample exclusive rewards for each dispensary
  const exclusiveRewardsData = [];
  
  for (const dispensary of insertedDispensaries) {
    exclusiveRewardsData.push(
      {
        dispensaryId: dispensary.id,
        title: "20% Off Next Purchase",
        description: "Exclusive discount for loyal customers who have visited 5+ times",
        type: "discount",
        value: "20%",
        requiredLevel: "bronze",
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
        isActive: true,
      },
      {
        dispensaryId: dispensary.id,
        title: "Early Access to New Products",
        description: "Get first access to new strain drops and limited edition products",
        type: "early_access",
        value: "exclusive",
        requiredLevel: "silver",
        isActive: true,
      },
      {
        dispensaryId: dispensary.id,
        title: "VIP Consultation Session",
        description: "One-on-one consultation with our head budtender",
        type: "consultation",
        value: "exclusive",
        requiredLevel: "gold",
        isActive: true,
      },
      {
        dispensaryId: dispensary.id,
        title: "Ambassador Exclusive Strain",
        description: "Access to limited edition ambassador-only cannabis strains",
        type: "exclusive_strain",
        value: "exclusive",
        requiredLevel: "platinum",
        isActive: true,
      },
      {
        dispensaryId: dispensary.id,
        title: "Loyalty Points Bonus",
        description: "Double loyalty points on all purchases for a month",
        type: "loyalty_points",
        value: "2x points",
        requiredLevel: "bronze",
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
        isActive: true,
      }
    );
  }

  // Insert exclusive rewards
  const insertedRewards = await db
    .insert(dispensaryExclusives)
    .values(exclusiveRewardsData)
    .onConflictDoNothing()
    .returning();

  console.log(`✅ Seeded ${insertedRewards.length} exclusive rewards`);

  // Create sample visit history for the authenticated user (if exists)
  // This would normally be done through the API when users actually visit dispensaries
  const sampleVisitHistory = [
    {
      userId: "42775411", // Example user ID from Replit auth
      dispensaryId: insertedDispensaries[0]?.id || 1,
      visitType: "purchase",
      amount: "85.50",
      strainsPurchased: JSON.stringify([1, 2, 3]),
      visitDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
      rating: 5,
      review: "Great selection and knowledgeable staff!",
    },
    {
      userId: "42775411",
      dispensaryId: insertedDispensaries[0]?.id || 1,
      visitType: "purchase",
      amount: "92.00",
      strainsPurchased: JSON.stringify([4, 5]),
      visitDate: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000), // 2 weeks ago
      rating: 4,
    },
    {
      userId: "42775411",
      dispensaryId: insertedDispensaries[1]?.id || 2,
      visitType: "visit",
      visitDate: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000), // 3 weeks ago
      rating: 4,
      review: "Clean facility, good prices",
    },
  ];

  try {
    const insertedVisits = await db
      .insert(userDispensaryHistory)
      .values(sampleVisitHistory)
      .onConflictDoNothing()
      .returning();

    console.log(`✅ Seeded ${insertedVisits.length} sample dispensary visits`);
  } catch (error) {
    console.log("⚠️  Could not seed sample visits (user may not exist yet)");
  }

  console.log("🏪 Dispensary seeding completed!");
}

// Allow running this file directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDispensaries()
    .then(() => {
      console.log("Dispensary seeding completed successfully!");
      process.exit(0);
    })
    .catch((error) => {
      console.error("Error seeding dispensaries:", error);
      process.exit(1);
    });
}