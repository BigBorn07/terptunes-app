import fs from 'fs';
import { storage } from './storage.js';

interface MaxValueLabResult {
  databaseIdentifier: string;
  databaseName: string;
  testResultUID: string;
  sampleName: string;
  sampleType: string;
  receiptTime: string;
  testTime: string;
  postTime: string;
  provider: string;
  
  // Terpenes (in mg/g, convert to percentages)
  cisNerolidol?: number;
  transNerolidol?: number;
  transOcimene?: number;
  carene?: number;
  camphene?: number;
  caryophylleneOxide?: number;
  eucalyptol?: number;
  geraniol?: number;
  guaiol?: number;
  isopulegol?: number;
  linalool?: number;
  ocimene?: number;
  terpinolene?: number;
  alphaBisabolol?: number;
  alphaHumulene?: number;
  alphaPinene?: number;
  alphaTerpinene?: number;
  betaCaryophyllene?: number;
  betaMyrcene?: number;
  betaOcimene?: number;
  betaPinene?: number;
  deltaLimonene?: number;
  gammaTerpinene?: number;
  pCymene?: number;
  
  // Cannabinoids
  delta9THCA?: number;
  delta9THC?: number;
  delta8THC?: number;
  THCA?: number;
  THCV?: number;
  CBN?: number;
  CBDA?: number;
  CBD?: number;
  CBDV?: number;
  CBDVA?: number;
  delta9CBGA?: number;
  delta9CBG?: number;
  CBC?: number;
  moistureContent?: number;
}

interface ProcessedStrainData {
  name: string;
  type: 'indica' | 'sativa' | 'hybrid';
  thcContent: string;
  cbdContent: string;
  description: string;
  effects: string[];
  flavors: string[];
  terpenes: Array<{ name: string; percentage: number }>;
  labSource: string;
  sampleCount: number;
  qualityScore: number;
}

export class MaxValueImporter {
  
  /**
   * Import and process MaxValue lab dataset
   */
  static async importMaxValueDataset(filePath: string = 'attached_assets/maxvalue_results.csv'): Promise<{
    processed: number;
    imported: number;
    uniqueStrains: number;
    newStrains: string[];
    qualityStats: { high: number; medium: number; low: number };
  }> {
    console.log('🔬 Processing MaxValue lab dataset...');
    
    const csvContent = fs.readFileSync(filePath, 'utf-8');
    const lines = csvContent.trim().split('\n');
    const headers = lines[0].split(',');
    
    console.log(`Found ${lines.length - 1} lab test results`);
    
    // Parse all lab results
    const labResults: MaxValueLabResult[] = [];
    for (let i = 1; i < lines.length; i++) {
      try {
        const values = this.parseCSVLine(lines[i]);
        if (values.length >= headers.length - 5) { // Allow some missing columns
          const result = this.mapToLabResult(headers, values);
          if (result.sampleName && result.sampleName.trim()) {
            labResults.push(result);
          }
        }
      } catch (error) {
        // Skip malformed lines
      }
    }
    
    console.log(`✅ Parsed ${labResults.length} valid lab results`);
    
    // Group by strain name and aggregate data
    const strainGroups = this.groupAndAggregateByStrain(labResults);
    console.log(`📊 Found ${strainGroups.size} unique strain names`);
    
    // Process each strain group
    const results = {
      processed: 0,
      imported: 0,
      uniqueStrains: strainGroups.size,
      newStrains: [] as string[],
      qualityStats: { high: 0, medium: 0, low: 0 }
    };
    
    // Get existing strains to avoid duplicates
    const existingStrains = await storage.getAllStrains();
    const existingNames = new Set(existingStrains.map(s => s.name.toLowerCase()));
    
    for (const [strainName, aggregatedData] of strainGroups) {
      try {
        results.processed++;
        
        // Skip if strain already exists
        if (existingNames.has(strainName.toLowerCase())) {
          continue;
        }
        
        // Only import high-quality strains with meaningful terpene profiles
        if (aggregatedData.qualityScore < 0.3 || aggregatedData.terpenes.length < 3) {
          continue;
        }
        
        // Create strain in database
        const strain = await storage.createStrain({
          name: aggregatedData.name,
          type: aggregatedData.type,
          thcContent: aggregatedData.thcContent,
          cbdContent: aggregatedData.cbdContent,
          description: aggregatedData.description,
          effects: aggregatedData.effects,
          flavors: aggregatedData.flavors,
          imageUrl: null
        });
        
        // Add terpene profiles
        for (const terpene of aggregatedData.terpenes) {
          await storage.createTerpeneProfile({
            strainId: strain.id,
            terpeneName: terpene.name,
            percentage: terpene.percentage.toString()
          });
        }
        
        results.imported++;
        results.newStrains.push(aggregatedData.name);
        existingNames.add(strainName.toLowerCase());
        
        // Track quality stats
        if (aggregatedData.qualityScore > 0.8) results.qualityStats.high++;
        else if (aggregatedData.qualityScore > 0.5) results.qualityStats.medium++;
        else results.qualityStats.low++;
        
        console.log(`✅ Imported: ${aggregatedData.name} (${aggregatedData.terpenes.length} terpenes, ${aggregatedData.sampleCount} samples, quality: ${(aggregatedData.qualityScore * 100).toFixed(0)}%)`);
        
      } catch (error) {
        console.error(`Error importing ${strainName}:`, error);
      }
    }
    
    return results;
  }
  
  /**
   * Parse CSV line handling quoted fields
   */
  private static parseCSVLine(line: string): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current.trim());
    return result;
  }
  
  /**
   * Map CSV values to lab result object
   */
  private static mapToLabResult(headers: string[], values: string[]): MaxValueLabResult {
    const result: any = {};
    
    for (let i = 0; i < Math.min(headers.length, values.length); i++) {
      const header = headers[i].replace(/[^a-zA-Z0-9]/g, '');
      const value = values[i];
      
      if (value && value !== '') {
        const numValue = parseFloat(value);
        result[header] = isNaN(numValue) ? value : numValue;
      }
    }
    
    return {
      databaseIdentifier: result.DatabaseIdentifier || '',
      databaseName: result.DatabaseName || '',
      testResultUID: result.TestResultUID || '',
      sampleName: result.SampleName || '',
      sampleType: result.SampleType || '',
      receiptTime: result.ReceiptTime || '',
      testTime: result.TestTime || '',
      postTime: result.PostTime || '',
      provider: result.Provider || '',
      
      // Map terpenes
      linalool: result.Linalool,
      alphaHumulene: result.alphaHumulene,
      alphaPinene: result.alphaPinene,
      betaCaryophyllene: result.betaCaryophyllene,
      betaMyrcene: result.betaMyrcene,
      betaPinene: result.betaPinene,
      deltaLimonene: result.deltaLimonene,
      terpinolene: result.Terpinolene,
      ocimene: result.Ocimene,
      alphaBisabolol: result.alphaBisabolol,
      caryophylleneOxide: result.CaryophylleneOxide,
      eucalyptol: result.Eucalyptol,
      geraniol: result.Geraniol,
      guaiol: result.Guaiol,
      carene: result.Carene || result['3Carene'],
      camphene: result.Camphene,
      
      // Map cannabinoids
      delta9THC: result.delta9THC,
      delta9THCA: result.delta9THCA,
      CBD: result.CBD,
      CBDA: result.CBDA,
      CBG: result.delta9CBG,
      CBC: result.CBC,
      CBN: result.CBN
    };
  }
  
  /**
   * Group lab results by strain and aggregate data
   */
  private static groupAndAggregateByStrain(labResults: MaxValueLabResult[]): Map<string, ProcessedStrainData> {
    const strainGroups = new Map<string, MaxValueLabResult[]>();
    
    // Group by normalized strain name
    labResults.forEach(result => {
      const normalizedName = this.normalizeStrainName(result.sampleName);
      if (normalizedName) {
        if (!strainGroups.has(normalizedName)) {
          strainGroups.set(normalizedName, []);
        }
        strainGroups.get(normalizedName)!.push(result);
      }
    });
    
    const aggregatedStrains = new Map<string, ProcessedStrainData>();
    
    // Process each strain group
    strainGroups.forEach((results, strainName) => {
      if (results.length < 1) return; // Need at least 1 valid result
      
      const aggregated = this.aggregateStrainData(strainName, results);
      if (aggregated) {
        aggregatedStrains.set(strainName, aggregated);
      }
    });
    
    return aggregatedStrains;
  }
  
  /**
   * Normalize strain names for consistent grouping
   */
  private static normalizeStrainName(name: string): string | null {
    if (!name || typeof name !== 'string') return null;
    
    // Clean up the name
    let cleaned = name
      .replace(/[^\w\s-]/g, ' ') // Remove special chars except hyphens
      .replace(/\s+/g, ' ') // Normalize whitespace
      .trim();
    
    // Skip obvious non-strain names
    if (cleaned.length < 3 || 
        /^(test|sample|unknown|N\/A|null|undefined)$/i.test(cleaned) ||
        /^\d+$/.test(cleaned) ||
        cleaned.toLowerCase().includes('bho ') ||
        cleaned.toLowerCase().includes('wax ') ||
        cleaned.toLowerCase().includes('shatter ')) {
      return null;
    }
    
    return cleaned;
  }
  
  /**
   * Aggregate multiple lab results for the same strain
   */
  private static aggregateStrainData(strainName: string, results: MaxValueLabResult[]): ProcessedStrainData | null {
    if (results.length === 0) return null;
    
    // Aggregate terpene data
    const terpeneAggregates = new Map<string, number[]>();
    const cannabinoidAggregates = new Map<string, number[]>();
    
    results.forEach(result => {
      // Process terpenes (convert mg/g to percentages)
      const terpeneMap = {
        'Myrcene': result.betaMyrcene,
        'Limonene': result.deltaLimonene,
        'Beta-Caryophyllene': result.betaCaryophyllene,
        'Alpha-Pinene': result.alphaPinene,
        'Beta-Pinene': result.betaPinene,
        'Linalool': result.linalool,
        'Humulene': result.alphaHumulene,
        'Terpinolene': result.terpinolene,
        'Ocimene': result.ocimene,
        'Alpha-Bisabolol': result.alphaBisabolol,
        'Caryophyllene Oxide': result.caryophylleneOxide,
        'Eucalyptol': result.eucalyptol,
        'Geraniol': result.geraniol,
        'Guaiol': result.guaiol,
        'Carene': result.carene,
        'Camphene': result.camphene
      };
      
      Object.entries(terpeneMap).forEach(([name, value]) => {
        if (value && value > 0) {
          if (!terpeneAggregates.has(name)) {
            terpeneAggregates.set(name, []);
          }
          // Convert mg/g to percentage (divide by 10)
          terpeneAggregates.get(name)!.push(value / 10);
        }
      });
      
      // Process cannabinoids
      if (result.delta9THC) cannabinoidAggregates.set('THC', (cannabinoidAggregates.get('THC') || []).concat([result.delta9THC]));
      if (result.CBD) cannabinoidAggregates.set('CBD', (cannabinoidAggregates.get('CBD') || []).concat([result.CBD]));
    });
    
    // Calculate averages and build final terpene profile
    const terpenes: Array<{ name: string; percentage: number }> = [];
    terpeneAggregates.forEach((values, name) => {
      if (values.length > 0) {
        const average = values.reduce((a, b) => a + b, 0) / values.length;
        if (average > 0.01) { // Only include meaningful percentages (>0.01%)
          terpenes.push({ name, percentage: parseFloat(average.toFixed(3)) });
        }
      }
    });
    
    // Sort by percentage
    terpenes.sort((a, b) => b.percentage - a.percentage);
    
    // Calculate quality score based on sample count and terpene diversity
    const qualityScore = Math.min(1.0, 
      (results.length * 0.1) + // More samples = higher quality
      (terpenes.length * 0.1) + // More terpenes = higher quality
      (terpenes.filter(t => t.percentage > 0.1).length * 0.2) // Significant terpenes
    );
    
    // Determine strain type based on terpene profile
    const type = this.determineStrainType(terpenes);
    
    // Calculate cannabinoid averages
    const thcValues = cannabinoidAggregates.get('THC') || [];
    const cbdValues = cannabinoidAggregates.get('CBD') || [];
    
    const avgTHC = thcValues.length > 0 ? thcValues.reduce((a, b) => a + b, 0) / thcValues.length : 0;
    const avgCBD = cbdValues.length > 0 ? cbdValues.reduce((a, b) => a + b, 0) / cbdValues.length : 0;
    
    return {
      name: strainName,
      type,
      thcContent: avgTHC.toFixed(1),
      cbdContent: avgCBD.toFixed(1),
      description: this.generateDescription(strainName, type, terpenes, results.length),
      effects: this.generateEffectsFromTerpenes(type, terpenes),
      flavors: this.generateFlavorsFromTerpenes(terpenes),
      terpenes: terpenes.slice(0, 8), // Top 8 terpenes
      labSource: results[0].databaseName,
      sampleCount: results.length,
      qualityScore
    };
  }
  
  private static determineStrainType(terpenes: Array<{ name: string; percentage: number }>): 'indica' | 'sativa' | 'hybrid' {
    const myrcene = terpenes.find(t => t.name === 'Myrcene')?.percentage || 0;
    const pinene = terpenes.find(t => t.name === 'Alpha-Pinene')?.percentage || 0;
    const terpinolene = terpenes.find(t => t.name === 'Terpinolene')?.percentage || 0;
    
    // Classic terpene-based classification
    if (myrcene > 0.5) return 'indica'; // High myrcene = indica
    if (pinene > 0.3 || terpinolene > 0.3) return 'sativa'; // High pinene/terpinolene = sativa
    return 'hybrid';
  }
  
  private static generateEffectsFromTerpenes(type: 'indica' | 'sativa' | 'hybrid', terpenes: Array<{ name: string; percentage: number }>): string[] {
    const effects: string[] = [];
    
    // Base effects by type
    if (type === 'indica') {
      effects.push('Relaxed', 'Calming', 'Sleepy');
    } else if (type === 'sativa') {
      effects.push('Energetic', 'Uplifted', 'Creative');
    } else {
      effects.push('Balanced', 'Happy', 'Relaxed');
    }
    
    // Terpene-specific effects
    terpenes.slice(0, 3).forEach(terpene => {
      switch (terpene.name) {
        case 'Myrcene':
          if (!effects.includes('Sedating')) effects.push('Sedating');
          break;
        case 'Limonene':
          if (!effects.includes('Euphoric')) effects.push('Euphoric');
          break;
        case 'Beta-Caryophyllene':
          if (!effects.includes('Anti-inflammatory')) effects.push('Anti-inflammatory');
          break;
        case 'Linalool':
          if (!effects.includes('Calming')) effects.push('Calming');
          break;
        case 'Alpha-Pinene':
          if (!effects.includes('Focused')) effects.push('Focused');
          break;
      }
    });
    
    return effects.slice(0, 5);
  }
  
  private static generateFlavorsFromTerpenes(terpenes: Array<{ name: string; percentage: number }>): string[] {
    const flavors: string[] = [];
    
    terpenes.slice(0, 4).forEach(terpene => {
      switch (terpene.name) {
        case 'Myrcene':
          flavors.push('Earthy', 'Musky');
          break;
        case 'Limonene':
          flavors.push('Citrus', 'Lemon');
          break;
        case 'Beta-Caryophyllene':
          flavors.push('Spicy', 'Peppery');
          break;
        case 'Linalool':
          flavors.push('Floral', 'Lavender');
          break;
        case 'Alpha-Pinene':
          flavors.push('Pine', 'Fresh');
          break;
        case 'Beta-Pinene':
          flavors.push('Pine', 'Woody');
          break;
      }
    });
    
    return Array.from(new Set(flavors)).slice(0, 4);
  }
  
  private static generateDescription(name: string, type: string, terpenes: Array<{ name: string; percentage: number }>, sampleCount: number): string {
    const dominantTerpene = terpenes[0]?.name || 'terpenes';
    const typeDescription = type === 'indica' ? 'relaxing indica' : 
                           type === 'sativa' ? 'energizing sativa' : 
                           'balanced hybrid';
    
    return `${name} is a ${typeDescription} strain with a dominant ${dominantTerpene.toLowerCase()} profile. Lab-tested data from ${sampleCount} professional samples confirms its unique terpene composition, making it ideal for precision music playlist generation.`;
  }
}