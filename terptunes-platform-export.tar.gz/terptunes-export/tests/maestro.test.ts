import { describe, it, expect } from 'vitest'

describe('Mello Maestro Tests', () => {
  describe('Terpene to Music Mapping', () => {
    it('should map relaxing terpenes to ambient genres', () => {
      const relaxingTerpenes = [
        { name: 'Myrcene', percentage: 25.5 },
        { name: 'Linalool', percentage: 8.2 }
      ]
      
      // Test that high Myrcene and Linalool percentages suggest relaxing music
      const highMyrcene = relaxingTerpenes.find(t => t.name === 'Myrcene')
      const highLinalool = relaxingTerpenes.find(t => t.name === 'Linalool')
      
      expect(highMyrcene?.percentage).toBeGreaterThan(20)
      expect(highLinalool?.percentage).toBeGreaterThan(5)
    })

    it('should map energetic terpenes to upbeat genres', () => {
      const energeticTerpenes = [
        { name: 'Limonene', percentage: 18.7 },
        { name: 'Pinene', percentage: 12.3 }
      ]
      
      // Test that high Limonene and Pinene suggest energetic music
      const highLimonene = energeticTerpenes.find(t => t.name === 'Limonene')
      const highPinene = energeticTerpenes.find(t => t.name === 'Pinene')
      
      expect(highLimonene?.percentage).toBeGreaterThan(15)
      expect(highPinene?.percentage).toBeGreaterThan(10)
    })

    it('should calculate musical energy from terpene profile', () => {
      const terpenes = [
        { name: 'Myrcene', percentage: 15.0 },  // relaxing
        { name: 'Limonene', percentage: 20.0 }, // energetic
        { name: 'Pinene', percentage: 10.0 }    // focus
      ]
      
      // Mock energy calculation based on terpene weights
      const energyScore = terpenes.reduce((acc, terpene) => {
        const weights = {
          'Myrcene': -0.5,    // reduces energy
          'Limonene': 0.8,    // increases energy
          'Pinene': 0.3       // mild energy boost
        }
        return acc + (terpene.percentage * (weights[terpene.name as keyof typeof weights] || 0))
      }, 50) // base energy of 50
      
      expect(energyScore).toBeGreaterThan(50) // Should be energetic overall
      expect(energyScore).toBeLessThan(100)   // Should be reasonable range
    })
  })

  describe('Strain Recommendations', () => {
    it('should recommend similar strains based on terpene profiles', () => {
      const targetStrain = {
        name: 'Blue Dream',
        terpenes: [
          { name: 'Myrcene', percentage: 18.5 },
          { name: 'Pinene', percentage: 12.3 },
          { name: 'Limonene', percentage: 8.7 }
        ]
      }
      
      // Test that we can identify dominant terpenes
      const dominantTerpene = targetStrain.terpenes.reduce((prev, current) => 
        prev.percentage > current.percentage ? prev : current
      )
      
      expect(dominantTerpene.name).toBe('Myrcene')
      expect(dominantTerpene.percentage).toBeGreaterThan(15)
    })

    it('should generate meaningful strain insights', () => {
      const strainInsights = {
        terpeneStory: "This balanced hybrid features dominant Myrcene for relaxation",
        musicalJourney: ["ambient intro", "electronic progression", "chill outro"],
        maestroScore: 85
      }
      
      expect(strainInsights.terpeneStory).toContain('Myrcene')
      expect(strainInsights.musicalJourney).toHaveLength(3)
      expect(strainInsights.maestroScore).toBeGreaterThanOrEqual(0)
      expect(strainInsights.maestroScore).toBeLessThanOrEqual(100)
    })
  })
})