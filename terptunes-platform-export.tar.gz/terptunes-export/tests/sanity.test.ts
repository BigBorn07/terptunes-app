import { describe, it, expect } from 'vitest'

describe('Math sanity check', () => {
  it('adds numbers correctly', () => {
    expect(1 + 1).toBe(2)
  })
})