import { describe, it, expect, beforeEach } from 'vitest'

describe('Strain Database Tests', () => {
  describe('Strain Model Validation', () => {
    it('should validate strain type enum', () => {
      const validTypes = ['indica', 'sativa', 'hybrid']
      validTypes.forEach(type => {
        expect(['indica', 'sativa', 'hybrid']).toContain(type)
      })
    })

    it('should validate THC content format', () => {
      const validThcFormats = ['15-20%', '18%', '12-25%']
      validThcFormats.forEach(thc => {
        expect(thc).toMatch(/^\d+(-\d+)?%$/)
      })
    })

    it('should validate CBD content format', () => {
      const validCbdFormats = ['0.1%', '<1%', '1-2%']
      validCbdFormats.forEach(cbd => {
        expect(cbd).toMatch(/^(<\d+|[\d.]+(-[\d.]+)?)%$/)
      })
    })
  })

  describe('Terpene Profile Validation', () => {
    it('should validate terpene percentage is numeric', () => {
      const terpenePercentages = ['15.5', '2.1', '0.8']
      terpenePercentages.forEach(percentage => {
        expect(parseFloat(percentage)).toBeGreaterThan(0)
        expect(parseFloat(percentage)).toBeLessThanOrEqual(100)
      })
    })

    it('should validate terpene names are valid', () => {
      const validTerpenes = [
        'Myrcene',
        'Limonene', 
        'Pinene',
        'Linalool',
        'Caryophyllene',
        'Humulene',
        'Terpinolene',
        'Ocimene'
      ]
      
      validTerpenes.forEach(terpene => {
        expect(terpene).toBeTruthy()
        expect(typeof terpene).toBe('string')
        expect(terpene.length).toBeGreaterThan(0)
      })
    })
  })
})