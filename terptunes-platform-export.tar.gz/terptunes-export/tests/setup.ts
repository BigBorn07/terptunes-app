import { beforeAll, afterAll, afterEach } from 'vitest'

// Mock environment variables for testing
process.env.NODE_ENV = 'test'
process.env.DATABASE_URL = 'postgresql://test:test@localhost:5432/test'

// Setup global test configuration
beforeAll(() => {
  // Global setup before all tests
})

afterEach(() => {
  // Clean up after each test
})

afterAll(() => {
  // Global cleanup after all tests
})