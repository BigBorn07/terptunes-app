# TerpTunes Setup Guide

## Prerequisites

- Node.js 18+ installed
- PostgreSQL database (local or cloud)
- Spotify Developer Account
- Git (for version control)

## Installation Steps

### 1. Clone or Extract Project
```bash
# If from git repository
git clone <repository-url>
cd terptunes

# If from zip file, extract and navigate to directory
cd terptunes-export
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Environment Configuration
```bash
# Copy environment template
cp .env.example .env

# Edit .env file with your configuration
```

Required environment variables:
- `DATABASE_URL`: PostgreSQL connection string
- `SPOTIFY_CLIENT_ID`: From Spotify Developer Dashboard
- `SPOTIFY_CLIENT_SECRET`: From Spotify Developer Dashboard
- `SPOTIFY_REDIRECT_URI`: Your callback URL
- `SESSION_SECRET`: Random secure string

### 4. Database Setup
```bash
# Push database schema
npm run db:push

# Optional: Seed with sample data
npm run db:seed
```

### 5. Development Server
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## Production Deployment

### 1. Build Application
```bash
npm run build
```

### 2. Start Production Server
```bash
npm start
```

### 3. Environment Variables for Production
Ensure all environment variables are set in your production environment:
- Set `NODE_ENV=production`
- Configure database URL for production database
- Set secure session secret
- Configure Spotify redirect URI for production domain

## Spotify Integration Setup

### 1. Create Spotify App
1. Go to [Spotify Developer Dashboard](https://developer.spotify.com/dashboard)
2. Create a new app
3. Note the Client ID and Client Secret
4. Add redirect URI: `http://localhost:5000/api/spotify/callback` (development)

### 2. Configure Scopes
The app requires these Spotify scopes:
- `playlist-modify-public`
- `playlist-modify-private`
- `user-read-private`
- `user-read-email`

## Database Configuration

### PostgreSQL Setup
```sql
-- Create database
CREATE DATABASE terptunes;

-- Create user (optional)
CREATE USER terptunes_user WITH PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE terptunes TO terptunes_user;
```

### Cloud Database Options
- **Neon**: Serverless PostgreSQL (recommended)
- **Supabase**: PostgreSQL with additional features
- **Railway**: Simple PostgreSQL hosting
- **Heroku Postgres**: Traditional cloud PostgreSQL

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check DATABASE_URL format
   - Ensure database server is running
   - Verify network connectivity

2. **Spotify Authentication Fails**
   - Verify Client ID and Secret
   - Check redirect URI matches exactly
   - Ensure app is not in development mode restrictions

3. **Build Errors**
   - Clear node_modules and reinstall
   - Check Node.js version compatibility
   - Verify all environment variables are set

4. **Port Already in Use**
   - Change PORT environment variable
   - Kill process using port 5000
   - Use different port for development

### Health Checks
The application provides health check endpoints:
- `/health` - Basic health status
- `/ready` - Application readiness
- `/alive` - Service availability

### Logs
Check application logs for detailed error information:
```bash
# Development
npm run dev

# Production with logs
npm start | tee app.log
```

## Development Workflow

### Code Structure
- `client/` - React frontend
- `server/` - Express backend
- `shared/` - Shared types and schemas
- `tests/` - Test suites

### Available Scripts
- `npm run dev` - Development server
- `npm run build` - Production build
- `npm run test` - Run tests
- `npm run db:push` - Update database schema
- `npm run lint` - Code linting

### Database Management
```bash
# View current schema
npm run db:studio

# Reset database (development only)
npm run db:reset

# Create migration
npm run db:generate
```

## Support

For technical issues:
1. Check this setup guide
2. Review TECHNICAL_HANDOFF.md for detailed documentation
3. Check application logs for specific errors
4. Verify all environment variables are correctly set

## Security Notes

- Never commit `.env` file to version control
- Use strong, unique session secrets
- Regularly rotate API keys
- Keep dependencies updated
- Use HTTPS in production
- Implement proper CORS policies