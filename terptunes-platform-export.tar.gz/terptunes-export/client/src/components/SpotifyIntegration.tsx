import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Music, Loader2, ExternalLink, CheckCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface SpotifyIntegrationProps {
  strainId?: number;
  strainName?: string;
}

export function SpotifyIntegration({ strainId, strainName }: SpotifyIntegrationProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check Spotify connection status
  const { data: spotifyStatus, isLoading: statusLoading } = useQuery({
    queryKey: ['/api/spotify/status'],
    retry: false,
  });

  // Connect to Spotify
  const connectMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('/api/spotify/auth');
      window.location.href = response.authUrl;
    },
    onError: (error) => {
      toast({
        title: "Connection Failed",
        description: error.message || "Failed to connect to Spotify",
        variant: "destructive",
      });
    },
  });

  // Create playlist from strain
  const createPlaylistMutation = useMutation({
    mutationFn: async (data: { strainId: number; trackCount?: number }) => {
      return await apiRequest(`/api/strains/${data.strainId}/playlist`, {
        method: 'POST',
        body: JSON.stringify({ trackCount: data.trackCount || 30 }),
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Playlist Created!",
        description: `Successfully created "${data.playlist.name}" in your Spotify account`,
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/playlists'] });
    },
    onError: (error) => {
      toast({
        title: "Playlist Creation Failed",
        description: error.message || "Failed to create playlist",
        variant: "destructive",
      });
    },
  });

  const isConnected = spotifyStatus?.connected;

  if (statusLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-6">
          <Loader2 className="w-6 h-6 animate-spin" />
        </CardContent>
      </Card>
    );
  }

  if (!isConnected) {
    return (
      <Card className="border-dashed">
        <CardHeader className="text-center pb-4">
          <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-3">
            <Music className="w-6 h-6 text-green-500" />
          </div>
          <CardTitle className="text-xl">Connect to Spotify</CardTitle>
          <CardDescription>
            Connect your Spotify account to create personalized playlists based on cannabis terpene profiles
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <Button 
            onClick={() => connectMutation.mutate()}
            disabled={connectMutation.isPending}
            className="bg-green-500 hover:bg-green-600 text-white"
          >
            {connectMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Connecting...
              </>
            ) : (
              <>
                <Music className="w-4 h-4 mr-2" />
                Connect Spotify
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-500" />
            </div>
            <div>
              <CardTitle className="text-lg">Spotify Connected</CardTitle>
              <CardDescription>
                Ready to create playlists from terpene profiles
              </CardDescription>
            </div>
          </div>
        </div>
      </CardHeader>
      {strainId && strainName && (
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-muted/50 rounded-lg">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-blue-500 mt-0.5" />
                <div className="flex-1">
                  <p className="font-medium text-sm">Generate Playlist for {strainName}</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    We'll analyze the terpene profile and create a 30-track playlist that matches the strain's mood and effects.
                  </p>
                </div>
              </div>
            </div>
            
            <Button 
              onClick={() => createPlaylistMutation.mutate({ strainId })}
              disabled={createPlaylistMutation.isPending}
              className="w-full"
            >
              {createPlaylistMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating Playlist...
                </>
              ) : (
                <>
                  <Music className="w-4 h-4 mr-2" />
                  Create Spotify Playlist
                </>
              )}
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  );
}

export default SpotifyIntegration;