import { useQuery } from "@tanstack/react-query";
import { Badge, Trophy, Star, Zap, Users, Beaker } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";

interface BadgeData {
  id: number;
  name: string;
  description: string;
  category: string;
  icon: string;
  rarity: string;
  points: number;
  earnedAt?: string;
}

interface UserStats {
  level: number;
  totalPoints: number;
  strainsDiscovered: number;
  playlistsCreated: number;
  terpeneKnowledge: number;
  socialScore: number;
}

const rarityColors = {
  common: "bg-gray-100 text-gray-800 border-gray-300",
  uncommon: "bg-green-100 text-green-800 border-green-300",
  rare: "bg-blue-100 text-blue-800 border-blue-300",
  legendary: "bg-purple-100 text-purple-800 border-purple-300"
};

const categoryIcons = {
  terpene: Beaker,
  discovery: Badge,
  playlist: Zap,
  social: Users,
  knowledge: Star
};

export default function BadgeSystem() {
  const { user, isAuthenticated } = useAuth();

  const { data: userStats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/gamification/stats"],
    enabled: isAuthenticated
  });

  const { data: userBadges, isLoading: badgesLoading } = useQuery({
    queryKey: ["/api/gamification/badges"],
    enabled: isAuthenticated
  });

  const { data: availableBadges } = useQuery({
    queryKey: ["/api/gamification/available-badges"],
    enabled: isAuthenticated
  });

  if (!isAuthenticated) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5" />
            Cannabis Explorer Journey
          </CardTitle>
          <CardDescription>
            Sign in to start earning badges and tracking your cannabis knowledge progress
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (statsLoading || badgesLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Loading your achievements...</CardTitle>
        </CardHeader>
      </Card>
    );
  }

  const stats: UserStats = userStats || {
    level: 1,
    totalPoints: 0,
    strainsDiscovered: 0,
    playlistsCreated: 0,
    terpeneKnowledge: 0,
    socialScore: 0
  };

  const earnedBadges: BadgeData[] = userBadges || [];
  const allBadges: BadgeData[] = availableBadges || [];

  // Calculate progress to next level
  const currentLevelPoints = Math.pow(stats.level - 1, 2) * 100;
  const nextLevelPoints = Math.pow(stats.level, 2) * 100;
  const progressToNext = ((stats.totalPoints - currentLevelPoints) / (nextLevelPoints - currentLevelPoints)) * 100;

  // Group badges by category
  const badgesByCategory = allBadges.reduce((acc, badge) => {
    if (!acc[badge.category]) acc[badge.category] = [];
    acc[badge.category].push(badge);
    return acc;
  }, {} as Record<string, BadgeData[]>);

  const earnedBadgeIds = new Set(earnedBadges.map(b => b.id));

  return (
    <div className="space-y-6">
      {/* User Stats Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            Cannabis Sommelier Level {stats.level}
          </CardTitle>
          <CardDescription>
            {stats.totalPoints} points earned • {earnedBadges.length} badges collected
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm">Progress to Level {stats.level + 1}</span>
              <span className="text-sm">{Math.round(progressToNext)}%</span>
            </div>
            <Progress value={progressToNext} className="h-2" />
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{stats.strainsDiscovered}</div>
              <div className="text-sm text-muted-foreground">Strains Discovered</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.playlistsCreated}</div>
              <div className="text-sm text-muted-foreground">Playlists Created</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.terpeneKnowledge}</div>
              <div className="text-sm text-muted-foreground">Terpene Knowledge</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">{stats.socialScore}</div>
              <div className="text-sm text-muted-foreground">Community Score</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Badge Collection */}
      <Card>
        <CardHeader>
          <CardTitle>Badge Collection</CardTitle>
          <CardDescription>
            Learn cannabis science while exploring strains and creating playlists
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="terpene" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="terpene" className="flex items-center gap-1">
                <Beaker className="h-4 w-4" />
                Terpenes
              </TabsTrigger>
              <TabsTrigger value="discovery" className="flex items-center gap-1">
                <Badge className="h-4 w-4" />
                Discovery
              </TabsTrigger>
              <TabsTrigger value="playlist" className="flex items-center gap-1">
                <Zap className="h-4 w-4" />
                Music
              </TabsTrigger>
              <TabsTrigger value="social" className="flex items-center gap-1">
                <Users className="h-4 w-4" />
                Community
              </TabsTrigger>
              <TabsTrigger value="knowledge" className="flex items-center gap-1">
                <Star className="h-4 w-4" />
                Knowledge
              </TabsTrigger>
            </TabsList>

            {Object.entries(badgesByCategory).map(([category, badges]) => (
              <TabsContent key={category} value={category} className="mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {badges.map((badge) => {
                    const isEarned = earnedBadgeIds.has(badge.id);
                    const CategoryIcon = categoryIcons[badge.category as keyof typeof categoryIcons] || Badge;
                    
                    return (
                      <Card 
                        key={badge.id} 
                        className={`transition-all ${isEarned ? 'ring-2 ring-green-500' : 'opacity-60'} ${rarityColors[badge.rarity as keyof typeof rarityColors]}`}
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="text-2xl">{badge.icon}</span>
                              <CategoryIcon className="h-4 w-4" />
                            </div>
                            {isEarned && (
                              <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
                                Earned
                              </Badge>
                            )}
                          </div>
                          <CardTitle className="text-lg">{badge.name}</CardTitle>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <p className="text-sm text-muted-foreground mb-2">
                            {badge.description}
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">
                              {badge.points} points
                            </span>
                            <span className={`text-xs px-2 py-1 rounded-full ${rarityColors[badge.rarity as keyof typeof rarityColors]}`}>
                              {badge.rarity}
                            </span>
                          </div>
                          {isEarned && earnedBadges.find(b => b.id === badge.id)?.earnedAt && (
                            <p className="text-xs text-muted-foreground mt-2">
                              Earned {new Date(earnedBadges.find(b => b.id === badge.id)!.earnedAt!).toLocaleDateString()}
                            </p>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>

      {/* Recent Achievements */}
      {earnedBadges.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Achievements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {earnedBadges.slice(0, 3).map((badge) => (
                <div key={badge.id} className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                  <span className="text-2xl">{badge.icon}</span>
                  <div className="flex-1">
                    <div className="font-medium">{badge.name}</div>
                    <div className="text-sm text-muted-foreground">{badge.description}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-green-600">+{badge.points} points</div>
                    {badge.earnedAt && (
                      <div className="text-xs text-muted-foreground">
                        {new Date(badge.earnedAt).toLocaleDateString()}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}