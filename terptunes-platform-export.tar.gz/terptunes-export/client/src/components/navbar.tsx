import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Leaf, Music, User, Trophy, Shield, Sprout, Store, Video, Library, UserCircle, Settings, Sparkles } from "lucide-react";

export function Navbar() {
  const [location] = useLocation();

  // Simulate user roles - in production this would come from auth context
  const userRole: 'user' | 'grower' | 'dispensary' | 'admin' | 'super-admin' = 'admin';
  const isLoggedIn = true; // Would come from auth state

  const getUserNavItems = () => {
    // Main user navigation items
    const baseItems = [
      { href: "/home", label: "Home", icon: null, active: location === '/home' },
      { href: "/discover", label: "Discover", icon: null, active: location === '/discover' },
      { href: "/playlist-library", label: "Playlists", icon: Library, active: location === '/playlist-library' },
      { href: "/profile", label: "Profile", icon: UserCircle, active: location === '/profile' },
      { href: "/brand-ambassador", label: "Ambassador", icon: Trophy, active: location === '/brand-ambassador' },
      { href: "/dispensary-ambassador", label: "Dispensary Rewards", icon: Store, active: location === '/dispensary-ambassador' },
      { href: "/mello-maestro", label: "Mello Maestro", icon: null, active: location === '/mello-maestro' },
      { href: "/maestro-demo", label: "Maestro Live Demo", icon: Sparkles, active: location === '/maestro-demo' },
      { href: "/watch-demo", label: "Watch Demo", icon: Video, active: location === '/watch-demo' },
    ];

    return baseItems;
  };

  const getBusinessNavItems = () => {
    const businessItems = [];
    
    // Only show business portals if user has access (separate login/auth)
    if (userRole === 'grower' || userRole === 'admin' || userRole === 'super-admin') {
      businessItems.push({
        href: "/grower-portal", 
        label: "Grower Portal", 
        icon: Sprout, 
        active: location === '/grower-portal',
        color: 'text-green-400'
      });
    }
    
    if (userRole === 'dispensary' || userRole === 'admin' || userRole === 'super-admin') {
      businessItems.push({
        href: "/dispensary-portal", 
        label: "Dispensary Portal", 
        icon: Store, 
        active: location === '/dispensary-portal',
        color: 'text-blue-400'
      });
    }
    
    return businessItems;
  };

  const getAdminNavItems = () => {
    const adminItems = [];
    
    if (userRole === 'admin' || userRole === 'super-admin') {
      adminItems.push({
        href: "/admin", 
        label: "Admin", 
        icon: Settings, 
        active: location === '/admin',
        color: 'text-orange-400'
      });
    }
    
    if (userRole === 'super-admin') {
      adminItems.push({
        href: "/super-admin", 
        label: "Super Admin", 
        icon: Shield, 
        active: location === '/super-admin',
        color: 'text-red-400'
      });
    }
    
    return adminItems;
  };

  const userNavItems = getUserNavItems();
  const businessNavItems = getBusinessNavItems();
  const adminNavItems = getAdminNavItems();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-gray-900/95 backdrop-blur-md border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 cannabis-gradient rounded-lg flex items-center justify-center">
              <Leaf className="text-white text-sm" />
            </div>
            <span className="text-xl font-display font-bold text-cannabis-gradient">
              TerpTunes
            </span>
          </Link>
          
          <div className="hidden md:flex items-center space-x-6">
            {/* User Navigation */}
            {userNavItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <span className={`text-gray-300 hover:text-green-400 transition-colors cursor-pointer flex items-center gap-1 ${
                  item.active ? 'text-green-400' : ''
                }`}>
                  {item.icon && <item.icon className="w-4 h-4" />}
                  {item.label}
                </span>
              </Link>
            ))}

            {/* Business Portals - Separated with divider */}
            {businessNavItems.length > 0 && (
              <>
                <div className="h-4 w-px bg-gray-600" />
                {businessNavItems.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <span className={`text-gray-300 hover:${item.color} transition-colors cursor-pointer flex items-center gap-1 ${
                      item.active ? item.color : ''
                    }`}>
                      <item.icon className="w-4 h-4" />
                      {item.label}
                    </span>
                  </Link>
                ))}
              </>
            )}

            {/* Admin Navigation - Separated with divider */}
            {adminNavItems.length > 0 && (
              <>
                <div className="h-4 w-px bg-gray-600" />
                {adminNavItems.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <span className={`text-gray-300 hover:${item.color} transition-colors cursor-pointer flex items-center gap-1 ${
                      item.active ? item.color : ''
                    }`}>
                      <item.icon className="w-4 h-4" />
                      {item.label}
                    </span>
                  </Link>
                ))}
              </>
            )}
          </div>

          <div className="flex items-center space-x-4">
            {!isLoggedIn ? (
              <>
                <Button variant="ghost" size="sm" className="hidden md:flex text-gray-300 hover:text-white">
                  <User className="w-4 h-4 mr-2" />
                  Log In
                </Button>
                <Button className="cannabis-gradient text-white font-medium hover:opacity-90">
                  <Music className="w-4 h-4 mr-2" />
                  Connect Spotify
                </Button>
              </>
            ) : (
              <Button variant="ghost" size="sm" className="hidden md:flex text-gray-300 hover:text-white">
                <UserCircle className="w-4 h-4 mr-2" />
                Profile
              </Button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
