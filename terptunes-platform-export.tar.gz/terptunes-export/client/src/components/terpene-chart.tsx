import { TerpeneProfile, TerpeneInfo } from "@/types";

interface TerpeneChartProps {
  terpenes: TerpeneProfile[];
  className?: string;
}

const terpeneColors: Record<string, string> = {
  myrcene: "bg-gradient-to-r from-green-400 to-green-500",
  limonene: "bg-gradient-to-r from-purple-400 to-purple-500",
  pinene: "bg-gradient-to-r from-blue-400 to-blue-500",
  linalool: "bg-gradient-to-r from-indigo-400 to-indigo-500",
  caryophyllene: "bg-gradient-to-r from-yellow-400 to-yellow-500",
  terpinolene: "bg-gradient-to-r from-pink-400 to-pink-500",
  humulene: "bg-gradient-to-r from-lime-400 to-lime-500",
  ocimene: "bg-gradient-to-r from-cyan-400 to-cyan-500",
};

export function TerpeneChart({ terpenes, className = "" }: TerpeneChartProps) {
  const maxPercentage = Math.max(...terpenes.map(t => t.percentage || 0));

  return (
    <div className={`space-y-3 ${className}`}>
      {terpenes.map((terpene, index) => (
        <div key={index} className="space-y-1">
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-300 capitalize font-medium">
              {terpene.name || 'Unknown Terpene'}
            </span>
            <span className="text-gray-300 text-xs">
              {(terpene.percentage || 0).toFixed(1)}%
            </span>
          </div>
          <div className="terpene-bar">
            <div 
              className={`terpene-fill ${terpeneColors[terpene.name?.toLowerCase()] || 'bg-gray-500'}`}
              style={{ 
                width: `${((terpene.percentage || 0) / maxPercentage) * 100}%` 
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
