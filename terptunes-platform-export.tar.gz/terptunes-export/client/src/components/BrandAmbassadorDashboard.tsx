import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Award, Crown, Gift, Star, TrendingUp, Users, Calendar, ExternalLink } from "lucide-react";

interface BrandConsumption {
  brandId: number;
  brandName: string;
  strainCount: number;
  isQualified: boolean;
  ambassadorLevel?: string;
  strains: Array<{
    id: number;
    name: string;
    consumedAt: string;
    rating?: number;
  }>;
}

interface AmbassadorshipStats {
  totalBrands: number;
  qualifiedBrands: number;
  totalStrains: number;
  ambassadorships: Array<{
    id: number;
    brandId: number;
    brandName: string;
    totalStrains: number;
    ambassadorLevel: string;
    qualifiedAt: string;
    exclusiveAccess: boolean;
  }>;
  exclusiveRewards: number;
}

interface ExclusiveReward {
  id: number;
  title: string;
  description: string;
  type: string;
  value: string;
  brandName: string;
  validUntil?: string;
}

const getLevelColor = (level: string): string => {
  switch (level.toLowerCase()) {
    case 'bronze': return 'bg-amber-600';
    case 'silver': return 'bg-gray-400';
    case 'gold': return 'bg-yellow-500';
    case 'platinum': return 'bg-purple-500';
    default: return 'bg-gray-500';
  }
};

const getLevelIcon = (level: string) => {
  switch (level.toLowerCase()) {
    case 'bronze': return <Award className="w-4 h-4" />;
    case 'silver': return <Star className="w-4 h-4" />;
    case 'gold': return <Crown className="w-4 h-4" />;
    case 'platinum': return <Crown className="w-4 h-4" />;
    default: return <Award className="w-4 h-4" />;
  }
};

const getRewardIcon = (type: string) => {
  switch (type) {
    case 'discount': return <TrendingUp className="w-4 h-4" />;
    case 'early_access': return <Star className="w-4 h-4" />;
    case 'exclusive_strain': return <Crown className="w-4 h-4" />;
    case 'event_invite': return <Users className="w-4 h-4" />;
    case 'merchandise': return <Gift className="w-4 h-4" />;
    default: return <Gift className="w-4 h-4" />;
  }
};

export function BrandAmbassadorDashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/brand-ambassador/stats'],
  });

  const { data: consumption, isLoading: consumptionLoading } = useQuery({
    queryKey: ['/api/brand-ambassador/consumption'],
  });

  const { data: rewards, isLoading: rewardsLoading } = useQuery({
    queryKey: ['/api/brand-ambassador/rewards'],
  });

  const { data: nearQualification } = useQuery({
    queryKey: ['/api/brand-ambassador/near-qualification'],
  });

  const ambassadorStats = stats as AmbassadorshipStats;
  const brandConsumption = consumption as BrandConsumption[];
  const exclusiveRewards = rewards as ExclusiveReward[];

  if (statsLoading || consumptionLoading || rewardsLoading) {
    return (
      <div className="space-y-6">
        <div className="h-32 bg-gray-800 rounded-lg animate-pulse" />
        <div className="h-64 bg-gray-800 rounded-lg animate-pulse" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Ambassador Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-300">Total Brands</p>
                <p className="text-2xl font-bold text-white">{ambassadorStats?.totalBrands || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-purple-500" />
              <div>
                <p className="text-sm text-gray-300">Ambassador Status</p>
                <p className="text-2xl font-bold text-white">{ambassadorStats?.qualifiedBrands || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-300">Total Strains</p>
                <p className="text-2xl font-bold text-white">{ambassadorStats?.totalStrains || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Gift className="w-5 h-5 text-yellow-500" />
              <div>
                <p className="text-sm text-gray-300">Exclusive Rewards</p>
                <p className="text-2xl font-bold text-white">{ambassadorStats?.exclusiveRewards || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Ambassador Status Cards */}
      {ambassadorStats?.ambassadorships?.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-white">Your Ambassador Status</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ambassadorStats.ambassadorships.map((ambassador) => (
              <Card key={ambassador.id} className="bg-gray-900 border-gray-700">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between">
                    <span className="text-white">{ambassador.brandName}</span>
                    <Badge className={`${getLevelColor(ambassador.ambassadorLevel)} text-white`}>
                      {getLevelIcon(ambassador.ambassadorLevel)}
                      <span className="ml-1 capitalize">{ambassador.ambassadorLevel}</span>
                    </Badge>
                  </CardTitle>
                  <CardDescription className="text-gray-300">
                    Ambassador since {new Date(ambassador.qualifiedAt).toLocaleDateString()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Strains Tried</span>
                      <span className="text-white font-semibold">{ambassador.totalStrains}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Exclusive Access</span>
                      <span className={ambassador.exclusiveAccess ? "text-green-500" : "text-red-500"}>
                        {ambassador.exclusiveAccess ? "Active" : "Inactive"}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <Tabs defaultValue="brands" className="space-y-6">
        <TabsList className="bg-gray-800 border-gray-700">
          <TabsTrigger value="brands" className="data-[state=active]:bg-gray-700">
            <Users className="w-4 h-4 mr-2" />
            Brand Progress
          </TabsTrigger>
          <TabsTrigger value="rewards" className="data-[state=active]:bg-gray-700">
            <Gift className="w-4 h-4 mr-2" />
            Exclusive Rewards
          </TabsTrigger>
          <TabsTrigger value="opportunities" className="data-[state=active]:bg-gray-700">
            <TrendingUp className="w-4 h-4 mr-2" />
            Opportunities
          </TabsTrigger>
        </TabsList>

        {/* Brand Progress Tab */}
        <TabsContent value="brands" className="space-y-4">
          <h3 className="text-xl font-bold text-white">Brand Consumption Progress</h3>
          <div className="grid grid-cols-1 gap-4">
            {brandConsumption?.map((brand) => (
              <Card key={brand.brandId} className="bg-gray-900 border-gray-700">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between">
                    <span className="text-white">{brand.brandName}</span>
                    <div className="flex items-center gap-2">
                      {brand.isQualified && (
                        <Badge className={`${getLevelColor(brand.ambassadorLevel || 'bronze')} text-white`}>
                          {getLevelIcon(brand.ambassadorLevel || 'bronze')}
                          <span className="ml-1 capitalize">{brand.ambassadorLevel}</span>
                        </Badge>
                      )}
                      <Badge variant={brand.isQualified ? "default" : "secondary"}>
                        {brand.strainCount}/10 strains
                      </Badge>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-gray-300">Progress to Ambassador</span>
                        <span className="text-sm text-white">
                          {Math.min(brand.strainCount, 10)}/10
                        </span>
                      </div>
                      <Progress 
                        value={(brand.strainCount / 10) * 100} 
                        className="h-2"
                      />
                    </div>
                    
                    {brand.strains.length > 0 && (
                      <div>
                        <p className="text-sm text-gray-300 mb-2">Recent Strains:</p>
                        <div className="flex flex-wrap gap-2">
                          {brand.strains.slice(0, 5).map((strain) => (
                            <Badge key={strain.id} variant="outline" className="text-xs">
                              {strain.name}
                              {strain.rating && (
                                <span className="ml-1 text-yellow-500">
                                  {'★'.repeat(strain.rating)}
                                </span>
                              )}
                            </Badge>
                          ))}
                          {brand.strains.length > 5 && (
                            <Badge variant="outline" className="text-xs text-gray-300">
                              +{brand.strains.length - 5} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Exclusive Rewards Tab */}
        <TabsContent value="rewards" className="space-y-4">
          <h3 className="text-xl font-bold text-white">Your Exclusive Rewards</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {exclusiveRewards?.map((reward) => (
              <Card key={reward.id} className="bg-gray-900 border-gray-700">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2">
                    {getRewardIcon(reward.type)}
                    <span className="text-white">{reward.title}</span>
                  </CardTitle>
                  <CardDescription className="text-gray-300">
                    From {reward.brandName}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-sm text-gray-300">{reward.description}</p>
                    
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary" className="capitalize">
                        {reward.type.replace('_', ' ')}
                      </Badge>
                      {reward.value !== 'exclusive' && (
                        <span className="text-green-500 font-semibold">{reward.value}</span>
                      )}
                    </div>

                    {reward.validUntil && (
                      <div className="flex items-center gap-1 text-xs text-gray-300">
                        <Calendar className="w-3 h-3" />
                        Valid until {new Date(reward.validUntil).toLocaleDateString()}
                      </div>
                    )}

                    <Button size="sm" className="w-full">
                      <ExternalLink className="w-3 h-3 mr-1" />
                      Claim Reward
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Opportunities Tab */}
        <TabsContent value="opportunities" className="space-y-4">
          <h3 className="text-xl font-bold text-white">Ambassador Opportunities</h3>
          
          {nearQualification && nearQualification.length > 0 && (
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-white">Close to Qualification</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {nearQualification.map((brand: any) => (
                  <Card key={brand.brandId} className="bg-gray-900 border-gray-700">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-white">{brand.brandName}</CardTitle>
                      <CardDescription className="text-gray-300">
                        {brand.needed} more strains needed for ambassador status
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between mb-2">
                            <span className="text-sm text-gray-300">Progress</span>
                            <span className="text-sm text-white">
                              {brand.currentStrains}/10
                            </span>
                          </div>
                          <Progress 
                            value={(brand.currentStrains / 10) * 100} 
                            className="h-2"
                          />
                        </div>
                        
                        <Button size="sm" variant="outline" className="w-full">
                          Explore {brand.brandName} Strains
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Ambassador Benefits</CardTitle>
              <CardDescription className="text-gray-300">
                What you get when you become a brand ambassador
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-green-500" />
                    <span className="text-white">Exclusive Discounts</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-blue-500" />
                    <span className="text-white">Early Access to New Strains</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Crown className="w-4 h-4 text-purple-500" />
                    <span className="text-white">Limited Edition Products</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-yellow-500" />
                    <span className="text-white">VIP Event Invitations</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Gift className="w-4 h-4 text-red-500" />
                    <span className="text-white">Branded Merchandise</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-orange-500" />
                    <span className="text-white">Special Recognition</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}