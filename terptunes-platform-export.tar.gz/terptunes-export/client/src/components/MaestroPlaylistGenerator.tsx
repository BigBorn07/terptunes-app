import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Music, Sparkles, Zap, Heart, Brain } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface MaestroPlaylistGeneratorProps {
  strainId: number;
  strainName: string;
  strainType: 'indica' | 'sativa' | 'hybrid';
}

export function MaestroPlaylistGenerator({ strainId, strainName, strainType }: MaestroPlaylistGeneratorProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [maestroResult, setMaestroResult] = useState<any>(null);
  const { toast } = useToast();

  const handleGeneratePlaylist = async () => {
    setIsGenerating(true);
    try {
      const response = await apiRequest('POST', '/api/maestro/create-playlist', {
        strainId,
        userId: 'guest-user' // In real app, get from auth
      });

      const result = await response.json();

      if (result.success) {
        setMaestroResult(result);
        toast({
          title: "✨ Maestro's Magic Complete",
          description: "Your personalized musical journey has been crafted",
        });
      }
    } catch (error) {
      console.error('Maestro playlist error:', error);
      toast({
        title: "Maestro's Flow Disrupted",
        description: "Unable to create playlist right now. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const getStrainIcon = (type: string) => {
    switch (type) {
      case 'indica': return <Heart className="w-4 h-4 text-purple-400" />;
      case 'sativa': return <Zap className="w-4 h-4 text-green-400" />;
      case 'hybrid': return <Brain className="w-4 h-4 text-blue-400" />;
      default: return <Sparkles className="w-4 h-4 text-gray-300" />;
    }
  };

  return (
    <Card className="bg-gradient-to-br from-purple-900/50 to-indigo-900/50 border-purple-500/30">
      <CardHeader className="text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Sparkles className="w-6 h-6 text-purple-400" />
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            Mello Maestro's Musical Alchemy
          </CardTitle>
          <Sparkles className="w-6 h-6 text-purple-400" />
        </div>
        <CardDescription className="text-purple-200">
          Transform {strainName}'s terpene profile into a personalized musical journey
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {!maestroResult ? (
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-3">
              {getStrainIcon(strainType)}
              <Badge 
                variant="outline" 
                className="bg-gradient-to-r from-purple-600/30 to-pink-600/30 border-purple-400 text-purple-200"
              >
                {strainName} • {strainType}
              </Badge>
            </div>
            
            <div className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
              <p className="text-purple-100 text-sm leading-relaxed">
                Maestro will analyze {strainName}'s unique terpene signature and weave it into a musical tapestry 
                that resonates with the strain's essence. Each song will be carefully selected to complement 
                the chemical harmony of your chosen strain.
              </p>
            </div>

            <Button 
              onClick={handleGeneratePlaylist}
              disabled={isGenerating}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold px-8 py-3 rounded-full shadow-lg hover:shadow-purple-500/25 transition-all duration-300"
            >
              {isGenerating ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Maestro is Weaving Musical Magic...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Music className="w-5 h-5" />
                  Summon Maestro's Musical Alchemy
                </div>
              )}
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Maestro's Insights */}
            <div className="bg-gradient-to-r from-purple-900/40 to-indigo-900/40 rounded-lg p-4 border border-purple-400/30">
              <h3 className="text-lg font-semibold text-purple-200 mb-3 flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Maestro's Insights
              </h3>
              <Textarea 
                value={maestroResult.maestroInsights}
                readOnly
                className="bg-black/30 border-purple-500/20 text-purple-100 min-h-[120px] resize-none"
              />
            </div>

            {/* Terpene Story */}
            <div className="bg-gradient-to-r from-indigo-900/40 to-purple-900/40 rounded-lg p-4 border border-indigo-400/30">
              <h3 className="text-lg font-semibold text-indigo-200 mb-3 flex items-center gap-2">
                <Brain className="w-5 h-5" />
                Terpene Story
              </h3>
              <p className="text-indigo-100 leading-relaxed">
                {maestroResult.terpeneStory}
              </p>
            </div>

            {/* Musical Journey */}
            <div className="bg-gradient-to-r from-pink-900/40 to-purple-900/40 rounded-lg p-4 border border-pink-400/30">
              <h3 className="text-lg font-semibold text-pink-200 mb-3 flex items-center gap-2">
                <Music className="w-5 h-5" />
                Musical Journey
              </h3>
              <div className="space-y-2">
                {maestroResult.musicalJourney?.map((step: string, index: number) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-pink-400 rounded-full" />
                    <span className="text-pink-100 text-sm">{step}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Playlist Details */}
            {maestroResult.playlist && (
              <div className="bg-gradient-to-r from-green-900/40 to-teal-900/40 rounded-lg p-4 border border-green-400/30">
                <h3 className="text-lg font-semibold text-green-200 mb-3 flex items-center gap-2">
                  <Music className="w-5 h-5" />
                  Your Maestro Playlist
                </h3>
                <div className="space-y-2">
                  <p className="text-green-100 font-medium">{maestroResult.playlist.name}</p>
                  <p className="text-green-200 text-sm">{maestroResult.playlist.description}</p>
                  <div className="flex gap-2">
                    <Badge className="bg-green-600/30 text-green-200 border-green-500/30">
                      Maestro Signature
                    </Badge>
                    <Badge className="bg-teal-600/30 text-teal-200 border-teal-500/30">
                      Terpene-Curated
                    </Badge>
                  </div>
                </div>
              </div>
            )}

            <Button 
              onClick={() => setMaestroResult(null)}
              variant="outline"
              className="w-full border-purple-500/30 text-purple-200 hover:bg-purple-500/20"
            >
              Create Another Maestro Experience
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default MaestroPlaylistGenerator;