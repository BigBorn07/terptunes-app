import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, X } from "lucide-react";
import { StrainSearchParams } from "@/types";

interface SearchFiltersProps {
  searchParams: StrainSearchParams;
  onSearchParamsChange: (params: StrainSearchParams) => void;
  onSearch: () => void;
  isLoading?: boolean;
}

const popularTerpenes = [
  { name: 'myrcene', color: 'bg-green-500/20 text-green-400' },
  { name: 'limonene', color: 'bg-purple-500/20 text-purple-400' },
  { name: 'pinene', color: 'bg-blue-500/20 text-blue-400' },
  { name: 'linalool', color: 'bg-indigo-500/20 text-indigo-400' },
  { name: 'caryophyllene', color: 'bg-yellow-500/20 text-yellow-400' },
];

const popularEffects = [
  'relaxing', 'energizing', 'creative', 'focused', 'happy', 'euphoric', 'sleepy', 'uplifting'
];

export function SearchFilters({ 
  searchParams, 
  onSearchParamsChange, 
  onSearch, 
  isLoading 
}: SearchFiltersProps) {
  
  const handleInputChange = (field: keyof StrainSearchParams, value: any) => {
    onSearchParamsChange({
      ...searchParams,
      [field]: value,
      offset: 0 // Reset offset when changing filters
    });
  };

  const toggleTerpene = (terpene: string) => {
    const currentTerpenes = searchParams.terpenes || [];
    const newTerpenes = currentTerpenes.includes(terpene)
      ? currentTerpenes.filter(t => t !== terpene)
      : [...currentTerpenes, terpene];
    
    handleInputChange('terpenes', newTerpenes);
  };

  const toggleEffect = (effect: string) => {
    const currentEffects = searchParams.effects || [];
    const newEffects = currentEffects.includes(effect)
      ? currentEffects.filter(e => e !== effect)
      : [...currentEffects, effect];
    
    handleInputChange('effects', newEffects);
  };

  const clearAllFilters = () => {
    onSearchParamsChange({
      query: '',
      type: undefined,
      effects: [],
      terpenes: [],
      minThc: undefined,
      maxThc: undefined,
      limit: 20,
      offset: 0
    });
  };

  const hasActiveFilters = !!(
    searchParams.query ||
    searchParams.type ||
    (searchParams.effects && searchParams.effects.length > 0) ||
    (searchParams.terpenes && searchParams.terpenes.length > 0) ||
    searchParams.minThc ||
    searchParams.maxThc
  );

  return (
    <div className="glassmorphism rounded-2xl p-6 space-y-6">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-5 h-5" />
        <Input
          placeholder="Search strains, effects, or terpenes..."
          value={searchParams.query || ''}
          onChange={(e) => handleInputChange('query', e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && onSearch()}
          className="pl-10 bg-gray-900/50 border-gray-600 text-white placeholder-gray-300 focus:border-green-400"
        />
      </div>

      {/* Filters Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Select 
          value={searchParams.type || 'all'} 
          onValueChange={(value) => handleInputChange('type', value === 'all' ? undefined : value)}
        >
          <SelectTrigger className="bg-gray-900/50 border-gray-600 text-white">
            <SelectValue placeholder="All Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="indica">Indica</SelectItem>
            <SelectItem value="sativa">Sativa</SelectItem>
            <SelectItem value="hybrid">Hybrid</SelectItem>
          </SelectContent>
        </Select>

        <Input
          type="number"
          placeholder="Min THC %"
          value={searchParams.minThc || ''}
          onChange={(e) => handleInputChange('minThc', e.target.value ? parseFloat(e.target.value) : undefined)}
          className="bg-gray-900/50 border-gray-600 text-white placeholder-gray-300"
        />

        <Input
          type="number"
          placeholder="Max THC %"
          value={searchParams.maxThc || ''}
          onChange={(e) => handleInputChange('maxThc', e.target.value ? parseFloat(e.target.value) : undefined)}
          className="bg-gray-900/50 border-gray-600 text-white placeholder-gray-300"
        />

        <div className="flex gap-2">
          <Button onClick={onSearch} disabled={isLoading} className="cannabis-gradient text-white flex-1">
            {isLoading ? 'Searching...' : 'Search'}
          </Button>
          {hasActiveFilters && (
            <Button variant="outline" onClick={clearAllFilters} size="icon">
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      {/* Terpene Filter Tags */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-300">Popular Terpenes:</span>
          <div className="flex flex-wrap gap-2">
            {popularTerpenes.map((terpene) => (
              <Badge
                key={terpene.name}
                variant="secondary"
                className={`cursor-pointer transition-all ${
                  searchParams.terpenes?.includes(terpene.name)
                    ? terpene.color
                    : 'hover:bg-gray-700'
                }`}
                onClick={() => toggleTerpene(terpene.name)}
              >
                {terpene.name}
              </Badge>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-300">Popular Effects:</span>
          <div className="flex flex-wrap gap-2">
            {popularEffects.map((effect) => (
              <Badge
                key={effect}
                variant="secondary"
                className={`cursor-pointer transition-all ${
                  searchParams.effects?.includes(effect)
                    ? 'bg-green-500/20 text-green-400'
                    : 'hover:bg-gray-700'
                }`}
                onClick={() => toggleEffect(effect)}
              >
                {effect}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
