import { Strain } from "@/types";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TerpeneChart } from "./terpene-chart";
import { Music, Leaf } from "lucide-react";

interface StrainCardProps {
  strain: Strain;
  onGeneratePlaylist?: (strain: Strain) => void;
  isGenerating?: boolean;
}

export function StrainCard({ strain, onGeneratePlaylist, isGenerating }: StrainCardProps) {
  const getTypeColor = (type: string) => {
    switch (type) {
      case 'indica':
        return 'bg-purple-500/20 text-purple-400';
      case 'sativa':
        return 'bg-green-500/20 text-green-400';
      case 'hybrid':
        return 'bg-blue-500/20 text-blue-400';
      default:
        return 'bg-gray-500/20 text-gray-300';
    }
  };

  return (
    <Card className="strain-card">
      <CardContent className="p-6">
        {strain.imageUrl && (
          <div className="w-full h-40 rounded-lg overflow-hidden mb-4 bg-gray-900 flex items-center justify-center">
            <img 
              src={strain.imageUrl} 
              alt={strain.name}
              className="max-w-full max-h-full object-contain"
            />
          </div>
        )}
        
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="text-lg font-semibold text-white group-hover:text-green-400 transition-colors">
              {strain.name}
            </h3>
            <p className="text-sm text-gray-300">
              {strain.type.charAt(0).toUpperCase() + strain.type.slice(1)} • THC: {strain.thcContent}%
            </p>
          </div>
          <Badge className={getTypeColor(strain.type)}>
            {strain.type.charAt(0).toUpperCase() + strain.type.slice(1)}
          </Badge>
        </div>

        {strain.terpenes && strain.terpenes.length > 0 && (
          <div className="mb-4">
            <TerpeneChart terpenes={strain.terpenes.slice(0, 3)} />
          </div>
        )}

        <div className="flex flex-wrap gap-2 mb-4">
          {strain.effects.slice(0, 3).map((effect, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {effect}
            </Badge>
          ))}
        </div>

        <Button 
          onClick={() => onGeneratePlaylist?.(strain)}
          disabled={isGenerating}
          className="w-full cannabis-gradient text-white font-medium hover:opacity-90 transition-all duration-200"
        >
          {isGenerating ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
              Creating...
            </>
          ) : (
            <>
              <Music className="w-4 h-4 mr-2" />
              Create Playlist
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
