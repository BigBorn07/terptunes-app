import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { 
  Search, 
  Filter, 
  Sliders, 
  Brain, 
  Zap, 
  Heart, 
  Clock, 
  Star,
  ChevronDown,
  ChevronUp,
  X,
  Sparkles,
  Target,
  TrendingUp,
  Palette,
  Music,
  RefreshCw
} from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface AdvancedSearchFilters {
  query: string;
  strainTypes: string[];
  effects: string[];
  flavors: string[];
  terpenes: string[];
  thcRange: [number, number];
  cbdRange: [number, number];
  growDifficulty: string[];
  floweringTime: [number, number];
  dataQuality: string[];
  searchMode: 'basic' | 'advanced' | 'ai';
  sortBy: string;
  labVerified: boolean;
  userRatingMin: number;
  energyLevel: [number, number];
  creativityBoost: [number, number];
  relaxationLevel: [number, number];
  musicGenres: string[];
  usageContext: string[];
  timeOfDay: string[];
}

interface AdvancedSearchProps {
  onFiltersChange: (filters: AdvancedSearchFilters) => void;
  onSearch: () => void;
  isLoading?: boolean;
  resultCount?: number;
}

const strainTypes = ['Indica', 'Sativa', 'Hybrid'];
const commonEffects = [
  'Relaxed', 'Energetic', 'Creative', 'Focused', 'Happy', 'Euphoric', 
  'Sleepy', 'Uplifted', 'Giggly', 'Talkative', 'Hungry', 'Calm',
  'Aroused', 'Tingly', 'Motivated', 'Sociable', 'Peaceful', 'Alert'
];

const commonFlavors = [
  'Earthy', 'Sweet', 'Citrus', 'Piney', 'Fruity', 'Spicy', 'Diesel',
  'Floral', 'Herbal', 'Minty', 'Woody', 'Berry', 'Tropical', 'Vanilla',
  'Cheese', 'Skunky', 'Nutty', 'Coffee', 'Chocolate', 'Grape'
];

const terpeneList = [
  { name: 'Myrcene', color: 'bg-green-500/20 text-green-400' },
  { name: 'Limonene', color: 'bg-yellow-500/20 text-yellow-400' },
  { name: 'Pinene', color: 'bg-blue-500/20 text-blue-400' },
  { name: 'Linalool', color: 'bg-purple-500/20 text-purple-400' },
  { name: 'Caryophyllene', color: 'bg-orange-500/20 text-orange-400' },
  { name: 'Terpinolene', color: 'bg-pink-500/20 text-pink-400' },
  { name: 'Humulene', color: 'bg-red-500/20 text-red-400' },
  { name: 'Ocimene', color: 'bg-cyan-500/20 text-cyan-400' }
];

const musicGenres = [
  'Electronic', 'Hip-Hop', 'Jazz', 'Rock', 'Ambient', 'Classical', 'R&B', 'Pop',
  'Indie', 'Folk', 'Reggae', 'Blues', 'Funk', 'Soul', 'Country', 'World'
];

const usageContexts = [
  'Morning Routine', 'Work/Study', 'Creative Projects', 'Social Events', 
  'Exercise', 'Meditation', 'Evening Wind-down', 'Weekend Relaxation',
  'Party/Club', 'Outdoor Activities', 'Gaming', 'Reading'
];

const timeOfDay = ['Morning', 'Afternoon', 'Evening', 'Night'];
const growDifficulty = ['Beginner', 'Intermediate', 'Advanced'];
const dataQuality = ['Lab Verified', 'User Submitted', 'Curated'];
const sortOptions = [
  { value: 'relevance', label: 'Relevance' },
  { value: 'popularity', label: 'Popularity' },
  { value: 'thc_desc', label: 'THC % (High to Low)' },
  { value: 'thc_asc', label: 'THC % (Low to High)' },
  { value: 'name_asc', label: 'Name (A-Z)' },
  { value: 'rating_desc', label: 'Rating (High to Low)' },
  { value: 'newest', label: 'Newest First' },
  { value: 'terpene_diversity', label: 'Terpene Diversity' }
];

export function AdvancedSearch({ onFiltersChange, onSearch, isLoading, resultCount }: AdvancedSearchProps) {
  const [filters, setFilters] = useState<AdvancedSearchFilters>({
    query: '',
    strainTypes: [],
    effects: [],
    flavors: [],
    terpenes: [],
    thcRange: [0, 40],
    cbdRange: [0, 25],
    growDifficulty: [],
    floweringTime: [40, 80],
    dataQuality: [],
    searchMode: 'basic',
    sortBy: 'relevance',
    labVerified: false,
    userRatingMin: 0,
    energyLevel: [1, 10],
    creativityBoost: [1, 10],
    relaxationLevel: [1, 10],
    musicGenres: [],
    usageContext: [],
    timeOfDay: []
  });

  const [expandedSections, setExpandedSections] = useState({
    basic: true,
    cannabinoids: false,
    terpenes: false,
    effects: false,
    music: false,
    advanced: false
  });

  // Get AI-powered search suggestions
  const { data: searchSuggestions } = useQuery({
    queryKey: ['/api/search/suggestions', filters.query],
    enabled: filters.query.length > 2,
  });

  // Get trending searches
  const { data: trendingSearches } = useQuery({
    queryKey: ['/api/search/trending'],
  });

  useEffect(() => {
    onFiltersChange(filters);
  }, [filters, onFiltersChange]);

  const updateFilter = (key: keyof AdvancedSearchFilters, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const toggleArrayItem = (key: keyof AdvancedSearchFilters, item: string) => {
    const currentArray = filters[key] as string[];
    if (currentArray.includes(item)) {
      updateFilter(key, currentArray.filter(i => i !== item));
    } else {
      updateFilter(key, [...currentArray, item]);
    }
  };

  const clearAllFilters = () => {
    setFilters({
      query: '',
      strainTypes: [],
      effects: [],
      flavors: [],
      terpenes: [],
      thcRange: [0, 40],
      cbdRange: [0, 25],
      growDifficulty: [],
      floweringTime: [40, 80],
      dataQuality: [],
      searchMode: 'basic',
      sortBy: 'relevance',
      labVerified: false,
      userRatingMin: 0,
      energyLevel: [1, 10],
      creativityBoost: [1, 10],
      relaxationLevel: [1, 10],
      musicGenres: [],
      usageContext: [],
      timeOfDay: []
    });
  };

  const getRandomDiscovery = () => {
    const randomEffects = commonEffects.sort(() => 0.5 - Math.random()).slice(0, 2);
    const randomTerpenes = terpeneList.sort(() => 0.5 - Math.random()).slice(0, 2).map(t => t.name);
    const randomType = strainTypes[Math.floor(Math.random() * strainTypes.length)];
    
    setFilters(prev => ({
      ...prev,
      effects: randomEffects.map(e => e.toLowerCase()),
      terpenes: randomTerpenes.map(t => t.toLowerCase()),
      strainTypes: [randomType.toLowerCase()],
      query: '',
      searchMode: 'advanced'
    }));
  };

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const activeFilterCount = [
    ...filters.strainTypes,
    ...filters.effects,
    ...filters.flavors,
    ...filters.terpenes,
    ...filters.musicGenres,
    ...filters.usageContext,
    ...filters.timeOfDay,
    ...filters.growDifficulty,
    ...filters.dataQuality
  ].length + 
  (filters.labVerified ? 1 : 0) +
  (filters.userRatingMin > 0 ? 1 : 0) +
  (filters.thcRange[0] > 0 || filters.thcRange[1] < 40 ? 1 : 0) +
  (filters.cbdRange[0] > 0 || filters.cbdRange[1] < 25 ? 1 : 0);

  return (
    <div className="space-y-6">
      {/* Search Header */}
      <Card className="bg-gray-800/80 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center">
              <Search className="w-5 h-5 mr-2 text-green-400" />
              Advanced Strain Discovery
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                {resultCount || 0} strains found
              </Badge>
              {activeFilterCount > 0 && (
                <Badge variant="secondary" className="bg-blue-500/20 text-blue-400">
                  {activeFilterCount} filters active
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search Mode Tabs */}
          <Tabs value={filters.searchMode} onValueChange={(value) => updateFilter('searchMode', value)} className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-700/50">
              <TabsTrigger value="basic" className="data-[state=active]:bg-green-500/20">
                <Filter className="w-4 h-4 mr-2" />
                Basic
              </TabsTrigger>
              <TabsTrigger value="advanced" className="data-[state=active]:bg-green-500/20">
                <Sliders className="w-4 h-4 mr-2" />
                Advanced
              </TabsTrigger>
              <TabsTrigger value="ai" className="data-[state=active]:bg-green-500/20">
                <Brain className="w-4 h-4 mr-2" />
                AI Search
              </TabsTrigger>
            </TabsList>

            {/* Main Search Input */}
            <div className="relative mt-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-5 h-5" />
              <Input
                placeholder={
                  filters.searchMode === 'ai' 
                    ? "Describe what you're looking for: 'I want something energizing for creative work with citrus flavors'"
                    : "Search strains, effects, or terpenes..."
                }
                value={filters.query}
                onChange={(e) => updateFilter('query', e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && onSearch()}
                className="pl-10 bg-gray-900/50 border-gray-600 text-white placeholder-gray-300 focus:border-green-400"
              />
              {filters.query && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => updateFilter('query', '')}
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>

            {/* Search Suggestions */}
            {searchSuggestions && searchSuggestions.length > 0 && (
              <div className="flex flex-wrap gap-2">
                <span className="text-sm text-gray-300">Suggestions:</span>
                {searchSuggestions.slice(0, 4).map((suggestion: string, index: number) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className="cursor-pointer hover:bg-green-500/20 hover:text-green-400"
                    onClick={() => updateFilter('query', suggestion)}
                  >
                    {suggestion}
                  </Badge>
                ))}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Button
                  onClick={onSearch}
                  disabled={isLoading}
                  className="cannabis-gradient"
                >
                  {isLoading ? (
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Search className="w-4 h-4 mr-2" />
                  )}
                  {isLoading ? 'Searching...' : 'Search Strains'}
                </Button>
                <Button
                  variant="outline"
                  onClick={getRandomDiscovery}
                  className="border-purple-500/50 text-purple-400 hover:bg-purple-500/20"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Random Discovery
                </Button>
              </div>
              <div className="flex items-center space-x-2">
                <Select value={filters.sortBy} onValueChange={(value) => updateFilter('sortBy', value)}>
                  <SelectTrigger className="w-40 bg-gray-700/50 border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {sortOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {activeFilterCount > 0 && (
                  <Button variant="outline" onClick={clearAllFilters} size="sm">
                    <X className="w-4 h-4 mr-2" />
                    Clear All
                  </Button>
                )}
              </div>
            </div>
          </Tabs>
        </CardContent>
      </Card>

      {/* Filter Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Basic Filters */}
        <Collapsible open={expandedSections.basic} onOpenChange={() => toggleSection('basic')}>
          <Card className="bg-gray-800/80 border-gray-700">
            <CollapsibleTrigger asChild>
              <CardHeader className="cursor-pointer hover:bg-gray-700/50">
                <CardTitle className="text-white flex items-center justify-between">
                  <div className="flex items-center">
                    <Filter className="w-5 h-5 mr-2 text-green-400" />
                    Basic Filters
                  </div>
                  {expandedSections.basic ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </CardTitle>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-gray-300">Strain Types</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {strainTypes.map((type) => (
                      <Badge
                        key={type}
                        variant="secondary"
                        className={`cursor-pointer transition-all ${
                          filters.strainTypes.includes(type.toLowerCase())
                            ? 'bg-green-500/20 text-green-400'
                            : 'hover:bg-gray-600'
                        }`}
                        onClick={() => toggleArrayItem('strainTypes', type.toLowerCase())}
                      >
                        {type}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <Label className="text-gray-300">Lab Verified Only</Label>
                  <Switch
                    checked={filters.labVerified}
                    onCheckedChange={(checked) => updateFilter('labVerified', checked)}
                  />
                </div>

                <div>
                  <Label className="text-gray-300">Minimum User Rating</Label>
                  <div className="mt-2">
                    <Slider
                      value={[filters.userRatingMin]}
                      onValueChange={([value]) => updateFilter('userRatingMin', value)}
                      min={0}
                      max={5}
                      step={0.5}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-gray-300 mt-1">
                      <span>Any Rating</span>
                      <span className="text-white">{filters.userRatingMin}+ stars</span>
                      <span>5 stars</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Cannabinoids */}
        <Collapsible open={expandedSections.cannabinoids} onOpenChange={() => toggleSection('cannabinoids')}>
          <Card className="bg-gray-800/80 border-gray-700">
            <CollapsibleTrigger asChild>
              <CardHeader className="cursor-pointer hover:bg-gray-700/50">
                <CardTitle className="text-white flex items-center justify-between">
                  <div className="flex items-center">
                    <Zap className="w-5 h-5 mr-2 text-yellow-400" />
                    Cannabinoid Content
                  </div>
                  {expandedSections.cannabinoids ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </CardTitle>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-gray-300">THC Range (%)</Label>
                  <div className="mt-2">
                    <Slider
                      value={filters.thcRange}
                      onValueChange={(value) => updateFilter('thcRange', value)}
                      min={0}
                      max={40}
                      step={1}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-gray-300 mt-1">
                      <span>0%</span>
                      <span className="text-white">{filters.thcRange[0]}% - {filters.thcRange[1]}%</span>
                      <span>40%</span>
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300">CBD Range (%)</Label>
                  <div className="mt-2">
                    <Slider
                      value={filters.cbdRange}
                      onValueChange={(value) => updateFilter('cbdRange', value)}
                      min={0}
                      max={25}
                      step={0.5}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-gray-300 mt-1">
                      <span>0%</span>
                      <span className="text-white">{filters.cbdRange[0]}% - {filters.cbdRange[1]}%</span>
                      <span>25%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Terpenes */}
        <Collapsible open={expandedSections.terpenes} onOpenChange={() => toggleSection('terpenes')}>
          <Card className="bg-gray-800/80 border-gray-700">
            <CollapsibleTrigger asChild>
              <CardHeader className="cursor-pointer hover:bg-gray-700/50">
                <CardTitle className="text-white flex items-center justify-between">
                  <div className="flex items-center">
                    <Palette className="w-5 h-5 mr-2 text-purple-400" />
                    Terpene Profile
                  </div>
                  {expandedSections.terpenes ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </CardTitle>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  {terpeneList.map((terpene) => (
                    <div
                      key={terpene.name}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        filters.terpenes.includes(terpene.name.toLowerCase())
                          ? `${terpene.color} border-current`
                          : 'bg-gray-700/50 border-gray-600 hover:bg-gray-600'
                      }`}
                      onClick={() => toggleArrayItem('terpenes', terpene.name.toLowerCase())}
                    >
                      <div className="font-medium text-sm">{terpene.name}</div>
                    </div>
                  ))}
                </div>

                <Separator className="my-4" />

                <div className="space-y-3">
                  <div>
                    <Label className="text-gray-300">Energy Level</Label>
                    <Slider
                      value={filters.energyLevel}
                      onValueChange={(value) => updateFilter('energyLevel', value)}
                      min={1}
                      max={10}
                      step={1}
                      className="w-full mt-2"
                    />
                    <div className="flex justify-between text-xs text-gray-300 mt-1">
                      <span>Sedating</span>
                      <span>{filters.energyLevel[0]} - {filters.energyLevel[1]}</span>
                      <span>Energizing</span>
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300">Creativity Boost</Label>
                    <Slider
                      value={filters.creativityBoost}
                      onValueChange={(value) => updateFilter('creativityBoost', value)}
                      min={1}
                      max={10}
                      step={1}
                      className="w-full mt-2"
                    />
                    <div className="flex justify-between text-xs text-gray-300 mt-1">
                      <span>Neutral</span>
                      <span>{filters.creativityBoost[0]} - {filters.creativityBoost[1]}</span>
                      <span>Very Creative</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Effects & Flavors */}
        <Collapsible open={expandedSections.effects} onOpenChange={() => toggleSection('effects')}>
          <Card className="bg-gray-800/80 border-gray-700">
            <CollapsibleTrigger asChild>
              <CardHeader className="cursor-pointer hover:bg-gray-700/50">
                <CardTitle className="text-white flex items-center justify-between">
                  <div className="flex items-center">
                    <Heart className="w-5 h-5 mr-2 text-pink-400" />
                    Effects & Flavors
                  </div>
                  {expandedSections.effects ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </CardTitle>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-gray-300">Desired Effects</Label>
                  <div className="flex flex-wrap gap-2 mt-2 max-h-32 overflow-y-auto">
                    {commonEffects.map((effect) => (
                      <Badge
                        key={effect}
                        variant="secondary"
                        className={`cursor-pointer transition-all text-xs ${
                          filters.effects.includes(effect.toLowerCase())
                            ? 'bg-pink-500/20 text-pink-400'
                            : 'hover:bg-gray-600'
                        }`}
                        onClick={() => toggleArrayItem('effects', effect.toLowerCase())}
                      >
                        {effect}
                      </Badge>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <Label className="text-gray-300">Flavors</Label>
                  <div className="flex flex-wrap gap-2 mt-2 max-h-32 overflow-y-auto">
                    {commonFlavors.map((flavor) => (
                      <Badge
                        key={flavor}
                        variant="secondary"
                        className={`cursor-pointer transition-all text-xs ${
                          filters.flavors.includes(flavor.toLowerCase())
                            ? 'bg-orange-500/20 text-orange-400'
                            : 'hover:bg-gray-600'
                        }`}
                        onClick={() => toggleArrayItem('flavors', flavor.toLowerCase())}
                      >
                        {flavor}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Music & Usage Context */}
        <Collapsible open={expandedSections.music} onOpenChange={() => toggleSection('music')}>
          <Card className="bg-gray-800/80 border-gray-700">
            <CollapsibleTrigger asChild>
              <CardHeader className="cursor-pointer hover:bg-gray-700/50">
                <CardTitle className="text-white flex items-center justify-between">
                  <div className="flex items-center">
                    <Music className="w-5 h-5 mr-2 text-blue-400" />
                    Music & Context
                  </div>
                  {expandedSections.music ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </CardTitle>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-gray-300">Music Genres</Label>
                  <div className="flex flex-wrap gap-2 mt-2 max-h-24 overflow-y-auto">
                    {musicGenres.map((genre) => (
                      <Badge
                        key={genre}
                        variant="secondary"
                        className={`cursor-pointer transition-all text-xs ${
                          filters.musicGenres.includes(genre.toLowerCase())
                            ? 'bg-blue-500/20 text-blue-400'
                            : 'hover:bg-gray-600'
                        }`}
                        onClick={() => toggleArrayItem('musicGenres', genre.toLowerCase())}
                      >
                        {genre}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300">Usage Context</Label>
                  <div className="flex flex-wrap gap-2 mt-2 max-h-24 overflow-y-auto">
                    {usageContexts.map((context) => (
                      <Badge
                        key={context}
                        variant="secondary"
                        className={`cursor-pointer transition-all text-xs ${
                          filters.usageContext.includes(context.toLowerCase())
                            ? 'bg-cyan-500/20 text-cyan-400'
                            : 'hover:bg-gray-600'
                        }`}
                        onClick={() => toggleArrayItem('usageContext', context.toLowerCase())}
                      >
                        {context}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300">Time of Day</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {timeOfDay.map((time) => (
                      <Badge
                        key={time}
                        variant="secondary"
                        className={`cursor-pointer transition-all ${
                          filters.timeOfDay.includes(time.toLowerCase())
                            ? 'bg-indigo-500/20 text-indigo-400'
                            : 'hover:bg-gray-600'
                        }`}
                        onClick={() => toggleArrayItem('timeOfDay', time.toLowerCase())}
                      >
                        {time}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>

        {/* Advanced Options */}
        <Collapsible open={expandedSections.advanced} onOpenChange={() => toggleSection('advanced')}>
          <Card className="bg-gray-800/80 border-gray-700">
            <CollapsibleTrigger asChild>
              <CardHeader className="cursor-pointer hover:bg-gray-700/50">
                <CardTitle className="text-white flex items-center justify-between">
                  <div className="flex items-center">
                    <Target className="w-5 h-5 mr-2 text-red-400" />
                    Advanced Options
                  </div>
                  {expandedSections.advanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </CardTitle>
              </CardHeader>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-gray-300">Growing Difficulty</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {growDifficulty.map((difficulty) => (
                      <Badge
                        key={difficulty}
                        variant="secondary"
                        className={`cursor-pointer transition-all ${
                          filters.growDifficulty.includes(difficulty.toLowerCase())
                            ? 'bg-green-500/20 text-green-400'
                            : 'hover:bg-gray-600'
                        }`}
                        onClick={() => toggleArrayItem('growDifficulty', difficulty.toLowerCase())}
                      >
                        {difficulty}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300">Data Quality</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {dataQuality.map((quality) => (
                      <Badge
                        key={quality}
                        variant="secondary"
                        className={`cursor-pointer transition-all ${
                          filters.dataQuality.includes(quality.toLowerCase())
                            ? 'bg-yellow-500/20 text-yellow-400'
                            : 'hover:bg-gray-600'
                        }`}
                        onClick={() => toggleArrayItem('dataQuality', quality.toLowerCase())}
                      >
                        {quality}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300">Flowering Time (days)</Label>
                  <div className="mt-2">
                    <Slider
                      value={filters.floweringTime}
                      onValueChange={(value) => updateFilter('floweringTime', value)}
                      min={30}
                      max={100}
                      step={5}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-gray-300 mt-1">
                      <span>30 days</span>
                      <span className="text-white">{filters.floweringTime[0]} - {filters.floweringTime[1]} days</span>
                      <span>100 days</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </CollapsibleContent>
          </Card>
        </Collapsible>
      </div>

      {/* Trending Searches */}
      {trendingSearches && trendingSearches.length > 0 && (
        <Card className="bg-gray-800/80 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-orange-400" />
              Trending Searches
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {trendingSearches.slice(0, 8).map((trend: string, index: number) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="cursor-pointer hover:bg-orange-500/20 hover:text-orange-400"
                  onClick={() => updateFilter('query', trend)}
                >
                  {trend}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}