import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { 
  Star, 
  MessageSquare, 
  ThumbsUp, 
  ThumbsDown, 
  Flag, 
  Edit3,
  Trash2,
  Plus,
  Send,
  Filter,
  TrendingUp,
  Award,
  Users,
  Clock,
  Verified,
  Heart
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Review {
  id: number;
  userId: string;
  userName: string;
  userAvatar?: string;
  strainId: number;
  rating: number;
  title: string;
  content: string;
  effects: string[];
  pros: string[];
  cons: string[];
  experienceLevel: string;
  consumptionMethod: string;
  dosage: string;
  occasion: string;
  createdAt: string;
  updatedAt?: string;
  likes: number;
  dislikes: number;
  userHasLiked: boolean;
  userHasDisliked: boolean;
  verified: boolean;
  helpful: number;
}

interface StrainReviewsProps {
  strainId: number;
  strainName: string;
}

const experienceLevels = ['Beginner', 'Intermediate', 'Experienced', 'Expert'];
const consumptionMethods = ['Flower', 'Vaporizer', 'Edibles', 'Concentrates', 'Pre-roll', 'Tincture'];
const occasions = ['Morning', 'Afternoon', 'Evening', 'Social', 'Solo', 'Work', 'Creative', 'Relaxation', 'Sleep'];
const dosageOptions = ['Micro (1-2.5mg)', 'Low (2.5-15mg)', 'Medium (15-30mg)', 'High (30-50mg)', 'Very High (50mg+)'];

export function StrainReviews({ strainId, strainName }: StrainReviewsProps) {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [sortBy, setSortBy] = useState('newest');
  const [filterBy, setFilterBy] = useState('all');
  const [showReviewForm, setShowReviewForm] = useState(false);

  const [reviewForm, setReviewForm] = useState({
    rating: 5,
    title: '',
    content: '',
    effects: [] as string[],
    pros: [] as string[],
    cons: [] as string[],
    experienceLevel: '',
    consumptionMethod: '',
    dosage: '',
    occasion: ''
  });

  // Fetch reviews for this strain
  const { data: reviews = [], isLoading } = useQuery({
    queryKey: ['/api/strains', strainId, 'reviews', sortBy, filterBy],
    queryFn: () => apiRequest(`/api/strains/${strainId}/reviews?sort=${sortBy}&filter=${filterBy}`),
  });

  // Fetch review summary
  const { data: reviewSummary } = useQuery({
    queryKey: ['/api/strains', strainId, 'review-summary'],
    queryFn: () => apiRequest(`/api/strains/${strainId}/review-summary`),
  });

  // Submit review mutation
  const submitReviewMutation = useMutation({
    mutationFn: async (reviewData: any) => {
      return await apiRequest(`/api/strains/${strainId}/reviews`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reviewData),
      });
    },
    onSuccess: () => {
      toast({
        title: "Review Submitted",
        description: "Your review has been posted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/strains', strainId, 'reviews'] });
      queryClient.invalidateQueries({ queryKey: ['/api/strains', strainId, 'review-summary'] });
      setShowReviewForm(false);
      setReviewForm({
        rating: 5,
        title: '',
        content: '',
        effects: [],
        pros: [],
        cons: [],
        experienceLevel: '',
        consumptionMethod: '',
        dosage: '',
        occasion: ''
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to submit review. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Like/dislike review mutation
  const voteReviewMutation = useMutation({
    mutationFn: async ({ reviewId, voteType }: { reviewId: number; voteType: 'like' | 'dislike' }) => {
      return await apiRequest(`/api/reviews/${reviewId}/vote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ voteType }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/strains', strainId, 'reviews'] });
    },
  });

  const handleSubmitReview = () => {
    if (!reviewForm.title.trim() || !reviewForm.content.trim()) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    submitReviewMutation.mutate(reviewForm);
  };

  const handleVoteReview = (reviewId: number, voteType: 'like' | 'dislike') => {
    if (!isAuthenticated) {
      toast({
        title: "Sign In Required",
        description: "Please sign in to vote on reviews.",
        variant: "destructive",
      });
      return;
    }
    voteReviewMutation.mutate({ reviewId, voteType });
  };

  const addToArray = (arrayName: keyof typeof reviewForm, item: string) => {
    const currentArray = reviewForm[arrayName] as string[];
    if (!currentArray.includes(item)) {
      setReviewForm(prev => ({
        ...prev,
        [arrayName]: [...currentArray, item]
      }));
    }
  };

  const removeFromArray = (arrayName: keyof typeof reviewForm, item: string) => {
    const currentArray = reviewForm[arrayName] as string[];
    setReviewForm(prev => ({
      ...prev,
      [arrayName]: currentArray.filter(i => i !== item)
    }));
  };

  const renderStarRating = (rating: number, interactive: boolean = false, onRatingChange?: (rating: number) => void) => {
    return (
      <div className="flex items-center space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-5 h-5 ${
              star <= rating 
                ? 'text-yellow-400 fill-current' 
                : 'text-gray-300'
            } ${interactive ? 'cursor-pointer hover:text-yellow-300' : ''}`}
            onClick={() => interactive && onRatingChange && onRatingChange(star)}
          />
        ))}
      </div>
    );
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)}d ago`;
    return `${Math.floor(diffInHours / 168)}w ago`;
  };

  return (
    <div className="space-y-6">
      {/* Review Summary */}
      {reviewSummary && (
        <Card className="bg-gray-800/80 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Award className="w-5 h-5 mr-2 text-yellow-400" />
              Community Reviews for {strainName}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-white">{reviewSummary.averageRating || 4.2}</div>
                {renderStarRating(Math.round(reviewSummary.averageRating || 4.2))}
                <div className="text-sm text-gray-300 mt-1">{reviewSummary.totalReviews || 47} reviews</div>
              </div>
              
              <div>
                <div className="text-sm font-medium text-gray-300 mb-2">Rating Distribution</div>
                {[5, 4, 3, 2, 1].map((rating) => (
                  <div key={rating} className="flex items-center space-x-2 mb-1">
                    <span className="text-xs text-gray-300 w-8">{rating}★</span>
                    <div className="flex-1 bg-gray-700 rounded h-2">
                      <div 
                        className="bg-yellow-400 h-2 rounded"
                        style={{ 
                          width: `${((reviewSummary.ratingDistribution?.[rating] || 0) / (reviewSummary.totalReviews || 1)) * 100}%` 
                        }}
                      />
                    </div>
                    <span className="text-xs text-gray-300 w-8">{reviewSummary.ratingDistribution?.[rating] || 0}</span>
                  </div>
                ))}
              </div>

              <div>
                <div className="text-sm font-medium text-gray-300 mb-2">Top Effects</div>
                <div className="space-y-1">
                  {(reviewSummary.topEffects || ['Relaxed', 'Creative', 'Happy']).slice(0, 4).map((effect: string, index: number) => (
                    <Badge key={effect} variant="secondary" className="text-xs bg-green-500/20 text-green-400">
                      {effect}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-sm font-medium text-gray-300 mb-2">Community Stats</div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Verified Reviews</span>
                    <span className="text-white">{reviewSummary.verifiedCount || 23}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Expert Reviews</span>
                    <span className="text-white">{reviewSummary.expertCount || 8}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Helpful Votes</span>
                    <span className="text-white">{reviewSummary.totalHelpful || 312}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Review Controls */}
      <Card className="bg-gray-800/80 border-gray-700">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-gray-300" />
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-32 bg-gray-700/50 border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="oldest">Oldest</SelectItem>
                    <SelectItem value="highest">Highest Rated</SelectItem>
                    <SelectItem value="lowest">Lowest Rated</SelectItem>
                    <SelectItem value="helpful">Most Helpful</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Select value={filterBy} onValueChange={setFilterBy}>
                <SelectTrigger className="w-36 bg-gray-700/50 border-gray-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Reviews</SelectItem>
                  <SelectItem value="verified">Verified Only</SelectItem>
                  <SelectItem value="expert">Expert Reviews</SelectItem>
                  <SelectItem value="recent">Last 30 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Dialog open={showReviewForm} onOpenChange={setShowReviewForm}>
              <DialogTrigger asChild>
                <Button className="cannabis-gradient" disabled={!isAuthenticated}>
                  <Plus className="w-4 h-4 mr-2" />
                  Write Review
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl bg-gray-800 border-gray-700">
                <DialogHeader>
                  <DialogTitle className="text-white">Review {strainName}</DialogTitle>
                </DialogHeader>
                
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300">Overall Rating</Label>
                      <div className="mt-2">
                        {renderStarRating(reviewForm.rating, true, (rating) => 
                          setReviewForm(prev => ({ ...prev, rating }))
                        )}
                      </div>
                    </div>

                    <div>
                      <Label className="text-gray-300">Experience Level</Label>
                      <Select value={reviewForm.experienceLevel} onValueChange={(value) => 
                        setReviewForm(prev => ({ ...prev, experienceLevel: value }))
                      }>
                        <SelectTrigger className="mt-2 bg-gray-700/50 border-gray-600">
                          <SelectValue placeholder="Select level" />
                        </SelectTrigger>
                        <SelectContent>
                          {experienceLevels.map((level) => (
                            <SelectItem key={level} value={level.toLowerCase()}>{level}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300">Review Title</Label>
                    <Input
                      value={reviewForm.title}
                      onChange={(e) => setReviewForm(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Summarize your experience..."
                      className="mt-2 bg-gray-700/50 border-gray-600 text-white"
                    />
                  </div>

                  <div>
                    <Label className="text-gray-300">Detailed Review</Label>
                    <Textarea
                      value={reviewForm.content}
                      onChange={(e) => setReviewForm(prev => ({ ...prev, content: e.target.value }))}
                      placeholder="Share your detailed experience with this strain..."
                      rows={4}
                      className="mt-2 bg-gray-700/50 border-gray-600 text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300">Consumption Method</Label>
                      <Select value={reviewForm.consumptionMethod} onValueChange={(value) => 
                        setReviewForm(prev => ({ ...prev, consumptionMethod: value }))
                      }>
                        <SelectTrigger className="mt-2 bg-gray-700/50 border-gray-600">
                          <SelectValue placeholder="How did you consume?" />
                        </SelectTrigger>
                        <SelectContent>
                          {consumptionMethods.map((method) => (
                            <SelectItem key={method} value={method.toLowerCase()}>{method}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-gray-300">Occasion</Label>
                      <Select value={reviewForm.occasion} onValueChange={(value) => 
                        setReviewForm(prev => ({ ...prev, occasion: value }))
                      }>
                        <SelectTrigger className="mt-2 bg-gray-700/50 border-gray-600">
                          <SelectValue placeholder="When did you use it?" />
                        </SelectTrigger>
                        <SelectContent>
                          {occasions.map((occasion) => (
                            <SelectItem key={occasion} value={occasion.toLowerCase()}>{occasion}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <Label className="text-gray-300">Effects Experienced</Label>
                      <div className="mt-2">
                        <Input
                          placeholder="Type effect and press Enter"
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              const target = e.target as HTMLInputElement;
                              if (target.value.trim()) {
                                addToArray('effects', target.value.trim());
                                target.value = '';
                              }
                            }
                          }}
                          className="bg-gray-700/50 border-gray-600 text-white"
                        />
                        <div className="flex flex-wrap gap-2 mt-2">
                          {reviewForm.effects.map((effect) => (
                            <Badge
                              key={effect}
                              variant="secondary"
                              className="bg-green-500/20 text-green-400 cursor-pointer"
                              onClick={() => removeFromArray('effects', effect)}
                            >
                              {effect} ×
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-gray-300">Pros</Label>
                        <div className="mt-2">
                          <Input
                            placeholder="Type pro and press Enter"
                            onKeyPress={(e) => {
                              if (e.key === 'Enter') {
                                const target = e.target as HTMLInputElement;
                                if (target.value.trim()) {
                                  addToArray('pros', target.value.trim());
                                  target.value = '';
                                }
                              }
                            }}
                            className="bg-gray-700/50 border-gray-600 text-white"
                          />
                          <div className="flex flex-wrap gap-1 mt-2">
                            {reviewForm.pros.map((pro) => (
                              <Badge
                                key={pro}
                                variant="secondary"
                                className="bg-blue-500/20 text-blue-400 cursor-pointer text-xs"
                                onClick={() => removeFromArray('pros', pro)}
                              >
                                {pro} ×
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div>
                        <Label className="text-gray-300">Cons</Label>
                        <div className="mt-2">
                          <Input
                            placeholder="Type con and press Enter"
                            onKeyPress={(e) => {
                              if (e.key === 'Enter') {
                                const target = e.target as HTMLInputElement;
                                if (target.value.trim()) {
                                  addToArray('cons', target.value.trim());
                                  target.value = '';
                                }
                              }
                            }}
                            className="bg-gray-700/50 border-gray-600 text-white"
                          />
                          <div className="flex flex-wrap gap-1 mt-2">
                            {reviewForm.cons.map((con) => (
                              <Badge
                                key={con}
                                variant="secondary"
                                className="bg-red-500/20 text-red-400 cursor-pointer text-xs"
                                onClick={() => removeFromArray('cons', con)}
                              >
                                {con} ×
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 pt-4">
                  <Button variant="outline" onClick={() => setShowReviewForm(false)}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleSubmitReview}
                    disabled={submitReviewMutation.isPending}
                    className="cannabis-gradient"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    {submitReviewMutation.isPending ? 'Submitting...' : 'Submit Review'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      {/* Reviews List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center py-8">
            <div className="text-gray-300">Loading reviews...</div>
          </div>
        ) : reviews.length === 0 ? (
          <Card className="bg-gray-800/80 border-gray-700">
            <CardContent className="text-center py-8">
              <MessageSquare className="w-12 h-12 mx-auto text-gray-300 mb-4" />
              <h3 className="text-white text-lg font-medium mb-2">No Reviews Yet</h3>
              <p className="text-gray-300 mb-4">Be the first to review {strainName}!</p>
              {isAuthenticated && (
                <Button onClick={() => setShowReviewForm(true)} className="cannabis-gradient">
                  <Plus className="w-4 h-4 mr-2" />
                  Write First Review
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          reviews.map((review: Review) => (
            <Card key={review.id} className="bg-gray-800/80 border-gray-700">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <Avatar className="w-10 h-10">
                      <AvatarFallback className="bg-green-500/20 text-green-400">
                        {review.userName.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium text-white">{review.userName}</span>
                        {review.verified && (
                          <Verified className="w-4 h-4 text-blue-400" />
                        )}
                        <Badge variant="secondary" className="text-xs">
                          {review.experienceLevel}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-2 mt-1">
                        {renderStarRating(review.rating)}
                        <span className="text-sm text-gray-300">
                          {formatTimeAgo(review.createdAt)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleVoteReview(review.id, 'like')}
                      className={`h-8 ${review.userHasLiked ? 'text-green-400' : 'text-gray-300'}`}
                    >
                      <ThumbsUp className="w-4 h-4 mr-1" />
                      {review.likes}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleVoteReview(review.id, 'dislike')}
                      className={`h-8 ${review.userHasDisliked ? 'text-red-400' : 'text-gray-300'}`}
                    >
                      <ThumbsDown className="w-4 h-4 mr-1" />
                      {review.dislikes}
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <h4 className="font-medium text-white mb-2">{review.title}</h4>
                <p className="text-gray-300 mb-4">{review.content}</p>
                
                {(review.effects.length > 0 || review.pros.length > 0 || review.cons.length > 0) && (
                  <div className="space-y-3">
                    {review.effects.length > 0 && (
                      <div>
                        <span className="text-sm font-medium text-gray-300 mb-2 block">Effects:</span>
                        <div className="flex flex-wrap gap-1">
                          {review.effects.map((effect) => (
                            <Badge key={effect} variant="secondary" className="text-xs bg-green-500/20 text-green-400">
                              {effect}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {review.pros.length > 0 && (
                      <div>
                        <span className="text-sm font-medium text-gray-300 mb-2 block">Pros:</span>
                        <div className="flex flex-wrap gap-1">
                          {review.pros.map((pro) => (
                            <Badge key={pro} variant="secondary" className="text-xs bg-blue-500/20 text-blue-400">
                              {pro}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {review.cons.length > 0 && (
                      <div>
                        <span className="text-sm font-medium text-gray-300 mb-2 block">Cons:</span>
                        <div className="flex flex-wrap gap-1">
                          {review.cons.map((con) => (
                            <Badge key={con} variant="secondary" className="text-xs bg-red-500/20 text-red-400">
                              {con}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <Separator className="my-4" />
                
                <div className="flex items-center justify-between text-sm text-gray-300">
                  <div className="flex items-center space-x-4">
                    <span>Via {review.consumptionMethod}</span>
                    <span>•</span>
                    <span>{review.occasion} use</span>
                    {review.dosage && (
                      <>
                        <span>•</span>
                        <span>{review.dosage}</span>
                      </>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <Heart className="w-4 h-4" />
                    <span>{review.helpful} helpful</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}