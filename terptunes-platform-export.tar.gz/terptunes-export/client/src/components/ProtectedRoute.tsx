import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, AlertTriangle, User } from "lucide-react";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: "consumer" | "grower" | "dispensary";
  requiresVerification?: boolean;
  requiresOnboarding?: boolean;
}

export default function ProtectedRoute({ 
  children, 
  requiredRole,
  requiresVerification = false,
  requiresOnboarding = true 
}: ProtectedRouteProps) {
  const { user, isLoading, isAuthenticated } = useAuth();

  // Get onboarding status if user is authenticated
  const { data: onboardingStatus } = useQuery({
    queryKey: ["/api/auth/onboarding-status"],
    enabled: isAuthenticated,
  });

  // Redirect to login if not authenticated
  if (!isLoading && !isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-6">
        <Card className="w-full max-w-md bg-gray-800 border-gray-700">
          <CardHeader className="text-center">
            <CardTitle className="text-white flex items-center justify-center gap-2">
              <Shield className="w-6 h-6 text-red-400" />
              Access Restricted
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-gray-300 mb-6">Please sign in to access this page.</p>
            <Button onClick={() => window.location.href = "/api/login"}>
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  // Check if onboarding is required and not completed
  if (requiresOnboarding && user && !user.onboardingCompleted) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-6">
        <Card className="w-full max-w-md bg-gray-800 border-gray-700">
          <CardHeader className="text-center">
            <CardTitle className="text-white flex items-center justify-center gap-2">
              <User className="w-6 h-6 text-blue-400" />
              Complete Your Setup
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-gray-300 mb-6">
              Please complete your account setup to access this feature.
            </p>
            <Button onClick={() => window.location.href = "/onboarding"}>
              Complete Setup
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Check role requirements
  if (requiredRole && user?.userType !== requiredRole) {
    const roleNames = {
      consumer: "Cannabis Enthusiast",
      grower: "Cannabis Grower", 
      dispensary: "Dispensary"
    };

    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-6">
        <Card className="w-full max-w-md bg-gray-800 border-gray-700">
          <CardHeader className="text-center">
            <CardTitle className="text-white flex items-center justify-center gap-2">
              <AlertTriangle className="w-6 h-6 text-orange-400" />
              Access Restricted
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-gray-300 mb-6">
              This page is only available to {roleNames[requiredRole]} accounts.
            </p>
            <Button variant="outline" onClick={() => window.location.href = "/"}>
              Return Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Check verification requirements for business accounts
  if (requiresVerification && user?.userType !== "consumer") {
    if (!user?.verificationStatus || user.verificationStatus === "pending") {
      return (
        <div className="min-h-screen bg-gray-900 flex items-center justify-center p-6">
          <Card className="w-full max-w-md bg-gray-800 border-gray-700">
            <CardHeader className="text-center">
              <CardTitle className="text-white flex items-center justify-center gap-2">
                <Shield className="w-6 h-6 text-yellow-400" />
                Verification Required
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-300 mb-6">
                {user?.verificationStatus === "pending" 
                  ? "Your business verification is pending review." 
                  : "Please complete business verification to access this feature."
                }
              </p>
              <Button 
                variant="outline" 
                onClick={() => window.location.href = user?.verificationStatus === "pending" ? "/" : "/onboarding"}
              >
                {user?.verificationStatus === "pending" ? "Return Home" : "Complete Verification"}
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (user.verificationStatus === "rejected") {
      return (
        <div className="min-h-screen bg-gray-900 flex items-center justify-center p-6">
          <Card className="w-full max-w-md bg-gray-800 border-gray-700">
            <CardHeader className="text-center">
              <CardTitle className="text-white flex items-center justify-center gap-2">
                <AlertTriangle className="w-6 h-6 text-red-400" />
                Verification Failed
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-300 mb-6">
                Your business verification was not approved. Please contact support for assistance.
              </p>
              <Button variant="outline" onClick={() => window.location.href = "/"}>
                Return Home
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }
  }

  // All checks passed - render the protected content
  return <>{children}</>;
}