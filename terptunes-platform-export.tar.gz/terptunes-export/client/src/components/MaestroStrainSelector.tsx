import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Sparkles, Brain, Heart, Zap, Music, Leaf } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface MaestroStrainSelectorProps {
  onStrainSelected?: (strain: any) => void;
}

export function MaestroStrainSelector({ onStrainSelected }: MaestroStrainSelectorProps) {
  const [mood, setMood] = useState<string>('');
  const [genre, setGenre] = useState<string>('');
  const [energy, setEnergy] = useState<number[]>([0.5]);
  const [isSearching, setIsSearching] = useState(false);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [maestroNote, setMaestroNote] = useState<string>('');
  const { toast } = useToast();

  const handleSearchStrains = async () => {
    setIsSearching(true);
    try {
      const response = await apiRequest('POST', '/api/maestro/recommend-strains', {
        mood: mood || undefined,
        genre: genre || undefined,
        energy: energy[0]
      });
      
      const result = await response.json();

      if (result.success) {
        setRecommendations(result.recommendations);
        setMaestroNote(result.maestroNote);
        toast({
          title: "🔮 Maestro's Divination Complete",
          description: `Found ${result.recommendations.length} harmonious strains`,
        });
      }
    } catch (error) {
      console.error('Maestro strain search error:', error);
      toast({
        title: "Maestro's Vision Clouded",
        description: "Unable to divine strains right now. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSearching(false);
    }
  };

  const getStrainIcon = (type: string) => {
    switch (type) {
      case 'indica': return <Heart className="w-4 h-4 text-purple-400" />;
      case 'sativa': return <Zap className="w-4 h-4 text-green-400" />;
      case 'hybrid': return <Brain className="w-4 h-4 text-blue-400" />;
      default: return <Leaf className="w-4 h-4 text-gray-300" />;
    }
  };

  const getMoodIcon = (selectedMood: string) => {
    switch (selectedMood) {
      case 'relaxed': return <Heart className="w-4 h-4" />;
      case 'uplifting': return <Zap className="w-4 h-4" />;
      case 'focused': return <Brain className="w-4 h-4" />;
      case 'peaceful': return <Sparkles className="w-4 h-4" />;
      default: return <Music className="w-4 h-4" />;
    }
  };

  return (
    <Card className="bg-gradient-to-br from-indigo-900/50 to-purple-900/50 border-indigo-500/30">
      <CardHeader className="text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Brain className="w-6 h-6 text-indigo-400" />
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
            Mello Strain Selection System
          </CardTitle>
          <Sparkles className="w-6 h-6 text-purple-400" />
        </div>
        <CardDescription className="text-indigo-200">
          Let Maestro guide your cannabis selection through the Mello system's wisdom
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Mood Selection */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-indigo-200 flex items-center gap-2">
              {getMoodIcon(mood)}
              Desired Mood State
            </label>
            <Select value={mood} onValueChange={setMood}>
              <SelectTrigger className="bg-black/30 border-indigo-500/30 text-indigo-100">
                <SelectValue placeholder="How do you want to feel?" />
              </SelectTrigger>
              <SelectContent className="bg-gray-900 border-indigo-500/30">
                <SelectItem value="relaxed">Relaxed & Calm</SelectItem>
                <SelectItem value="uplifting">Uplifting & Euphoric</SelectItem>
                <SelectItem value="focused">Focused & Clear</SelectItem>
                <SelectItem value="peaceful">Peaceful & Meditative</SelectItem>
                <SelectItem value="balanced">Balanced & Harmonious</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Genre Selection */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-indigo-200 flex items-center gap-2">
              <Music className="w-4 h-4" />
              Musical Preference
            </label>
            <Select value={genre} onValueChange={setGenre}>
              <SelectTrigger className="bg-black/30 border-indigo-500/30 text-indigo-100">
                <SelectValue placeholder="What sounds call to you?" />
              </SelectTrigger>
              <SelectContent className="bg-gray-900 border-indigo-500/30">
                <SelectItem value="ambient">Ambient & Atmospheric</SelectItem>
                <SelectItem value="electronic">Electronic & Synthetic</SelectItem>
                <SelectItem value="jazz">Jazz & Improvisational</SelectItem>
                <SelectItem value="classical">Classical & Orchestral</SelectItem>
                <SelectItem value="hip-hop">Hip-Hop & Rhythmic</SelectItem>
                <SelectItem value="rock">Rock & Alternative</SelectItem>
                <SelectItem value="world">World & Cultural</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Energy Level */}
        <div className="space-y-3">
          <label className="text-sm font-medium text-indigo-200 flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Energy Frequency: {Math.round(energy[0] * 100)}%
          </label>
          <div className="px-3">
            <Slider
              value={energy}
              onValueChange={setEnergy}
              max={1}
              min={0}
              step={0.1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-indigo-300 mt-1">
              <span>Deeply Mellow</span>
              <span>Balanced Flow</span>
              <span>High Vibration</span>
            </div>
          </div>
        </div>

        {/* Search Button */}
        <Button 
          onClick={handleSearchStrains}
          disabled={isSearching}
          size="lg"
          className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold py-3 rounded-full shadow-lg hover:shadow-indigo-500/25 transition-all duration-300"
        >
          {isSearching ? (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Maestro is Divining Strains...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5" />
              Consult Maestro's Strain Oracle
            </div>
          )}
        </Button>

        {/* Maestro's Note */}
        {maestroNote && (
          <div className="bg-gradient-to-r from-purple-900/40 to-indigo-900/40 rounded-lg p-4 border border-purple-400/30">
            <p className="text-purple-100 text-sm italic text-center">
              💭 {maestroNote}
            </p>
          </div>
        )}

        {/* Strain Recommendations */}
        {recommendations.length > 0 && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-indigo-200 text-center">
              Maestro's Curated Selection
            </h3>
            <div className="grid gap-4">
              {recommendations.map((strain) => (
                <Card 
                  key={strain.id} 
                  className="bg-gradient-to-r from-black/40 to-gray-900/40 border-indigo-400/30 hover:border-purple-400/50 transition-colors cursor-pointer"
                  onClick={() => onStrainSelected?.(strain)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {getStrainIcon(strain.type)}
                        <div>
                          <h4 className="font-medium text-indigo-100">{strain.name}</h4>
                          <p className="text-sm text-indigo-300 capitalize">{strain.type}</p>
                        </div>
                      </div>
                      <div className="text-right space-y-1">
                        <Badge className="bg-purple-600/30 text-purple-200 border-purple-500/30">
                          {strain.maestroScore}% Match
                        </Badge>
                        <p className="text-xs text-indigo-300">
                          {strain.musicalProfile?.primaryMood}
                        </p>
                      </div>
                    </div>
                    
                    {strain.maestroNote && (
                      <div className="mt-3 p-2 bg-black/30 rounded border border-purple-500/20">
                        <p className="text-xs text-purple-200 italic">
                          🎵 {strain.maestroNote}
                        </p>
                      </div>
                    )}

                    <div className="flex gap-2 mt-3">
                      <Badge variant="outline" className="text-xs bg-indigo-600/20 text-indigo-300 border-indigo-500/30">
                        {strain.musicalProfile?.genres[0]}
                      </Badge>
                      <Badge variant="outline" className="text-xs bg-purple-600/20 text-purple-300 border-purple-500/30">
                        Energy: {Math.round((strain.musicalProfile?.energy || 0) * 100)}%
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default MaestroStrainSelector;