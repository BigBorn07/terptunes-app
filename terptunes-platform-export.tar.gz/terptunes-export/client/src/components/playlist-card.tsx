import { Playlist } from "@/types";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, ExternalLink, Clock, Music } from "lucide-react";
import { formatDistanceToNow } from 'date-fns';

interface PlaylistCardProps {
  playlist: Playlist;
  onPlay?: (playlist: Playlist) => void;
}

export function PlaylistCard({ playlist, onPlay }: PlaylistCardProps) {
  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  return (
    <Card className="strain-card group cursor-pointer hover:scale-105 transition-all duration-200">
      <CardContent className="p-4">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 cannabis-gradient rounded-lg flex items-center justify-center flex-shrink-0">
            <Music className="text-white" />
          </div>
          
          <div className="flex-1 min-w-0">
            <h4 className="font-medium text-white group-hover:text-green-400 transition-colors truncate">
              {playlist.name}
            </h4>
            <p className="text-sm text-gray-300">
              Created {formatDistanceToNow(new Date(playlist.createdAt))} ago • {playlist.trackCount} tracks
            </p>
            
            <div className="flex items-center space-x-2 mt-2">
              {playlist.dominantTerpenes.slice(0, 3).map((terpene, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {terpene}
                </Badge>
              ))}
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <div className="text-right text-sm text-gray-300">
              <div className="flex items-center">
                <Clock className="w-3 h-3 mr-1" />
                {formatDuration(playlist.duration)}
              </div>
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onPlay?.(playlist)}
              className="opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <Play className="w-4 h-4" />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.open(`https://open.spotify.com/playlist/${playlist.spotifyPlaylistId}`, '_blank')}
              className="opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <ExternalLink className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
