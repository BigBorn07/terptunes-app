import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { MapPin, Store, TrendingUp, Gift, Star, Calendar, Award, Crown, Gem, Zap, ExternalLink } from "lucide-react";

interface DispensaryConsumption {
  dispensaryId: number;
  dispensaryName: string;
  location: string;
  totalVisits: number;
  loyaltyPoints: number;
  isQualified: boolean;
  ambassadorLevel?: string;
  visits: Array<{
    id: number;
    visitType: string;
    visitDate: string;
    rating?: number;
    review?: string;
  }>;
}

interface DispensaryAmbassadorshipStats {
  totalDispensaries: number;
  qualifiedDispensaries: number;
  totalVisits: number;
  loyaltyPoints: number;
  ambassadorships: Array<{
    id: number;
    dispensaryId: number;
    dispensaryName: string;
    location: string;
    totalVisits: number;
    ambassadorLevel: string;
    qualifiedAt: string;
    exclusiveAccess: boolean;
    loyaltyPoints: number;
  }>;
  exclusiveRewards: number;
}

interface DispensaryExclusive {
  id: number;
  dispensaryId: number;
  dispensaryName: string;
  title: string;
  description: string;
  type: string;
  value: string;
  requiredLevel: string;
  validUntil?: string;
  isActive: boolean;
}

interface NearQualificationDispensary {
  dispensaryId: number;
  dispensaryName: string;
  location: string;
  currentVisits: number;
  neededForNext: {
    visits: number;
    level: string;
  };
  progress: number;
}

export function DispensaryAmbassadorDashboard() {
  const { data: stats } = useQuery<DispensaryAmbassadorshipStats>({
    queryKey: ["/api/dispensary-ambassador/stats"],
  });

  const { data: consumption } = useQuery<DispensaryConsumption[]>({
    queryKey: ["/api/dispensary-ambassador/consumption"],
  });

  const { data: rewards } = useQuery<DispensaryExclusive[]>({
    queryKey: ["/api/dispensary-ambassador/rewards"],
  });

  const { data: nearQualification } = useQuery<NearQualificationDispensary[]>({
    queryKey: ["/api/dispensary-ambassador/near-qualification"],
  });

  const getAmbassadorLevelIcon = (level: string) => {
    switch (level) {
      case "bronze": return <Award className="h-4 w-4 text-amber-600" />;
      case "silver": return <Star className="h-4 w-4 text-gray-300" />;
      case "gold": return <Crown className="h-4 w-4 text-yellow-500" />;
      case "platinum": return <Gem className="h-4 w-4 text-purple-500" />;
      default: return <Store className="h-4 w-4 text-gray-300" />;
    }
  };

  const getAmbassadorLevelColor = (level: string) => {
    switch (level) {
      case "bronze": return "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300";
      case "silver": return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300";
      case "gold": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300";
      case "platinum": return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300";
    }
  };



  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Dispensaries</CardTitle>
            <Store className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalDispensaries || 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.qualifiedDispensaries || 0} with ambassador status
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Visits</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalVisits || 0}</div>
            <p className="text-xs text-muted-foreground">
              Across all dispensaries
            </p>
          </CardContent>
        </Card>



        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Loyalty Points</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.loyaltyPoints || 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.exclusiveRewards || 0} exclusive rewards available
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Current Ambassadorships */}
      {stats?.ambassadorships && stats.ambassadorships.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Crown className="h-5 w-5 text-yellow-500" />
              Your Dispensary Ambassadorships
            </CardTitle>
            <CardDescription>
              Dispensaries where you've achieved ambassador status
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {stats.ambassadorships.map((ambassadorship) => (
                <div key={ambassadorship.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    {getAmbassadorLevelIcon(ambassadorship.ambassadorLevel)}
                    <div>
                      <div className="font-semibold">{ambassadorship.dispensaryName}</div>
                      <div className="text-sm text-muted-foreground flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {ambassadorship.location}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className={getAmbassadorLevelColor(ambassadorship.ambassadorLevel)}>
                      {ambassadorship.ambassadorLevel.toUpperCase()}
                    </Badge>
                    <div className="text-sm text-muted-foreground mt-1">
                      {ambassadorship.totalVisits} visits
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dispensary Consumption */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-green-500" />
            Dispensary Activity
          </CardTitle>
          <CardDescription>
            Your visit history and progress toward ambassador status
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {consumption?.map((dispensary) => (
              <div key={dispensary.dispensaryId} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="font-semibold">{dispensary.dispensaryName}</div>
                    <div className="text-sm text-muted-foreground flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      {dispensary.location}
                    </div>
                  </div>
                  {dispensary.isQualified && dispensary.ambassadorLevel && (
                    <Badge className={getAmbassadorLevelColor(dispensary.ambassadorLevel)}>
                      {dispensary.ambassadorLevel.toUpperCase()} AMBASSADOR
                    </Badge>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground">Visits</div>
                    <div className="font-semibold">{dispensary.totalVisits}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Loyalty Points</div>
                    <div className="font-semibold">{dispensary.loyaltyPoints}</div>
                  </div>
                </div>

                {dispensary.visits.length > 0 && (
                  <div className="mt-3 pt-3 border-t">
                    <div className="text-sm font-medium mb-2">Recent Visits</div>
                    <div className="space-y-2">
                      {dispensary.visits.slice(0, 3).map((visit) => (
                        <div key={visit.id} className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs">
                              {visit.visitType}
                            </Badge>
                            {visit.rating && (
                              <div className="flex items-center gap-1">
                                <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                                <span>{visit.rating}</span>
                              </div>
                            )}
                          </div>
                          <div className="text-muted-foreground">
                            {new Date(visit.visitDate).toLocaleDateString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Near Qualification */}
      {nearQualification && nearQualification.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-blue-500" />
              Almost There!
            </CardTitle>
            <CardDescription>
              Dispensaries where you're close to earning ambassador status
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {nearQualification.map((dispensary) => (
                <div key={dispensary.dispensaryId} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <div className="font-semibold">{dispensary.dispensaryName}</div>
                      <div className="text-sm text-muted-foreground flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {dispensary.location}
                      </div>
                    </div>
                    <Badge variant="outline" className="text-blue-600 border-blue-300">
                      {dispensary.neededForNext?.level?.toUpperCase() || 'NEXT LEVEL'}
                    </Badge>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Progress to {dispensary.neededForNext?.level || 'Next Level'}</span>
                        <span>{Math.round(dispensary.progress)}%</span>
                      </div>
                      <Progress value={dispensary.progress} className="h-2" />
                    </div>

                    <div className="text-sm">
                      <div className="text-muted-foreground">Need {dispensary.neededForNext?.visits || 3} more visits</div>
                      <div className="font-semibold">
                        {dispensary.currentVisits || 0} / {(dispensary.currentVisits || 0) + (dispensary.neededForNext?.visits || 3)} visits
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Available Rewards */}
      {rewards && rewards.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="h-5 w-5 text-purple-500" />
              Exclusive Rewards
            </CardTitle>
            <CardDescription>
              Rewards available through your dispensary ambassador status
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {rewards.map((reward) => (
                <div key={reward.id} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="font-semibold">{reward.title}</div>
                        <Badge className={getAmbassadorLevelColor(reward.requiredLevel)}>
                          {reward.requiredLevel.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground mb-2">{reward.description}</div>
                      <div className="text-sm font-medium text-green-600">
                        {reward.dispensaryName} • {reward.value}
                      </div>
                      {reward.validUntil && (
                        <div className="text-xs text-muted-foreground mt-1">
                          Valid until {new Date(reward.validUntil).toLocaleDateString()}
                        </div>
                      )}
                    </div>
                    <Button size="sm" variant="outline">
                      <ExternalLink className="h-3 w-3 mr-1" />
                      Claim
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* How it Works */}
      <Card>
        <CardHeader>
          <CardTitle>How Dispensary Ambassador Program Works</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 border rounded-lg">
              <Award className="h-8 w-8 text-amber-600 mx-auto mb-2" />
              <div className="font-semibold text-amber-600">Bronze</div>
              <div className="text-sm text-muted-foreground">5+ visits OR $150+ spent</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <Star className="h-8 w-8 text-gray-300 mx-auto mb-2" />
              <div className="font-semibold text-gray-600">Silver</div>
              <div className="text-sm text-muted-foreground">10+ visits OR $350+ spent</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <Crown className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
              <div className="font-semibold text-yellow-600">Gold</div>
              <div className="text-sm text-muted-foreground">20+ visits OR $750+ spent</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <Gem className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <div className="font-semibold text-purple-600">Platinum</div>
              <div className="text-sm text-muted-foreground">50+ visits OR $2000+ spent</div>
            </div>
          </div>

          <div className="prose dark:prose-invert max-w-none">
            <p className="text-sm text-muted-foreground">
              Earn ambassador status by being a loyal customer. Visit frequently, make purchases, and unlock exclusive discounts, 
              early access to new products, VIP consultations, and special limited-edition strains. Each dispensary tracks your 
              activity independently, so you can be an ambassador at multiple locations!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}