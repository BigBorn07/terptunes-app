import { useEffect, useState } from 'react';

interface TerpeneProfile {
  name: string;
  percentage: number;
}

interface MusicMood {
  energy: number;
  mood: string;
  genre: string;
}

interface BackgroundStyle {
  primary: string;
  secondary: string;
  accent: string;
  gradient: string;
  animation: string;
}

// Terpene to color mapping based on their natural characteristics
const TERPENE_COLOR_MAP: Record<string, string> = {
  // Calming terpenes - cool colors
  'Myrcene': '#6B46C1', // Deep purple - sedating
  'Linalool': '#8B5CF6', // Light purple - floral, calming
  'Nerolidol': '#A855F7', // Purple - woody, fresh
  'Terpinolene': '#C084FC', // Soft purple - piney, floral
  
  // Energizing terpenes - warm colors
  'Limonene': '#F59E0B', // Orange - citrusy, uplifting
  'Pinene': '#10B981', // Green - piney, alert
  'Terpinene': '#059669', // Forest green - herbal
  'Ocimene': '#34D399', // Mint green - sweet, herbaceous
  
  // Balancing terpenes - mixed colors
  'Caryophyllene': '#DC2626', // Red - spicy, peppery
  'Humulene': '#B91C1C', // Dark red - earthy, woody
  'Bisabolol': '#3B82F6', // Blue - floral, sweet
  'Camphene': '#1D4ED8', // Deep blue - cooling, camphor
  
  // Unique terpenes
  'Geraniol': '#EC4899', // Pink - rose-like, sweet
  'Eucalyptol': '#06B6D4', // Cyan - minty, cooling
  'Pulegone': '#8B5CF6', // Purple - minty
  'Sabinene': '#F97316', // Orange - spicy, pine
};

// Music mood to color intensity and animation mapping
const MOOD_STYLE_MAP: Record<string, { intensity: number; animation: string }> = {
  'relaxed': { intensity: 0.3, animation: 'gentle-pulse' },
  'uplifting': { intensity: 0.7, animation: 'energetic-wave' },
  'focused': { intensity: 0.5, animation: 'steady-glow' },
  'peaceful': { intensity: 0.2, animation: 'soft-fade' },
  'balanced': { intensity: 0.4, animation: 'harmonious-blend' },
  'euphoric': { intensity: 0.8, animation: 'vibrant-dance' },
  'creative': { intensity: 0.6, animation: 'inspiring-flow' },
  'meditative': { intensity: 0.3, animation: 'zen-breathing' },
};

// Genre to visual style mapping
const GENRE_STYLE_MAP: Record<string, { pattern: string; complexity: number }> = {
  'ambient': { pattern: 'smooth-gradient', complexity: 0.2 },
  'electronic': { pattern: 'geometric-pulse', complexity: 0.8 },
  'jazz': { pattern: 'organic-flow', complexity: 0.6 },
  'classical': { pattern: 'elegant-sweep', complexity: 0.4 },
  'hip-hop': { pattern: 'rhythmic-beat', complexity: 0.7 },
  'rock': { pattern: 'dynamic-edge', complexity: 0.9 },
  'world': { pattern: 'cultural-blend', complexity: 0.5 },
};

export function useDynamicBackground(terpenes?: TerpeneProfile[], musicMood?: MusicMood) {
  const [backgroundStyle, setBackgroundStyle] = useState<BackgroundStyle>({
    primary: '#1F2937',
    secondary: '#111827',
    accent: '#374151',
    gradient: 'linear-gradient(135deg, #1F2937 0%, #111827 100%)',
    animation: 'none'
  });

  useEffect(() => {
    if (!terpenes || terpenes.length === 0) {
      // Default dark theme
      setBackgroundStyle({
        primary: '#1F2937',
        secondary: '#111827',
        accent: '#374151',
        gradient: 'linear-gradient(135deg, #1F2937 0%, #111827 100%)',
        animation: 'none'
      });
      return;
    }

    // Calculate dominant terpene colors based on percentages
    const dominantColors = terpenes
      .filter(t => t.percentage > 0.5) // Only significant terpenes
      .sort((a, b) => b.percentage - a.percentage)
      .slice(0, 3) // Top 3 terpenes
      .map(t => ({
        color: TERPENE_COLOR_MAP[t.name] || '#6B7280',
        weight: t.percentage
      }));

    if (dominantColors.length === 0) {
      dominantColors.push({ color: '#6B7280', weight: 1 });
    }

    // Apply music mood modifications
    const moodStyle = musicMood ? MOOD_STYLE_MAP[musicMood.mood] || MOOD_STYLE_MAP['balanced'] : MOOD_STYLE_MAP['balanced'];
    const genreStyle = musicMood ? GENRE_STYLE_MAP[musicMood.genre] || GENRE_STYLE_MAP['ambient'] : GENRE_STYLE_MAP['ambient'];

    // Calculate energy-based color intensity
    const energyMultiplier = musicMood ? (0.5 + (musicMood.energy * 0.5)) : 0.7;
    const moodIntensity = moodStyle.intensity * energyMultiplier;

    // Create primary color blend
    const primaryColor = dominantColors[0].color;
    const secondaryColor = dominantColors[1]?.color || primaryColor;
    const accentColor = dominantColors[2]?.color || secondaryColor;

    // Adjust colors based on mood intensity
    const adjustedPrimary = adjustColorIntensity(primaryColor, moodIntensity);
    const adjustedSecondary = adjustColorIntensity(secondaryColor, moodIntensity * 0.7);
    const adjustedAccent = adjustColorIntensity(accentColor, moodIntensity * 0.5);

    // Create gradient based on genre complexity
    const gradient = createGradient(adjustedPrimary, adjustedSecondary, adjustedAccent, genreStyle.complexity);

    // Combine animations
    const animation = `${moodStyle.animation} ${genreStyle.pattern}`;

    setBackgroundStyle({
      primary: adjustedPrimary,
      secondary: adjustedSecondary,
      accent: adjustedAccent,
      gradient,
      animation
    });

    // Apply CSS custom properties for global use
    document.documentElement.style.setProperty('--dynamic-bg-primary', adjustedPrimary);
    document.documentElement.style.setProperty('--dynamic-bg-secondary', adjustedSecondary);
    document.documentElement.style.setProperty('--dynamic-bg-accent', adjustedAccent);
    document.documentElement.style.setProperty('--dynamic-bg-gradient', gradient);

  }, [terpenes, musicMood]);

  return backgroundStyle;
}

function adjustColorIntensity(color: string, intensity: number): string {
  // Convert hex to RGB
  const hex = color.replace('#', '');
  const r = parseInt(hex.substr(0, 2), 16);
  const g = parseInt(hex.substr(2, 2), 16);
  const b = parseInt(hex.substr(4, 2), 16);

  // Adjust intensity (0 = very dark, 1 = full brightness)
  const adjustedR = Math.round(r * intensity);
  const adjustedG = Math.round(g * intensity);
  const adjustedB = Math.round(b * intensity);

  // Convert back to hex
  return `#${adjustedR.toString(16).padStart(2, '0')}${adjustedG.toString(16).padStart(2, '0')}${adjustedB.toString(16).padStart(2, '0')}`;
}

function createGradient(primary: string, secondary: string, accent: string, complexity: number): string {
  if (complexity < 0.3) {
    // Simple gradient
    return `linear-gradient(135deg, ${primary} 0%, ${secondary} 100%)`;
  } else if (complexity < 0.6) {
    // Three-color gradient
    return `linear-gradient(135deg, ${primary} 0%, ${secondary} 50%, ${accent} 100%)`;
  } else {
    // Complex radial gradient
    return `radial-gradient(ellipse at center, ${primary} 0%, ${secondary} 40%, ${accent} 70%, ${primary}40 100%)`;
  }
}

export default useDynamicBackground;