import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DispensaryAmbassadorDashboard } from "@/components/DispensaryAmbassadorDashboard";
import { useAuth } from "@/hooks/useAuth";
import { Store, Users, Target, Gift, Star, CheckCircle, ArrowRight, TrendingUp, Award } from "lucide-react";
import { Link } from "wouter";

export default function DispensaryAmbassadorPage() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 dark:bg-gray-700 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="container mx-auto p-6">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <div className="space-y-4">
            <div className="flex justify-center">
              <div className="p-4 bg-gradient-to-br from-green-100 to-blue-100 dark:from-green-900 dark:to-blue-900 rounded-full">
                <Store className="h-12 w-12 text-green-600 dark:text-green-400" />
              </div>
            </div>
            <h1 className="text-4xl font-bold">Dispensary Ambassador Program</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Earn rewards, discounts, and exclusive access by being a loyal customer at your favorite dispensaries
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center">
              <CardHeader>
                <Target className="h-8 w-8 mx-auto text-amber-600" />
                <CardTitle className="text-lg">Visit & Purchase</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Make regular visits and purchases at participating dispensaries
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <TrendingUp className="h-8 w-8 mx-auto text-blue-600" />
                <CardTitle className="text-lg">Build Loyalty</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Accumulate visits and spending to unlock ambassador tiers
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Award className="h-8 w-8 mx-auto text-purple-600" />
                <CardTitle className="text-lg">Earn Status</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Achieve Bronze, Silver, Gold, or Platinum ambassador levels
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Gift className="h-8 w-8 mx-auto text-green-600" />
                <CardTitle className="text-lg">Get Rewards</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Unlock exclusive discounts, early access, and VIP experiences
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Ambassador Benefits</CardTitle>
              <CardDescription>What you'll unlock as a dispensary ambassador</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Exclusive discounts up to 30%</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Early access to new products</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">VIP consultation sessions</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Limited edition strains</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Double loyalty points</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Exclusive dispensary events</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t">
                <Link href="/api/login">
                  <Button size="lg" className="w-full">
                    Sign In to Get Started
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <div className="text-center space-y-4">
            <h2 className="text-2xl font-bold">How It Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              <div className="space-y-2">
                <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-amber-600 font-bold">1</span>
                </div>
                <h3 className="font-semibold">Visit Dispensaries</h3>
                <p className="text-sm text-muted-foreground">Log your visits and purchases at participating dispensaries</p>
              </div>
              <div className="space-y-2">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-blue-600 font-bold">2</span>
                </div>
                <h3 className="font-semibold">Build Loyalty</h3>
                <p className="text-sm text-muted-foreground">Accumulate visits and spending to progress through tiers</p>
              </div>
              <div className="space-y-2">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-purple-600 font-bold">3</span>
                </div>
                <h3 className="font-semibold">Unlock Status</h3>
                <p className="text-sm text-muted-foreground">Achieve ambassador status and unlock exclusive benefits</p>
              </div>
              <div className="space-y-2">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-green-600 font-bold">4</span>
                </div>
                <h3 className="font-semibold">Enjoy Rewards</h3>
                <p className="text-sm text-muted-foreground">Access discounts, events, and exclusive products</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Store className="h-8 w-8 text-green-600" />
              Dispensary Ambassador
            </h1>
            <p className="text-muted-foreground">
              Your loyalty program dashboard for participating dispensaries
            </p>
          </div>
        </div>

        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="about" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Program Info
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <DispensaryAmbassadorDashboard />
          </TabsContent>

          <TabsContent value="about">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Dispensary Ambassador Program</CardTitle>
                  <CardDescription>
                    Build loyalty relationships with dispensaries and unlock exclusive benefits
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-3">How Qualification Works</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base flex items-center gap-2">
                            <Award className="h-4 w-4 text-amber-600" />
                            Bronze Level
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-2">Requirements:</p>
                          <ul className="text-sm space-y-1">
                            <li>• 5+ visits OR $150+ spent</li>
                            <li>• 20% discounts</li>
                            <li>• Loyalty points bonus</li>
                          </ul>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base flex items-center gap-2">
                            <Star className="h-4 w-4 text-gray-300" />
                            Silver Level
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-2">Requirements:</p>
                          <ul className="text-sm space-y-1">
                            <li>• 10+ visits OR $350+ spent</li>
                            <li>• Early product access</li>
                            <li>• Enhanced discounts</li>
                          </ul>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base flex items-center gap-2">
                            <Award className="h-4 w-4 text-yellow-500" />
                            Gold Level
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-2">Requirements:</p>
                          <ul className="text-sm space-y-1">
                            <li>• 20+ visits OR $750+ spent</li>
                            <li>• VIP consultations</li>
                            <li>• Exclusive events</li>
                          </ul>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base flex items-center gap-2">
                            <Award className="h-4 w-4 text-purple-500" />
                            Platinum Level
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground mb-2">Requirements:</p>
                          <ul className="text-sm space-y-1">
                            <li>• 50+ visits OR $2000+ spent</li>
                            <li>• Limited edition strains</li>
                            <li>• Ultimate VIP treatment</li>
                          </ul>
                        </CardContent>
                      </Card>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-3">Benefits by Level</h3>
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="font-medium mb-2">Discounts & Savings</h4>
                          <ul className="text-sm text-muted-foreground space-y-1">
                            <li>• Bronze: 20% off purchases</li>
                            <li>• Silver: 25% off + early access pricing</li>
                            <li>• Gold: 30% off + exclusive discounts</li>
                            <li>• Platinum: Maximum discounts + custom pricing</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-medium mb-2">Exclusive Access</h4>
                          <ul className="text-sm text-muted-foreground space-y-1">
                            <li>• Bronze: Loyalty points program</li>
                            <li>• Silver: Early access to new products</li>
                            <li>• Gold: VIP consultation sessions</li>
                            <li>• Platinum: Limited edition strains</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-3">Participating Dispensaries</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Each dispensary tracks your activity independently, so you can be an ambassador at multiple locations! 
                      Current participating dispensaries include premium Maryland cannabis retailers.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <Badge variant="outline" className="justify-center p-2">Culta (Baltimore)</Badge>
                      <Badge variant="outline" className="justify-center p-2">Remedy Columbia</Badge>
                      <Badge variant="outline" className="justify-center p-2">Zen Leaf (Towson)</Badge>
                      <Badge variant="outline" className="justify-center p-2">Health for Life</Badge>
                      <Badge variant="outline" className="justify-center p-2">Liberty Cannabis</Badge>
                      <Badge variant="outline" className="justify-center p-2">+ More Coming Soon</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}