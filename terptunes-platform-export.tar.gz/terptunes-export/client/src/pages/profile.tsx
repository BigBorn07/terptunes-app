import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { 
  User, 
  Music, 
  Leaf, 
  Heart, 
  Play, 
  Calendar, 
  Award, 
  TrendingUp,
  Plus,
  Settings,
  CheckCircle,
  Clock,
  ExternalLink,
  Trophy
} from "lucide-react";
import { SiSpotify } from "react-icons/si";
import BadgeSystem from "@/components/BadgeSystem";

export default function Profile() {
  const { user, isAuthenticated, isLoading } = useAuth();

  // Safe data handling with type assertions
  const safeUser = user as any || {};
  const safePlaylists = [] as any[];
  const safeSubmissions = { strains: [] } as any;
  const safeLikes = [] as any[];
  const safeSpotifyStatus = { connected: false } as any;

  // Get user's playlists
  const { data: userPlaylists = safePlaylists } = useQuery({
    queryKey: ["/api/playlists"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Get user's strain submissions
  const { data: userSubmissions = safeSubmissions } = useQuery({
    queryKey: ["/api/strains/user-submissions"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Get user's playlist likes
  const { data: userLikes = safeLikes } = useQuery({
    queryKey: ["/api/playlists/likes"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Get Spotify connection status
  const { data: spotifyStatus = safeSpotifyStatus } = useQuery({
    queryKey: ["/api/spotify/status"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Redirect if not authenticated
  if (!isLoading && !isAuthenticated) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="pt-6 text-center">
            <User className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-4">Authentication Required</h2>
            <p className="text-gray-300 mb-6">Please sign in to view your profile and access personalized features.</p>
            <div className="space-y-4">
              <Button 
                onClick={() => window.location.href = "/api/login"}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                Sign In to Continue
              </Button>
              <Link href="/home">
                <Button variant="outline" className="w-full border-gray-600 text-gray-300 hover:bg-gray-800">
                  Back to Home
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading || !user) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="animate-pulse space-y-8">
          <div className="h-32 bg-gray-800 rounded-lg"></div>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="h-64 bg-gray-800 rounded-lg"></div>
            <div className="h-64 bg-gray-800 rounded-lg"></div>
            <div className="h-64 bg-gray-800 rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  const getInitials = (firstName?: string, lastName?: string) => {
    return `${firstName?.[0] || ''}${lastName?.[0] || ''}`.toUpperCase() || 'U';
  };

  const totalPlaylists = Array.isArray(userPlaylists) ? userPlaylists.length : 0;
  const totalStrainSubmissions = userSubmissions?.strains && Array.isArray(userSubmissions.strains) ? userSubmissions.strains.length : 0;
  const totalLikes = Array.isArray(userLikes) ? userLikes.length : 0;
  const verifiedSubmissions = userSubmissions?.strains && Array.isArray(userSubmissions.strains) ? 
    userSubmissions.strains.filter((s: any) => s.isVerified).length : 0;

  const memberSince = safeUser?.createdAt ? new Date(safeUser.createdAt).toLocaleDateString() : 'Unknown';
  const contributorLevel = totalStrainSubmissions >= 10 ? 'Expert' : totalStrainSubmissions >= 5 ? 'Contributor' : totalStrainSubmissions >= 1 ? 'Novice' : 'Member';

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Profile Header */}
      <Card className="bg-gray-900 border-gray-700 mb-8">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-6 items-start">
            <Avatar className="w-24 h-24">
              <AvatarImage src={safeUser?.profileImageUrl} alt={`${safeUser?.firstName || ''} ${safeUser?.lastName || ''}`} />
              <AvatarFallback className="text-2xl bg-green-600">
                {getInitials(safeUser?.firstName, safeUser?.lastName)}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 space-y-4">
              <div>
                <h1 className="text-3xl font-bold text-white">
                  {safeUser?.firstName && safeUser?.lastName ? `${safeUser.firstName} ${safeUser.lastName}` : safeUser?.name || 'TerpTunes User'}
                </h1>
                <p className="text-gray-300">{safeUser?.email}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="outline" className="border-green-600 text-green-400">
                    {contributorLevel} Contributor
                  </Badge>
                  {spotifyStatus?.connected && (
                    <Badge variant="outline" className="border-green-600 text-green-400">
                      <SiSpotify className="w-3 h-3 mr-1" />
                      Connected
                    </Badge>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">{totalPlaylists}</div>
                  <div className="text-sm text-gray-300">Playlists Created</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">{totalStrainSubmissions}</div>
                  <div className="text-sm text-gray-300">Strains Added</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">{totalLikes}</div>
                  <div className="text-sm text-gray-300">Playlists Liked</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">{verifiedSubmissions}</div>
                  <div className="text-sm text-gray-300">Verified Strains</div>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <Button variant="outline" className="border-gray-600 text-white">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
              {!spotifyStatus?.connected && (
                <Link href="/api/spotify/auth">
                  <Button className="bg-green-600 hover:bg-green-700">
                    <SiSpotify className="w-4 h-4 mr-2" />
                    Connect Spotify
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="bg-gray-800 border-gray-700">
          <TabsTrigger value="overview" className="data-[state=active]:bg-gray-700">
            <TrendingUp className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="playlists" className="data-[state=active]:bg-gray-700">
            <Music className="w-4 h-4 mr-2" />
            My Playlists
          </TabsTrigger>
          <TabsTrigger value="strains" className="data-[state=active]:bg-gray-700">
            <Leaf className="w-4 h-4 mr-2" />
            Strain Contributions
          </TabsTrigger>
          <TabsTrigger value="achievements" className="data-[state=active]:bg-gray-700">
            <Trophy className="w-4 h-4 mr-2" />
            Achievements
          </TabsTrigger>
          <TabsTrigger value="ambassadors" className="data-[state=active]:bg-gray-700">
            <Award className="w-4 h-4 mr-2" />
            Ambassador Programs
          </TabsTrigger>
          <TabsTrigger value="activity" className="data-[state=active]:bg-gray-700">
            <Heart className="w-4 h-4 mr-2" />
            Activity
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Quick Stats */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Award className="w-5 h-5 text-yellow-500" />
                  Achievements
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-300">Contributor Level</span>
                    <span className="text-white">{contributorLevel}</span>
                  </div>
                  <Progress 
                    value={Math.min((totalStrainSubmissions / 10) * 100, 100)} 
                    className="h-2"
                  />
                </div>
                
                <div className="space-y-3 text-sm">
                  <div className="flex items-center gap-2">
                    {totalPlaylists >= 1 ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <Clock className="w-4 h-4 text-gray-300" />
                    )}
                    <span className={totalPlaylists >= 1 ? "text-white" : "text-gray-300"}>
                      Created first playlist
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {totalStrainSubmissions >= 1 ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <Clock className="w-4 h-4 text-gray-300" />
                    )}
                    <span className={totalStrainSubmissions >= 1 ? "text-white" : "text-gray-300"}>
                      Added first strain
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {spotifyStatus?.connected ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <Clock className="w-4 h-4 text-gray-300" />
                    )}
                    <span className={spotifyStatus?.connected ? "text-white" : "text-gray-300"}>
                      Connected Spotify
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {verifiedSubmissions >= 1 ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <Clock className="w-4 h-4 text-gray-300" />
                    )}
                    <span className={verifiedSubmissions >= 1 ? "text-white" : "text-gray-300"}>
                      Verified strain contributor
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {userPlaylists && userPlaylists.length > 0 && (
                  <div className="text-sm">
                    <p className="text-gray-300">Latest playlist:</p>
                    <p className="text-white font-medium truncate">{userPlaylists[0].name}</p>
                  </div>
                )}
                
                {userSubmissions?.strains && userSubmissions.strains.length > 0 && (
                  <div className="text-sm">
                    <p className="text-gray-300">Latest strain submission:</p>
                    <p className="text-white font-medium">{userSubmissions.strains[0].name}</p>
                  </div>
                )}
                
                <div className="text-sm">
                  <p className="text-gray-300">Member since:</p>
                  <p className="text-white">{memberSince}</p>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href="/add-strain">
                  <Button className="w-full bg-green-600 hover:bg-green-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add New Strain
                  </Button>
                </Link>
                
                <Link href="/discover">
                  <Button variant="outline" className="w-full border-gray-600 text-white">
                    <Leaf className="w-4 h-4 mr-2" />
                    Discover Strains
                  </Button>
                </Link>
                
                <Link href="/playlists">
                  <Button variant="outline" className="w-full border-gray-600 text-white">
                    <Music className="w-4 h-4 mr-2" />
                    Browse Playlists
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* The Adventures of Mello Maestro */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Leaf className="w-5 h-5 text-green-500" />
                  The Adventures of Mello Maestro
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-gray-300 text-sm">
                  Explore cannabis strain reviews and insights from Mello Maestro
                </p>
                
                <div className="space-y-2">
                  <a 
                    href="https://mellowmaestro.com/reviews/og-kush-analysis" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors group"
                  >
                    <span className="text-white text-sm">OG Kush Deep Dive</span>
                    <ExternalLink className="w-4 h-4 text-gray-300 group-hover:text-green-500" />
                  </a>
                  
                  <a 
                    href="https://mellowmaestro.com/reviews/wedding-cake-review" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors group"
                  >
                    <span className="text-white text-sm">Wedding Cake Review</span>
                    <ExternalLink className="w-4 h-4 text-gray-300 group-hover:text-green-500" />
                  </a>
                  
                  <a 
                    href="https://mellowmaestro.com/reviews/blue-dream-experience" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors group"
                  >
                    <span className="text-white text-sm">Blue Dream Experience</span>
                    <ExternalLink className="w-4 h-4 text-gray-300 group-hover:text-green-500" />
                  </a>
                  
                  <a 
                    href="https://mellowmaestro.com/reviews/gorilla-glue-breakdown" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors group"
                  >
                    <span className="text-white text-sm">Gorilla Glue Breakdown</span>
                    <ExternalLink className="w-4 h-4 text-gray-300 group-hover:text-green-500" />
                  </a>
                  
                  <a 
                    href="https://mellowmaestro.com/reviews/terpene-profiles-guide" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors group"
                  >
                    <span className="text-white text-sm">Terpene Profiles Guide</span>
                    <ExternalLink className="w-4 h-4 text-gray-300 group-hover:text-green-500" />
                  </a>
                </div>
                
                <div className="pt-2 border-t border-gray-700">
                  <a 
                    href="https://mellowmaestro.com/reviews" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-green-500 hover:text-green-400 text-sm font-medium flex items-center gap-1"
                  >
                    View All Reviews
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Playlists Tab */}
        <TabsContent value="playlists" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-white">My Playlists ({totalPlaylists})</h2>
            <Link href="/discover">
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                Create Playlist
              </Button>
            </Link>
          </div>

          {userPlaylists && userPlaylists.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {userPlaylists.map((playlist: any) => (
                <Card key={playlist.id} className="bg-gray-900 border-gray-700">
                  <CardContent className="pt-6">
                    <h3 className="font-semibold text-white mb-2 truncate">{playlist.name}</h3>
                    {playlist.description && (
                      <p className="text-gray-300 text-sm mb-3 line-clamp-2">{playlist.description}</p>
                    )}
                    
                    <div className="flex items-center justify-between text-sm text-gray-300 mb-3">
                      <span>{playlist.trackCount || 0} tracks</span>
                      <span>{playlist.playCount || 0} plays</span>
                    </div>

                    <div className="flex gap-2 mb-3">
                      {playlist.primaryGenre && (
                        <Badge variant="outline" className="text-xs">{playlist.primaryGenre}</Badge>
                      )}
                      {playlist.mood && (
                        <Badge variant="outline" className="text-xs">{playlist.mood}</Badge>
                      )}
                    </div>

                    <div className="flex gap-2">
                      {playlist.spotifyUrl && (
                        <Button size="sm" className="flex-1 bg-green-600 hover:bg-green-700">
                          <Play className="w-3 h-3 mr-1" />
                          Play on Spotify
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="bg-gray-900 border-gray-700">
              <CardContent className="pt-6 text-center">
                <Music className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">No playlists yet</h3>
                <p className="text-gray-300 mb-4">Create your first playlist by generating music from a strain</p>
                <Link href="/discover">
                  <Button className="bg-green-600 hover:bg-green-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Discover Strains
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Strain Contributions Tab */}
        <TabsContent value="strains" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-white">Strain Contributions ({totalStrainSubmissions})</h2>
            <Link href="/add-strain">
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Strain
              </Button>
            </Link>
          </div>

          {userSubmissions?.strains && userSubmissions.strains.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {userSubmissions.strains.map((strain: any) => (
                <Card key={strain.id} className="bg-gray-900 border-gray-700">
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start mb-3">
                      <h3 className="font-semibold text-white">{strain.name}</h3>
                      {strain.isVerified ? (
                        <Badge className="bg-green-600">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Verified
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="border-yellow-600 text-yellow-400">
                          <Clock className="w-3 h-3 mr-1" />
                          Pending
                        </Badge>
                      )}
                    </div>
                    
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Type:</span>
                        <span className="text-white capitalize">{strain.type}</span>
                      </div>
                      
                      {strain.thcContent && (
                        <div className="flex justify-between">
                          <span className="text-gray-300">THC:</span>
                          <span className="text-white">{strain.thcContent}%</span>
                        </div>
                      )}
                      
                      {strain.qualityScore && (
                        <div className="flex justify-between">
                          <span className="text-gray-300">Quality Score:</span>
                          <span className="text-white">{strain.qualityScore}/10</span>
                        </div>
                      )}
                      
                      <div className="flex justify-between">
                        <span className="text-gray-300">Submitted:</span>
                        <span className="text-white">
                          {strain.createdAt ? new Date(strain.createdAt).toLocaleDateString() : 'Unknown'}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="bg-gray-900 border-gray-700">
              <CardContent className="pt-6 text-center">
                <Leaf className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">No strain contributions yet</h3>
                <p className="text-gray-300 mb-4">Help expand our database by adding strains you know</p>
                <Link href="/add-strain">
                  <Button className="bg-green-600 hover:bg-green-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Your First Strain
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Achievements Tab */}
        <TabsContent value="achievements">
          <BadgeSystem />
        </TabsContent>

        {/* Ambassador Programs Tab */}
        <TabsContent value="ambassadors" className="space-y-6">
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-bold text-white flex items-center justify-center gap-3">
                <Award className="w-8 h-8 text-purple-500" />
                Ambassador Programs
              </h2>
              <p className="text-gray-300 max-w-2xl mx-auto">
                Earn loyalty status with your favorite cultivators and dispensaries. 
                Unlock exclusive rewards, early access, and VIP experiences.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              {/* Brand Ambassador Card */}
              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Leaf className="w-5 h-5 text-green-500" />
                    Brand Ambassador
                  </CardTitle>
                  <CardDescription>
                    Loyalty programs with cannabis cultivators and brands
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-300 text-sm">
                    Try 10+ strains from the same cultivator to unlock ambassador status 
                    and exclusive brand rewards.
                  </p>
                  <Link href="/brand-ambassador">
                    <Button className="w-full bg-green-600 hover:bg-green-700">
                      View Brand Ambassador Dashboard
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              {/* Dispensary Ambassador Card */}
              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Award className="w-5 h-5 text-purple-500" />
                    Dispensary Ambassador
                  </CardTitle>
                  <CardDescription>
                    Loyalty programs with local dispensaries
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-300 text-sm">
                    Visit dispensaries frequently to unlock ambassador tiers 
                    and location-specific exclusive rewards.
                  </p>
                  <Link href="/dispensary-ambassador">
                    <Button className="w-full bg-purple-600 hover:bg-purple-700">
                      View Dispensary Ambassador Dashboard
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Activity Tab */}
        <TabsContent value="activity" className="space-y-6">
          <h2 className="text-2xl font-bold text-white">Recent Activity</h2>
          
          <div className="space-y-4">
            {/* Combine recent activities */}
            {userPlaylists?.slice(0, 3).map((playlist: any) => (
              <Card key={`playlist-${playlist.id}`} className="bg-gray-900 border-gray-700">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                      <Music className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="text-white">Created playlist <span className="font-semibold">"{playlist.name}"</span></p>
                      <p className="text-gray-300 text-sm">
                        {playlist.createdAt ? new Date(playlist.createdAt).toLocaleDateString() : 'Recently'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {userSubmissions?.strains?.slice(0, 3).map((strain: any) => (
              <Card key={`strain-${strain.id}`} className="bg-gray-900 border-gray-700">
                <CardContent className="pt-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
                      <Leaf className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="text-white">Added strain <span className="font-semibold">"{strain.name}"</span></p>
                      <p className="text-gray-300 text-sm">
                        {strain.createdAt ? new Date(strain.createdAt).toLocaleDateString() : 'Recently'}
                      </p>
                    </div>
                    {strain.isVerified && (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}

            {(!userPlaylists || userPlaylists.length === 0) && 
             (!userSubmissions?.strains || userSubmissions.strains.length === 0) && (
              <Card className="bg-gray-900 border-gray-700">
                <CardContent className="pt-6 text-center">
                  <Calendar className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">No activity yet</h3>
                  <p className="text-gray-300">Start by creating playlists or adding strains to see your activity here</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}