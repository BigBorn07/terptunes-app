import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/navbar";
import { PlaylistCard } from "@/components/playlist-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Music, 
  TrendingUp, 
  Clock, 
  Play, 
  ExternalLink,
  BarChart3,
  Settings,
  Download,
  Share,
  Heart
} from "lucide-react";
import { Playlist, UserPreferences } from "@/types";
import { formatDistanceToNow } from 'date-fns';

export default function Dashboard() {
  const [selectedTab, setSelectedTab] = useState("playlists");
  
  // Mock user ID - in real app this would come from auth
  const userId = "mock-user-id";

  const { data: playlists, isLoading: playlistsLoading } = useQuery<Playlist[]>({
    queryKey: ["/api/user/playlists", userId],
    queryFn: async () => {
      const response = await fetch(`/api/user/playlists?userId=${userId}`);
      if (!response.ok) throw new Error('Failed to fetch playlists');
      return response.json();
    }
  });

  const { data: preferences, isLoading: preferencesLoading } = useQuery<UserPreferences>({
    queryKey: ["/api/user/preferences", userId],
    queryFn: async () => {
      const response = await fetch(`/api/user/preferences?userId=${userId}`);
      if (!response.ok) throw new Error('Failed to fetch preferences');
      return response.json();
    }
  });

  const handlePlayPlaylist = (playlist: Playlist) => {
    window.open(`https://open.spotify.com/playlist/${playlist.spotifyPlaylistId}`, '_blank');
  };

  const totalPlaylists = playlists?.length || 0;
  const totalTracks = playlists?.reduce((sum, p) => sum + p.trackCount, 0) || 0;
  const totalDuration = playlists?.reduce((sum, p) => sum + p.duration, 0) || 0;
  const avgPlaylistLength = totalPlaylists > 0 ? Math.round(totalDuration / totalPlaylists) : 0;

  // Calculate favorite terpenes from playlists
  const terpeneCount: Record<string, number> = {};
  playlists?.forEach(playlist => {
    playlist.dominantTerpenes.forEach(terpene => {
      terpeneCount[terpene] = (terpeneCount[terpene] || 0) + 1;
    });
  });

  const topTerpenes = Object.entries(terpeneCount)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5)
    .map(([name, count]) => ({ name, count, percentage: Math.round((count / totalPlaylists) * 100) }));

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Navbar />
      
      <main className="pt-20 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-display font-bold text-white mb-4">
              Your Music <span className="text-cannabis-gradient">Laboratory</span>
            </h1>
            <p className="text-xl text-gray-300">
              Track your preferences, save favorite combinations, and discover new musical journeys
            </p>
          </div>

          {/* Stats Overview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card className="glassmorphism">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-400 mb-1">
                  {totalPlaylists}
                </div>
                <div className="text-sm text-gray-300">Playlists Created</div>
              </CardContent>
            </Card>

            <Card className="glassmorphism">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-purple-400 mb-1">
                  {totalTracks}
                </div>
                <div className="text-sm text-gray-300">Total Tracks</div>
              </CardContent>
            </Card>

            <Card className="glassmorphism">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-400 mb-1">
                  {formatDuration(totalDuration)}
                </div>
                <div className="text-sm text-gray-300">Total Duration</div>
              </CardContent>
            </Card>

            <Card className="glassmorphism">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-yellow-400 mb-1">
                  {formatDuration(avgPlaylistLength)}
                </div>
                <div className="text-sm text-gray-300">Avg Length</div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Panel */}
            <div className="lg:col-span-2">
              <Tabs value={selectedTab} onValueChange={setSelectedTab}>
                <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
                  <TabsTrigger value="playlists" className="data-[state=active]:bg-green-600">
                    <Music className="w-4 h-4 mr-2" />
                    Playlists
                  </TabsTrigger>
                  <TabsTrigger value="analytics" className="data-[state=active]:bg-green-600">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Analytics
                  </TabsTrigger>
                  <TabsTrigger value="preferences" className="data-[state=active]:bg-green-600">
                    <Settings className="w-4 h-4 mr-2" />
                    Preferences
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="playlists" className="mt-6">
                  <Card className="glassmorphism">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-white">Your Playlists</CardTitle>
                        <Button variant="outline" size="sm" className="border-green-500 text-green-400">
                          <Download className="w-4 h-4 mr-2" />
                          Export
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {playlistsLoading ? (
                        Array.from({ length: 3 }).map((_, i) => (
                          <div key={i} className="flex items-center space-x-4 p-4">
                            <Skeleton className="w-12 h-12 rounded" />
                            <div className="flex-1">
                              <Skeleton className="h-4 w-3/4 mb-2" />
                              <Skeleton className="h-3 w-1/2" />
                            </div>
                            <Skeleton className="w-20 h-8" />
                          </div>
                        ))
                      ) : playlists && playlists.length > 0 ? (
                        playlists.map((playlist) => (
                          <PlaylistCard
                            key={playlist.id}
                            playlist={playlist}
                            onPlay={handlePlayPlaylist}
                          />
                        ))
                      ) : (
                        <div className="text-center py-8">
                          <Music className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                          <h3 className="text-lg font-semibold text-gray-300 mb-2">No playlists yet</h3>
                          <p className="text-gray-300 mb-4">Start by generating your first playlist from a cannabis strain</p>
                          <Button className="cannabis-gradient">
                            Explore Strains
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="analytics" className="mt-6">
                  <div className="space-y-6">
                    {/* Listening Habits */}
                    <Card className="glassmorphism">
                      <CardHeader>
                        <CardTitle className="text-white">Listening Habits</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-300">Average Session Length</span>
                            <span className="text-white font-semibold">{formatDuration(avgPlaylistLength)}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-300">Most Active Time</span>
                            <span className="text-white font-semibold">Evening (8-10 PM)</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-300">Preferred Playlist Size</span>
                            <span className="text-white font-semibold">{Math.round(totalTracks / Math.max(totalPlaylists, 1))} tracks</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Monthly Activity */}
                    <Card className="glassmorphism">
                      <CardHeader>
                        <CardTitle className="text-white">This Month</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-green-400 mb-1">
                              {playlists?.filter(p => {
                                const created = new Date(p.createdAt);
                                const now = new Date();
                                return created.getMonth() === now.getMonth() && created.getFullYear() === now.getFullYear();
                              }).length || 0}
                            </div>
                            <div className="text-sm text-gray-300">Playlists Created</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-purple-400 mb-1">
                              {topTerpenes.length}
                            </div>
                            <div className="text-sm text-gray-300">Terpenes Explored</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="preferences" className="mt-6">
                  <Card className="glassmorphism">
                    <CardHeader>
                      <CardTitle className="text-white">Music Preferences</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div>
                        <h4 className="text-sm font-medium text-gray-300 mb-3">Preferred Playlist Duration</h4>
                        <div className="flex space-x-2">
                          {[30, 60, 90, 120].map(duration => (
                            <Button 
                              key={duration}
                              variant={preferences?.playlistDuration === duration ? "default" : "outline"}
                              size="sm"
                              className={preferences?.playlistDuration === duration ? "cannabis-gradient" : ""}
                            >
                              {duration}m
                            </Button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium text-gray-300 mb-3">Explicit Content</h4>
                        <div className="flex items-center space-x-2">
                          <input 
                            type="checkbox" 
                            checked={preferences?.explicitContent}
                            className="rounded border-gray-600" 
                          />
                          <span className="text-white text-sm">Allow explicit content in playlists</span>
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium text-gray-300 mb-3">Preferred Genres</h4>
                        <div className="flex flex-wrap gap-2">
                          {['Electronic', 'Hip-Hop', 'Rock', 'Jazz', 'Ambient', 'Classical'].map(genre => (
                            <Badge key={genre} variant="secondary" className="cursor-pointer hover:bg-green-500/20">
                              {genre}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Favorite Terpenes */}
              <Card className="glassmorphism">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Favorite Terpenes</CardTitle>
                </CardHeader>
                <CardContent>
                  {topTerpenes.length > 0 ? (
                    <div className="space-y-3">
                      {topTerpenes.map((terpene, index) => (
                        <div key={terpene.name} className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className={`w-3 h-3 rounded-full ${
                              index === 0 ? 'bg-green-500' :
                              index === 1 ? 'bg-purple-500' :
                              index === 2 ? 'bg-blue-500' :
                              index === 3 ? 'bg-yellow-500' : 'bg-indigo-500'
                            }`}></div>
                            <span className="text-gray-300 capitalize">{terpene.name}</span>
                          </div>
                          <span className="text-sm text-gray-300">{terpene.percentage}%</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-300 text-sm">No terpene preferences yet</p>
                  )}
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="glassmorphism">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full cannabis-gradient text-white">
                    <Music className="w-4 h-4 mr-2" />
                    Create Random Mix
                  </Button>
                  <Button variant="outline" className="w-full border-purple-500 text-purple-400">
                    <Share className="w-4 h-4 mr-2" />
                    Share Profile
                  </Button>
                  <Button variant="outline" className="w-full border-blue-500 text-blue-400">
                    <Settings className="w-4 h-4 mr-2" />
                    Account Settings
                  </Button>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card className="glassmorphism">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  {playlists && playlists.length > 0 ? (
                    <div className="space-y-3">
                      {playlists.slice(0, 3).map((playlist) => (
                        <div key={playlist.id} className="text-sm">
                          <div className="text-white font-medium truncate">{playlist.name}</div>
                          <div className="text-gray-300 text-xs">
                            Created {formatDistanceToNow(new Date(playlist.createdAt))} ago
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-300 text-sm">No recent activity</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
