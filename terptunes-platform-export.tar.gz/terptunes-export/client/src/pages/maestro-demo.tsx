import { useState } from "react";
import { Navbar } from "@/components/navbar";
import MaestroStrainSelector from "@/components/MaestroStrainSelector";
import MaestroPlaylistGenerator from "@/components/MaestroPlaylistGenerator";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Music, Brain, Heart, Zap, ArrowDown } from "lucide-react";
import { useDynamicBackground } from "@/hooks/useDynamicBackground";

export default function MaestroDemo() {
  const [selectedStrain, setSelectedStrain] = useState<any>(null);
  const [currentMusicMood, setCurrentMusicMood] = useState<any>(null);

  // Generate terpene profile data for dynamic background
  const generateTerpeneProfile = (strain: any) => {
    if (!strain) return [];
    
    // Convert strain terpenes to the format expected by useDynamicBackground
    return strain.terpenes?.map((t: any) => ({
      name: t.name,
      percentage: parseFloat(t.percentage) || 1.0
    })) || [];
  };

  // Generate music mood data for dynamic background
  const generateMusicMood = (strain: any) => {
    if (!strain) return null;
    
    const strainType = strain.type?.toLowerCase();
    
    // Map strain characteristics to music mood
    if (strainType === 'indica') {
      return {
        energy: 0.3,
        mood: 'relaxed',
        genre: 'ambient'
      };
    } else if (strainType === 'sativa') {
      return {
        energy: 0.8,
        mood: 'uplifting',
        genre: 'electronic'
      };
    } else {
      return {
        energy: 0.6,
        mood: 'balanced',
        genre: 'jazz'
      };
    }
  };

  const terpeneProfile = generateTerpeneProfile(selectedStrain);
  const musicMood = generateMusicMood(selectedStrain);
  
  // Use dynamic background hook
  const backgroundStyle = useDynamicBackground(terpeneProfile, musicMood || undefined);

  const handleStrainSelected = (strain: any) => {
    setSelectedStrain(strain);
    setCurrentMusicMood(generateMusicMood(strain));
    
    // Smooth scroll to playlist generator
    setTimeout(() => {
      document.getElementById('playlist-generator')?.scrollIntoView({ 
        behavior: 'smooth',
        block: 'center'
      });
    }, 100);
  };

  const getStrainIcon = (type: string) => {
    switch (type) {
      case 'indica': return <Heart className="w-5 h-5 text-purple-400" />;
      case 'sativa': return <Zap className="w-5 h-5 text-green-400" />;
      case 'hybrid': return <Brain className="w-5 h-5 text-blue-400" />;
      default: return <Sparkles className="w-5 h-5 text-gray-300" />;
    }
  };

  // Generate dynamic CSS classes based on current mood and terpenes
  const getDynamicClasses = () => {
    const baseClasses = "min-h-screen text-white dynamic-background";
    
    if (!musicMood) return `${baseClasses} bg-gray-900`;
    
    const moodClass = musicMood.mood ? musicMood.mood.replace('_', '-') : '';
    const genreClass = musicMood.genre ? musicMood.genre.replace('_', '-') : '';
    
    return `${baseClasses} ${moodClass} ${genreClass}`;
  };

  return (
    <div className={getDynamicClasses()}>
      <Navbar />
      
      <main className="container mx-auto px-4 py-8 space-y-8">
        {/* Hero Section */}
        <div className="text-center space-y-4 py-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Sparkles className="w-8 h-8 text-purple-400 animate-pulse" />
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-indigo-400 bg-clip-text text-transparent">
              Mello Maestro Integration
            </h1>
            <Music className="w-8 h-8 text-indigo-400 animate-pulse" />
          </div>
          
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Experience the revolutionary fusion where <span className="text-purple-400 font-semibold">cannabis selection flows through Mello's wisdom</span> and 
            <span className="text-indigo-400 font-semibold"> all playlists are born from Maestro's musical alchemy</span>
          </p>
          
          <div className="flex flex-wrap gap-3 justify-center mt-6">
            <Badge className="bg-purple-600/30 text-purple-200 border-purple-500/30 px-4 py-2">
              🧠 AI-Powered Strain Selection
            </Badge>
            <Badge className="bg-indigo-600/30 text-indigo-200 border-indigo-500/30 px-4 py-2">
              🎵 Terpene-Music Alchemy
            </Badge>
            <Badge className="bg-pink-600/30 text-pink-200 border-pink-500/30 px-4 py-2">
              ✨ Maestro's Magical Touch
            </Badge>
          </div>

          {/* Dynamic Background Status */}
          {selectedStrain && (
            <div className="mt-8 p-4 bg-black/40 backdrop-blur-sm rounded-lg border border-gray-700/50">
              <p className="text-sm text-gray-300 text-center mb-2">🎨 Dynamic Background Active</p>
              <div className="flex flex-wrap justify-center gap-2 text-xs">
                <Badge variant="outline" className="text-emerald-300 border-emerald-500/30">
                  Strain: {selectedStrain.name}
                </Badge>
                <Badge variant="outline" className="text-blue-300 border-blue-500/30">
                  Type: {selectedStrain.type}
                </Badge>
                {musicMood && (
                  <>
                    <Badge variant="outline" className="text-purple-300 border-purple-500/30">
                      Mood: {musicMood.mood}
                    </Badge>
                    <Badge variant="outline" className="text-orange-300 border-orange-500/30">
                      Energy: {Math.round(musicMood.energy * 100)}%
                    </Badge>
                    <Badge variant="outline" className="text-pink-300 border-pink-500/30">
                      Genre: {musicMood.genre}
                    </Badge>
                  </>
                )}
              </div>
              {terpeneProfile.length > 0 && (
                <div className="mt-3">
                  <p className="text-xs text-gray-300 text-center mb-2">Active Terpenes:</p>
                  <div className="flex flex-wrap justify-center gap-1">
                    {terpeneProfile.slice(0, 5).map((terpene, index) => (
                      <Badge key={index} variant="outline" className="text-xs text-cyan-300 border-cyan-500/30">
                        {terpene.name}: {terpene.percentage.toFixed(1)}%
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Flow Explanation */}
        <Card className="bg-gradient-to-r from-gray-900/50 to-black/50 border-gray-700/30">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-gray-100">How the Mello System Works</CardTitle>
            <CardDescription className="text-gray-300">
              Every interaction flows through Maestro's enhanced intelligence
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center space-y-3">
                <div className="w-16 h-16 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-full flex items-center justify-center mx-auto">
                  <Brain className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-indigo-200">1. Mello Strain Selection</h3>
                <p className="text-gray-300 text-sm">
                  Your preferences flow through Maestro's cannabis intelligence, 
                  analyzing mood, energy, and musical taste to divine the perfect strains
                </p>
              </div>
              
              <div className="text-center space-y-3">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-purple-200">2. Maestro's Alchemy</h3>
                <p className="text-gray-300 text-sm">
                  Selected strain's terpene profile gets transformed through Maestro's 
                  special musical algorithm, creating personalized sonic experiences
                </p>
              </div>
              
              <div className="text-center space-y-3">
                <div className="w-16 h-16 bg-gradient-to-br from-pink-600 to-indigo-600 rounded-full flex items-center justify-center mx-auto">
                  <Music className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-pink-200">3. Musical Journey</h3>
                <p className="text-gray-300 text-sm">
                  Every playlist bears Maestro's signature, complete with terpene stories, 
                  musical insights, and the perfect sonic companion to your strain choice
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Step 1: Strain Selection */}
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold">1</div>
            <h2 className="text-2xl font-bold text-indigo-200">Cannabis Selection Through Mello</h2>
          </div>
          <MaestroStrainSelector onStrainSelected={handleStrainSelected} />
        </div>

        {/* Flow Arrow */}
        {selectedStrain && (
          <div className="flex justify-center py-4">
            <div className="flex flex-col items-center space-y-2 text-purple-400">
              <ArrowDown className="w-8 h-8 animate-bounce" />
              <span className="text-sm font-medium">Strain flows to Maestro's playlist alchemy</span>
            </div>
          </div>
        )}

        {/* Step 2: Playlist Generation */}
        {selectedStrain && (
          <div className="space-y-4" id="playlist-generator">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold">2</div>
              <h2 className="text-2xl font-bold text-purple-200">Maestro's Musical Alchemy</h2>
            </div>
            
            {/* Selected Strain Display */}
            <Card className="bg-gradient-to-r from-gray-900/50 to-indigo-900/30 border-indigo-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  {getStrainIcon(selectedStrain.type)}
                  <div>
                    <h3 className="font-semibold text-indigo-100">{selectedStrain.name}</h3>
                    <p className="text-sm text-indigo-300 capitalize">
                      {selectedStrain.type} • {selectedStrain.maestroScore}% Maestro Match
                    </p>
                  </div>
                  <Badge className="ml-auto bg-indigo-600/30 text-indigo-200 border-indigo-500/30">
                    Selected for Maestro's Touch
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <MaestroPlaylistGenerator 
              strainId={selectedStrain.id}
              strainName={selectedStrain.name}
              strainType={selectedStrain.type}
            />
          </div>
        )}

        {/* Integration Benefits */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-indigo-900/30 border-purple-500/30">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-purple-200">Why Maestro Integration Changes Everything</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-purple-200">🧬 Scientific Precision</h3>
                <ul className="space-y-2 text-gray-300 text-sm">
                  <li>• Terpene profiles analyzed with molecular accuracy</li>
                  <li>• Musical frequencies matched to chemical compounds</li>
                  <li>• Personalized experiences based on biochemical harmony</li>
                </ul>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-indigo-200">🎵 Musical Intelligence</h3>
                <ul className="space-y-2 text-gray-300 text-sm">
                  <li>• Every playlist tells your strain's unique story</li>
                  <li>• Musical journeys crafted by AI sommelier</li>
                  <li>• Genre selection based on terpene characteristics</li>
                </ul>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-pink-200">🌟 Maestro's Magic</h3>
                <ul className="space-y-2 text-gray-300 text-sm">
                  <li>• Cannabis wisdom meets musical intuition</li>
                  <li>• Personalized insights for every experience</li>
                  <li>• Continuous learning from user preferences</li>
                </ul>
              </div>
              
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-green-200">🚀 Platform Evolution</h3>
                <ul className="space-y-2 text-gray-300 text-sm">
                  <li>• Revolutionary cannabis-music connection</li>
                  <li>• First AI-powered terpene-playlist matching</li>
                  <li>• Setting new standards for personalized experiences</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Call to Action */}
        {!selectedStrain && (
          <div className="text-center py-8">
            <p className="text-xl text-gray-300 mb-4">
              Ready to experience the future of cannabis-music connection?
            </p>
            <p className="text-purple-400 font-medium">
              ↑ Start by selecting your desired mood and musical preferences above ↑
            </p>
          </div>
        )}
      </main>
    </div>
  );
}