import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { 
  User, 
  Settings,
  Music,
  Heart,
  Star,
  Zap,
  Brain,
  Target,
  Palette,
  Volume2,
  Clock,
  MapPin,
  Save,
  Edit3,
  Headphones,
  Sparkles,
  TrendingUp
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface UserPreferences {
  favoriteStrainTypes: string[];
  favoriteTerpenes: string[];
  preferredEffects: string[];
  thcPreference: { min: number; max: number };
  musicGenres: string[];
  moodStates: string[];
  usageContext: string[];
  playlistDuration: number;
  explicitContent: boolean;
  notifications: {
    newStrains: boolean;
    playlistRecommendations: boolean;
    weeklyInsights: boolean;
  };
}

const availableTerpenes = [
  { name: 'myrcene', color: 'bg-green-500/20 text-green-400', description: 'Relaxing, sedating' },
  { name: 'limonene', color: 'bg-yellow-500/20 text-yellow-400', description: 'Uplifting, energetic' },
  { name: 'pinene', color: 'bg-blue-500/20 text-blue-400', description: 'Focus, alertness' },
  { name: 'linalool', color: 'bg-purple-500/20 text-purple-400', description: 'Calming, anti-anxiety' },
  { name: 'caryophyllene', color: 'bg-orange-500/20 text-orange-400', description: 'Anti-inflammatory' },
  { name: 'terpinolene', color: 'bg-pink-500/20 text-pink-400', description: 'Dreamy, creative' },
  { name: 'humulene', color: 'bg-red-500/20 text-red-400', description: 'Appetite suppressing' },
  { name: 'ocimene', color: 'bg-cyan-500/20 text-cyan-400', description: 'Energizing, uplifting' }
];

const musicGenres = [
  'Electronic', 'Hip-Hop', 'Jazz', 'Rock', 'Ambient', 'Classical', 'R&B', 'Pop',
  'Indie', 'Folk', 'Reggae', 'Blues', 'Funk', 'Soul', 'Country', 'World'
];

const effects = [
  'Relaxed', 'Energetic', 'Creative', 'Focused', 'Happy', 'Euphoric', 
  'Sleepy', 'Uplifted', 'Giggly', 'Talkative', 'Hungry', 'Calm'
];

const contexts = [
  'Morning Routine', 'Work/Study', 'Creative Projects', 'Social Events', 
  'Exercise', 'Meditation', 'Evening Wind-down', 'Weekend Relaxation',
  'Party/Club', 'Outdoor Activities', 'Gaming', 'Reading'
];

export default function UserProfilePage() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("preferences");
  const [isEditing, setIsEditing] = useState(false);

  // Fetch user preferences
  const { data: preferences, isLoading: preferencesLoading } = useQuery({
    queryKey: ['/api/user/preferences'],
    enabled: isAuthenticated,
  });

  // Fetch user stats/history
  const { data: userStats } = useQuery({
    queryKey: ['/api/user/stats'],
    enabled: isAuthenticated,
  });

  // Fetch recent activity
  const { data: recentActivity } = useQuery({
    queryKey: ['/api/user/activity'],
    enabled: isAuthenticated,
  });

  // Update preferences mutation
  const updatePreferencesMutation = useMutation({
    mutationFn: async (data: Partial<UserPreferences>) => {
      return await apiRequest('/api/user/preferences', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user?.id, ...data }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Preferences Updated",
        description: "Your preferences have been saved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/user/preferences'] });
      setIsEditing(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update preferences. Please try again.",
        variant: "destructive",
      });
    },
  });

  const [localPreferences, setLocalPreferences] = useState<Partial<UserPreferences>>({
    favoriteStrainTypes: ['hybrid'],
    favoriteTerpenes: ['myrcene', 'limonene'],
    preferredEffects: ['relaxed', 'creative'],
    thcPreference: { min: 15, max: 25 },
    musicGenres: ['electronic', 'ambient'],
    moodStates: ['relaxed', 'creative'],
    usageContext: ['evening wind-down'],
    playlistDuration: 60,
    explicitContent: false,
    notifications: {
      newStrains: true,
      playlistRecommendations: true,
      weeklyInsights: false,
    },
    ...preferences
  });

  const handleSavePreferences = () => {
    updatePreferencesMutation.mutate(localPreferences);
  };

  const toggleArrayItem = (array: string[], item: string, setter: (value: string[]) => void) => {
    if (array.includes(item)) {
      setter(array.filter(i => i !== item));
    } else {
      setter([...array, item]);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <Card className="w-full max-w-md bg-gray-800/80 border-gray-700">
          <CardHeader className="text-center">
            <User className="w-12 h-12 mx-auto text-green-400 mb-4" />
            <CardTitle className="text-white">Sign In Required</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-gray-300 mb-4">
              Please sign in to view and manage your profile.
            </p>
            <Button onClick={() => window.location.href = '/api/login'} className="cannabis-gradient">
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Profile Header */}
        <div className="glassmorphism rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-20 h-20 rounded-full bg-gradient-to-r from-green-400 to-blue-500 flex items-center justify-center">
                {user?.profileImageUrl ? (
                  <img 
                    src={user.profileImageUrl} 
                    alt="Profile" 
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <User className="w-10 h-10 text-white" />
                )}
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">
                  {user?.firstName || user?.email || 'Cannabis Enthusiast'}
                </h1>
                <p className="text-gray-300">Member since {new Date().getFullYear()}</p>
                <div className="flex items-center space-x-4 mt-2">
                  <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                    <Sparkles className="w-3 h-3 mr-1" />
                    Terpene Explorer
                  </Badge>
                  <Badge variant="secondary" className="bg-purple-500/20 text-purple-400">
                    <Music className="w-3 h-3 mr-1" />
                    Playlist Creator
                  </Badge>
                </div>
              </div>
            </div>
            <Button
              variant={isEditing ? "default" : "outline"}
              onClick={() => setIsEditing(!isEditing)}
              className={isEditing ? "cannabis-gradient" : ""}
            >
              <Edit3 className="w-4 h-4 mr-2" />
              {isEditing ? 'Save Changes' : 'Edit Profile'}
            </Button>
          </div>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800/80">
            <TabsTrigger value="preferences" className="data-[state=active]:bg-green-500/20">
              <Settings className="w-4 h-4 mr-2" />
              Preferences
            </TabsTrigger>
            <TabsTrigger value="activity" className="data-[state=active]:bg-green-500/20">
              <TrendingUp className="w-4 h-4 mr-2" />
              Activity
            </TabsTrigger>
            <TabsTrigger value="recommendations" className="data-[state=active]:bg-green-500/20">
              <Brain className="w-4 h-4 mr-2" />
              Recommendations
            </TabsTrigger>
            <TabsTrigger value="insights" className="data-[state=active]:bg-green-500/20">
              <Target className="w-4 h-4 mr-2" />
              Insights
            </TabsTrigger>
          </TabsList>

          {/* Preferences Tab */}
          <TabsContent value="preferences" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Strain Preferences */}
              <Card className="bg-gray-800/80 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Zap className="w-5 h-5 mr-2 text-green-400" />
                    Strain Preferences
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-gray-300">Favorite Strain Types</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {['indica', 'sativa', 'hybrid'].map((type) => (
                        <Badge
                          key={type}
                          variant="secondary"
                          className={`cursor-pointer transition-all ${
                            localPreferences.favoriteStrainTypes?.includes(type)
                              ? 'bg-green-500/20 text-green-400'
                              : 'hover:bg-gray-600'
                          }`}
                          onClick={() => isEditing && toggleArrayItem(
                            localPreferences.favoriteStrainTypes || [],
                            type,
                            (value) => setLocalPreferences(prev => ({ ...prev, favoriteStrainTypes: value }))
                          )}
                        >
                          {type}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300">THC Preference Range (%)</Label>
                    <div className="mt-2 space-y-2">
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-300 w-12">
                          {localPreferences.thcPreference?.min || 15}%
                        </span>
                        <Slider
                          value={[localPreferences.thcPreference?.min || 15]}
                          onValueChange={([value]) => isEditing && setLocalPreferences(prev => ({
                            ...prev,
                            thcPreference: { ...prev.thcPreference!, min: value }
                          }))}
                          min={0}
                          max={40}
                          step={1}
                          className="flex-1"
                          disabled={!isEditing}
                        />
                        <span className="text-sm text-gray-300 w-12">Min</span>
                      </div>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-300 w-12">
                          {localPreferences.thcPreference?.max || 25}%
                        </span>
                        <Slider
                          value={[localPreferences.thcPreference?.max || 25]}
                          onValueChange={([value]) => isEditing && setLocalPreferences(prev => ({
                            ...prev,
                            thcPreference: { ...prev.thcPreference!, max: value }
                          }))}
                          min={0}
                          max={40}
                          step={1}
                          className="flex-1"
                          disabled={!isEditing}
                        />
                        <span className="text-sm text-gray-300 w-12">Max</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300">Preferred Effects</Label>
                    <div className="flex flex-wrap gap-2 mt-2 max-h-32 overflow-y-auto">
                      {effects.map((effect) => (
                        <Badge
                          key={effect}
                          variant="secondary"
                          className={`cursor-pointer transition-all text-xs ${
                            localPreferences.preferredEffects?.includes(effect.toLowerCase())
                              ? 'bg-blue-500/20 text-blue-400'
                              : 'hover:bg-gray-600'
                          }`}
                          onClick={() => isEditing && toggleArrayItem(
                            localPreferences.preferredEffects || [],
                            effect.toLowerCase(),
                            (value) => setLocalPreferences(prev => ({ ...prev, preferredEffects: value }))
                          )}
                        >
                          {effect}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Music Preferences */}
              <Card className="bg-gray-800/80 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Headphones className="w-5 h-5 mr-2 text-purple-400" />
                    Music Preferences
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-gray-300">Favorite Genres</Label>
                    <div className="flex flex-wrap gap-2 mt-2 max-h-32 overflow-y-auto">
                      {musicGenres.map((genre) => (
                        <Badge
                          key={genre}
                          variant="secondary"
                          className={`cursor-pointer transition-all text-xs ${
                            localPreferences.musicGenres?.includes(genre.toLowerCase())
                              ? 'bg-purple-500/20 text-purple-400'
                              : 'hover:bg-gray-600'
                          }`}
                          onClick={() => isEditing && toggleArrayItem(
                            localPreferences.musicGenres || [],
                            genre.toLowerCase(),
                            (value) => setLocalPreferences(prev => ({ ...prev, musicGenres: value }))
                          )}
                        >
                          {genre}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-gray-300">Playlist Duration (minutes)</Label>
                    <div className="mt-2">
                      <Slider
                        value={[localPreferences.playlistDuration || 60]}
                        onValueChange={([value]) => isEditing && setLocalPreferences(prev => ({ 
                          ...prev, 
                          playlistDuration: value 
                        }))}
                        min={15}
                        max={180}
                        step={15}
                        className="w-full"
                        disabled={!isEditing}
                      />
                      <div className="flex justify-between text-sm text-gray-300 mt-1">
                        <span>15 min</span>
                        <span className="text-white">{localPreferences.playlistDuration || 60} min</span>
                        <span>3 hours</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="text-gray-300">Allow Explicit Content</Label>
                    <Switch
                      checked={localPreferences.explicitContent || false}
                      onCheckedChange={(checked) => isEditing && setLocalPreferences(prev => ({ 
                        ...prev, 
                        explicitContent: checked 
                      }))}
                      disabled={!isEditing}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Terpene Preferences */}
              <Card className="bg-gray-800/80 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Palette className="w-5 h-5 mr-2 text-green-400" />
                    Terpene Preferences
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2">
                    {availableTerpenes.map((terpene) => (
                      <div
                        key={terpene.name}
                        className={`p-3 rounded-lg border cursor-pointer transition-all ${
                          localPreferences.favoriteTerpenes?.includes(terpene.name)
                            ? `${terpene.color} border-current`
                            : 'bg-gray-700/50 border-gray-600 hover:bg-gray-600'
                        }`}
                        onClick={() => isEditing && toggleArrayItem(
                          localPreferences.favoriteTerpenes || [],
                          terpene.name,
                          (value) => setLocalPreferences(prev => ({ ...prev, favoriteTerpenes: value }))
                        )}
                      >
                        <div className="font-medium text-sm">{terpene.name}</div>
                        <div className="text-xs text-gray-300">{terpene.description}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Usage Context */}
              <Card className="bg-gray-800/80 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Clock className="w-5 h-5 mr-2 text-blue-400" />
                    Usage Context
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {contexts.map((context) => (
                      <Badge
                        key={context}
                        variant="secondary"
                        className={`cursor-pointer transition-all text-xs ${
                          localPreferences.usageContext?.includes(context.toLowerCase())
                            ? 'bg-blue-500/20 text-blue-400'
                            : 'hover:bg-gray-600'
                        }`}
                        onClick={() => isEditing && toggleArrayItem(
                          localPreferences.usageContext || [],
                          context.toLowerCase(),
                          (value) => setLocalPreferences(prev => ({ ...prev, usageContext: value }))
                        )}
                      >
                        {context}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {isEditing && (
              <div className="flex justify-end space-x-4">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setIsEditing(false);
                    setLocalPreferences({ ...preferences });
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleSavePreferences} 
                  disabled={updatePreferencesMutation.isPending}
                  className="cannabis-gradient"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {updatePreferencesMutation.isPending ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            )}
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gray-800/80 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-300 text-sm">Strains Discovered</p>
                      <p className="text-2xl font-bold text-white">{userStats?.strainsDiscovered || 47}</p>
                    </div>
                    <Zap className="w-8 h-8 text-green-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/80 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-300 text-sm">Playlists Created</p>
                      <p className="text-2xl font-bold text-white">{userStats?.playlistsCreated || 23}</p>
                    </div>
                    <Music className="w-8 h-8 text-purple-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/80 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-300 text-sm">Total Listening Time</p>
                      <p className="text-2xl font-bold text-white">{userStats?.totalListeningHours || 127}h</p>
                    </div>
                    <Volume2 className="w-8 h-8 text-blue-400" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/80 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-300 text-sm">Favorite Terpene</p>
                      <p className="text-2xl font-bold text-white">{userStats?.favoriteTerpene || 'Myrcene'}</p>
                    </div>
                    <Star className="w-8 h-8 text-yellow-400" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity Feed */}
            <Card className="bg-gray-800/80 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {(recentActivity || [
                    { type: 'strain_discovery', strain: 'Purple Punch', time: '2 hours ago' },
                    { type: 'playlist_created', playlist: 'Chill Vibes Mix', time: '1 day ago' },
                    { type: 'recommendation_liked', strain: 'Blue Dream', time: '2 days ago' },
                    { type: 'strain_discovery', strain: 'Wedding Cake', time: '3 days ago' },
                  ]).map((activity: any, index: number) => (
                    <div key={index} className="flex items-center space-x-3 p-3 rounded-lg bg-gray-700/50">
                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-white text-sm">
                          {activity.type === 'strain_discovery' && `Discovered ${activity.strain}`}
                          {activity.type === 'playlist_created' && `Created playlist "${activity.playlist}"`}
                          {activity.type === 'recommendation_liked' && `Liked recommendation for ${activity.strain}`}
                        </p>
                        <p className="text-gray-300 text-xs">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Recommendations Tab */}
          <TabsContent value="recommendations">
            <Card className="bg-gray-800/80 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-green-400" />
                  Personalized Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 text-center py-8">
                  Personalized recommendations will appear here based on your preferences and activity.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Insights Tab */}
          <TabsContent value="insights">
            <Card className="bg-gray-800/80 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Target className="w-5 h-5 mr-2 text-blue-400" />
                  Personal Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 text-center py-8">
                  Personal insights and analytics will be available here soon.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}