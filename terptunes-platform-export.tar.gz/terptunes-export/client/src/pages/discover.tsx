import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/navbar";
import { StrainCard } from "@/components/strain-card";
import { SearchFilters } from "@/components/search-filters";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { 
  Loader2, 
  Filter, 
  SortAsc, 
  Grid3X3, 
  List,
  Leaf,
  TrendingUp
} from "lucide-react";
import { Strain, StrainSearchParams, StrainSearchResult } from "@/types";

export default function Discover() {
  const { toast } = useToast();
  const [searchParams, setSearchParams] = useState<StrainSearchParams>({
    query: '',
    type: undefined,
    effects: [],
    terpenes: [],
    minThc: undefined,
    maxThc: undefined,
    limit: 20,
    offset: 0
  });
  
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isGeneratingPlaylist, setIsGeneratingPlaylist] = useState<string | null>(null);

  // Build query key for search
  const queryKey = [
    "/api/strains",
    searchParams.query,
    searchParams.type,
    searchParams.effects?.join(','),
    searchParams.terpenes?.join(','),
    searchParams.minThc,
    searchParams.maxThc,
    searchParams.limit,
    searchParams.offset
  ].filter(Boolean);

  const { 
    data: searchResult, 
    isLoading, 
    refetch,
    isFetching,
    error 
  } = useQuery<StrainSearchResult>({
    queryKey,
    queryFn: async () => {
      const params = new URLSearchParams();
      
      if (searchParams.query) params.append('query', searchParams.query);
      if (searchParams.type) params.append('type', searchParams.type);
      if (searchParams.effects?.length) params.append('effects', searchParams.effects.join(','));
      if (searchParams.terpenes?.length) params.append('terpenes', searchParams.terpenes.join(','));
      if (searchParams.minThc) params.append('minThc', searchParams.minThc.toString());
      if (searchParams.maxThc) params.append('maxThc', searchParams.maxThc.toString());
      if (searchParams.limit) params.append('limit', searchParams.limit.toString());
      if (searchParams.offset) params.append('offset', searchParams.offset.toString());

      const response = await fetch(`/api/strains?${params}`);
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to search strains: ${response.status} - ${errorText}`);
      }
      const data = await response.json();
      console.log('API Response:', data); // Debug log
      return data;
    },
    retry: 3,
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
  });

  const { data: popularStrains } = useQuery<Strain[]>({
    queryKey: ["/api/strains/popular"],
    staleTime: 10 * 60 * 1000, // Cache for 10 minutes
  });

  const handleSearchParamsChange = (newParams: StrainSearchParams) => {
    setSearchParams(newParams);
  };

  const handleSearch = () => {
    refetch();
  };

  const handleLoadMore = () => {
    setSearchParams(prev => ({
      ...prev,
      offset: (prev.offset || 0) + (prev.limit || 20)
    }));
  };

  const handleGeneratePlaylist = async (strain: Strain) => {
    setIsGeneratingPlaylist(strain.name);
    
    try {
      // This would integrate with Spotify API
      toast({
        title: "Playlist Generation",
        description: `Creating playlist for ${strain.name}...`,
      });

      // Simulate playlist generation
      setTimeout(() => {
        setIsGeneratingPlaylist(null);
        toast({
          title: "Success!",
          description: `Playlist "${strain.name} Vibes" created in your Spotify account.`,
        });
      }, 2000);
    } catch (error) {
      setIsGeneratingPlaylist(null);
      toast({
        title: "Error",
        description: "Failed to generate playlist. Please try again.",
        variant: "destructive",
      });
    }
  };

  const strains = searchResult?.strains || [];
  const hasResults = strains.length > 0;
  const hasMore = searchResult?.hasMore || false;

  // Debug logging
  console.log('Search Result:', searchResult);
  console.log('Strains:', strains);
  console.log('Has Results:', hasResults);
  console.log('Error:', error);

  // Show error state
  if (error) {
    console.error('Strain loading error:', error);
    toast({
      title: "Error Loading Strains",
      description: error.message || "Failed to load strain data",
      variant: "destructive",
    });
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Navbar />
      
      <main className="pt-20 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-display font-bold text-white mb-4">
              Discover <span className="text-cannabis-gradient">Cannabis Strains</span>
            </h1>
            <p className="text-xl text-gray-300">
              Explore 731+ lab-tested cannabis strains and their unique musical personalities
            </p>
          </div>

          {/* Search and Filters */}
          <div className="mb-8">
            <SearchFilters
              searchParams={searchParams}
              onSearchParamsChange={handleSearchParamsChange}
              onSearch={handleSearch}
              isLoading={isFetching}
            />
          </div>

          {/* Results Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <h2 className="text-xl font-semibold text-white">
                {isLoading ? (
                  <Skeleton className="h-6 w-32" />
                ) : hasResults ? (
                  `${searchResult?.total || 0} strains found`
                ) : searchParams.query || searchParams.type || searchParams.effects?.length || searchParams.terpenes?.length ? (
                  "No strains found"
                ) : (
                  "Popular strains"
                )}
              </h2>
              
              {isFetching && (
                <Loader2 className="w-5 h-5 animate-spin text-green-400" />
              )}
            </div>

            <div className="flex items-center space-x-2">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className={viewMode === 'grid' ? 'cannabis-gradient' : ''}
              >
                <Grid3X3 className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className={viewMode === 'list' ? 'cannabis-gradient' : ''}
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Results Grid */}
          {isLoading ? (
            <div className={`grid ${viewMode === 'grid' ? 'md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'} gap-6`}>
              {Array.from({ length: 8 }).map((_, i) => (
                <Card key={i} className="glassmorphism">
                  <CardContent className="p-6">
                    <Skeleton className="h-32 w-full mb-4" />
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-4" />
                    <div className="space-y-2 mb-4">
                      <Skeleton className="h-3 w-full" />
                      <Skeleton className="h-3 w-full" />
                      <Skeleton className="h-3 w-3/4" />
                    </div>
                    <Skeleton className="h-10 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : hasResults ? (
            <>
              <div className={`grid ${viewMode === 'grid' ? 'md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'} gap-6 mb-8`}>
                {strains.map((strain: Strain) => (
                  <StrainCard
                    key={strain.name}
                    strain={strain}
                    onGeneratePlaylist={handleGeneratePlaylist}
                    isGenerating={isGeneratingPlaylist === strain.name}
                  />
                ))}
              </div>
              
              {hasMore && (
                <div className="text-center">
                  <Button 
                    onClick={handleLoadMore}
                    disabled={isFetching}
                    variant="outline"
                    className="border-green-500 text-green-400 hover:bg-green-500/10"
                  >
                    {isFetching ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Loading...
                      </>
                    ) : (
                      "Load More Strains"
                    )}
                  </Button>
                </div>
              )}
            </>
          ) : searchParams.query || searchParams.type || searchParams.effects?.length || searchParams.terpenes?.length ? (
            // No results for search
            <div className="text-center py-12">
              <Leaf className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-300 mb-2">No strains found</h3>
              <p className="text-gray-300 mb-6">Try adjusting your search criteria or filters</p>
              <Button 
                onClick={() => {
                  setSearchParams({
                    query: '',
                    type: undefined,
                    effects: [],
                    terpenes: [],
                    minThc: undefined,
                    maxThc: undefined,
                    limit: 20,
                    offset: 0
                  });
                }}
                variant="outline"
                className="border-green-500 text-green-400 hover:bg-green-500/10"
              >
                Clear Filters
              </Button>
            </div>
          ) : (
            // Show popular strains when no search
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {(popularStrains || []).map((strain: Strain) => (
                <StrainCard
                  key={strain.name}
                  strain={strain}
                  onGeneratePlaylist={handleGeneratePlaylist}
                  isGenerating={isGeneratingPlaylist === strain.name}
                />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
