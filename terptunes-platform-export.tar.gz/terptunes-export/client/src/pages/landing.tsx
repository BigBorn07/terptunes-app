import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Navbar } from "@/components/navbar";
import { TerpeneChart } from "@/components/terpene-chart";
import { 
  Search, 
  Music, 
  Brain, 
  Database, 
  Smartphone,
  TrendingUp,
  Users,
  Leaf,
  Play,
  CheckCircle,
  ExternalLink
} from "lucide-react";
import { Link } from "wouter";

export default function Landing() {
  const sampleStrain = {
    name: "OG Kush",
    type: "hybrid" as const,
    thcContent: "22.5",
    cbdContent: "0.3",
    description: "A legendary hybrid strain with balanced effects and complex terpene profile",
    effects: ["balanced", "euphoric", "relaxing"],
    flavors: ["earthy", "pine", "citrus"],
    terpenes: [
      { name: "myrcene", percentage: 0.8 },
      { name: "limonene", percentage: 0.6 },
      { name: "pinene", percentage: 0.4 }
    ]
  };

  const features = [
    {
      icon: <Brain className="w-6 h-6" />,
      title: "AI-Powered Matching",
      description: "Machine learning algorithms continuously improve terpene-to-music correlations",
      color: "from-green-500 to-green-600"
    },
    {
      icon: <Database className="w-6 h-6" />,
      title: "Professional Database",
      description: "Access 731+ lab-tested cannabis strains with authentic terpene profiles",
      color: "from-purple-500 to-purple-600"
    },
    {
      icon: <Music className="w-6 h-6" />,
      title: "Seamless Integration",
      description: "Direct Spotify integration with instant playlist creation",
      color: "from-green-500 to-green-600"
    },
    {
      icon: <Smartphone className="w-6 h-6" />,
      title: "Progressive Web App",
      description: "Mobile-optimized experience with offline functionality",
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: <TrendingUp className="w-6 h-6" />,
      title: "Advanced Analytics",
      description: "Comprehensive insights into your listening patterns and preferences",
      color: "from-yellow-500 to-yellow-600"
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Business Accounts",
      description: "Cultivator dashboards for cannabis producers and dispensaries",
      color: "from-indigo-500 to-indigo-600"
    }
  ];

  const terpeneExamples = [
    {
      name: "Myrcene",
      effects: "Sedating, relaxing effects",
      music: "Ambient, Chill, Downtempo",
      icon: "🛌",
      color: "from-green-400 to-green-500"
    },
    {
      name: "Limonene",
      effects: "Uplifting, mood-boosting",
      music: "Upbeat, Pop, Electronic",
      icon: "😊",
      color: "from-purple-400 to-purple-500"
    },
    {
      name: "Pinene",
      effects: "Alertness, focus",
      music: "Instrumental, Focus, Study",
      icon: "👁️",
      color: "from-blue-400 to-blue-500"
    },
    {
      name: "Linalool",
      effects: "Calming, anti-anxiety",
      music: "Meditation, Spa, Relaxing",
      icon: "🧘",
      color: "from-indigo-400 to-indigo-500"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-white" itemScope itemType="https://schema.org/WebApplication">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-20 pb-20 overflow-hidden hero-bg">
        {/* Floating elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-green-500/20 rounded-full blur-xl floating-element"></div>
        <div className="absolute top-40 right-20 w-32 h-32 bg-purple-500/20 rounded-full blur-xl floating-element-delayed"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-5xl lg:text-6xl font-display font-bold leading-tight" itemProp="headline">
                  <span className="text-cannabis-gradient">
                    AI-Powered Cannabis Terpene
                  </span>
                  <br />
                  <span className="text-white">Music Matching Platform</span>
                </h1>
                <p className="text-xl text-gray-200 max-w-lg" itemProp="description">
                  Revolutionary AI technology generates personalized Spotify playlists using scientific analysis of cannabis terpene profiles. Lab-verified strain database with precision terpene chemistry data creates perfect music experiences tailored to your cannabis choice.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="cannabis-gradient text-white font-semibold">
                  <Search className="w-5 h-5 mr-3" />
                  Explore 731+ Lab-Tested Strains
                </Button>
                <Link href="/watch-demo">
                  <Button size="lg" variant="outline" className="border-purple-500 text-purple-400 hover:bg-purple-500/10">
                    <Play className="w-5 h-5 mr-3" />
                    Watch Demo
                  </Button>
                </Link>
              </div>

              <div className="flex items-center space-x-8 text-sm text-gray-300" itemScope itemType="https://schema.org/Dataset">
                <div className="flex items-center space-x-2" itemProp="keywords">
                  <Database className="w-4 h-4 text-green-400" />
                  <span itemProp="description">731+ Lab-Verified Cannabis Strains</span>
                </div>
                <div className="flex items-center space-x-2" itemProp="keywords">
                  <Leaf className="w-4 h-4 text-purple-400" />
                  <span itemProp="description">3,140+ Scientific Terpene Profiles</span>
                </div>
                <div className="flex items-center space-x-2" itemProp="keywords">
                  <Music className="w-4 h-4 text-green-400" />
                  <span itemProp="description">AI Spotify Music Integration</span>
                </div>
              </div>
            </div>

            <div className="relative">
              {/* Main interface mockup */}
              <Card className="glassmorphism">
                <CardContent className="p-6">
                  {/* Search bar */}
                  <div className="mb-6">
                    <div className="relative">
                      <Input 
                        placeholder="Search strains by name, effects, or terpenes..." 
                        className="pl-12 bg-gray-900/50 border-gray-600 text-white placeholder-gray-300"
                      />
                      <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-300 w-4 h-4" />
                    </div>
                  </div>

                  {/* Strain card */}
                  <Card className="strain-card mb-4">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-semibold text-lg text-white">{sampleStrain.name}</h3>
                          <p className="text-green-400 text-sm">
                            {sampleStrain.type.charAt(0).toUpperCase() + sampleStrain.type.slice(1)} • THC: {sampleStrain.thcContent}%
                          </p>
                        </div>
                        <Button size="sm" className="purple-gradient text-white">
                          <Music className="w-3 h-3 mr-1" />
                          Generate
                        </Button>
                      </div>
                      
                      <TerpeneChart terpenes={sampleStrain.terpenes} />
                    </CardContent>
                  </Card>

                  {/* Playlist preview */}
                  <Card className="bg-gradient-to-r from-green-900/30 to-green-800/30 border-green-700/50">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="w-10 h-10 bg-green-500 rounded flex items-center justify-center">
                          <Music className="text-white w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-medium text-white">OG Kush Vibes</h4>
                          <p className="text-sm text-gray-300">32 tracks • 2h 14m</p>
                        </div>
                      </div>
                      <div className="text-xs text-green-400 flex items-center">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Playlist created in your Spotify
                      </div>
                    </CardContent>
                  </Card>
                </CardContent>
              </Card>

              {/* Floating music notes */}
              <div className="absolute -top-4 -right-4 w-8 h-8 bg-purple-500/30 rounded-full flex items-center justify-center floating-element">
                <Music className="text-purple-400 w-4 h-4" />
              </div>
              <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-green-500/30 rounded-full flex items-center justify-center floating-element-delayed">
                <Leaf className="text-green-400 w-3 h-3" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="science" className="py-20 bg-gradient-to-b from-gray-950 to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-display font-bold text-white mb-4" itemProp="headline">
              Advanced <span className="text-cannabis-gradient">AI Cannabis Science</span> Technology Platform
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto" itemProp="description">
              Revolutionary machine learning algorithms analyze molecular terpene structures, psychoactive compound interactions, and neuroacoustic research to generate scientifically-optimized Spotify playlists that enhance your cannabis experience through precision music curation.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="text-center group">
              <div className="w-16 h-16 cannabis-gradient rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-200">
                <Search className="text-white w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2" itemProp="name">1. AI-Powered Cannabis Strain Analysis</h3>
              <p className="text-gray-300" itemProp="description">Comprehensive database of 731+ lab-verified cannabis strains with scientific terpene profiling, THC/CBD analysis, and documented effects for precision cannabis selection.</p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 purple-gradient rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-200">
                <Brain className="text-white w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2" itemProp="name">2. Scientific Terpene-to-Music AI Mapping</h3>
              <p className="text-gray-300" itemProp="description">Advanced machine learning algorithms analyze terpene molecular structures and documented psychoactive effects, connecting them to musical characteristics through psychoacoustic research and neuroscience principles.</p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-200">
                <Music className="text-white w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2" itemProp="name">3. Personalized Spotify Playlist Generation</h3>
              <p className="text-gray-300" itemProp="description">Automated Spotify playlist creation powered by AI algorithms that match terpene profiles to musical genres, tempos, and moods. Playlists are instantly delivered to your Spotify account with scientifically-backed music curation.</p>
            </div>
          </div>

          {/* Terpene mapping examples */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {terpeneExamples.map((terpene, index) => (
              <Card key={index} className="glassmorphism hover:border-green-500/50 transition-colors group" itemScope itemType="https://schema.org/ChemicalSubstance">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4 group-hover:bg-green-500/30 transition-colors">
                    <span className="text-2xl">{terpene.icon}</span>
                  </div>
                  <h4 className="font-semibold text-white mb-2" itemProp="name">{terpene.name} Terpene</h4>
                  <p className="text-sm text-gray-300 mb-3" itemProp="description">Psychoactive Effects: {terpene.effects}</p>
                  <div className="text-xs text-green-400" itemProp="applicationCategory">AI Music Match → {terpene.music}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-display font-bold text-white mb-4">
              Advanced <span className="text-cannabis-gradient">Features</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Powered by machine learning and scientific research to deliver the perfect cannabis-music experience
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="glassmorphism hover:border-green-500/50 transition-colors group">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 bg-gradient-to-r ${feature.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-200`}>
                    {feature.icon}
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                  <p className="text-gray-300 text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-b from-gray-950 to-gray-900 relative overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-40 h-40 bg-green-500/10 rounded-full blur-3xl floating-element"></div>
          <div className="absolute bottom-20 right-20 w-60 h-60 bg-purple-500/10 rounded-full blur-3xl floating-element-delayed"></div>
        </div>

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl lg:text-5xl font-display font-bold text-white mb-6">
            Ready to <span className="text-cannabis-gradient">Elevate</span> Your Experience?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands of cannabis enthusiasts who've discovered the perfect soundtrack to their sessions. Connect your Spotify and start exploring today.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Button size="lg" className="cannabis-gradient text-white font-semibold">
              <Music className="w-5 h-5 mr-3" />
              Connect Spotify Free
            </Button>
            <Button size="lg" variant="outline" className="border-purple-500 text-purple-400 hover:bg-purple-500/10">
              <Play className="w-5 h-5 mr-3" />
              Watch Demo
            </Button>
          </div>

          <div className="text-sm text-gray-300 space-y-2">
            <p>✓ Free to use • ✓ No credit card required • ✓ 30-second setup</p>
            <p>🔒 Your Spotify data is never stored or shared</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 cannabis-gradient rounded-lg flex items-center justify-center">
                  <Leaf className="text-white w-4 h-4" />
                </div>
                <span className="text-xl font-display font-bold text-cannabis-gradient">TerpTunes</span>
              </div>
              <p className="text-gray-300 text-sm">The world's first cannabis-music connection platform, powered by science.</p>
              <div className="flex space-x-4">
                <Button variant="ghost" size="sm" className="text-gray-300 hover:text-green-400">
                  <ExternalLink className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-green-400 transition-colors">How It Works</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Strain Database</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Music Science</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">API Access</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Business</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-green-400 transition-colors">Cultivator Dashboard</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Dispensary Integration</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Partnership Program</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">White Label</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-green-400 transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Contact Us</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-300 text-sm">© 2024 TerpTunes. All rights reserved.</p>
            <p className="text-gray-300 text-sm mt-2 md:mt-0">
              🌿 Responsible consumption • 🎵 Music for wellness • 🔬 Science-backed experiences
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
