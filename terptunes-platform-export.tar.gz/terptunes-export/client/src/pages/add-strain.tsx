import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle, Info, Plus, X } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface StrainSubmission {
  name: string;
  type: 'indica' | 'sativa' | 'hybrid';
  thcContent?: string;
  cbdContent?: string;
  description?: string;
  effects?: string[];
  flavors?: string[];
  brand?: string;
  grower?: string;
  providedTerpenes?: Array<{ name: string; percentage: number }>;
}

interface ValidationResult {
  isValid: boolean;
  isDuplicate: boolean;
  duplicateId?: number;
  duplicateName?: string;
  similarityScore?: number;
  suggestions?: string[];
  issues: string[];
  needsReview?: boolean;
}

export default function AddStrain() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState<StrainSubmission>({
    name: '',
    type: 'hybrid',
    thcContent: '',
    cbdContent: '',
    description: '',
    effects: [],
    flavors: [],
    brand: '',
    grower: '',
    providedTerpenes: []
  });
  
  const [newEffect, setNewEffect] = useState('');
  const [newFlavor, setNewFlavor] = useState('');
  const [newTerpene, setNewTerpene] = useState({ name: '', percentage: 0 });
  const [validation, setValidation] = useState<ValidationResult | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Redirect if not authenticated
  if (!isLoading && !isAuthenticated) {
    setTimeout(() => {
      window.location.href = "/api/login";
    }, 500);
    return null;
  }

  // Validate strain as user types
  const validateMutation = useMutation({
    mutationFn: async (data: StrainSubmission) => {
      return await apiRequest("/api/strains/validate", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: (data) => {
      setValidation(data);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      console.error("Validation error:", error);
    },
  });

  // Submit strain
  const submitMutation = useMutation({
    mutationFn: async (data: StrainSubmission) => {
      return await apiRequest("/api/strains/submit", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Strain Submitted Successfully!",
        description: `${data.strain.name} has been added to the database with ${data.terpeneProfile.source} terpene profile.`,
      });
      
      // Reset form
      setFormData({
        name: '',
        type: 'hybrid',
        thcContent: '',
        cbdContent: '',
        description: '',
        effects: [],
        flavors: [],
        providedTerpenes: []
      });
      setValidation(null);
      
      // Invalidate strains cache
      queryClient.invalidateQueries({ queryKey: ["/api/strains"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      const errorMessage = error.message || "Failed to submit strain";
      toast({
        title: "Submission Failed",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  // Get user's previous submissions
  const { data: userSubmissions } = useQuery({
    queryKey: ["/api/strains/user-submissions"],
    retry: false,
  });

  const handleInputChange = (field: keyof StrainSubmission, value: any) => {
    const newData = { ...formData, [field]: value };
    setFormData(newData);
    
    // Validate if name is provided and at least 2 characters
    if (newData.name && newData.name.length >= 2) {
      validateMutation.mutate(newData);
    }
  };

  const addEffect = () => {
    if (newEffect.trim() && !formData.effects?.includes(newEffect.trim())) {
      handleInputChange('effects', [...(formData.effects || []), newEffect.trim()]);
      setNewEffect('');
    }
  };

  const removeEffect = (effect: string) => {
    handleInputChange('effects', formData.effects?.filter(e => e !== effect) || []);
  };

  const addFlavor = () => {
    if (newFlavor.trim() && !formData.flavors?.includes(newFlavor.trim())) {
      handleInputChange('flavors', [...(formData.flavors || []), newFlavor.trim()]);
      setNewFlavor('');
    }
  };

  const removeFlavor = (flavor: string) => {
    handleInputChange('flavors', formData.flavors?.filter(f => f !== flavor) || []);
  };

  const addTerpene = () => {
    if (newTerpene.name.trim() && newTerpene.percentage > 0) {
      const existing = formData.providedTerpenes?.find(t => t.name === newTerpene.name.trim());
      if (!existing) {
        handleInputChange('providedTerpenes', [
          ...(formData.providedTerpenes || []),
          { name: newTerpene.name.trim(), percentage: newTerpene.percentage }
        ]);
        setNewTerpene({ name: '', percentage: 0 });
      }
    }
  };

  const removeTerpene = (terpeneName: string) => {
    handleInputChange('providedTerpenes', 
      formData.providedTerpenes?.filter(t => t.name !== terpeneName) || []
    );
  };

  const canSubmit = validation?.isValid && !validation?.isDuplicate && formData.name.length >= 2;

  const commonEffects = [
    'relaxing', 'energizing', 'uplifting', 'focused', 'creative', 'happy', 
    'sleepy', 'euphoric', 'calming', 'social', 'pain-relief', 'stress-relief'
  ];

  const commonFlavors = [
    'citrus', 'pine', 'sweet', 'earthy', 'floral', 'spicy', 'diesel', 
    'berry', 'mint', 'vanilla', 'chocolate', 'sour', 'tropical'
  ];

  const commonTerpenes = [
    'Myrcene', 'Limonene', 'Caryophyllene', 'Linalool', 'Pinene', 
    'Terpinolene', 'Humulene', 'Ocimene', 'Geraniol', 'Eucalyptol'
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Add New Strain</h1>
        <p className="text-gray-300">
          Contribute to our cannabis database by adding strains not yet in our collection. 
          We'll validate for duplicates and generate terpene profiles if needed.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Main Form */}
        <div className="md:col-span-2 space-y-6">
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Basic Information</CardTitle>
              <CardDescription>Required details about the strain</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name" className="text-white">Strain Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="e.g., Blue Dream, OG Kush"
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="type" className="text-white">Strain Type *</Label>
                <Select value={formData.type} onValueChange={(value) => handleInputChange('type', value)}>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="indica">Indica</SelectItem>
                    <SelectItem value="sativa">Sativa</SelectItem>
                    <SelectItem value="hybrid">Hybrid</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="brand" className="text-white">Brand/Cultivator</Label>
                  <Input
                    id="brand"
                    value={formData.brand || ''}
                    onChange={(e) => handleInputChange('brand', e.target.value)}
                    placeholder="e.g., Cookies, Jungle Boys"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="grower" className="text-white">Specific Grower</Label>
                  <Input
                    id="grower"
                    value={formData.grower || ''}
                    onChange={(e) => handleInputChange('grower', e.target.value)}
                    placeholder="e.g., Specific farm name"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="thc" className="text-white">THC Content (%)</Label>
                  <Input
                    id="thc"
                    value={formData.thcContent}
                    onChange={(e) => handleInputChange('thcContent', e.target.value)}
                    placeholder="e.g., 18.5"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="cbd" className="text-white">CBD Content (%)</Label>
                  <Input
                    id="cbd"
                    value={formData.cbdContent}
                    onChange={(e) => handleInputChange('cbdContent', e.target.value)}
                    placeholder="e.g., 0.8"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description" className="text-white">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="Describe the strain's characteristics, growth patterns, or notable features..."
                  className="bg-gray-800 border-gray-600 text-white"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Effects Section */}
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Effects</CardTitle>
              <CardDescription>What effects does this strain typically produce?</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  value={newEffect}
                  onChange={(e) => setNewEffect(e.target.value)}
                  placeholder="Add effect"
                  className="bg-gray-800 border-gray-600 text-white"
                  onKeyPress={(e) => e.key === 'Enter' && addEffect()}
                />
                <Button onClick={addEffect} size="sm">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {commonEffects.map(effect => (
                  <Badge
                    key={effect}
                    variant={formData.effects?.includes(effect) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => {
                      if (formData.effects?.includes(effect)) {
                        removeEffect(effect);
                      } else {
                        handleInputChange('effects', [...(formData.effects || []), effect]);
                      }
                    }}
                  >
                    {effect}
                  </Badge>
                ))}
              </div>

              {formData.effects && formData.effects.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {formData.effects.map(effect => (
                    <Badge key={effect} className="bg-green-600">
                      {effect}
                      <X 
                        className="w-3 h-3 ml-1 cursor-pointer" 
                        onClick={() => removeEffect(effect)}
                      />
                    </Badge>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Flavors Section */}
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Flavors</CardTitle>
              <CardDescription>What flavors or aromas are present in this strain?</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  value={newFlavor}
                  onChange={(e) => setNewFlavor(e.target.value)}
                  placeholder="Add flavor"
                  className="bg-gray-800 border-gray-600 text-white"
                  onKeyPress={(e) => e.key === 'Enter' && addFlavor()}
                />
                <Button onClick={addFlavor} size="sm">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {commonFlavors.map(flavor => (
                  <Badge
                    key={flavor}
                    variant={formData.flavors?.includes(flavor) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => {
                      if (formData.flavors?.includes(flavor)) {
                        removeFlavor(flavor);
                      } else {
                        handleInputChange('flavors', [...(formData.flavors || []), flavor]);
                      }
                    }}
                  >
                    {flavor}
                  </Badge>
                ))}
              </div>

              {formData.flavors && formData.flavors.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {formData.flavors.map(flavor => (
                    <Badge key={flavor} className="bg-blue-600">
                      {flavor}
                      <X 
                        className="w-3 h-3 ml-1 cursor-pointer" 
                        onClick={() => removeFlavor(flavor)}
                      />
                    </Badge>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Advanced Terpene Section */}
          {showAdvanced && (
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Terpene Profile (Optional)</CardTitle>
                <CardDescription>
                  If you have lab test results, you can provide specific terpene percentages. 
                  Otherwise, we'll generate an intelligent profile based on strain characteristics.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  <Select value={newTerpene.name} onValueChange={(value) => setNewTerpene({...newTerpene, name: value})}>
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select terpene" />
                    </SelectTrigger>
                    <SelectContent>
                      {commonTerpenes.map(terpene => (
                        <SelectItem key={terpene} value={terpene}>{terpene}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      max="5"
                      value={newTerpene.percentage}
                      onChange={(e) => setNewTerpene({...newTerpene, percentage: parseFloat(e.target.value) || 0})}
                      placeholder="% (e.g., 0.8)"
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                    <Button onClick={addTerpene} size="sm">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {formData.providedTerpenes && formData.providedTerpenes.length > 0 && (
                  <div className="space-y-2">
                    {formData.providedTerpenes.map(terpene => (
                      <div key={terpene.name} className="flex justify-between items-center bg-gray-800 p-2 rounded">
                        <span className="text-white">{terpene.name}: {terpene.percentage}%</span>
                        <X 
                          className="w-4 h-4 cursor-pointer text-red-400" 
                          onClick={() => removeTerpene(terpene.name)}
                        />
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          <div className="flex gap-4">
            <Button
              onClick={() => setShowAdvanced(!showAdvanced)}
              variant="outline"
              className="border-gray-600 text-white"
            >
              {showAdvanced ? 'Hide' : 'Show'} Advanced Options
            </Button>
            
            <Button
              onClick={() => submitMutation.mutate(formData)}
              disabled={!canSubmit || submitMutation.isPending}
              className="bg-green-600 hover:bg-green-700"
            >
              {submitMutation.isPending ? 'Submitting...' : 'Submit Strain'}
            </Button>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Validation Status */}
          {validation && (
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  {validation.isValid && !validation.isDuplicate ? (
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-yellow-500" />
                  )}
                  Validation Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {validation.isDuplicate && (
                  <Alert className="border-red-600">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      Strain "{validation.duplicateName}" already exists in our database.
                    </AlertDescription>
                  </Alert>
                )}

                {validation.suggestions && validation.suggestions.length > 0 && (
                  <Alert className="border-yellow-600">
                    <Info className="h-4 w-4" />
                    <AlertDescription>
                      Similar strains found: {validation.suggestions.join(', ')}. 
                      Consider if this is the same strain with a different name.
                    </AlertDescription>
                  </Alert>
                )}

                {validation.issues.length > 0 && (
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-white">Issues to fix:</p>
                    {validation.issues.map((issue, index) => (
                      <p key={index} className="text-sm text-red-400">• {issue}</p>
                    ))}
                  </div>
                )}

                {validation.isValid && !validation.isDuplicate && (
                  <Alert className="border-green-600">
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription>
                      Strain validation passed! Ready to submit.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          )}

          {/* Data Quality Info */}
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Data Quality</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-gray-300">
              <div className="space-y-2">
                <p><strong>Duplicate Prevention:</strong> We check for exact name matches and similar strain names using fuzzy matching.</p>
                <p><strong>Terpene Profiles:</strong> If you don't provide lab data, we generate intelligent profiles based on strain type and similar strains in our database.</p>
                <p><strong>Quality Scoring:</strong> User submissions start with a 5.0/10 quality score and can be verified by our team.</p>
                <p><strong>Data Sources:</strong> We prioritize lab-tested data from professional sources, followed by user submissions.</p>
              </div>
            </CardContent>
          </Card>

          {/* Previous Submissions */}
          {userSubmissions?.strains && userSubmissions.strains.length > 0 && (
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Your Submissions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {userSubmissions.strains.slice(0, 5).map((strain: any) => (
                  <div key={strain.id} className="text-sm">
                    <p className="text-white font-medium">{strain.name}</p>
                    <p className="text-gray-300 capitalize">{strain.type} • {strain.isVerified ? 'Verified' : 'Pending Review'}</p>
                  </div>
                ))}
                {userSubmissions.strains.length > 5 && (
                  <p className="text-gray-300 text-xs">+{userSubmissions.strains.length - 5} more submissions</p>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}