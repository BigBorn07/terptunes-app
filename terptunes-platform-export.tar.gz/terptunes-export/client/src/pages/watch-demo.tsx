import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Play, Pause, Volume2, SkipBack, SkipForward, Download, Share2, ExternalLink } from 'lucide-react';
// import { Progress } from '@/components/ui/progress';

interface DemoVideo {
  id: string;
  title: string;
  description: string;
  duration: string;
  thumbnail: string;
  category: 'platform-overview' | 'strain-discovery' | 'music-generation' | 'b2b-features' | 'user-features';
  features: string[];
  videoUrl: string;
}

const demoVideos: DemoVideo[] = [
  {
    id: 'platform-overview',
    title: 'TerpTunes Platform Overview',
    description: 'Complete walkthrough of the revolutionary cannabis-music matching platform',
    duration: '4:32',
    thumbnail: '/demo-videos/platform-overview-thumb.jpg',
    category: 'platform-overview',
    features: ['Platform Navigation', 'Key Features Tour', 'Value Proposition', 'Getting Started'],
    videoUrl: '/demo-videos/platform-overview.mp4'
  },
  {
    id: 'strain-discovery',
    title: 'Advanced Strain Discovery System',
    description: 'Explore our comprehensive strain database with lab-verified terpene profiles',
    duration: '3:45',
    thumbnail: '/demo-videos/strain-discovery-thumb.jpg',
    category: 'strain-discovery',
    features: ['Search & Filtering', 'Terpene Analysis', 'Lab Data Integration', 'Strain Recommendations'],
    videoUrl: '/demo-videos/strain-discovery.mp4'
  },
  {
    id: 'music-generation',
    title: 'Terpene-to-Music Playlist Generation',
    description: 'Watch how cannabis terpene profiles create personalized Spotify playlists',
    duration: '5:18',
    thumbnail: '/demo-videos/music-generation-thumb.jpg',
    category: 'music-generation',
    features: ['Spotify Integration', 'Terpene Mapping', 'Playlist Creation', 'Music Science'],
    videoUrl: '/demo-videos/music-generation.mp4'
  },
  {
    id: 'grower-portal',
    title: 'Grower B2B Portal Demo',
    description: 'Cannabis cultivator dashboard for strain uploads and playlist curation',
    duration: '4:12',
    thumbnail: '/demo-videos/grower-portal-thumb.jpg',
    category: 'b2b-features',
    features: ['Strain Management', 'Curated Playlists', 'Analytics Dashboard', 'Partnership Tools'],
    videoUrl: '/demo-videos/grower-portal.mp4'
  },
  {
    id: 'dispensary-portal',
    title: 'Dispensary Ambassador Program',
    description: 'Loyalty programs and promotional campaigns for dispensary partners',
    duration: '3:28',
    thumbnail: '/demo-videos/dispensary-portal-thumb.jpg',
    category: 'b2b-features',
    features: ['Loyalty Tracking', 'Promotional Campaigns', 'Customer Analytics', 'Rewards System'],
    videoUrl: '/demo-videos/dispensary-portal.mp4'
  },
  {
    id: 'recommendation-engine',
    title: 'AI Recommendation Engine',
    description: 'Machine learning algorithms for personalized strain and music suggestions',
    duration: '4:55',
    thumbnail: '/demo-videos/ai-recommendations-thumb.jpg',
    category: 'user-features',
    features: ['ML Algorithms', 'User Preferences', 'Personalization', 'Advanced Analytics'],
    videoUrl: '/demo-videos/ai-recommendations.mp4'
  },
  {
    id: 'social-features',
    title: 'Community & Social Features',
    description: 'Reviews, ratings, and social interactions within the TerpTunes community',
    duration: '3:33',
    thumbnail: '/demo-videos/social-features-thumb.jpg',
    category: 'user-features',
    features: ['Strain Reviews', 'Community Ratings', 'Social Sharing', 'User Profiles'],
    videoUrl: '/demo-videos/social-features.mp4'
  }
];

export default function WatchDemo() {
  const [selectedVideo, setSelectedVideo] = useState<DemoVideo>(demoVideos[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Videos', count: demoVideos.length },
    { id: 'platform-overview', label: 'Platform Overview', count: 1 },
    { id: 'strain-discovery', label: 'Strain Discovery', count: 1 },
    { id: 'music-generation', label: 'Music Generation', count: 1 },
    { id: 'b2b-features', label: 'B2B Features', count: 2 },
    { id: 'user-features', label: 'User Features', count: 2 }
  ];

  const filteredVideos = selectedCategory === 'all' 
    ? demoVideos 
    : demoVideos.filter(video => video.category === selectedCategory);

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const getDurationInSeconds = (duration: string) => {
    const [minutes, seconds] = duration.split(':').map(Number);
    return minutes * 60 + seconds;
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-purple-950 to-gray-900">
      {/* Header */}
      <div className="border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-4xl font-bold text-white mb-2">
            TerpTunes Demo Videos
          </h1>
          <p className="text-gray-300 text-lg">
            Explore the revolutionary cannabis-music connection platform through comprehensive video demonstrations
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Video Player */}
          <div className="lg:col-span-2">
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-0">
                {/* Video Player Container */}
                <div className="relative aspect-video bg-black rounded-t-lg overflow-hidden">
                  {/* Video Thumbnail/Player */}
                  <div 
                    className="w-full h-full bg-gradient-to-br from-purple-900 to-blue-900 flex items-center justify-center cursor-pointer"
                    onClick={togglePlayPause}
                  >
                    <div className="text-center">
                      <div className="w-20 h-20 bg-purple-600 rounded-full flex items-center justify-center mb-4 mx-auto hover:bg-purple-500 transition-colors">
                        {isPlaying ? (
                          <Pause className="w-8 h-8 text-white" />
                        ) : (
                          <Play className="w-8 h-8 text-white ml-1" />
                        )}
                      </div>
                      <p className="text-white text-lg">{selectedVideo.title}</p>
                      <p className="text-gray-300 text-sm">Click to {isPlaying ? 'pause' : 'play'}</p>
                    </div>
                  </div>

                  {/* Video Controls Overlay */}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                    {/* Progress Bar */}
                    <div className="mb-3">
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div 
                          className="bg-purple-500 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${(currentTime / getDurationInSeconds(selectedVideo.duration)) * 100}%` }}
                        />
                      </div>
                    </div>

                    {/* Control Buttons */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Button size="sm" variant="ghost" className="text-white hover:bg-white/20">
                          <SkipBack className="w-4 h-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="text-white hover:bg-white/20"
                          onClick={togglePlayPause}
                        >
                          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        </Button>
                        <Button size="sm" variant="ghost" className="text-white hover:bg-white/20">
                          <SkipForward className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" className="text-white hover:bg-white/20">
                          <Volume2 className="w-4 h-4" />
                        </Button>
                        <span className="text-white text-sm">
                          {formatTime(currentTime)} / {selectedVideo.duration}
                        </span>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Button size="sm" variant="ghost" className="text-white hover:bg-white/20">
                          <Download className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" className="text-white hover:bg-white/20">
                          <Share2 className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" className="text-white hover:bg-white/20">
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Video Information */}
                <div className="p-6">
                  <h2 className="text-2xl font-bold text-white mb-2">{selectedVideo.title}</h2>
                  <p className="text-gray-300 mb-4">{selectedVideo.description}</p>
                  
                  {/* Features Covered */}
                  <div className="mb-4">
                    <h3 className="text-lg font-semibold text-white mb-2">Features Covered:</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedVideo.features.map((feature, index) => (
                        <Badge key={index} variant="secondary" className="bg-purple-600 text-white">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Video Library Sidebar */}
          <div className="space-y-6">
            {/* Category Filter */}
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Video Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                        selectedCategory === category.id
                          ? 'bg-purple-600 text-white'
                          : 'text-gray-300 hover:bg-gray-800'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span>{category.label}</span>
                        <Badge variant="outline" className="border-gray-600 text-gray-300">
                          {category.count}
                        </Badge>
                      </div>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Video List */}
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">All Demo Videos</CardTitle>
                <CardDescription className="text-gray-300">
                  {filteredVideos.length} videos available
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {filteredVideos.map((video) => (
                    <div
                      key={video.id}
                      onClick={() => setSelectedVideo(video)}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedVideo.id === video.id
                          ? 'bg-purple-600 text-white'
                          : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-1">
                        <h4 className="font-medium text-sm">{video.title}</h4>
                        <span className="text-xs opacity-75">{video.duration}</span>
                      </div>
                      <p className="text-xs opacity-75 leading-relaxed">
                        {video.description}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Call to Action */}
            <Card className="bg-gradient-to-br from-purple-900 to-blue-900 border-purple-600">
              <CardContent className="p-6 text-center">
                <h3 className="text-xl font-bold text-white mb-2">
                  Ready to Experience TerpTunes?
                </h3>
                <p className="text-purple-100 mb-4 text-sm">
                  Join the revolutionary cannabis-music platform today
                </p>
                <Button className="w-full bg-white text-purple-900 hover:bg-purple-100">
                  Start Free Trial
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Additional Information */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Play className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Video Quality</h3>
              <p className="text-gray-300 text-sm">
                All demos recorded in 4K with professional narration and clear feature explanations
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Download className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Download Available</h3>
              <p className="text-gray-300 text-sm">
                Download demo videos for offline viewing or presentation purposes
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-800">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Share2 className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Easy Sharing</h3>
              <p className="text-gray-300 text-sm">
                Share specific demo videos with stakeholders and potential partners
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}