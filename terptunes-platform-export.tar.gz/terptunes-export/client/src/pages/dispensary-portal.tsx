import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Store, 
  BarChart3, 
  Users, 
  TrendingUp,
  MapPin,
  Eye,
  Target,
  Globe,
  Award,
  Clock,
  Leaf,
  Music
} from "lucide-react";
import ProtectedRoute from "@/components/ProtectedRoute";

function DispensaryPortalContent() {
  const [activeTab, setActiveTab] = useState("dashboard");

  // Fetch TerpTunes analytics for this dispensary
  const { data: terptunesAnalytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ["/api/dispensary/terptunes-analytics"],
    refetchInterval: 30000,
  });

  // Fetch user visit patterns from TerpTunes
  const { data: userVisits, isLoading: visitsLoading } = useQuery({
    queryKey: ["/api/dispensary/user-visits"],
  });

  // Fetch strain-based referrals
  const { data: strainReferrals, isLoading: referralsLoading } = useQuery({
    queryKey: ["/api/dispensary/strain-referrals"],
  });

  // Fetch user journey analytics
  const { data: userJourney, isLoading: journeyLoading } = useQuery({
    queryKey: ["/api/dispensary/user-journey"],
  });

  // Fetch TerpTunes integration status
  const { data: integrationStatus, isLoading: integrationLoading } = useQuery({
    queryKey: ["/api/dispensary/integration-status"],
  });

  if (analyticsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-black">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500 mx-auto"></div>
          <p className="text-white mt-4">Loading TerpTunes Analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-black text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Store className="w-8 h-8 text-blue-400" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Dispensary Portal
            </h1>
          </div>
          <p className="text-xl text-gray-300">Create promotions via playlists and drive business to your storefront</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-blue-600">
              <BarChart3 className="w-4 h-4 mr-2" />
              TerpTunes Analytics
            </TabsTrigger>
            <TabsTrigger value="user-visits" className="data-[state=active]:bg-blue-600">
              <Users className="w-4 h-4 mr-2" />
              User Visits
            </TabsTrigger>
            <TabsTrigger value="strain-referrals" className="data-[state=active]:bg-blue-600">
              <Leaf className="w-4 h-4 mr-2" />
              Strain Referrals
            </TabsTrigger>
            <TabsTrigger value="user-journey" className="data-[state=active]:bg-blue-600">
              <MapPin className="w-4 h-4 mr-2" />
              User Journey
            </TabsTrigger>
            <TabsTrigger value="integration" className="data-[state=active]:bg-blue-600">
              <Globe className="w-4 h-4 mr-2" />
              TerpTunes Integration
            </TabsTrigger>
            <TabsTrigger value="promotional-playlists" className="data-[state=active]:bg-blue-600">
              <Music className="w-4 h-4 mr-2" />
              Promotional Playlists
            </TabsTrigger>
          </TabsList>

          {/* TerpTunes Analytics Dashboard */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-300">TerpTunes Referrals</CardTitle>
                  <Users className="h-4 w-4 text-blue-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{terptunesAnalytics?.monthlyReferrals || 1247}</div>
                  <p className="text-xs text-gray-300">+23.5% from last month</p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-300">Conversion Rate</CardTitle>
                  <Target className="h-4 w-4 text-green-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{terptunesAnalytics?.conversionRate || "68%"}</div>
                  <p className="text-xs text-gray-300">TerpTunes users who visit</p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-300">Weekly Visits</CardTitle>
                  <Eye className="h-4 w-4 text-purple-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{terptunesAnalytics?.weeklyVisits || 412}</div>
                  <p className="text-xs text-gray-300">From TerpTunes recommendations</p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-300">Top Strain Requests</CardTitle>
                  <Leaf className="h-4 w-4 text-green-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{terptunesAnalytics?.topStrainRequests || 89}</div>
                  <p className="text-xs text-gray-300">Purple Punch this week</p>
                </CardContent>
              </Card>
            </div>

            {/* TerpTunes Impact Chart */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <TrendingUp className="w-5 h-5 text-blue-400" />
                  TerpTunes Referral Trends
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Week 1</span>
                    <div className="flex items-center gap-2">
                      <Progress value={75} className="w-32" />
                      <span className="text-sm text-white">318 visits</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Week 2</span>
                    <div className="flex items-center gap-2">
                      <Progress value={85} className="w-32" />
                      <span className="text-sm text-white">367 visits</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Week 3</span>
                    <div className="flex items-center gap-2">
                      <Progress value={92} className="w-32" />
                      <span className="text-sm text-white">389 visits</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Week 4</span>
                    <div className="flex items-center gap-2">
                      <Progress value={100} className="w-32" />
                      <span className="text-sm text-white">412 visits</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Visits Analytics */}
          <TabsContent value="user-visits" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Users className="w-5 h-5 text-blue-400" />
                  TerpTunes User Visit Patterns
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {userVisits?.visitPatterns?.map((pattern: any, index: number) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-900 rounded-lg">
                    <div>
                      <h4 className="font-medium text-white">{pattern.timeSlot}</h4>
                      <p className="text-sm text-gray-300">{pattern.description}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-blue-400">{pattern.visits}</div>
                      <div className="text-sm text-gray-300">visits</div>
                    </div>
                  </div>
                )) || [
                  {
                    timeSlot: "Morning (9AM-12PM)",
                    description: "Early strain researchers",
                    visits: 87
                  },
                  {
                    timeSlot: "Afternoon (12PM-5PM)",
                    description: "Lunch break browsers",
                    visits: 156
                  },
                  {
                    timeSlot: "Evening (5PM-8PM)",
                    description: "Post-work playlist users",
                    visits: 198
                  },
                  {
                    timeSlot: "Night (8PM+)",
                    description: "Evening enthusiasts",
                    visits: 143
                  }
                ].map((pattern, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-900 rounded-lg">
                    <div>
                      <h4 className="font-medium text-white">{pattern.timeSlot}</h4>
                      <p className="text-sm text-gray-300">{pattern.description}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-blue-400">{pattern.visits}</div>
                      <div className="text-sm text-gray-300">visits</div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Strain Referrals */}
          <TabsContent value="strain-referrals" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Leaf className="w-5 h-5 text-green-400" />
                  Most Requested Strains from TerpTunes
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {strainReferrals?.topStrains?.map((strain: any, index: number) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-900 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      <div>
                        <h4 className="font-medium text-white">{strain.name}</h4>
                        <p className="text-sm text-gray-300">{strain.type} • {strain.thc} THC</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-green-400">{strain.requests}</div>
                      <div className="text-sm text-gray-300">requests</div>
                    </div>
                  </div>
                )) || [
                  {
                    name: "Purple Punch",
                    type: "Indica",
                    thc: "22%",
                    requests: 89
                  },
                  {
                    name: "Blue Dream",
                    type: "Sativa",
                    thc: "19%",
                    requests: 67
                  },
                  {
                    name: "Wedding Cake",
                    type: "Hybrid",
                    thc: "25%",
                    requests: 54
                  },
                  {
                    name: "Gorilla Glue #4",
                    type: "Hybrid",
                    thc: "24%",
                    requests: 42
                  }
                ].map((strain, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-900 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      <div>
                        <h4 className="font-medium text-white">{strain.name}</h4>
                        <p className="text-sm text-gray-300">{strain.type} • {strain.thc} THC</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-green-400">{strain.requests}</div>
                      <div className="text-sm text-gray-300">requests</div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Journey */}
          <TabsContent value="user-journey" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <MapPin className="w-5 h-5 text-purple-400" />
                  TerpTunes User Journey to Your Dispensary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                      <Music className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white">Playlist Generation</h4>
                      <p className="text-sm text-gray-300">User creates terpene-based playlist</p>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-blue-400">2,847</div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                      <Leaf className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white">Strain Discovery</h4>
                      <p className="text-sm text-gray-300">User explores strain details</p>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-green-400">1,937</div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                      <MapPin className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white">Dispensary Lookup</h4>
                      <p className="text-sm text-gray-300">User searches for local dispensaries</p>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-purple-400">1,247</div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center">
                      <Store className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white">Dispensary Visit</h4>
                      <p className="text-sm text-gray-300">User visits your dispensary</p>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-orange-400">847</div>
                </div>

                <div className="mt-6 p-4 bg-blue-900/30 rounded-lg border border-blue-700">
                  <h4 className="font-medium text-blue-300 mb-2">Conversion Funnel</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Playlist → Strain Discovery</span>
                      <span className="text-green-400">68% conversion</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Strain → Dispensary Lookup</span>
                      <span className="text-blue-400">64% conversion</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Lookup → Visit</span>
                      <span className="text-purple-400">68% conversion</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* TerpTunes Integration */}
          <TabsContent value="integration" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Globe className="w-5 h-5 text-blue-400" />
                  TerpTunes Integration Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-green-900/30 rounded-lg border border-green-700">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                    <div>
                      <h4 className="font-medium text-white">Integration Active</h4>
                      <p className="text-sm text-gray-300">Your dispensary appears in TerpTunes recommendations</p>
                    </div>
                  </div>
                  <Badge className="bg-green-600 text-white">LIVE</Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-900 rounded-lg">
                    <h4 className="font-medium text-white mb-2">Monthly Impressions</h4>
                    <div className="text-2xl font-bold text-blue-400">84,789</div>
                    <p className="text-sm text-gray-300">Times your dispensary was shown</p>
                  </div>
                  <div className="p-4 bg-gray-900 rounded-lg">
                    <h4 className="font-medium text-white mb-2">Click-through Rate</h4>
                    <div className="text-2xl font-bold text-green-400">12.8%</div>
                    <p className="text-sm text-gray-300">Users who clicked your listing</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium text-white">Integration Benefits</h4>
                  <div className="space-y-2">
                    {[
                      "Enhanced Customer Discovery",
                      "Strain-based Recommendations", 
                      "Music-driven Traffic",
                      "Analytics & Insights",
                      "Premium Placement"
                    ].map((benefit, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Award className="w-4 h-4 text-blue-400" />
                        <span className="text-gray-300">{benefit}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Promotional Playlists */}
          <TabsContent value="promotional-playlists" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Music className="w-5 h-5 text-purple-400" />
                  TerpTunes Promotional Playlists
                </CardTitle>
                <p className="text-gray-300 mt-2">Use these curated playlists to drive traffic to your dispensary through social media and in-store promotions</p>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  {
                    name: "Happy Hour Vibes",
                    description: "Perfect for evening promotions and social hours",
                    strains: ["Blue Dream", "Green Crack", "Durban Poison"],
                    tracks: 28,
                    spotifyUrl: "https://open.spotify.com/playlist/37i9dQZF1DXdXlbRAWwOJy",
                    mood: "Energetic & Social",
                    bestFor: "Evening events, social promotions"
                  },
                  {
                    name: "Chill Sessions",
                    description: "Relaxing playlist for indica promotions",
                    strains: ["Purple Punch", "Granddaddy Purple", "Northern Lights"],
                    tracks: 24,
                    spotifyUrl: "https://open.spotify.com/playlist/37i9dQZF1DX0XUsuxWHRQd",
                    mood: "Relaxing & Meditative",
                    bestFor: "Weekend deals, relaxation products"
                  },
                  {
                    name: "Creative Focus",
                    description: "Perfect for promoting creativity-enhancing strains",
                    strains: ["Sour Diesel", "Jack Herer", "Strawberry Cough"],
                    tracks: 22,
                    spotifyUrl: "https://open.spotify.com/playlist/37i9dQZF1DWSkMjlBZUDWa",
                    mood: "Creative & Focused",
                    bestFor: "Artistic events, productivity strains"
                  },
                  {
                    name: "Weekend Warriors",
                    description: "High-energy playlist for weekend promotions",
                    strains: ["Wedding Cake", "Gelato", "Zkittlez"],
                    tracks: 26,
                    spotifyUrl: "https://open.spotify.com/playlist/37i9dQZF1DX4WYpdgoIcn6",
                    mood: "Uplifting & Fun",
                    bestFor: "Weekend specials, party promotions"
                  }
                ].map((playlist, index) => (
                  <div key={index} className="p-4 bg-gray-900 rounded-lg border border-purple-500/20">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4 className="font-medium text-white mb-1">{playlist.name}</h4>
                        <p className="text-sm text-gray-300 mb-2">{playlist.description}</p>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className="bg-purple-600 text-white">{playlist.tracks} tracks</Badge>
                          <Badge className="bg-blue-600 text-white">{playlist.mood}</Badge>
                        </div>
                      </div>
                      <Button 
                        size="sm" 
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                        onClick={() => window.open(playlist.spotifyUrl, '_blank')}
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Open Playlist
                      </Button>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                      <div>
                        <span className="text-xs text-gray-300">Featured Strains:</span>
                        <p className="text-sm text-gray-300">{playlist.strains.join(", ")}</p>
                      </div>
                      <div>
                        <span className="text-xs text-gray-300">Best For:</span>
                        <p className="text-sm text-gray-300">{playlist.bestFor}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-gray-700">
                      <span className="text-xs text-purple-400">TerpTunes Official Playlist</span>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="h-7 px-3 text-xs">
                          Share on Social
                        </Button>
                        <Button size="sm" variant="outline" className="h-7 px-3 text-xs">
                          Use in Promotion
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}

                <Card className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 border-purple-500/30">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <Award className="w-6 h-6 text-purple-400" />
                      <h3 className="text-lg font-semibold text-white">Promotion Ideas</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium text-white mb-2">Social Media</h4>
                        <ul className="text-sm text-gray-300 space-y-1">
                          <li>• Share playlists with strain recommendations</li>
                          <li>• Create Instagram Stories with playlist links</li>
                          <li>• Post "What to listen to while enjoying [strain]"</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-medium text-white mb-2">In-Store</h4>
                        <ul className="text-sm text-gray-300 space-y-1">
                          <li>• Play playlists during business hours</li>
                          <li>• QR codes linking to strain-specific playlists</li>
                          <li>• "Playlist of the Week" promotions</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default function DispensaryPortalPage() {
  return (
    <ProtectedRoute 
      requiredRole="dispensary" 
      requiresVerification={true}
      requiresOnboarding={true}
    >
      <DispensaryPortalContent />
    </ProtectedRoute>
  );
}