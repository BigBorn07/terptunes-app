import { useState, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, 
  Filter, 
  Sliders,
  Grid3x3,
  List,
  Star,
  Zap,
  TrendingUp,
  Sparkles,
  Play,
  ChevronRight,
  Settings,
  Brain,
  MessageSquare
} from "lucide-react";
import { TerpeneChart } from "@/components/terpene-chart";
import { SpotifyIntegration } from "@/components/SpotifyIntegration";
import { AdvancedSearch } from "@/components/advanced-search";
import { StrainReviews } from "@/components/strain-reviews";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface SearchFilters {
  query: string;
  strainTypes: string[];
  effects: string[];
  flavors: string[];
  terpenes: string[];
  thcRange: [number, number];
  cbdRange: [number, number];
  growDifficulty: string[];
  floweringTime: [number, number];
  dataQuality: string[];
  searchMode: 'basic' | 'advanced' | 'ai';
  sortBy: string;
  labVerified: boolean;
  userRatingMin: number;
  energyLevel: [number, number];
  creativityBoost: [number, number];
  relaxationLevel: [number, number];
  musicGenres: string[];
  usageContext: string[];
  timeOfDay: string[];
}

export default function Discover() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [activeTab, setActiveTab] = useState("discover");
  const [selectedStrain, setSelectedStrain] = useState<any>(null);
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [showStrainDetails, setShowStrainDetails] = useState(false);
  
  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    strainTypes: [],
    effects: [],
    flavors: [],
    terpenes: [],
    thcRange: [0, 40],
    cbdRange: [0, 25],
    growDifficulty: [],
    floweringTime: [40, 80],
    dataQuality: [],
    searchMode: 'basic',
    sortBy: 'relevance',
    labVerified: false,
    userRatingMin: 0,
    energyLevel: [1, 10],
    creativityBoost: [1, 10],
    relaxationLevel: [1, 10],
    musicGenres: [],
    usageContext: [],
    timeOfDay: []
  });

  // Fetch strains with search/filter parameters
  const { data: searchResults, isLoading, refetch } = useQuery({
    queryKey: ["/api/strains/search", filters],
    queryFn: () => {
      // In a real implementation, this would send filters to the backend
      // For now, we'll use the basic strains endpoint
      return fetch('/api/strains').then(res => res.json());
    }
  });

  // Get personalized recommendations
  const { data: recommendations } = useQuery({
    queryKey: ["/api/recommendations/strains"],
  });

  // Get trending strains
  const { data: trendingStrains } = useQuery({
    queryKey: ["/api/strains/trending"],
    queryFn: () => {
      // Mock trending strains for now
      return Promise.resolve([
        { id: 1, name: 'Blue Dream', trend: '+15%', reason: 'Popular this week' },
        { id: 2, name: 'Purple Punch', trend: '+12%', reason: 'High user ratings' },
        { id: 3, name: 'Wedding Cake', trend: '+8%', reason: 'New reviews' }
      ]);
    }
  });

  const handleFiltersChange = useCallback((newFilters: SearchFilters) => {
    setFilters(newFilters);
  }, []);

  const handleSearch = useCallback(() => {
    refetch();
  }, [refetch]);

  const applyBasicFilters = (strains: any[]) => {
    if (!strains) return [];
    
    return strains.filter((strain: any) => {
      // Apply basic text search
      if (filters.query) {
        const query = filters.query.toLowerCase();
        const matchesName = strain.name.toLowerCase().includes(query);
        const matchesEffects = strain.effects?.some((effect: string) => 
          effect.toLowerCase().includes(query)
        );
        const matchesDescription = strain.description?.toLowerCase().includes(query);
        
        if (!matchesName && !matchesEffects && !matchesDescription) {
          return false;
        }
      }

      // Apply strain type filter
      if (filters.strainTypes.length > 0) {
        if (!filters.strainTypes.includes(strain.type?.toLowerCase())) {
          return false;
        }
      }

      // Apply effects filter
      if (filters.effects.length > 0) {
        const hasMatchingEffect = filters.effects.some(effect => 
          strain.effects?.some((strainEffect: string) => 
            strainEffect.toLowerCase().includes(effect.toLowerCase())
          )
        );
        if (!hasMatchingEffect) return false;
      }

      // Apply THC range filter
      if (filters.thcRange[0] > 0 || filters.thcRange[1] < 40) {
        const thcValue = parseFloat(strain.thcContent?.replace('%', '') || '0');
        if (thcValue < filters.thcRange[0] || thcValue > filters.thcRange[1]) {
          return false;
        }
      }

      return true;
    });
  };

  const strains = applyBasicFilters(searchResults || []);
  const resultCount = strains.length;

  const StrainCard = ({ strain }: { strain: any }) => (
    <Card className="bg-gray-800/80 border-gray-700 hover:border-green-500/50 transition-all group">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-white text-lg">{strain.name}</CardTitle>
            <div className="flex items-center space-x-2 mt-1">
              <Badge 
                variant="secondary" 
                className={`${
                  strain.type === 'indica' ? 'bg-purple-500/20 text-purple-400' :
                  strain.type === 'sativa' ? 'bg-green-500/20 text-green-400' :
                  'bg-blue-500/20 text-blue-400'
                }`}
              >
                {strain.type}
              </Badge>
              <div className="flex items-center">
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <span className="text-sm text-gray-300 ml-1">4.2</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-300">THC</div>
            <div className="text-white font-medium">{strain.thcContent}</div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-gray-300 text-sm mb-4 line-clamp-2">{strain.description}</p>
        
        <div className="space-y-3">
          <div>
            <div className="text-sm font-medium text-gray-300 mb-2">Effects</div>
            <div className="flex flex-wrap gap-1">
              {strain.effects?.slice(0, 3).map((effect: string) => (
                <Badge key={effect} variant="outline" className="text-xs">
                  {effect}
                </Badge>
              ))}
              {strain.effects?.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{strain.effects.length - 3} more
                </Badge>
              )}
            </div>
          </div>

          <div>
            <div className="text-sm font-medium text-gray-300 mb-2">Top Terpenes</div>
            <TerpeneChart 
              terpenes={strain.terpenes || []} 
              size="small" 
              maxDisplay={3}
            />
          </div>
        </div>

        <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-700">
          <SpotifyIntegration 
            strain={strain} 
            size="small"
          />
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-gray-300 hover:text-white"
              onClick={() => {
                setSelectedStrain(strain);
                setShowStrainDetails(true);
              }}
            >
              <MessageSquare className="w-4 h-4 mr-1" />
              Reviews
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-gray-300 hover:text-white"
              onClick={() => {
                setSelectedStrain(strain);
                setShowStrainDetails(true);
              }}
            >
              View Details
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-4">
            Discover Your Perfect Strain
          </h1>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Explore our comprehensive database of cannabis strains with advanced filtering, 
            terpene analysis, and personalized music recommendations.
          </p>
        </div>

        {/* Main Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800/80">
            <TabsTrigger value="discover" className="data-[state=active]:bg-green-500/20">
              <Search className="w-4 h-4 mr-2" />
              Discover
            </TabsTrigger>
            <TabsTrigger value="trending" className="data-[state=active]:bg-green-500/20">
              <TrendingUp className="w-4 h-4 mr-2" />
              Trending
            </TabsTrigger>
            <TabsTrigger value="recommended" className="data-[state=active]:bg-green-500/20">
              <Brain className="w-4 h-4 mr-2" />
              For You
            </TabsTrigger>
            <TabsTrigger value="advanced" className="data-[state=active]:bg-green-500/20">
              <Sliders className="w-4 h-4 mr-2" />
              Advanced
            </TabsTrigger>
          </TabsList>

          {/* Discover Tab */}
          <TabsContent value="discover" className="space-y-6">
            {/* Search Controls */}
            <Card className="bg-gray-800/80 border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-white font-medium">Search & Filter</h3>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowAdvancedSearch(!showAdvancedSearch)}
                    >
                      <Settings className="w-4 h-4 mr-2" />
                      {showAdvancedSearch ? 'Hide' : 'Show'} Advanced
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}
                    >
                      {viewMode === "grid" ? <List className="w-4 h-4" /> : <Grid3x3 className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                {showAdvancedSearch && (
                  <AdvancedSearch
                    onFiltersChange={handleFiltersChange}
                    onSearch={handleSearch}
                    isLoading={isLoading}
                    resultCount={resultCount}
                  />
                )}
              </CardContent>
            </Card>

            {/* Results */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <h2 className="text-xl font-semibold text-white">
                  {resultCount} Strains Found
                </h2>
                {(filters.query || filters.strainTypes.length > 0 || filters.effects.length > 0) && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setFilters({
                        ...filters,
                        query: '',
                        strainTypes: [],
                        effects: [],
                        flavors: [],
                        terpenes: []
                      });
                    }}
                  >
                    Clear Filters
                  </Button>
                )}
              </div>
              
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-green-400" />
                <span className="text-sm text-gray-300">Sorted by {filters.sortBy}</span>
              </div>
            </div>

            {/* Strain Grid/List */}
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Card key={i} className="bg-gray-800/80 border-gray-700 animate-pulse">
                    <CardHeader>
                      <div className="h-4 bg-gray-700 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-700 rounded w-1/2 mt-2"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="h-3 bg-gray-700 rounded"></div>
                        <div className="h-3 bg-gray-700 rounded w-5/6"></div>
                        <div className="h-8 bg-gray-700 rounded"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : strains.length === 0 ? (
              <Card className="bg-gray-800/80 border-gray-700">
                <CardContent className="text-center py-12">
                  <Search className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-white text-lg font-medium mb-2">No strains found</h3>
                  <p className="text-gray-300 mb-4">
                    Try adjusting your search terms or filters to find more results.
                  </p>
                  <Button
                    onClick={() => {
                      setFilters({
                        ...filters,
                        query: '',
                        strainTypes: [],
                        effects: []
                      });
                    }}
                    className="cannabis-gradient"
                  >
                    Clear All Filters
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className={`grid gap-6 ${
                viewMode === "grid" 
                  ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" 
                  : "grid-cols-1"
              }`}>
                {strains.map((strain: any) => (
                  <StrainCard key={strain.id} strain={strain} />
                ))}
              </div>
            )}
          </TabsContent>

          {/* Trending Tab */}
          <TabsContent value="trending" className="space-y-6">
            <Card className="bg-gray-800/80 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-orange-400" />
                  Trending Strains This Week
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {(trendingStrains || []).map((trending: any) => (
                    <Card key={trending.id} className="bg-gray-700/50">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-white">{trending.name}</h4>
                          <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                            {trending.trend}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-300">{trending.reason}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Recommendations Tab */}
          <TabsContent value="recommended" className="space-y-6">
            <Card className="bg-gray-800/80 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-purple-400" />
                  Personalized Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                {recommendations && recommendations.length > 0 ? (
                  <div className="space-y-4">
                    {recommendations.map((rec: any) => (
                      <Card key={rec.id} className="bg-gray-700/50">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-medium text-white">{rec.name}</h4>
                              <p className="text-sm text-gray-300">{rec.reason}</p>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge variant="secondary" className="bg-purple-500/20 text-purple-400">
                                {rec.matchScore}% match
                              </Badge>
                              <Button size="sm" className="cannabis-gradient">
                                View Strain
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Brain className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                    <h3 className="text-white text-lg font-medium mb-2">No Recommendations Yet</h3>
                    <p className="text-gray-300">
                      Explore more strains and update your preferences to get personalized recommendations.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Advanced Search Tab */}
          <TabsContent value="advanced" className="space-y-6">
            <AdvancedSearch
              onFiltersChange={handleFiltersChange}
              onSearch={handleSearch}
              isLoading={isLoading}
              resultCount={resultCount}
            />
          </TabsContent>
        </Tabs>

        {/* Strain Details Dialog */}
        <Dialog open={showStrainDetails} onOpenChange={setShowStrainDetails}>
          <DialogContent className="max-w-4xl max-h-[80vh] bg-gray-800 border-gray-700 overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white">
                {selectedStrain?.name} - Reviews & Details
              </DialogTitle>
            </DialogHeader>
            {selectedStrain && (
              <StrainReviews 
                strainId={selectedStrain.id} 
                strainName={selectedStrain.name}
              />
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}