import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Music, Sparkles, Play, ExternalLink } from "lucide-react";
import SpotifyIntegration from "@/components/SpotifyIntegration";
import { Strain } from "@shared/schema";

export default function SpotifyDemo() {
  const [selectedStrain, setSelectedStrain] = useState<Strain | null>(null);

  // Get a few popular strains for demo
  const { data: strainsData, isLoading } = useQuery({
    queryKey: ['/api/strains', { limit: 6 }],
  });

  const strains = strainsData?.strains || [];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-700 rounded w-1/3 mb-4"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-48 bg-gray-800 rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-green-500/20 rounded-full">
              <Music className="w-8 h-8 text-green-400" />
            </div>
            <div className="p-3 bg-purple-500/20 rounded-full">
              <Sparkles className="w-8 h-8 text-purple-400" />
            </div>
          </div>
          <h1 className="text-4xl font-display font-bold text-white mb-4">
            Cannabis × <span className="text-green-400">Music</span> Integration
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Experience the revolutionary connection between cannabis terpene profiles and personalized music recommendations powered by Spotify.
          </p>
        </div>

        {/* Demo Section */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Strain Selection */}
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">
              1. Choose a Cannabis Strain
            </h2>
            <div className="grid gap-4">
              {strains.slice(0, 6).map((strain: Strain) => (
                <Card 
                  key={strain.id}
                  className={`cursor-pointer transition-all duration-200 ${
                    selectedStrain?.id === strain.id
                      ? 'ring-2 ring-green-500 bg-green-500/10'
                      : 'hover:bg-gray-800/50'
                  }`}
                  onClick={() => setSelectedStrain(strain)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-lg text-white">
                          {strain.name}
                        </h3>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="capitalize">
                            {strain.type}
                          </Badge>
                          {strain.thcContent && (
                            <Badge variant="secondary">
                              {strain.thcContent}% THC
                            </Badge>
                          )}
                        </div>
                      </div>
                      {selectedStrain?.id === strain.id && (
                        <div className="p-2 bg-green-500 rounded-full">
                          <Play className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Spotify Integration */}
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">
              2. Generate Spotify Playlist
            </h2>
            {selectedStrain ? (
              <SpotifyIntegration 
                strainId={selectedStrain.id}
                strainName={selectedStrain.name}
              />
            ) : (
              <Card className="border-dashed">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Music className="w-8 h-8 text-gray-300" />
                  </div>
                  <p className="text-gray-300">
                    Select a strain above to begin the playlist generation process
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* How It Works */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-2xl text-center">How The Magic Works</CardTitle>
            <CardDescription className="text-center text-lg">
              The science behind terpene-to-music matching
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-blue-400">1</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Terpene Analysis</h3>
                <p className="text-gray-300">
                  We analyze the strain's terpene profile - the aromatic compounds that create unique effects and flavors.
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-purple-400">2</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Musical Mapping</h3>
                <p className="text-gray-300">
                  Each terpene corresponds to specific musical characteristics like energy, mood, and genre preferences.
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-green-400">3</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">Playlist Creation</h3>
                <p className="text-gray-300">
                  Spotify's algorithm finds tracks matching the calculated musical profile and creates your personalized playlist.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Terpene Examples */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center">Terpene Musical Personalities</CardTitle>
            <CardDescription className="text-center text-lg">
              Examples of how different terpenes influence musical recommendations
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center p-4 bg-gradient-to-br from-blue-500/10 to-blue-600/5 rounded-lg">
                <h4 className="font-semibold text-lg mb-2 text-blue-400">Myrcene</h4>
                <p className="text-sm text-gray-300 mb-3">Relaxing & Sedating</p>
                <div className="space-y-2">
                  <Badge variant="outline" className="text-xs">Ambient</Badge>
                  <Badge variant="outline" className="text-xs">Lo-Fi</Badge>
                  <Badge variant="outline" className="text-xs">Chill</Badge>
                </div>
              </div>

              <div className="text-center p-4 bg-gradient-to-br from-yellow-500/10 to-yellow-600/5 rounded-lg">
                <h4 className="font-semibold text-lg mb-2 text-yellow-400">Limonene</h4>
                <p className="text-sm text-gray-300 mb-3">Uplifting & Energetic</p>
                <div className="space-y-2">
                  <Badge variant="outline" className="text-xs">Pop</Badge>
                  <Badge variant="outline" className="text-xs">Electronic</Badge>
                  <Badge variant="outline" className="text-xs">Funk</Badge>
                </div>
              </div>

              <div className="text-center p-4 bg-gradient-to-br from-red-500/10 to-red-600/5 rounded-lg">
                <h4 className="font-semibold text-lg mb-2 text-red-400">Caryophyllene</h4>
                <p className="text-sm text-gray-300 mb-3">Spicy & Powerful</p>
                <div className="space-y-2">
                  <Badge variant="outline" className="text-xs">Rock</Badge>
                  <Badge variant="outline" className="text-xs">Alternative</Badge>
                  <Badge variant="outline" className="text-xs">Grunge</Badge>
                </div>
              </div>

              <div className="text-center p-4 bg-gradient-to-br from-purple-500/10 to-purple-600/5 rounded-lg">
                <h4 className="font-semibold text-lg mb-2 text-purple-400">Linalool</h4>
                <p className="text-sm text-gray-300 mb-3">Calming & Floral</p>
                <div className="space-y-2">
                  <Badge variant="outline" className="text-xs">Classical</Badge>
                  <Badge variant="outline" className="text-xs">New Age</Badge>
                  <Badge variant="outline" className="text-xs">Meditation</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}