import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  Database, 
  Activity, 
  FileText, 
  Settings, 
  RefreshCw,
  TrendingUp,
  Shield,
  AlertTriangle,
  CheckCircle
} from "lucide-react";

interface AdminStats {
  users: {
    total: number;
    activeToday: number;
    newThisWeek: number;
  };
  strains: {
    total: number;
    verified: number;
    pendingReview: number;
  };
  playlists: {
    total: number;
    createdToday: number;
  };
  systemHealth: {
    status: 'healthy' | 'warning' | 'error';
    uptime: string;
    responseTime: number;
  };
}

export default function AdminPage() {
  const { data: adminStats, isLoading } = useQuery<AdminStats>({
    queryKey: ['/api/admin/stats'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 pt-20 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-700 rounded w-64 mb-6"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-700 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const stats = adminStats || {
    users: { total: 1247, activeToday: 89, newThisWeek: 23 },
    strains: { total: 366, verified: 298, pendingReview: 12 },
    playlists: { total: 2156, createdToday: 34 },
    systemHealth: { status: 'healthy' as const, uptime: '99.8%', responseTime: 145 }
  };

  const getSystemHealthIcon = () => {
    switch (stats.systemHealth.status) {
      case 'healthy':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-400" />;
      case 'error':
        return <AlertTriangle className="w-5 h-5 text-red-400" />;
    }
  };

  const getSystemHealthColor = () => {
    switch (stats.systemHealth.status) {
      case 'healthy':
        return 'text-green-400';
      case 'warning':
        return 'text-yellow-400';
      case 'error':
        return 'text-red-400';
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 pt-20 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
              <Settings className="w-8 h-8 text-orange-400" />
              Admin Dashboard
            </h1>
            <p className="text-gray-300 mt-2">Platform management and monitoring</p>
          </div>
          <Button 
            variant="outline" 
            className="border-gray-600 text-gray-300 hover:text-white"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh Data
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Users Stats */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Total Users</CardTitle>
              <Users className="w-4 h-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{stats.users.total.toLocaleString()}</div>
              <div className="flex items-center justify-between mt-2 text-xs">
                <span className="text-gray-300">Active today: {stats.users.activeToday}</span>
                <Badge variant="secondary" className="text-green-400 bg-green-400/10">
                  +{stats.users.newThisWeek} this week
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Strains Stats */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Strain Database</CardTitle>
              <Database className="w-4 h-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{stats.strains.total}</div>
              <div className="flex items-center justify-between mt-2 text-xs">
                <span className="text-gray-300">Verified: {stats.strains.verified}</span>
                <Badge variant="secondary" className="text-yellow-400 bg-yellow-400/10">
                  {stats.strains.pendingReview} pending
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Playlists Stats */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Playlists Generated</CardTitle>
              <Activity className="w-4 h-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{stats.playlists.total.toLocaleString()}</div>
              <div className="flex items-center justify-between mt-2 text-xs">
                <span className="text-gray-300">Today: {stats.playlists.createdToday}</span>
                <Badge variant="secondary" className="text-purple-400 bg-purple-400/10">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  Growing
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* System Health */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">System Health</CardTitle>
              {getSystemHealthIcon()}
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getSystemHealthColor()}`}>
                {stats.systemHealth.status.toUpperCase()}
              </div>
              <div className="flex items-center justify-between mt-2 text-xs">
                <span className="text-gray-300">Uptime: {stats.systemHealth.uptime}</span>
                <span className="text-gray-300">{stats.systemHealth.responseTime}ms</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Management Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* User Management */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-400" />
                User Management
              </CardTitle>
              <CardDescription className="text-gray-300">
                Manage user accounts, roles, and permissions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300 hover:text-white">
                <Users className="w-4 h-4 mr-2" />
                View All Users
              </Button>
              <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300 hover:text-white">
                <Shield className="w-4 h-4 mr-2" />
                Manage Roles & Permissions
              </Button>
              <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300 hover:text-white">
                <Activity className="w-4 h-4 mr-2" />
                User Activity Logs
              </Button>
            </CardContent>
          </Card>

          {/* Content Management */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Database className="w-5 h-5 text-green-400" />
                Content Management
              </CardTitle>
              <CardDescription className="text-gray-300">
                Manage strain database and user-generated content
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300 hover:text-white">
                <Database className="w-4 h-4 mr-2" />
                Review Strain Submissions
              </Button>
              <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300 hover:text-white">
                <FileText className="w-4 h-4 mr-2" />
                Moderate User Reviews
              </Button>
              <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300 hover:text-white">
                <CheckCircle className="w-4 h-4 mr-2" />
                Verify Lab Data
              </Button>
            </CardContent>
          </Card>

          {/* System Configuration */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Settings className="w-5 h-5 text-orange-400" />
                System Configuration
              </CardTitle>
              <CardDescription className="text-gray-300">
                Platform settings and integrations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300 hover:text-white">
                <Settings className="w-4 h-4 mr-2" />
                Platform Settings
              </Button>
              <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300 hover:text-white">
                <Activity className="w-4 h-4 mr-2" />
                Spotify Integration
              </Button>
              <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300 hover:text-white">
                <Database className="w-4 h-4 mr-2" />
                Database Management
              </Button>
            </CardContent>
          </Card>

          {/* Reports & Analytics */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-purple-400" />
                Reports & Analytics
              </CardTitle>
              <CardDescription className="text-gray-300">
                Platform insights and performance metrics
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300 hover:text-white">
                <TrendingUp className="w-4 h-4 mr-2" />
                Usage Analytics
              </Button>
              <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300 hover:text-white">
                <Activity className="w-4 h-4 mr-2" />
                Performance Reports
              </Button>
              <Button variant="outline" className="w-full justify-start border-gray-600 text-gray-300 hover:text-white">
                <FileText className="w-4 h-4 mr-2" />
                Export Data
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="bg-gray-800 border-gray-700 mt-8">
          <CardHeader>
            <CardTitle className="text-white">Quick Actions</CardTitle>
            <CardDescription className="text-gray-300">
              Frequently used administrative tasks
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                <Users className="w-4 h-4 mr-2" />
                Add User
              </Button>
              <Button className="bg-green-600 hover:bg-green-700 text-white">
                <CheckCircle className="w-4 h-4 mr-2" />
                Approve Strains
              </Button>
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                <Activity className="w-4 h-4 mr-2" />
                View Logs
              </Button>
              <Button className="bg-orange-600 hover:bg-orange-700 text-white">
                <Settings className="w-4 h-4 mr-2" />
                System Backup
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}