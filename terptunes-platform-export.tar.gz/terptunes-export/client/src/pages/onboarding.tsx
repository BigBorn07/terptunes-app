import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { 
  User, 
  Building2, 
  Sprout, 
  Music, 
  Leaf, 
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  Upload,
  FileText,
  Shield,
  Play
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

type UserType = "consumer" | "grower" | "dispensary";
type OnboardingStep = "user_type" | "preferences" | "verification" | "tutorial" | "completed";

interface OnboardingData {
  userType?: UserType;
  preferences?: {
    favoriteStrainTypes: string[];
    favoriteTerpenes: string[];
    preferredEffects: string[];
    musicGenres: string[];
    playlistDuration: number;
    explicitContent: boolean;
  };
  businessInfo?: {
    businessName: string;
    businessLicense: string;
    businessAddress: string;
    businessPhone: string;
    businessWebsite?: string;
  };
}

export default function OnboardingPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, isAuthenticated } = useAuth();
  
  const [currentStep, setCurrentStep] = useState<OnboardingStep>("user_type");
  const [onboardingData, setOnboardingData] = useState<OnboardingData>({});
  const [isLoading, setIsLoading] = useState(false);

  // Get current onboarding status
  const { data: onboardingStatus } = useQuery({
    queryKey: ["/api/auth/onboarding-status"],
    enabled: isAuthenticated,
  });

  // Update onboarding step mutation
  const updateStepMutation = useMutation({
    mutationFn: async ({ step, data }: { step: string; data?: any }) => {
      return await apiRequest("/api/auth/update-onboarding", "POST", { step, data });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/onboarding-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
  });

  // Update user type mutation
  const updateUserTypeMutation = useMutation({
    mutationFn: async (userType: UserType) => {
      return await apiRequest("/api/auth/update-user-type", "POST", { userType });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
  });

  // Submit business verification mutation
  const submitVerificationMutation = useMutation({
    mutationFn: async (businessData: any) => {
      return await apiRequest("/api/auth/submit-verification", "POST", businessData);
    },
    onSuccess: () => {
      toast({
        title: "Verification Submitted",
        description: "Your business verification request has been submitted for review.",
      });
      setCurrentStep("tutorial");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit verification request. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Set up user preferences mutation
  const setupPreferencesMutation = useMutation({
    mutationFn: async (preferences: any) => {
      return await apiRequest("/api/auth/setup-preferences", "POST", preferences);
    },
    onSuccess: () => {
      toast({
        title: "Preferences Saved",
        description: "Your preferences have been saved successfully.",
      });
      // Move to next step based on user type
      if (onboardingData.userType === "consumer") {
        setCurrentStep("tutorial");
      } else {
        setCurrentStep("verification");
      }
    },
  });

  // Complete onboarding mutation
  const completeOnboardingMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/auth/complete-onboarding", "POST", {});
    },
    onSuccess: () => {
      toast({
        title: "Welcome to TerpTunes!",
        description: "Your onboarding is complete. Let's start exploring!",
      });
      window.location.href = "/";
    },
  });

  useEffect(() => {
    if (onboardingStatus) {
      setCurrentStep(onboardingStatus.currentStep || "user_type");
    }
  }, [onboardingStatus]);

  const getStepProgress = () => {
    const steps = ["user_type", "preferences", "verification", "tutorial", "completed"];
    return (steps.indexOf(currentStep) + 1) / steps.length * 100;
  };

  const handleUserTypeSelection = async (userType: UserType) => {
    setIsLoading(true);
    setOnboardingData({ ...onboardingData, userType });
    
    try {
      await updateUserTypeMutation.mutateAsync(userType);
      await updateStepMutation.mutateAsync({ step: "user_type", data: { userType } });
      setCurrentStep("preferences");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update user type. Please try again.",
        variant: "destructive",
      });
    }
    setIsLoading(false);
  };

  const handlePreferencesSubmit = () => {
    const preferences = onboardingData.preferences;
    if (!preferences) return;
    
    setupPreferencesMutation.mutate(preferences);
    updateStepMutation.mutate({ step: "preferences", data: preferences });
  };

  const handleVerificationSubmit = () => {
    if (!onboardingData.businessInfo) return;
    
    submitVerificationMutation.mutate(onboardingData.businessInfo);
    updateStepMutation.mutate({ step: "verification", data: onboardingData.businessInfo });
  };

  const handleTutorialComplete = () => {
    updateStepMutation.mutate({ step: "tutorial" });
    completeOnboardingMutation.mutate();
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-6">
        <Card className="w-full max-w-md bg-gray-800 border-gray-700">
          <CardHeader className="text-center">
            <CardTitle className="text-white">Welcome to TerpTunes</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-gray-300 mb-6">Please sign in to continue with your onboarding.</p>
            <Button onClick={() => window.location.href = "/api/login"}>
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Welcome to TerpTunes</h1>
          <p className="text-gray-300">Let's set up your personalized cannabis and music experience</p>
          
          <div className="mt-6">
            <Progress value={getStepProgress()} className="w-full h-2" />
            <p className="text-sm text-gray-300 mt-2">
              Step {["user_type", "preferences", "verification", "tutorial"].indexOf(currentStep) + 1} of 4
            </p>
          </div>
        </div>

        {/* User Type Selection */}
        {currentStep === "user_type" && (
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white text-center">Choose Your Account Type</CardTitle>
              <p className="text-gray-300 text-center">
                Select the option that best describes how you'll use TerpTunes
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Consumer */}
                <div 
                  className="cursor-pointer group"
                  onClick={() => handleUserTypeSelection("consumer")}
                >
                  <Card className="h-full bg-gray-700 border-gray-600 hover:border-purple-500 transition-colors group-hover:bg-gray-600">
                    <CardContent className="p-6 text-center">
                      <User className="w-12 h-12 text-purple-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-white mb-2">Cannabis Enthusiast</h3>
                      <p className="text-gray-300 text-sm mb-4">
                        Discover strains, create playlists, and explore the connection between terpenes and music
                      </p>
                      <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                        Consumer Account
                      </Badge>
                    </CardContent>
                  </Card>
                </div>

                {/* Grower */}
                <div 
                  className="cursor-pointer group"
                  onClick={() => handleUserTypeSelection("grower")}
                >
                  <Card className="h-full bg-gray-700 border-gray-600 hover:border-green-500 transition-colors group-hover:bg-gray-600">
                    <CardContent className="p-6 text-center">
                      <Sprout className="w-12 h-12 text-green-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-white mb-2">Cannabis Grower</h3>
                      <p className="text-gray-300 text-sm mb-4">
                        Upload your strains, create curated playlists, and connect with consumers
                      </p>
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        Business Account
                      </Badge>
                    </CardContent>
                  </Card>
                </div>

                {/* Dispensary */}
                <div 
                  className="cursor-pointer group"
                  onClick={() => handleUserTypeSelection("dispensary")}
                >
                  <Card className="h-full bg-gray-700 border-gray-600 hover:border-orange-500 transition-colors group-hover:bg-gray-600">
                    <CardContent className="p-6 text-center">
                      <Building2 className="w-12 h-12 text-orange-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-white mb-2">Dispensary</h3>
                      <p className="text-gray-300 text-sm mb-4">
                        Promote your products, drive traffic, and engage customers through music
                      </p>
                      <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                        Business Account
                      </Badge>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Preferences Setup */}
        {currentStep === "preferences" && (
          <PreferencesStep 
            onboardingData={onboardingData} 
            setOnboardingData={setOnboardingData}
            onNext={handlePreferencesSubmit}
            onBack={() => setCurrentStep("user_type")}
          />
        )}

        {/* Business Verification */}
        {currentStep === "verification" && (
          <VerificationStep 
            onboardingData={onboardingData}
            setOnboardingData={setOnboardingData}
            onNext={handleVerificationSubmit}
            onBack={() => setCurrentStep("preferences")}
          />
        )}

        {/* Tutorial */}
        {currentStep === "tutorial" && (
          <TutorialStep 
            userType={onboardingData.userType!}
            onComplete={handleTutorialComplete}
            onBack={() => setCurrentStep(onboardingData.userType === "consumer" ? "preferences" : "verification")}
          />
        )}
      </div>
    </div>
  );
}

// Preferences Step Component
function PreferencesStep({ onboardingData, setOnboardingData, onNext, onBack }: any) {
  const [preferences, setPreferences] = useState(
    onboardingData.preferences || {
      favoriteStrainTypes: [],
      favoriteTerpenes: [],
      preferredEffects: [],
      musicGenres: [],
      playlistDuration: 60,
      explicitContent: false,
    }
  );

  const strainTypes = ["indica", "sativa", "hybrid"];
  const terpenes = ["Myrcene", "Limonene", "Pinene", "Linalool", "Caryophyllene", "Humulene", "Terpinolene"];
  const effects = ["Relaxed", "Happy", "Creative", "Energetic", "Focused", "Euphoric", "Sleepy", "Uplifted"];
  const genres = ["Electronic", "Ambient", "Rock", "Hip Hop", "Jazz", "Classical", "Reggae", "Indie"];

  const handleArrayToggle = (array: string[], value: string, field: string) => {
    const newArray = array.includes(value) 
      ? array.filter(item => item !== value)
      : [...array, value];
    
    setPreferences({ ...preferences, [field]: newArray });
    setOnboardingData({ 
      ...onboardingData, 
      preferences: { ...preferences, [field]: newArray }
    });
  };

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Leaf className="w-6 h-6 text-green-400" />
          Set Your Preferences
        </CardTitle>
        <p className="text-gray-300">
          Help us personalize your TerpTunes experience
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Strain Types */}
        <div>
          <Label className="text-white text-base mb-3 block">Favorite Strain Types</Label>
          <div className="flex flex-wrap gap-2">
            {strainTypes.map((type) => (
              <Badge
                key={type}
                variant={preferences.favoriteStrainTypes.includes(type) ? "default" : "secondary"}
                className={`cursor-pointer ${
                  preferences.favoriteStrainTypes.includes(type) 
                    ? "bg-purple-600 hover:bg-purple-700" 
                    : "bg-gray-600 hover:bg-gray-500"
                }`}
                onClick={() => handleArrayToggle(preferences.favoriteStrainTypes, type, "favoriteStrainTypes")}
              >
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </Badge>
            ))}
          </div>
        </div>

        {/* Terpenes */}
        <div>
          <Label className="text-white text-base mb-3 block">Favorite Terpenes</Label>
          <div className="flex flex-wrap gap-2">
            {terpenes.map((terpene) => (
              <Badge
                key={terpene}
                variant={preferences.favoriteTerpenes.includes(terpene) ? "default" : "secondary"}
                className={`cursor-pointer ${
                  preferences.favoriteTerpenes.includes(terpene) 
                    ? "bg-green-600 hover:bg-green-700" 
                    : "bg-gray-600 hover:bg-gray-500"
                }`}
                onClick={() => handleArrayToggle(preferences.favoriteTerpenes, terpene, "favoriteTerpenes")}
              >
                {terpene}
              </Badge>
            ))}
          </div>
        </div>

        {/* Effects */}
        <div>
          <Label className="text-white text-base mb-3 block">Preferred Effects</Label>
          <div className="flex flex-wrap gap-2">
            {effects.map((effect) => (
              <Badge
                key={effect}
                variant={preferences.preferredEffects.includes(effect) ? "default" : "secondary"}
                className={`cursor-pointer ${
                  preferences.preferredEffects.includes(effect) 
                    ? "bg-blue-600 hover:bg-blue-700" 
                    : "bg-gray-600 hover:bg-gray-500"
                }`}
                onClick={() => handleArrayToggle(preferences.preferredEffects, effect, "preferredEffects")}
              >
                {effect}
              </Badge>
            ))}
          </div>
        </div>

        {/* Music Genres */}
        <div>
          <Label className="text-white text-base mb-3 block">Music Genres</Label>
          <div className="flex flex-wrap gap-2">
            {genres.map((genre) => (
              <Badge
                key={genre}
                variant={preferences.musicGenres.includes(genre) ? "default" : "secondary"}
                className={`cursor-pointer ${
                  preferences.musicGenres.includes(genre) 
                    ? "bg-purple-600 hover:bg-purple-700" 
                    : "bg-gray-600 hover:bg-gray-500"
                }`}
                onClick={() => handleArrayToggle(preferences.musicGenres, genre, "musicGenres")}
              >
                {genre}
              </Badge>
            ))}
          </div>
        </div>

        {/* Playlist Duration */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label className="text-white">Default Playlist Duration (minutes)</Label>
            <Select 
              value={preferences.playlistDuration.toString()}
              onValueChange={(value) => {
                const duration = parseInt(value);
                setPreferences({ ...preferences, playlistDuration: duration });
                setOnboardingData({ 
                  ...onboardingData, 
                  preferences: { ...preferences, playlistDuration: duration }
                });
              }}
            >
              <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30">30 minutes</SelectItem>
                <SelectItem value="60">1 hour</SelectItem>
                <SelectItem value="90">1.5 hours</SelectItem>
                <SelectItem value="120">2 hours</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2 mt-6">
            <Checkbox 
              id="explicit"
              checked={preferences.explicitContent}
              onCheckedChange={(checked) => {
                setPreferences({ ...preferences, explicitContent: checked as boolean });
                setOnboardingData({ 
                  ...onboardingData, 
                  preferences: { ...preferences, explicitContent: checked as boolean }
                });
              }}
            />
            <Label htmlFor="explicit" className="text-white">
              Allow explicit content
            </Label>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between pt-6">
          <Button variant="outline" onClick={onBack} className="border-gray-600 text-gray-300">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button onClick={onNext} className="bg-purple-600 hover:bg-purple-700">
            Continue
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Verification Step Component  
function VerificationStep({ onboardingData, setOnboardingData, onNext, onBack }: any) {
  const [businessInfo, setBusinessInfo] = useState(
    onboardingData.businessInfo || {
      businessName: "",
      businessLicense: "",
      businessAddress: "",
      businessPhone: "",
      businessWebsite: "",
    }
  );

  const handleInputChange = (field: string, value: string) => {
    const newInfo = { ...businessInfo, [field]: value };
    setBusinessInfo(newInfo);
    setOnboardingData({ ...onboardingData, businessInfo: newInfo });
  };

  const isValid = businessInfo.businessName && businessInfo.businessLicense && 
                 businessInfo.businessAddress && businessInfo.businessPhone;

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Shield className="w-6 h-6 text-blue-400" />
          Business Verification
        </CardTitle>
        <p className="text-gray-300">
          We need to verify your business before you can access advanced features
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label className="text-white">Business Name *</Label>
            <Input
              value={businessInfo.businessName}
              onChange={(e) => handleInputChange("businessName", e.target.value)}
              placeholder="Enter your business name"
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>

          <div>
            <Label className="text-white">Business License Number *</Label>
            <Input
              value={businessInfo.businessLicense}
              onChange={(e) => handleInputChange("businessLicense", e.target.value)}
              placeholder="Enter license number"
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>

          <div>
            <Label className="text-white">Business Phone *</Label>
            <Input
              value={businessInfo.businessPhone}
              onChange={(e) => handleInputChange("businessPhone", e.target.value)}
              placeholder="(555) 123-4567"
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>

          <div>
            <Label className="text-white">Website (Optional)</Label>
            <Input
              value={businessInfo.businessWebsite}
              onChange={(e) => handleInputChange("businessWebsite", e.target.value)}
              placeholder="https://yourbusiness.com"
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>
        </div>

        <div>
          <Label className="text-white">Business Address *</Label>
          <Textarea
            value={businessInfo.businessAddress}
            onChange={(e) => handleInputChange("businessAddress", e.target.value)}
            placeholder="Enter your complete business address"
            className="bg-gray-700 border-gray-600 text-white"
            rows={3}
          />
        </div>

        <div className="bg-blue-900/20 border border-blue-700 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <FileText className="w-5 h-5 text-blue-400 mt-0.5" />
            <div>
              <h4 className="text-white font-medium">Verification Process</h4>
              <p className="text-blue-200 text-sm mt-1">
                Your information will be reviewed by our team within 2-3 business days. 
                You'll receive an email confirmation once verified.
              </p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between pt-6">
          <Button variant="outline" onClick={onBack} className="border-gray-600 text-gray-300">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button 
            onClick={onNext} 
            disabled={!isValid}
            className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
          >
            Submit for Verification
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Tutorial Step Component
function TutorialStep({ userType, onComplete, onBack }: any) {
  const [currentTutorial, setCurrentTutorial] = useState(0);

  const getTutorials = () => {
    switch (userType) {
      case "consumer":
        return [
          {
            title: "Discover Strains",
            icon: <Leaf className="w-8 h-8 text-green-400" />,
            description: "Browse our extensive strain database and learn about terpene profiles",
            content: "Use our advanced search to find strains by type, effects, or terpenes. Each strain shows detailed terpene profiles and user reviews."
          },
          {
            title: "Create Playlists",
            icon: <Music className="w-8 h-8 text-purple-400" />,
            description: "Generate personalized playlists based on strain terpene profiles",
            content: "Select any strain and click 'Generate Playlist' to create music matched to its terpene profile. Your playlists are saved to your Spotify account."
          },
          {
            title: "Connect Your Spotify",
            icon: <Play className="w-8 h-8 text-green-500" />,
            description: "Link your Spotify account to save and enjoy your generated playlists",
            content: "Go to your profile settings and connect Spotify to automatically save playlists and get personalized music recommendations."
          }
        ];

      case "grower":
        return [
          {
            title: "Upload Your Strains",
            icon: <Upload className="w-8 h-8 text-green-400" />,
            description: "Add your cultivated strains to the TerpTunes database",
            content: "Use the Grower Portal to upload strain information, terpene profiles, and growing details. Verified growers can contribute to our database."
          },
          {
            title: "Create Curated Playlists",
            icon: <Music className="w-8 h-8 text-purple-400" />,
            description: "Curate playlists that showcase your strains' unique characteristics",
            content: "Create custom playlists for each of your strains to help customers understand the experience through music."
          },
          {
            title: "Track Performance",
            icon: <CheckCircle className="w-8 h-8 text-blue-400" />,
            description: "Monitor how users engage with your strains and playlists",
            content: "View analytics on strain popularity, playlist plays, and user engagement in your grower dashboard."
          }
        ];

      case "dispensary":
        return [
          {
            title: "Promote Your Products",
            icon: <Building2 className="w-8 h-8 text-orange-400" />,
            description: "Use TerpTunes to drive traffic to your dispensary",
            content: "Create promotional campaigns linking strains to music experiences that encourage store visits."
          },
          {
            title: "Engage Customers",
            icon: <User className="w-8 h-8 text-purple-400" />,
            description: "Connect with customers through the shared language of music",
            content: "Use music to help customers understand strain effects and create memorable experiences."
          },
          {
            title: "Analytics Dashboard",
            icon: <CheckCircle className="w-8 h-8 text-blue-400" />,
            description: "Track customer engagement and referral traffic",
            content: "Monitor how TerpTunes users discover and interact with your dispensary through our analytics."
          }
        ];

      default:
        return [];
    }
  };

  const tutorials = getTutorials();
  const currentTutorialData = tutorials[currentTutorial];

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          {currentTutorialData.icon}
          Quick Tutorial: {currentTutorialData.title}
        </CardTitle>
        <p className="text-gray-300">
          {currentTutorialData.description}
        </p>
      </CardHeader>
      <CardContent>
        <div className="bg-gray-700/50 rounded-lg p-6 mb-6">
          <p className="text-gray-300 leading-relaxed">
            {currentTutorialData.content}
          </p>
        </div>

        {/* Tutorial Progress */}
        <div className="flex justify-center mb-6">
          <div className="flex space-x-2">
            {tutorials.map((_, index) => (
              <div
                key={index}
                className={`w-3 h-3 rounded-full ${
                  index === currentTutorial ? "bg-purple-500" : "bg-gray-600"
                }`}
              />
            ))}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button 
            variant="outline" 
            onClick={currentTutorial === 0 ? onBack : () => setCurrentTutorial(currentTutorial - 1)}
            className="border-gray-600 text-gray-300"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            {currentTutorial === 0 ? "Back" : "Previous"}
          </Button>
          
          {currentTutorial < tutorials.length - 1 ? (
            <Button 
              onClick={() => setCurrentTutorial(currentTutorial + 1)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Next
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button 
              onClick={onComplete}
              className="bg-green-600 hover:bg-green-700"
            >
              Complete Onboarding
              <CheckCircle className="w-4 h-4 ml-2" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}