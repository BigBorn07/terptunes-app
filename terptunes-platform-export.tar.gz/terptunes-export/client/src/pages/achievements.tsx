import BadgeSystem from "@/components/BadgeSystem";

export default function Achievements() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Cannabis Explorer Journey</h1>
        <p className="text-muted-foreground text-lg">
          Discover strains, learn terpene science, and earn badges while creating the perfect playlists
        </p>
      </div>
      
      <BadgeSystem />
    </div>
  );
}