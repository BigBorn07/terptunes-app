import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Headphones, 
  Play, 
  Clock, 
  Calendar,
  ExternalLink,
  Mic,
  Users,
  Star,
  Download
} from "lucide-react";

export default function Podcast() {
  const podcastEpisodes = [
    {
      id: 1,
      title: "The Science of Terpenes: How Cannabis Compounds Create Musical Moods",
      description: "Deep dive into the scientific research behind terpene profiles and their connection to musical preferences. Featuring Dr. Sarah Martinez, cannabis researcher.",
      duration: "48:32",
      releaseDate: "2024-12-15",
      category: "Science",
      guests: ["Dr. Sarah Martinez", "Prof. Michael Chen"],
      spotifyUrl: "https://open.spotify.com/episode/example1",
      applePodcastsUrl: "https://podcasts.apple.com/episode/example1",
      featured: true
    },
    {
      id: 2,
      title: "From Playlist to Strain: A Music Producer's Cannabis Journey",
      description: "Grammy-nominated producer Jake Williams shares how different cannabis strains inspire his creative process and music production techniques.",
      duration: "35:47",
      releaseDate: "2024-12-08",
      category: "Creative",
      guests: ["Jake Williams"],
      spotifyUrl: "https://open.spotify.com/episode/example2",
      applePodcastsUrl: "https://podcasts.apple.com/episode/example2",
      featured: false
    },
    {
      id: 3,
      title: "Indica vs Sativa: Debunking Music Preference Myths",
      description: "Exploring whether indica and sativa classifications really predict musical taste, with insights from TerpTunes user data and expert analysis.",
      duration: "42:18",
      releaseDate: "2024-12-01",
      category: "Analysis",
      guests: ["Cannabis Sommelier Lisa Park"],
      spotifyUrl: "https://open.spotify.com/episode/example3",
      applePodcastsUrl: "https://podcasts.apple.com/episode/example3",
      featured: false
    },
    {
      id: 4,
      title: "Building TerpTunes: The Story Behind the Spotify of Cannabis",
      description: "Co-founders discuss the vision, challenges, and breakthroughs in creating the world's first terpene-to-music matching platform.",
      duration: "52:15",
      releaseDate: "2024-11-24",
      category: "Founder Story",
      guests: ["TerpTunes Co-founders"],
      spotifyUrl: "https://open.spotify.com/episode/example4",
      applePodcastsUrl: "https://podcasts.apple.com/episode/example4",
      featured: true
    },
    {
      id: 5,
      title: "Cannabis Culture & Music: Regional Differences in Strain Preferences",
      description: "Analyzing how geographic location influences both cannabis strain choices and musical taste patterns across different markets.",
      duration: "39:22",
      releaseDate: "2024-11-17",
      category: "Culture",
      guests: ["Cultural Anthropologist Dr. Emma Rodriguez"],
      spotifyUrl: "https://open.spotify.com/episode/example5",
      applePodcastsUrl: "https://podcasts.apple.com/episode/example5",
      featured: false
    }
  ];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Science': return 'bg-blue-600';
      case 'Creative': return 'bg-purple-600';
      case 'Analysis': return 'bg-green-600';
      case 'Founder Story': return 'bg-orange-600';
      case 'Culture': return 'bg-pink-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 p-4">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-white flex items-center justify-center gap-3">
            <Headphones className="w-10 h-10 text-green-500" />
            TerpTunes Podcast
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Exploring the intersection of cannabis science, music culture, and innovation. 
            Weekly episodes featuring experts, artists, and industry leaders.
          </p>
        </div>

        {/* Podcast Info */}
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="pt-6">
            <div className="grid gap-6 md:grid-cols-3">
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Mic className="w-8 h-8 text-green-500" />
                </div>
                <h3 className="text-lg font-semibold text-white">Weekly Episodes</h3>
                <p className="text-gray-300">New episodes every Sunday</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Users className="w-8 h-8 text-purple-500" />
                </div>
                <h3 className="text-lg font-semibold text-white">Expert Guests</h3>
                <p className="text-gray-300">Scientists, artists, & entrepreneurs</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Star className="w-8 h-8 text-yellow-500" />
                </div>
                <h3 className="text-lg font-semibold text-white">4.8/5 Rating</h3>
                <p className="text-gray-300">Based on 2,847 reviews</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Subscribe Section */}
        <Card className="bg-gradient-to-r from-green-900 to-purple-900 border-gray-700">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <h2 className="text-2xl font-bold text-white">Subscribe & Listen</h2>
              <p className="text-gray-200">Available on all major podcast platforms</p>
              <div className="flex flex-wrap justify-center gap-4">
                <Button className="bg-green-600 hover:bg-green-700">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Spotify
                </Button>
                <Button className="bg-gray-700 hover:bg-gray-600">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Apple Podcasts
                </Button>
                <Button className="bg-orange-600 hover:bg-orange-700">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Google Podcasts
                </Button>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  YouTube
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Featured Episodes */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-white">Featured Episodes</h2>
          <div className="grid gap-6">
            {podcastEpisodes.filter(ep => ep.featured).map((episode) => (
              <Card key={episode.id} className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <Badge className={getCategoryColor(episode.category)}>
                        {episode.category}
                      </Badge>
                      <CardTitle className="text-white">{episode.title}</CardTitle>
                      <CardDescription className="text-gray-300">
                        {episode.description}
                      </CardDescription>
                    </div>
                    <Star className="w-5 h-5 text-yellow-500 flex-shrink-0" />
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-4 text-sm text-gray-300">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {episode.duration}
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {new Date(episode.releaseDate).toLocaleDateString()}
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {episode.guests.join(", ")}
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button size="sm" className="bg-green-600 hover:bg-green-700">
                      <Play className="w-4 h-4 mr-2" />
                      Play Episode
                    </Button>
                    <Button size="sm" variant="outline" className="border-gray-600">
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* All Episodes */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-white">All Episodes</h2>
          <div className="grid gap-4">
            {podcastEpisodes.map((episode) => (
              <Card key={episode.id} className="bg-gray-900 border-gray-700">
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2">
                        <Badge className={getCategoryColor(episode.category)}>
                          {episode.category}
                        </Badge>
                        {episode.featured && (
                          <Star className="w-4 h-4 text-yellow-500" />
                        )}
                      </div>
                      <h3 className="text-white font-medium">{episode.title}</h3>
                      <p className="text-gray-300 text-sm">{episode.description}</p>
                      <div className="flex items-center gap-4 text-xs text-gray-300">
                        <span>{episode.duration}</span>
                        <span>{new Date(episode.releaseDate).toLocaleDateString()}</span>
                        <span>{episode.guests.join(", ")}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        <Play className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline" className="border-gray-600">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Newsletter Signup */}
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Stay Updated</CardTitle>
            <CardDescription>
              Get notified about new episodes and exclusive content
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="flex-1 px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white placeholder-gray-300"
              />
              <Button className="bg-green-600 hover:bg-green-700">
                Subscribe
              </Button>
            </div>
            <p className="text-xs text-gray-300">
              No spam, unsubscribe anytime. We respect your privacy.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}