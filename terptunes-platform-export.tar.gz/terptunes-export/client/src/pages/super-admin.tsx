import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  Database, 
  Download, 
  Upload, 
  Users, 
  Shield, 
  Activity, 
  BarChart3,
  Settings,
  Trash2,
  Check,
  X,
  AlertTriangle,
  Play,
  Pause,
  RotateCw
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function SuperAdminPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeOperation, setActiveOperation] = useState<string | null>(null);

  // Fetch system statistics
  const { data: systemStats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/admin/stats"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch data integration status
  const { data: integrationStatus } = useQuery({
    queryKey: ["/api/admin/integrate/status"],
    refetchInterval: 10000,
  });

  // Fetch user management data
  const { data: userStats } = useQuery({
    queryKey: ["/api/admin/users/stats"],
  });

  // Data Integration Operations
  const runFullIntegration = useMutation({
    mutationFn: () => apiRequest("/api/admin/integrate/full", "POST"),
    onMutate: () => setActiveOperation("integration"),
    onSuccess: (data) => {
      toast({
        title: "Integration Complete",
        description: `Processed ${data.results?.integratedStrains || 0} strains with ${data.results?.importResults?.success || 0} successful imports`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin"] });
    },
    onError: (error) => {
      toast({
        title: "Integration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => setActiveOperation(null),
  });

  // Database Operations
  const optimizeDatabase = useMutation({
    mutationFn: () => apiRequest("/api/admin/database/optimize", "POST"),
    onMutate: () => setActiveOperation("optimize"),
    onSuccess: () => {
      toast({
        title: "Database Optimized",
        description: "Database performance has been optimized",
      });
    },
    onError: (error) => {
      toast({
        title: "Optimization Failed",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => setActiveOperation(null),
  });

  const backupDatabase = useMutation({
    mutationFn: () => apiRequest("/api/admin/database/backup", "POST"),
    onMutate: () => setActiveOperation("backup"),
    onSuccess: (data) => {
      toast({
        title: "Backup Created",
        description: `Database backup completed: ${data.filename}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Backup Failed",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => setActiveOperation(null),
  });

  // User Management Operations
  const promoteUser = useMutation({
    mutationFn: (userId: string) => apiRequest(`/api/admin/users/${userId}/promote`, "POST"),
    onSuccess: () => {
      toast({
        title: "User Promoted",
        description: "User has been granted admin privileges",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error) => {
      toast({
        title: "Promotion Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-green-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">TerpTunes Super Admin</h1>
          <p className="text-gray-300">System administration and data management dashboard</p>
        </div>

        {/* System Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Total Strains</CardTitle>
              <Database className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {statsLoading ? "..." : systemStats?.totalStrains || 0}
              </div>
              <p className="text-xs text-gray-300">
                {systemStats?.labVerifiedStrains || 0} lab-verified
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Active Users</CardTitle>
              <Users className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {userStats?.activeUsers || 0}
              </div>
              <p className="text-xs text-gray-300">
                {userStats?.totalUsers || 0} total registered
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Playlists Created</CardTitle>
              <Activity className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {systemStats?.totalPlaylists || 0}
              </div>
              <p className="text-xs text-gray-300">
                {systemStats?.todayPlaylists || 0} today
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">System Health</CardTitle>
              <Shield className="h-4 w-4 text-yellow-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {systemStats?.systemHealth === "excellent" ? "Excellent" : 
                 systemStats?.systemHealth === "good" ? "Good" : "Needs Attention"}
              </div>
              <p className="text-xs text-gray-300">
                {systemStats?.uptime || "Unknown"} uptime
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Admin Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-gray-800/50 border-gray-700">
            <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600">
              Overview
            </TabsTrigger>
            <TabsTrigger value="data" className="data-[state=active]:bg-purple-600">
              Data Management
            </TabsTrigger>
            <TabsTrigger value="users" className="data-[state=active]:bg-purple-600">
              User Management
            </TabsTrigger>
            <TabsTrigger value="system" className="data-[state=active]:bg-purple-600">
              System Operations
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-purple-600">
              Analytics
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Activity */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Recent System Activity</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Database Integration</span>
                    <Badge variant="outline" className="border-green-500 text-green-400">
                      {integrationStatus?.status || "Unknown"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Last Backup</span>
                    <span className="text-gray-300 text-sm">
                      {systemStats?.lastBackup || "Never"}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Data Quality Score</span>
                    <span className="text-purple-400 font-semibold">
                      {systemStats?.dataQualityScore || "N/A"}/10
                    </span>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    onClick={() => runFullIntegration.mutate()}
                    disabled={runFullIntegration.isPending || activeOperation === "integration"}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                  >
                    {activeOperation === "integration" ? (
                      <>
                        <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                        Running Integration...
                      </>
                    ) : (
                      <>
                        <Download className="mr-2 h-4 w-4" />
                        Run Full Data Integration
                      </>
                    )}
                  </Button>
                  
                  <Button
                    onClick={() => optimizeDatabase.mutate()}
                    disabled={optimizeDatabase.isPending || activeOperation === "optimize"}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    {activeOperation === "optimize" ? (
                      <>
                        <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                        Optimizing...
                      </>
                    ) : (
                      <>
                        <Settings className="mr-2 h-4 w-4" />
                        Optimize Database
                      </>
                    )}
                  </Button>
                  
                  <Button
                    onClick={() => backupDatabase.mutate()}
                    disabled={backupDatabase.isPending || activeOperation === "backup"}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    {activeOperation === "backup" ? (
                      <>
                        <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                        Creating Backup...
                      </>
                    ) : (
                      <>
                        <Upload className="mr-2 h-4 w-4" />
                        Create Database Backup
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Data Management Tab */}
          <TabsContent value="data" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* MaxValue + Leafly Integration */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">MaxValue + Leafly Integration</CardTitle>
                  <p className="text-gray-300 text-sm">
                    Combine lab-verified terpene data with strain metadata
                  </p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-300">Integration Progress</span>
                      <span className="text-gray-300">
                        {integrationStatus?.progress || 0}%
                      </span>
                    </div>
                    <Progress 
                      value={integrationStatus?.progress || 0} 
                      className="h-2"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-gray-300">Leafly Strains</div>
                      <div className="text-white font-semibold">
                        {integrationStatus?.leaflyCount || 0}
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-300">MaxValue Records</div>
                      <div className="text-white font-semibold">
                        {integrationStatus?.maxValueCount || 0}
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={() => runFullIntegration.mutate()}
                    disabled={runFullIntegration.isPending}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                  >
                    {runFullIntegration.isPending ? (
                      <>
                        <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Play className="mr-2 h-4 w-4" />
                        Start Integration
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Database Operations */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Database Operations</CardTitle>
                  <p className="text-gray-300 text-sm">
                    Maintenance and optimization tools
                  </p>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <div className="text-gray-300">Total Records</div>
                      <div className="text-white font-semibold">
                        {systemStats?.totalRecords || 0}
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-300">Database Size</div>
                      <div className="text-white font-semibold">
                        {systemStats?.databaseSize || "Unknown"}
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={() => optimizeDatabase.mutate()}
                    disabled={optimizeDatabase.isPending}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    <Settings className="mr-2 h-4 w-4" />
                    Optimize Performance
                  </Button>

                  <Button
                    onClick={() => backupDatabase.mutate()}
                    disabled={backupDatabase.isPending}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    Create Backup
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* User Management Tab */}
          <TabsContent value="users" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">User Management</CardTitle>
                <p className="text-gray-300 text-sm">
                  Manage user accounts, permissions, and activity
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <div className="text-sm text-gray-300">Total Users</div>
                    <div className="text-2xl font-bold text-white">
                      {userStats?.totalUsers || 0}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-sm text-gray-300">Active Today</div>
                    <div className="text-2xl font-bold text-green-400">
                      {userStats?.activeToday || 0}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-sm text-gray-300">Admins</div>
                    <div className="text-2xl font-bold text-purple-400">
                      {userStats?.adminCount || 0}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Operations Tab */}
          <TabsContent value="system" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* System Monitoring */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">System Monitoring</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Server Status</span>
                    <Badge className="bg-green-600">Online</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Database Status</span>
                    <Badge className="bg-green-600">Connected</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Spotify API</span>
                    <Badge className="bg-green-600">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Memory Usage</span>
                    <span className="text-gray-300">
                      {systemStats?.memoryUsage || "Unknown"}
                    </span>
                  </div>
                </CardContent>
              </Card>

              {/* Maintenance Tools */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Maintenance Tools</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full bg-yellow-600 hover:bg-yellow-700">
                    <AlertTriangle className="mr-2 h-4 w-4" />
                    Clear Cache
                  </Button>
                  <Button className="w-full bg-orange-600 hover:bg-orange-700">
                    <RotateCw className="mr-2 h-4 w-4" />
                    Restart Services
                  </Button>
                  <Button 
                    variant="destructive" 
                    className="w-full"
                    disabled
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Reset Database (Disabled)
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Platform Analytics</CardTitle>
                <p className="text-gray-300 text-sm">
                  Usage statistics and performance metrics
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="space-y-2">
                    <div className="text-sm text-gray-300">Daily Active Users</div>
                    <div className="text-2xl font-bold text-white">
                      {systemStats?.dailyActiveUsers || 0}
                    </div>
                    <div className="text-xs text-green-400">
                      +{systemStats?.dailyGrowth || 0}% from yesterday
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-sm text-gray-300">Playlists Generated</div>
                    <div className="text-2xl font-bold text-white">
                      {systemStats?.dailyPlaylists || 0}
                    </div>
                    <div className="text-xs text-blue-400">
                      {systemStats?.avgPlaylistsPerUser || 0} avg per user
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-sm text-gray-300">Popular Strains</div>
                    <div className="text-2xl font-bold text-white">
                      {systemStats?.topStrainRequests || 0}
                    </div>
                    <div className="text-xs text-purple-400">
                      searches today
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-sm text-gray-300">Data Quality</div>
                    <div className="text-2xl font-bold text-white">
                      {systemStats?.dataQualityScore || 0}/10
                    </div>
                    <div className="text-xs text-yellow-400">
                      {systemStats?.qualityTrend || "Stable"} trend
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}