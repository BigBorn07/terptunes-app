import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/navbar";
import { StrainCard } from "@/components/strain-card";
import { PlaylistCard } from "@/components/playlist-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  TrendingUp, 
  Music, 
  Leaf, 
  Database,
  Play,
  Search,
  ArrowRight
} from "lucide-react";
import { Link } from "wouter";
import { Strain, Playlist } from "@/types";

export default function Home() {
  const { data: popularStrains, isLoading: strainsLoading } = useQuery({
    queryKey: ["/api/strains/popular"],
  });

  const { data: strainStats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/strains/stats"],
  });

  const { data: recentPlaylists, isLoading: playlistsLoading } = useQuery({
    queryKey: ["/api/user/playlists"],
    retry: false,
  });

  const handleGeneratePlaylist = async (strain: Strain) => {
    // This would trigger the playlist generation flow
    console.log("Generating playlist for:", strain.name);
  };

  const handlePlayPlaylist = (playlist: Playlist) => {
    window.open(`https://open.spotify.com/playlist/${playlist.spotifyPlaylistId}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Navbar />
      
      <main className="pt-20 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Hero Section */}
          <section className="py-12">
            <div className="text-center mb-12">
              <h1 className="text-4xl lg:text-5xl font-display font-bold mb-4">
                Welcome to <span className="text-cannabis-gradient">TerpTunes</span>
              </h1>
              <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                Discover the perfect soundtrack for your cannabis experience through science-backed terpene analysis
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <Card className="glassmorphism">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 cannabis-gradient rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Search className="text-white w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">Explore Strains</h3>
                  <p className="text-gray-300 text-sm mb-4">Browse our database of 27,000+ cannabis products</p>
                  <Link href="/discover">
                    <Button className="w-full cannabis-gradient">
                      Start Exploring
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="glassmorphism">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 purple-gradient rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Music className="text-white w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">Generate Playlists</h3>
                  <p className="text-gray-300 text-sm mb-4">Create personalized Spotify playlists instantly</p>
                  <Button variant="outline" className="w-full border-purple-500 text-purple-400">
                    <Music className="w-4 h-4 mr-2" />
                    Connect Spotify
                  </Button>
                </CardContent>
              </Card>

              <Card className="glassmorphism">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="text-white w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">Track Preferences</h3>
                  <p className="text-gray-300 text-sm mb-4">Monitor your music and terpene preferences</p>
                  <Link href="/dashboard">
                    <Button variant="outline" className="w-full border-blue-500 text-blue-400">
                      View Dashboard
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </section>

          {/* Stats Section */}
          <section className="mb-12">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="glassmorphism">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-400 mb-1">
                    {statsLoading ? <Skeleton className="h-8 w-16 mx-auto" /> : strainStats?.totalStrains?.toLocaleString() || "731+"}
                  </div>
                  <div className="text-sm text-gray-300">Lab-Tested Strains</div>
                </CardContent>
              </Card>

              <Card className="glassmorphism">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-purple-400 mb-1">
                    {statsLoading ? <Skeleton className="h-8 w-12 mx-auto" /> : "3,140+"}
                  </div>
                  <div className="text-sm text-gray-300">Terpene Profiles</div>
                </CardContent>
              </Card>

              <Card className="glassmorphism">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-400 mb-1">
                    {statsLoading ? <Skeleton className="h-8 w-12 mx-auto" /> : strainStats?.avgThc?.toFixed(1) + "%" || "19.2%"}
                  </div>
                  <div className="text-sm text-gray-300">Avg THC Content</div>
                </CardContent>
              </Card>

              <Card className="glassmorphism">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-400 mb-1">
                    {recentPlaylists?.length || "0"}
                  </div>
                  <div className="text-sm text-gray-300">Your Playlists</div>
                </CardContent>
              </Card>
            </div>
          </section>

          {/* Popular Strains Section */}
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-display font-bold text-white">Popular Strains</h2>
              <Link href="/discover">
                <Button variant="ghost" className="text-green-400 hover:text-green-300">
                  View All <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {strainsLoading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <Card key={i} className="glassmorphism">
                    <CardContent className="p-6">
                      <Skeleton className="h-32 w-full mb-4" />
                      <Skeleton className="h-6 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2 mb-4" />
                      <div className="space-y-2 mb-4">
                        <Skeleton className="h-3 w-full" />
                        <Skeleton className="h-3 w-full" />
                        <Skeleton className="h-3 w-3/4" />
                      </div>
                      <Skeleton className="h-10 w-full" />
                    </CardContent>
                  </Card>
                ))
              ) : (
                popularStrains?.slice(0, 4).map((strain: Strain) => (
                  <StrainCard
                    key={strain.name}
                    strain={strain}
                    onGeneratePlaylist={handleGeneratePlaylist}
                  />
                ))
              )}
            </div>
          </section>

          {/* Recent Playlists Section */}
          {recentPlaylists && recentPlaylists.length > 0 && (
            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-display font-bold text-white">Recent Playlists</h2>
                <Link href="/dashboard">
                  <Button variant="ghost" className="text-green-400 hover:text-green-300">
                    View All <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>

              <div className="space-y-4">
                {recentPlaylists.slice(0, 3).map((playlist: Playlist) => (
                  <PlaylistCard
                    key={playlist.id}
                    playlist={playlist}
                    onPlay={handlePlayPlaylist}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Top Terpenes Section */}
          {strainStats?.topTerpenes && (
            <section className="mt-12">
              <h2 className="text-2xl font-display font-bold text-white mb-6">Popular Terpenes</h2>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {strainStats.topTerpenes.map((terpene: { name: string; count: number }, index) => (
                  <Card key={terpene.name} className="glassmorphism text-center">
                    <CardContent className="p-4">
                      <div className="text-lg font-semibold text-white capitalize mb-1">
                        {terpene.name}
                      </div>
                      <div className="text-sm text-gray-300">
                        {terpene.count} strains
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>
          )}
        </div>
      </main>
    </div>
  );
}
