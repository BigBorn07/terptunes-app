import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { 
  Building2, 
  Leaf, 
  TrendingUp, 
  Users, 
  Music, 
  BarChart3,
  Star,
  Award,
  Package,
  MapPin,
  Calendar,
  Globe,
  CheckCircle,
  Plus,
  Eye,
  Download,
  Share2,
  Target,
  Zap
} from "lucide-react";

export default function PartnerPortal() {
  const { user, isLoading } = useAuth();

  // Mock partner data - in real app this would come from API
  const partnerData = {
    name: "Green Valley Dispensary",
    type: "Dispensary",
    logo: "/api/placeholder/120/120",
    verified: true,
    memberSince: "March 2024",
    location: "Los Angeles, CA",
    website: "greenvalleydispensary.com",
    rating: 4.8,
    totalStrains: 45,
    activePromotions: 8,
    monthlyCustomers: 2847,
    playlistViews: 12500,
    revenue: "$142,500",
    growthRate: 23.5
  };

  const strainPerformance = [
    { name: "OG Kush", sales: 245, playlists: 89, revenue: "$12,300" },
    { name: "Blue Dream", sales: 198, playlists: 76, revenue: "$9,900" },
    { name: "Wedding Cake", sales: 167, playlists: 64, revenue: "$8,350" },
    { name: "Gelato", sales: 134, playlists: 52, revenue: "$6,700" },
    { name: "Gorilla Glue", sales: 123, playlists: 48, revenue: "$6,150" }
  ];

  const promotions = [
    { 
      id: 1, 
      title: "Chill Vibes Sunday", 
      strain: "Northern Lights", 
      discount: "25% Off",
      playlist: "Sunday Relaxation Mix",
      active: true,
      views: 1250
    },
    { 
      id: 2, 
      title: "Creative Flow Friday", 
      strain: "Sour Diesel", 
      discount: "20% Off",
      playlist: "Focus & Flow Beats",
      active: true,
      views: 980
    },
    { 
      id: 3, 
      title: "Weekend Party Pack", 
      strain: "Green Crack", 
      discount: "15% Off",
      playlist: "High Energy Party Mix",
      active: false,
      views: 2100
    }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white">Loading partner portal...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16">
              <AvatarImage src={partnerData.logo} alt={partnerData.name} />
              <AvatarFallback className="bg-green-600 text-white">
                <Building2 className="w-8 h-8" />
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-3xl font-bold">{partnerData.name}</h1>
                {partnerData.verified && (
                  <CheckCircle className="w-6 h-6 text-green-500" />
                )}
              </div>
              <div className="flex items-center gap-4 text-gray-300">
                <Badge variant="outline" className="text-green-500 border-green-500">
                  {partnerData.type}
                </Badge>
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  {partnerData.location}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Member since {partnerData.memberSince}
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex gap-3">
            <Button variant="outline" className="border-gray-600">
              <Download className="w-4 h-4 mr-2" />
              Analytics Report
            </Button>
            <Button className="bg-green-600 hover:bg-green-700">
              <Plus className="w-4 h-4 mr-2" />
              New Promotion
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm">Monthly Revenue</p>
                  <p className="text-2xl font-bold text-green-500">{partnerData.revenue}</p>
                  <p className="text-xs text-green-400 flex items-center gap-1 mt-1">
                    <TrendingUp className="w-3 h-3" />
                    +{partnerData.growthRate}% this month
                  </p>
                </div>
                <BarChart3 className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm">Active Strains</p>
                  <p className="text-2xl font-bold text-white">{partnerData.totalStrains}</p>
                  <p className="text-xs text-gray-300 mt-1">8 new this week</p>
                </div>
                <Leaf className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm">Playlist Views</p>
                  <p className="text-2xl font-bold text-white">{partnerData.playlistViews.toLocaleString()}</p>
                  <p className="text-xs text-blue-400 mt-1">4.2k this week</p>
                </div>
                <Music className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm">Monthly Customers</p>
                  <p className="text-2xl font-bold text-white">{partnerData.monthlyCustomers.toLocaleString()}</p>
                  <p className="text-xs text-purple-400 mt-1">+15% from last month</p>
                </div>
                <Users className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-gray-900 border-gray-700">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="strains">Strain Performance</TabsTrigger>
            <TabsTrigger value="promotions">Promotions</TabsTrigger>
            <TabsTrigger value="playlists">Playlists</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Partner Profile */}
              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-green-500" />
                    Partner Profile
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Business Type</span>
                    <Badge variant="outline">{partnerData.type}</Badge>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Rating</span>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span className="text-white">{partnerData.rating}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Website</span>
                    <a 
                      href={`https://${partnerData.website}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-green-500 hover:text-green-400 flex items-center gap-1"
                    >
                      <Globe className="w-4 h-4" />
                      {partnerData.website}
                    </a>
                  </div>
                  
                  <div className="pt-4 border-t border-gray-700">
                    <h4 className="font-semibold mb-2">Partner Benefits</h4>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span>Verified partner badge</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span>Priority playlist features</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span>Advanced analytics dashboard</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span>Custom promotion tools</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="bg-gray-900 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-500" />
                    Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full bg-green-600 hover:bg-green-700 justify-start">
                    <Plus className="w-4 h-4 mr-2" />
                    Add New Strain
                  </Button>
                  
                  <Button variant="outline" className="w-full border-gray-600 justify-start">
                    <Target className="w-4 h-4 mr-2" />
                    Create Promotion
                  </Button>
                  
                  <Button variant="outline" className="w-full border-gray-600 justify-start">
                    <Music className="w-4 h-4 mr-2" />
                    Generate Playlist
                  </Button>
                  
                  <Button variant="outline" className="w-full border-gray-600 justify-start">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    View Analytics
                  </Button>
                  
                  <Button variant="outline" className="w-full border-gray-600 justify-start">
                    <Share2 className="w-4 h-4 mr-2" />
                    Share Partner Profile
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card className="bg-gray-900 border-gray-700">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 bg-gray-800 rounded-lg">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-white text-sm">New strain "Purple Haze" added to inventory</p>
                      <p className="text-gray-300 text-xs">2 hours ago</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-gray-800 rounded-lg">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-white text-sm">Playlist "Chill Vibes Sunday" reached 1,000 views</p>
                      <p className="text-gray-300 text-xs">5 hours ago</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-gray-800 rounded-lg">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-white text-sm">Weekly analytics report generated</p>
                      <p className="text-gray-300 text-xs">1 day ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Strain Performance Tab */}
          <TabsContent value="strains" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Top Performing Strains</h2>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Strain
              </Button>
            </div>

            <div className="grid gap-4">
              {strainPerformance.map((strain, index) => (
                <Card key={strain.name} className="bg-gray-900 border-gray-700">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center">
                          <Leaf className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-white">{strain.name}</h3>
                          <p className="text-gray-300 text-sm">#{index + 1} Best Seller</p>
                        </div>
                      </div>
                      
                      <div className="flex gap-8 text-right">
                        <div>
                          <p className="text-white font-semibold">{strain.sales}</p>
                          <p className="text-gray-300 text-xs">Sales</p>
                        </div>
                        <div>
                          <p className="text-white font-semibold">{strain.playlists}</p>
                          <p className="text-gray-300 text-xs">Playlists</p>
                        </div>
                        <div>
                          <p className="text-green-500 font-semibold">{strain.revenue}</p>
                          <p className="text-gray-300 text-xs">Revenue</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Promotions Tab */}
          <TabsContent value="promotions" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Active Promotions</h2>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                Create Promotion
              </Button>
            </div>

            <div className="grid gap-4">
              {promotions.map((promo) => (
                <Card key={promo.id} className="bg-gray-900 border-gray-700">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center">
                          <Target className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-white">{promo.title}</h3>
                          <p className="text-gray-300 text-sm">{promo.strain} • {promo.playlist}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4">
                        <Badge 
                          variant={promo.active ? "default" : "outline"}
                          className={promo.active ? "bg-green-600" : "border-gray-600"}
                        >
                          {promo.active ? "Active" : "Inactive"}
                        </Badge>
                        <div className="text-right">
                          <p className="text-white font-semibold">{promo.discount}</p>
                          <p className="text-gray-300 text-xs">{promo.views} views</p>
                        </div>
                        <Button size="sm" variant="outline" className="border-gray-600">
                          <Eye className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Playlists Tab */}
          <TabsContent value="playlists" className="space-y-6">
            <div className="text-center py-12">
              <Music className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Playlist Management</h3>
              <p className="text-gray-300 mb-6">Create and manage playlists for your strains</p>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Playlist
              </Button>
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="text-center py-12">
              <BarChart3 className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Advanced Analytics</h3>
              <p className="text-gray-300 mb-6">Detailed insights and performance metrics</p>
              <Button className="bg-green-600 hover:bg-green-700">
                <Download className="w-4 h-4 mr-2" />
                Generate Report
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}