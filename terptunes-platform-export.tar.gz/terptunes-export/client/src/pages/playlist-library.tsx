import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Music, 
  Play, 
  Heart, 
  ExternalLink, 
  Search, 
  TrendingUp, 
  Clock,
  Users,
  Filter
} from "lucide-react";
import { Playlist, Strain } from "@shared/schema";

interface PlaylistWithStrain extends Playlist {
  strain?: Strain;
}

export default function PlaylistLibrary() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [selectedStrain, setSelectedStrain] = useState<number | null>(null);

  // Fetch strains for dropdown
  const { data: strainsData } = useQuery({
    queryKey: ['/api/strains', { limit: 100 }],
  });

  // Fetch popular playlists
  const { data: popularPlaylists, isLoading: loadingPopular } = useQuery({
    queryKey: ['/api/playlists/popular'],
  });

  // Fetch public playlists
  const { data: publicPlaylists, isLoading: loadingPublic } = useQuery({
    queryKey: ['/api/playlists/public'],
  });

  // Search playlists
  const { data: searchResults, isLoading: loadingSearch } = useQuery({
    queryKey: ['/api/playlists/search', { q: searchQuery }],
    enabled: searchQuery.length > 2,
  });

  // Playlists by genre
  const { data: genrePlaylists, isLoading: loadingGenre } = useQuery({
    queryKey: [`/api/playlists/by-genre/${selectedGenre}`],
    enabled: !!selectedGenre,
  });

  // Playlists by mood
  const { data: moodPlaylists, isLoading: loadingMood } = useQuery({
    queryKey: [`/api/playlists/by-mood/${selectedMood}`],
    enabled: !!selectedMood,
  });

  // Playlists by strain
  const { data: strainPlaylists, isLoading: loadingStrain } = useQuery({
    queryKey: [`/api/playlists/by-strain/${selectedStrain}`],
    enabled: !!selectedStrain,
  });

  const genres = [
    "ambient", "blues", "chill", "classical", "country", "dance", 
    "electronic", "folk", "funk", "hip-hop", "house", "indie", 
    "jazz", "lo-fi", "metal", "pop", "punk", "r-n-b", "reggae", 
    "rock", "soul", "techno", "trance", "world"
  ];

  const moods = [
    "relaxing", "energetic", "focused", "creative", "meditative", 
    "euphoric", "sleepy", "uplifting", "calming", "motivating"
  ];

  const PlaylistCard = ({ playlist }: { playlist: Playlist }) => (
    <Card className="group hover:shadow-lg transition-all duration-200 bg-gray-800/50 border-gray-700">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="font-semibold text-lg text-white group-hover:text-green-400 transition-colors">
              {playlist.name}
            </h3>
            <p className="text-sm text-gray-300 mt-1 line-clamp-2">
              {playlist.description}
            </p>
          </div>
          <Button 
            size="sm" 
            variant="ghost" 
            className="p-2 text-gray-300 hover:text-green-400"
            onClick={() => {
              if (playlist.spotifyUrl) {
                window.open(playlist.spotifyUrl, '_blank');
              }
            }}
          >
            <ExternalLink className="w-4 h-4" />
          </Button>
        </div>

        <div className="space-y-2 mb-4">
          <div className="flex items-center gap-2 flex-wrap">
            {playlist.primaryGenre && (
              <Badge variant="outline" className="text-xs">
                {playlist.primaryGenre}
              </Badge>
            )}
            {playlist.mood && (
              <Badge variant="secondary" className="text-xs">
                {playlist.mood}
              </Badge>
            )}
          </div>
          
          <div className="flex items-center gap-4 text-xs text-gray-300">
            <div className="flex items-center gap-1">
              <Music className="w-3 h-3" />
              {playlist.trackCount || 0} tracks
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {playlist.duration || 0}m
            </div>
            <div className="flex items-center gap-1">
              <Heart className="w-3 h-3" />
              {playlist.likeCount || 0}
            </div>
            <div className="flex items-center gap-1">
              <Play className="w-3 h-3" />
              {playlist.playCount || 0}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <Button 
            size="sm" 
            className="bg-green-600 hover:bg-green-700"
            onClick={() => {
              if (playlist.spotifyUrl) {
                window.open(playlist.spotifyUrl, '_blank');
              }
            }}
          >
            <Play className="w-4 h-4 mr-2" />
            Play on Spotify
          </Button>
          
          <div className="flex items-center gap-2">
            <Button size="sm" variant="ghost" className="p-2">
              <Heart className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const PlaylistGrid = ({ playlists, isLoading }: { playlists?: Playlist[], isLoading: boolean }) => {
    if (isLoading) {
      return (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <Card key={i} className="animate-pulse bg-gray-800/50">
              <CardContent className="p-4">
                <div className="h-6 bg-gray-700 rounded mb-2"></div>
                <div className="h-4 bg-gray-700 rounded w-3/4 mb-4"></div>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-700 rounded w-1/2"></div>
                  <div className="h-8 bg-gray-700 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      );
    }

    if (!playlists || playlists.length === 0) {
      return (
        <div className="text-center py-12">
          <Music className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-300 text-lg">No playlists found</p>
        </div>
      );
    }

    return (
      <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {playlists.map((playlist) => (
          <PlaylistCard key={playlist.id} playlist={playlist} />
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-display font-bold text-white mb-4">
            Playlist <span className="text-green-400">Library</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Discover curated playlists created from cannabis terpene profiles. Find the perfect soundtrack for every strain and mood.
          </p>
        </div>

        {/* Search and Filters */}
        <Card className="mb-8 bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-5 h-5" />
                  <Input
                    placeholder="Search playlists by name, genre, or mood..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
              
              <div className="flex gap-2">
                <select
                  value={selectedGenre || ''}
                  onChange={(e) => setSelectedGenre(e.target.value || null)}
                  className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                >
                  <option value="">All Genres</option>
                  {genres.map(genre => (
                    <option key={genre} value={genre} className="capitalize">
                      {genre}
                    </option>
                  ))}
                </select>
                
                <select
                  value={selectedMood || ''}
                  onChange={(e) => setSelectedMood(e.target.value || null)}
                  className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                >
                  <option value="">All Moods</option>
                  {moods.map(mood => (
                    <option key={mood} value={mood} className="capitalize">
                      {mood}
                    </option>
                  ))}
                </select>
                
                <select
                  value={selectedStrain || ''}
                  onChange={(e) => setSelectedStrain(e.target.value ? parseInt(e.target.value) : null)}
                  className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                >
                  <option value="">All Strains</option>
                  {strainsData?.strains?.map((strain: any) => (
                    <option key={strain.id} value={strain.id}>
                      {strain.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Content Tabs */}
        <Tabs defaultValue="popular" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8 bg-gray-800">
            <TabsTrigger value="popular" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Popular
            </TabsTrigger>
            <TabsTrigger value="recent" className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Recent
            </TabsTrigger>
            <TabsTrigger value="search" className="flex items-center gap-2" disabled={!searchQuery}>
              <Search className="w-4 h-4" />
              Search Results
            </TabsTrigger>
            <TabsTrigger value="filtered" className="flex items-center gap-2" disabled={!selectedGenre && !selectedMood && !selectedStrain}>
              <Filter className="w-4 h-4" />
              Filtered
            </TabsTrigger>
          </TabsList>

          <TabsContent value="popular">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-white mb-2">Most Popular Playlists</h2>
              <p className="text-gray-300">Top-rated playlists loved by the community</p>
            </div>
            <PlaylistGrid playlists={popularPlaylists} isLoading={loadingPopular} />
          </TabsContent>

          <TabsContent value="recent">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-white mb-2">Recently Created</h2>
              <p className="text-gray-300">Fresh playlists from the TerpTunes community</p>
            </div>
            <PlaylistGrid playlists={publicPlaylists} isLoading={loadingPublic} />
          </TabsContent>

          <TabsContent value="search">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-white mb-2">Search Results</h2>
              <p className="text-gray-300">Playlists matching "{searchQuery}"</p>
            </div>
            <PlaylistGrid playlists={searchResults} isLoading={loadingSearch} />
          </TabsContent>

          <TabsContent value="filtered">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-white mb-2">Filtered Results</h2>
              <p className="text-gray-300">
                {selectedStrain && selectedGenre && selectedMood ? 
                  `${selectedGenre} playlists for ${selectedMood} mood from strain ${strainsData?.strains?.find((s: any) => s.id === selectedStrain)?.name}` :
                 selectedStrain && selectedGenre ? 
                  `${selectedGenre} playlists from strain ${strainsData?.strains?.find((s: any) => s.id === selectedStrain)?.name}` :
                 selectedStrain && selectedMood ? 
                  `${selectedMood} mood playlists from strain ${strainsData?.strains?.find((s: any) => s.id === selectedStrain)?.name}` :
                 selectedStrain ? 
                  `Playlists from strain ${strainsData?.strains?.find((s: any) => s.id === selectedStrain)?.name}` :
                 selectedGenre && selectedMood ? 
                  `${selectedGenre} playlists for ${selectedMood} mood` :
                 selectedGenre ? 
                  `${selectedGenre} playlists` :
                 selectedMood ? 
                  `${selectedMood} mood playlists` : 
                  'Filtered playlists'}
              </p>
            </div>
            <PlaylistGrid 
              playlists={selectedStrain ? strainPlaylists : selectedGenre ? genrePlaylists : moodPlaylists} 
              isLoading={selectedStrain ? loadingStrain : selectedGenre ? loadingGenre : loadingMood} 
            />
          </TabsContent>
        </Tabs>

        {/* Quick Stats */}
        <Card className="mt-12 bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-center text-2xl text-white">
              Community Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-3xl font-bold text-green-400 mb-2">
                  {publicPlaylists?.length || 0}
                </div>
                <p className="text-gray-300">Total Playlists</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-purple-400 mb-2">
                  {genres.length}
                </div>
                <p className="text-gray-300">Musical Genres</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-blue-400 mb-2">
                  {moods.length}
                </div>
                <p className="text-gray-300">Mood Categories</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}