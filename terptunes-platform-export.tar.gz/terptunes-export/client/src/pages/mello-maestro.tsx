import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Leaf, ExternalLink, Star, Calendar, User, Headphones, Play, Music } from "lucide-react";

export default function MelloMaestro() {
  const featuredReviews = [
    {
      title: "OG Kush Deep Dive",
      description: "Journey to the legendary OG Kush planet, where ancient myrcene atmospheres create euphoric frequencies. Explore the cosmic genetics and terpene constellations of this celestial cultivar.",
      url: "https://mellowmaestro.com/podcasts/og-kush-analysis",
      category: "Strain Analysis",
      rating: 5,
      listenTime: "18 min listen",
      publishDate: "December 15, 2024",
      image: "https://images.unsplash.com/photo-1536431311719-398b6704d4cc?w=400&h=300&fit=crop&crop=center",
      playlistUrl: "https://open.spotify.com/playlist/3cEYpjA9g0FHmFiXFkHtSP",
      playlistTracks: 20
    },
    {
      title: "Wedding Cake Review",
      description: "Navigate the Wedding Cake constellation where vanilla-sweet terpene clouds drift through relaxing nebulas, perfect for evening cosmic meditations.",
      url: "https://mellowmaestro.com/podcasts/wedding-cake-review",
      category: "Strain Review",
      rating: 4.5,
      listenTime: "15 min listen",
      publishDate: "December 8, 2024",
      image: "https://images.unsplash.com/photo-1583137179004-13d5e7293b8a?w=400&h=300&fit=crop&crop=center",
      playlistUrl: "https://open.spotify.com/playlist/5xY3nA8m1VcHgFiXFkHtRQ",
      playlistTracks: 18
    },
    {
      title: "Blue Dream Experience",
      description: "Drift through the Blue Dream galaxy where limonene and pinene stars create balanced energy fields, harmonizing cerebral exploration with cosmic tranquility.",
      url: "https://mellowmaestro.com/podcasts/blue-dream-experience",
      category: "Experience Report",
      rating: 4.8,
      listenTime: "22 min listen",
      publishDate: "November 28, 2024",
      image: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400&h=300&fit=crop&crop=center",
      playlistUrl: "https://open.spotify.com/playlist/7zA1mB9l3KcHgFiXFkHtWE",
      playlistTracks: 22
    },
    {
      title: "Gorilla Glue Breakdown",
      description: "Explore the Gorilla Glue asteroid belt where powerful caryophyllene crystals form unbreakable bonds, creating sedative gravitational fields perfect for deep space relaxation.",
      url: "https://mellowmaestro.com/podcasts/gorilla-glue-breakdown",
      category: "Strain Analysis",
      rating: 4.7,
      listenTime: "20 min listen",
      publishDate: "November 20, 2024",
      image: "https://images.unsplash.com/photo-1536431311719-398b6704d4cc?w=400&h=300&fit=crop&crop=center&sat=-20&bright=10",
      playlistUrl: "https://open.spotify.com/playlist/9mP2cD4k7VcHgFiXFkHtZR",
      playlistTracks: 16
    },
    {
      title: "Terpene Profiles Guide",
      description: "Navigate the Terpene Academy space station where cosmic professors decode molecular frequencies across multiple dimensions of aromatic understanding.",
      url: "https://mellowmaestro.com/podcasts/terpene-profiles-guide",
      category: "Educational",
      rating: 5,
      listenTime: "25 min listen",
      publishDate: "November 10, 2024",
      image: "https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=400&h=300&fit=crop&crop=center",
      playlistUrl: "https://open.spotify.com/playlist/4bL8fE2n9VcHgFiXFkHtYS",
      playlistTracks: 24
    },
    {
      title: "Sativa vs Indica: The Truth",
      description: "Journey beyond the binary star system where ancient cosmic wisdom reveals the true nature of terpene diversity across infinite cannabis galaxies.",
      url: "https://mellowmaestro.com/podcasts/sativa-vs-indica-truth",
      category: "Educational",
      rating: 4.9,
      listenTime: "16 min listen",
      publishDate: "October 25, 2024",
      image: "https://images.unsplash.com/photo-1605007493699-48ad9bc9c1a5?w=400&h=300&fit=crop&crop=center",
      playlistUrl: "https://open.spotify.com/playlist/8kN5gH7m2VcHgFiXFkHtXT",
      playlistTracks: 19
    }
  ];

  const categories = [
    { name: "All", count: 24 },
    { name: "Strain Reviews", count: 12 },
    { name: "Strain Analysis", count: 8 },
    { name: "Educational", count: 6 },
    { name: "Experience Reports", count: 4 }
  ];

  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    const stars = [];

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />);
    }

    if (hasHalfStar) {
      stars.push(<Star key="half" className="w-4 h-4 fill-yellow-400/50 text-yellow-400" />);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="w-4 h-4 text-gray-600" />);
    }

    return stars;
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Leaf className="w-12 h-12 text-green-500" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-green-400 to-green-600 bg-clip-text text-transparent">
              The Adventures of Mello Maestro
            </h1>
          </div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Join the cosmic journey of a celestial being who harmonizes cannabis cultivars with cosmic frequencies. 
            Experience the Euphonic Odyssey through immersive audio adventures across the cannabis universe.
          </p>
        </div>

        {/* Author Bio */}
        <Card className="bg-gray-900 border-gray-700 mb-8">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center">
                <User className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white mb-2">About Mello Maestro</h3>
                <p className="text-gray-300 leading-relaxed">
                  A celestial being of three distinctive personas: Mello (Master Cannabis Aromatist), 
                  Maestro (Master Cosmic Curator), and their unified form. Hailing from planet Nanland 
                  in the Cannabi section of the Audo galaxy, Mello Maestro conducts the Euphonic Odyssey—
                  traversing universes to harmonize cannabis cultivars with cosmic frequencies and celestial melodies.
                </p>
                <div className="flex items-center gap-4 mt-3 text-sm text-gray-300">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    Journey began 2019
                  </span>
                  <span className="flex items-center gap-1">
                    <Headphones className="w-4 h-4" />
                    Cosmic audio curator
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Categories */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-4">Browse Categories</h2>
          <div className="flex flex-wrap gap-3">
            {categories.map((category) => (
              <Badge 
                key={category.name}
                variant="outline" 
                className="px-4 py-2 border-gray-600 text-gray-300 hover:bg-green-600 hover:border-green-600 hover:text-white cursor-pointer transition-colors"
              >
                {category.name} ({category.count})
              </Badge>
            ))}
          </div>
        </div>

        {/* Featured Podcast Episodes */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-6">Featured Podcast Episodes</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredReviews.map((review, index) => (
              <Card key={index} className="bg-gray-900 border-gray-700 hover:border-green-600 transition-colors group overflow-hidden">
                {/* Strain Image */}
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={review.image} 
                    alt={review.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3">
                    <Badge variant="outline" className="border-green-600 text-green-400 bg-black/50 backdrop-blur-sm">
                      {review.category}
                    </Badge>
                  </div>
                  <div className="absolute top-3 right-3 flex items-center gap-1 bg-black/50 backdrop-blur-sm rounded px-2 py-1">
                    {renderStars(review.rating)}
                  </div>
                </div>

                <CardHeader>
                  <CardTitle className="text-white group-hover:text-green-400 transition-colors">
                    {review.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 text-sm mb-4 line-clamp-3">
                    {review.description}
                  </p>
                  
                  <div className="flex items-center justify-between text-xs text-gray-300 mb-4">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {review.publishDate}
                    </span>
                    <span className="flex items-center gap-1">
                      <Headphones className="w-3 h-3" />
                      {review.listenTime}
                    </span>
                  </div>

                  {/* Curated Playlist Section */}
                  <div className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 rounded-lg p-3 mb-4 border border-purple-500/20">
                    <div className="flex items-center justify-between text-xs text-purple-200 mb-2">
                      <span className="flex items-center gap-1">
                        <Music className="w-3 h-3" />
                        Mello Maestro Curated Playlist
                      </span>
                      <span>{review.playlistTracks} tracks</span>
                    </div>
                    <a 
                      href={review.playlistUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" size="sm" className="w-full text-xs border-purple-400 text-purple-200 hover:bg-purple-800/30">
                        <Music className="w-3 h-3 mr-1" />
                        Open Cosmic Frequencies
                        <ExternalLink className="w-3 h-3 ml-1" />
                      </Button>
                    </a>
                  </div>

                  <a 
                    href={review.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full"
                  >
                    <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                      <Play className="w-4 h-4 mr-2" />
                      Listen Now
                      <ExternalLink className="w-4 h-4 ml-2" />
                    </Button>
                  </a>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <Card className="bg-gradient-to-r from-green-900 to-green-800 border-green-600">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-white mb-4">
              Join the Euphonic Odyssey
            </h3>
            <p className="text-green-100 mb-6 max-w-2xl mx-auto">
              Receive transmissions from across the cannabis universe. Stay connected to cosmic frequencies, 
              celestial strain discoveries, and terpene harmonies that transcend ordinary reality. Join fellow cosmic explorers.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="https://mellowmaestro.com/reviews" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Button size="lg" className="bg-white text-green-800 hover:bg-gray-100">
                  <ExternalLink className="w-5 h-5 mr-2" />
                  Visit Full Site
                </Button>
              </a>
              <a 
                href="https://mellowmaestro.com/subscribe" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-green-800">
                  Subscribe to Newsletter
                </Button>
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}