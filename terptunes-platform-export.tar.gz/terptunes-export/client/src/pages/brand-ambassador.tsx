import { BrandAmbassadorDashboard } from "@/components/BrandAmbassadorDashboard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Crown, Users, Gift, TrendingUp } from "lucide-react";

export default function BrandAmbassadorPage() {
  return (
    <div className="min-h-screen bg-gray-950 p-4">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header Section */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-white flex items-center justify-center gap-3">
            <Crown className="w-10 h-10 text-purple-500" />
            Brand Ambassador Program
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Become a brand ambassador by trying 10+ strains from the same cultivator. 
            Unlock exclusive rewards, early access, and VIP experiences with your favorite cannabis brands.
          </p>
        </div>

        {/* How It Works Section */}
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white text-2xl">How It Works</CardTitle>
            <CardDescription className="text-gray-300">
              Your journey to becoming a brand ambassador
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center space-y-3">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold">1. Explore Brands</h3>
                <p className="text-gray-300 text-sm">
                  Try different strains from various cultivators like Curio, Grow West, Grassroots, and more.
                </p>
              </div>
              
              <div className="text-center space-y-3">
                <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center mx-auto">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold">2. Track Progress</h3>
                <p className="text-gray-300 text-sm">
                  We automatically track your strain consumption and brand loyalty as you explore.
                </p>
              </div>
              
              <div className="text-center space-y-3">
                <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center mx-auto">
                  <Crown className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold">3. Qualify</h3>
                <p className="text-gray-300 text-sm">
                  Consume 10+ strains from the same brand to automatically qualify for ambassador status.
                </p>
              </div>
              
              <div className="text-center space-y-3">
                <div className="w-12 h-12 bg-yellow-600 rounded-full flex items-center justify-center mx-auto">
                  <Gift className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold">4. Enjoy Rewards</h3>
                <p className="text-gray-300 text-sm">
                  Access exclusive discounts, early releases, VIP events, and special merchandise.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Ambassador Levels */}
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white text-2xl">Ambassador Levels</CardTitle>
            <CardDescription className="text-gray-300">
              Unlock better rewards as you try more strains from each brand
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-amber-900/20 border border-amber-600 rounded-lg p-4 text-center">
                <div className="w-8 h-8 bg-amber-600 rounded-full mx-auto mb-2 flex items-center justify-center">
                  <Crown className="w-4 h-4 text-white" />
                </div>
                <h4 className="text-amber-400 font-semibold">Bronze</h4>
                <p className="text-sm text-gray-300">10-19 strains</p>
                <p className="text-xs text-gray-300 mt-1">Basic exclusive access</p>
              </div>
              
              <div className="bg-gray-700/20 border border-gray-400 rounded-lg p-4 text-center">
                <div className="w-8 h-8 bg-gray-400 rounded-full mx-auto mb-2 flex items-center justify-center">
                  <Crown className="w-4 h-4 text-white" />
                </div>
                <h4 className="text-gray-300 font-semibold">Silver</h4>
                <p className="text-sm text-gray-300">20-29 strains</p>
                <p className="text-xs text-gray-300 mt-1">Enhanced rewards + early access</p>
              </div>
              
              <div className="bg-yellow-900/20 border border-yellow-500 rounded-lg p-4 text-center">
                <div className="w-8 h-8 bg-yellow-500 rounded-full mx-auto mb-2 flex items-center justify-center">
                  <Crown className="w-4 h-4 text-white" />
                </div>
                <h4 className="text-yellow-400 font-semibold">Gold</h4>
                <p className="text-sm text-gray-300">30-49 strains</p>
                <p className="text-xs text-gray-300 mt-1">VIP events + limited editions</p>
              </div>
              
              <div className="bg-purple-900/20 border border-purple-500 rounded-lg p-4 text-center">
                <div className="w-8 h-8 bg-purple-500 rounded-full mx-auto mb-2 flex items-center justify-center">
                  <Crown className="w-4 h-4 text-white" />
                </div>
                <h4 className="text-purple-400 font-semibold">Platinum</h4>
                <p className="text-sm text-gray-300">50+ strains</p>
                <p className="text-xs text-gray-300 mt-1">Ultimate VIP experience</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Dashboard */}
        <BrandAmbassadorDashboard />
      </div>
    </div>
  );
}