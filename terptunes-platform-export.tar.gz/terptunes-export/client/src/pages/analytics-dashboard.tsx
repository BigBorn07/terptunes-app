import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { Activity, TrendingUp, Zap, Database, Search, Target, Award, BarChart3 } from "lucide-react";

interface PerformanceMetrics {
  timestamp: string;
  apiResponseTime: string;
  databaseMetrics: {
    totalStrains: number;
    queryTime: string;
  };
  recommendationEngine: {
    responseTime: string;
    confidence: number;
    genresGenerated: number;
  };
  searchEngine: {
    responseTime: string;
    resultsFound: number;
  };
  targetMetrics: {
    apiResponseTimeTarget: string;
    recommendationAccuracy: string;
    uptimeTarget: string;
  };
  status: "OPTIMAL" | "NEEDS_OPTIMIZATION";
}

interface TerpeneCorrelation {
  strainName: string;
  strainType: string;
  dominantTerpenes: Array<{ name: string; percentage: number }>;
  musicGenres: string[];
  mood: string;
  energy: number;
  confidence: number;
}

interface CorrelationAnalytics {
  totalAnalyzed: number;
  correlations: TerpeneCorrelation[];
  algorithm: string;
  timestamp: string;
}

export default function AnalyticsDashboard() {
  const [refreshKey, setRefreshKey] = useState(0);

  const { data: performanceMetrics, isLoading: metricsLoading } = useQuery<PerformanceMetrics>({
    queryKey: ["/api/metrics/performance", refreshKey],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: correlationData, isLoading: correlationsLoading } = useQuery<CorrelationAnalytics>({
    queryKey: ["/api/analytics/terpene-correlations", refreshKey],
    refetchInterval: 60000, // Refresh every minute
  });

  const refreshData = () => {
    setRefreshKey(prev => prev + 1);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "OPTIMAL": return "text-green-600 dark:text-green-400";
      case "NEEDS_OPTIMIZATION": return "text-yellow-600 dark:text-yellow-400";
      default: return "text-gray-600 dark:text-gray-300";
    }
  };

  const getResponseTimeValue = (timeString: string) => {
    return parseInt(timeString.replace('ms', ''));
  };

  const calculateProgress = (current: number, target: number) => {
    return Math.min((target / current) * 100, 100);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              TerpTunes Analytics Dashboard
            </h1>
            <p className="text-gray-600 dark:text-gray-300 mt-2">
              Real-time performance metrics and AI correlation insights for acquisition readiness
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="outline" className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
              <Activity className="w-4 h-4 mr-1" />
              Live Monitoring
            </Badge>
            <Button onClick={refreshData} variant="outline">
              <BarChart3 className="w-4 h-4 mr-2" />
              Refresh Data
            </Button>
          </div>
        </div>

        <Tabs defaultValue="performance" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="performance">System Performance</TabsTrigger>
            <TabsTrigger value="correlations">AI Correlations</TabsTrigger>
            <TabsTrigger value="acquisition">Acquisition Metrics</TabsTrigger>
          </TabsList>

          <TabsContent value="performance" className="space-y-6">
            {metricsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[...Array(4)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader className="pb-2">
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : performanceMetrics ? (
              <>
                {/* Key Performance Indicators */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center">
                        <Zap className="w-4 h-4 mr-2 text-blue-500" />
                        API Response Time
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{performanceMetrics.apiResponseTime}</div>
                      <div className="text-xs text-gray-300 mt-1">
                        Target: {performanceMetrics.targetMetrics.apiResponseTimeTarget}
                      </div>
                      <Progress 
                        value={calculateProgress(
                          getResponseTimeValue(performanceMetrics.apiResponseTime), 
                          200
                        )} 
                        className="mt-2" 
                      />
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center">
                        <Database className="w-4 h-4 mr-2 text-green-500" />
                        Database Strains
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{performanceMetrics.databaseMetrics.totalStrains.toLocaleString()}</div>
                      <div className="text-xs text-gray-300 mt-1">
                        Query: {performanceMetrics.databaseMetrics.queryTime}
                      </div>
                      <div className="flex items-center mt-2">
                        <TrendingUp className="w-3 h-3 text-green-500 mr-1" />
                        <span className="text-xs text-green-600 dark:text-green-400">Professional Grade</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center">
                        <Search className="w-4 h-4 mr-2 text-purple-500" />
                        Search Engine
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{performanceMetrics.searchEngine.responseTime}</div>
                      <div className="text-xs text-gray-300 mt-1">
                        {performanceMetrics.searchEngine.resultsFound} results found
                      </div>
                      <div className="flex items-center mt-2">
                        <Award className="w-3 h-3 text-purple-500 mr-1" />
                        <span className="text-xs text-purple-600 dark:text-purple-400">Advanced AI</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium flex items-center">
                        <Target className="w-4 h-4 mr-2 text-orange-500" />
                        AI Confidence
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {Math.round(performanceMetrics.recommendationEngine.confidence * 100)}%
                      </div>
                      <div className="text-xs text-gray-300 mt-1">
                        Response: {performanceMetrics.recommendationEngine.responseTime}
                      </div>
                      <Progress 
                        value={performanceMetrics.recommendationEngine.confidence * 100} 
                        className="mt-2" 
                      />
                    </CardContent>
                  </Card>
                </div>

                {/* System Status */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Activity className="w-5 h-5 mr-2" />
                      System Status Overview
                    </CardTitle>
                    <CardDescription>
                      Real-time performance analysis - Updated: {new Date(performanceMetrics.timestamp).toLocaleTimeString()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">Overall Status</span>
                          <Badge variant={performanceMetrics.status === "OPTIMAL" ? "default" : "secondary"}>
                            {performanceMetrics.status}
                          </Badge>
                        </div>
                        <div className={`text-lg font-semibold ${getStatusColor(performanceMetrics.status)}`}>
                          {performanceMetrics.status === "OPTIMAL" ? "All Systems Operational" : "Optimization Needed"}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="text-sm font-medium">Performance Targets</div>
                        <div className="space-y-1 text-sm text-gray-600 dark:text-gray-300">
                          <div>• API Response: {performanceMetrics.targetMetrics.apiResponseTimeTarget}</div>
                          <div>• Recommendation Accuracy: {performanceMetrics.targetMetrics.recommendationAccuracy}</div>
                          <div>• Uptime: {performanceMetrics.targetMetrics.uptimeTarget}</div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="text-sm font-medium">AI Engine Metrics</div>
                        <div className="space-y-1 text-sm text-gray-600 dark:text-gray-300">
                          <div>• Genres Generated: {performanceMetrics.recommendationEngine.genresGenerated}</div>
                          <div>• Response Time: {performanceMetrics.recommendationEngine.responseTime}</div>
                          <div>• Confidence Score: {Math.round(performanceMetrics.recommendationEngine.confidence * 100)}%</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card>
                <CardContent className="p-6">
                  <div className="text-center text-gray-300 dark:text-gray-300">
                    No performance data available
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="correlations" className="space-y-6">
            {correlationsLoading ? (
              <Card className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ) : correlationData ? (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <TrendingUp className="w-5 h-5 mr-2" />
                      Terpene-Music Correlation Analysis
                    </CardTitle>
                    <CardDescription>
                      AI-powered analysis of {correlationData.totalAnalyzed} strains using {correlationData.algorithm}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                          {correlationData.totalAnalyzed}
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-300">Strains Analyzed</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-green-600 dark:text-green-400">
                          {Math.round(correlationData.correlations.reduce((acc, c) => acc + c.confidence, 0) / correlationData.correlations.length * 100)}%
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-300">Avg Confidence</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-purple-600 dark:text-purple-400">
                          {new Set(correlationData.correlations.flatMap(c => c.musicGenres)).size}
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-300">Unique Genres</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {correlationData.correlations.slice(0, 6).map((correlation, index) => (
                    <Card key={index}>
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{correlation.strainName}</CardTitle>
                          <Badge variant="outline">{correlation.strainType}</Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <div className="text-sm font-medium mb-2">Dominant Terpenes</div>
                          <div className="flex flex-wrap gap-1">
                            {correlation.dominantTerpenes.map((terpene, i) => (
                              <Badge key={i} variant="secondary" className="text-xs">
                                {terpene.name} ({terpene.percentage.toFixed(1)}%)
                              </Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <div className="text-sm font-medium mb-2">Music Genres</div>
                          <div className="flex flex-wrap gap-1">
                            {correlation.musicGenres.map((genre, i) => (
                              <Badge key={i} variant="outline" className="text-xs capitalize">
                                {genre}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-sm">
                          <div>
                            <span className="font-medium">Mood:</span> 
                            <span className="ml-1 capitalize">{correlation.mood}</span>
                          </div>
                          <div>
                            <span className="font-medium">Energy:</span> 
                            <span className="ml-1">{correlation.energy}/10</span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">AI Confidence</span>
                          <div className="flex items-center space-x-2">
                            <Progress value={correlation.confidence * 100} className="w-20" />
                            <span className="text-sm">{Math.round(correlation.confidence * 100)}%</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </>
            ) : (
              <Card>
                <CardContent className="p-6">
                  <div className="text-center text-gray-300 dark:text-gray-300">
                    No correlation data available
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="acquisition" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Target className="w-5 h-5 mr-2 text-blue-500" />
                    Phase 1 KPIs
                  </CardTitle>
                  <CardDescription>Foundation metrics for acquisition readiness</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">API Response Time</span>
                    <Badge variant={performanceMetrics?.status === "OPTIMAL" ? "default" : "secondary"}>
                      {performanceMetrics?.apiResponseTime || "Loading..."}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Database Scale</span>
                    <Badge variant="default">
                      {performanceMetrics?.databaseMetrics.totalStrains.toLocaleString() || "Loading..."} strains
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">AI Accuracy</span>
                    <Badge variant="default">
                      {performanceMetrics ? Math.round(performanceMetrics.recommendationEngine.confidence * 100) : "Loading"}%
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Award className="w-5 h-5 mr-2 text-green-500" />
                    Core IP Assets
                  </CardTitle>
                  <CardDescription>Proprietary technology differentiators</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="text-sm font-medium">✓ Terpene-Music Correlation Algorithm</div>
                    <div className="text-sm font-medium">✓ Advanced Fuzzy Search Engine</div>
                    <div className="text-sm font-medium">✓ Professional Lab Data Integration</div>
                    <div className="text-sm font-medium">✓ Real-time Performance Analytics</div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2 text-purple-500" />
                    Market Position
                  </CardTitle>
                  <CardDescription>Competitive advantages and moats</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="text-sm">
                      <span className="font-medium">Data Moat:</span> 
                      <span className="ml-1">{performanceMetrics?.databaseMetrics.totalStrains.toLocaleString()}+ verified strains</span>
                    </div>
                    <div className="text-sm">
                      <span className="font-medium">Algorithm IP:</span> 
                      <span className="ml-1">Proprietary terpene mapping</span>
                    </div>
                    <div className="text-sm">
                      <span className="font-medium">Performance:</span> 
                      <span className="ml-1">Sub-200ms response times</span>
                    </div>
                    <div className="text-sm">
                      <span className="font-medium">Scalability:</span> 
                      <span className="ml-1">Enterprise-ready architecture</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Acquisition Readiness Scorecard</CardTitle>
                <CardDescription>
                  Key metrics demonstrating platform readiness for Series A and strategic acquisition
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <h4 className="font-semibold text-lg">Technical Excellence</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Performance Optimization</span>
                        <div className="flex items-center space-x-2">
                          <Progress value={performanceMetrics?.status === "OPTIMAL" ? 95 : 75} className="w-24" />
                          <span className="text-sm font-medium">95%</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Data Quality & Scale</span>
                        <div className="flex items-center space-x-2">
                          <Progress value={90} className="w-24" />
                          <span className="text-sm font-medium">90%</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">AI/ML Implementation</span>
                        <div className="flex items-center space-x-2">
                          <Progress value={85} className="w-24" />
                          <span className="text-sm font-medium">85%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-semibold text-lg">Market Readiness</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">IP Protection Strategy</span>
                        <div className="flex items-center space-x-2">
                          <Progress value={80} className="w-24" />
                          <span className="text-sm font-medium">80%</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">B2B Platform Features</span>
                        <div className="flex items-center space-x-2">
                          <Progress value={85} className="w-24" />
                          <span className="text-sm font-medium">85%</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Scalability Architecture</span>
                        <div className="flex items-center space-x-2">
                          <Progress value={90} className="w-24" />
                          <span className="text-sm font-medium">90%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <div className="flex items-center">
                    <Award className="w-5 h-5 text-blue-500 mr-2" />
                    <span className="font-semibold text-blue-900 dark:text-blue-100">
                      Overall Acquisition Readiness: 87%
                    </span>
                  </div>
                  <p className="text-sm text-blue-800 dark:text-blue-200 mt-2">
                    Platform demonstrates strong technical foundation, proprietary IP, and enterprise scalability required for strategic acquisition by major music or cannabis industry players.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}