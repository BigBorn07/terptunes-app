import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  Sprout, 
  Upload, 
  Music,
  Leaf,
  Plus,
  Play,
  BarChart3,
  Users,
  Star,
  TrendingUp,
  Target,
  Award
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import ProtectedRoute from "@/components/ProtectedRoute";

function GrowerPortalContent() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [newStrainData, setNewStrainData] = useState({
    name: "",
    type: "",
    thcContent: "",
    cbdContent: "",
    description: "",
    terpeneProfile: "",
    harvestDate: "",
    batchNumber: "",
    growerNotes: ""
  });

  const [newPlaylistData, setNewPlaylistData] = useState({
    strainId: "",
    playlistName: "",
    description: "",
    vibe: "",
    targetAudience: ""
  });

  // Fetch grower stats and uploads
  const { data: growerStats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/grower/stats"],
    refetchInterval: 30000,
  });

  // Fetch uploaded strains
  const { data: uploadedStrains, isLoading: strainsLoading } = useQuery({
    queryKey: ["/api/grower/uploaded-strains"],
  });

  // Fetch curated playlists
  const { data: curatedPlaylists, isLoading: playlistsLoading } = useQuery({
    queryKey: ["/api/grower/curated-playlists"],
  });

  // Fetch performance analytics
  const { data: performance, isLoading: performanceLoading } = useQuery({
    queryKey: ["/api/grower/performance"],
  });

  // Submit new strain mutation
  const submitStrain = useMutation({
    mutationFn: async (strainData: any) => {
      return await apiRequest("/api/grower/upload-strain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(strainData),
      });
    },
    onSuccess: () => {
      toast({
        title: "Strain Uploaded",
        description: "Your strain has been uploaded and will be available on TerpTunes shortly.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/grower/uploaded-strains"] });
      setNewStrainData({
        name: "",
        type: "",
        thcContent: "",
        cbdContent: "",
        description: "",
        terpeneProfile: "",
        harvestDate: "",
        batchNumber: "",
        growerNotes: ""
      });
    },
    onError: () => {
      toast({
        title: "Upload Failed",
        description: "Failed to upload strain. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Submit new playlist mutation
  const submitPlaylist = useMutation({
    mutationFn: async (playlistData: any) => {
      return await apiRequest("/api/grower/create-playlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(playlistData),
      });
    },
    onSuccess: () => {
      toast({
        title: "Playlist Created",
        description: "Your curated playlist has been created and is now live on TerpTunes.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/grower/curated-playlists"] });
      setNewPlaylistData({
        strainId: "",
        playlistName: "",
        description: "",
        vibe: "",
        targetAudience: ""
      });
    },
  });

  if (statsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-black">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-500 mx-auto"></div>
          <p className="text-white mt-4">Loading Grower Portal...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900 to-black text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Sprout className="w-8 h-8 text-green-400" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
              Grower Portal
            </h1>
          </div>
          <p className="text-xl text-gray-300">Upload your strains and create curated playlists for your grows</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-green-600">
              <BarChart3 className="w-4 h-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="upload-strains" className="data-[state=active]:bg-green-600">
              <Upload className="w-4 h-4 mr-2" />
              Upload Strains
            </TabsTrigger>
            <TabsTrigger value="create-playlists" className="data-[state=active]:bg-green-600">
              <Music className="w-4 h-4 mr-2" />
              Create Playlists
            </TabsTrigger>
            <TabsTrigger value="my-content" className="data-[state=active]:bg-green-600">
              <Leaf className="w-4 h-4 mr-2" />
              My Content
            </TabsTrigger>
            <TabsTrigger value="performance" className="data-[state=active]:bg-green-600">
              <TrendingUp className="w-4 h-4 mr-2" />
              Performance
            </TabsTrigger>
          </TabsList>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-300">Uploaded Strains</CardTitle>
                  <Leaf className="h-4 w-4 text-green-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{growerStats?.uploadedStrains || 23}</div>
                  <p className="text-xs text-gray-300">Active on TerpTunes</p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-300">Curated Playlists</CardTitle>
                  <Music className="h-4 w-4 text-blue-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{growerStats?.curatedPlaylists || 8}</div>
                  <p className="text-xs text-gray-300">+2 this month</p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-300">Monthly Plays</CardTitle>
                  <Play className="h-4 w-4 text-purple-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{growerStats?.monthlyPlays || 1247}</div>
                  <p className="text-xs text-gray-300">Your playlists played</p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-300">User Engagement</CardTitle>
                  <Users className="h-4 w-4 text-orange-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{growerStats?.userEngagement || "89%"}</div>
                  <p className="text-xs text-gray-300">Positive feedback</p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Target className="w-5 h-5 text-green-400" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gray-900 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <div>
                      <h4 className="font-medium text-white">Purple Punch uploaded</h4>
                      <p className="text-sm text-gray-300">Strain approved and live on platform</p>
                    </div>
                  </div>
                  <span className="text-sm text-gray-300">2 hours ago</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-900 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                    <div>
                      <h4 className="font-medium text-white">Chill Vibes playlist created</h4>
                      <p className="text-sm text-gray-300">For Blue Dream strain</p>
                    </div>
                  </div>
                  <span className="text-sm text-gray-300">1 day ago</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-900 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                    <div>
                      <h4 className="font-medium text-white">Wedding Cake playlist trending</h4>
                      <p className="text-sm text-gray-300">156 plays in last 24 hours</p>
                    </div>
                  </div>
                  <span className="text-sm text-gray-300">2 days ago</span>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Upload Strains */}
          <TabsContent value="upload-strains" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Upload className="w-5 h-5 text-green-400" />
                  Upload New Strain
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="strainName" className="text-gray-300">Strain Name</Label>
                    <Input
                      id="strainName"
                      value={newStrainData.name}
                      onChange={(e) => setNewStrainData({...newStrainData, name: e.target.value})}
                      placeholder="e.g., Purple Punch"
                      className="bg-gray-900 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="strainType" className="text-gray-300">Strain Type</Label>
                    <Select onValueChange={(value) => setNewStrainData({...newStrainData, type: value})}>
                      <SelectTrigger className="bg-gray-900 border-gray-600 text-white">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="indica">Indica</SelectItem>
                        <SelectItem value="sativa">Sativa</SelectItem>
                        <SelectItem value="hybrid">Hybrid</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="thcContent" className="text-gray-300">THC Content (%)</Label>
                    <Input
                      id="thcContent"
                      value={newStrainData.thcContent}
                      onChange={(e) => setNewStrainData({...newStrainData, thcContent: e.target.value})}
                      placeholder="e.g., 22.5"
                      className="bg-gray-900 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cbdContent" className="text-gray-300">CBD Content (%)</Label>
                    <Input
                      id="cbdContent"
                      value={newStrainData.cbdContent}
                      onChange={(e) => setNewStrainData({...newStrainData, cbdContent: e.target.value})}
                      placeholder="e.g., 0.5"
                      className="bg-gray-900 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="harvestDate" className="text-gray-300">Harvest Date</Label>
                    <Input
                      id="harvestDate"
                      type="date"
                      value={newStrainData.harvestDate}
                      onChange={(e) => setNewStrainData({...newStrainData, harvestDate: e.target.value})}
                      className="bg-gray-900 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="batchNumber" className="text-gray-300">Batch Number</Label>
                    <Input
                      id="batchNumber"
                      value={newStrainData.batchNumber}
                      onChange={(e) => setNewStrainData({...newStrainData, batchNumber: e.target.value})}
                      placeholder="e.g., PP-2024-001"
                      className="bg-gray-900 border-gray-600 text-white"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="description" className="text-gray-300">Description</Label>
                  <Textarea
                    id="description"
                    value={newStrainData.description}
                    onChange={(e) => setNewStrainData({...newStrainData, description: e.target.value})}
                    placeholder="Describe your strain's effects, flavor, and characteristics..."
                    className="bg-gray-900 border-gray-600 text-white"
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="terpeneProfile" className="text-gray-300">Terpene Profile</Label>
                  <Textarea
                    id="terpeneProfile"
                    value={newStrainData.terpeneProfile}
                    onChange={(e) => setNewStrainData({...newStrainData, terpeneProfile: e.target.value})}
                    placeholder="List dominant terpenes and percentages..."
                    className="bg-gray-900 border-gray-600 text-white"
                    rows={2}
                  />
                </div>
                <div>
                  <Label htmlFor="growerNotes" className="text-gray-300">Grower Notes</Label>
                  <Textarea
                    id="growerNotes"
                    value={newStrainData.growerNotes}
                    onChange={(e) => setNewStrainData({...newStrainData, growerNotes: e.target.value})}
                    placeholder="Growing conditions, special techniques, recommended use..."
                    className="bg-gray-900 border-gray-600 text-white"
                    rows={3}
                  />
                </div>
                <Button
                  onClick={() => submitStrain.mutate(newStrainData)}
                  disabled={submitStrain.isPending || !newStrainData.name || !newStrainData.type}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  {submitStrain.isPending ? "Uploading..." : "Upload Strain"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Create Playlists */}
          <TabsContent value="create-playlists" className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Music className="w-5 h-5 text-blue-400" />
                  Create Curated Playlist
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="strainSelect" className="text-gray-300">Select Your Strain</Label>
                  <Select onValueChange={(value) => setNewPlaylistData({...newPlaylistData, strainId: value})}>
                    <SelectTrigger className="bg-gray-900 border-gray-600 text-white">
                      <SelectValue placeholder="Choose a strain from your uploads" />
                    </SelectTrigger>
                    <SelectContent>
                      {uploadedStrains?.map((strain: any) => (
                        <SelectItem key={strain.id} value={strain.id.toString()}>
                          {strain.name} ({strain.type})
                        </SelectItem>
                      )) || [
                        <SelectItem key="1" value="1">Purple Punch (Indica)</SelectItem>,
                        <SelectItem key="2" value="2">Blue Dream (Sativa)</SelectItem>,
                        <SelectItem key="3" value="3">Wedding Cake (Hybrid)</SelectItem>
                      ]}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="playlistName" className="text-gray-300">Playlist Name</Label>
                  <Input
                    id="playlistName"
                    value={newPlaylistData.playlistName}
                    onChange={(e) => setNewPlaylistData({...newPlaylistData, playlistName: e.target.value})}
                    placeholder="e.g., Purple Punch Chill Sessions"
                    className="bg-gray-900 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="vibe" className="text-gray-300">Playlist Vibe</Label>
                  <Select onValueChange={(value) => setNewPlaylistData({...newPlaylistData, vibe: value})}>
                    <SelectTrigger className="bg-gray-900 border-gray-600 text-white">
                      <SelectValue placeholder="Select the mood/vibe" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="relaxing">Relaxing & Chill</SelectItem>
                      <SelectItem value="energetic">Energetic & Uplifting</SelectItem>
                      <SelectItem value="creative">Creative & Focus</SelectItem>
                      <SelectItem value="social">Social & Party</SelectItem>
                      <SelectItem value="meditative">Meditative & Spiritual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="targetAudience" className="text-gray-300">Target Audience</Label>
                  <Select onValueChange={(value) => setNewPlaylistData({...newPlaylistData, targetAudience: value})}>
                    <SelectTrigger className="bg-gray-900 border-gray-600 text-white">
                      <SelectValue placeholder="Who is this playlist for?" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginners">Cannabis Beginners</SelectItem>
                      <SelectItem value="experienced">Experienced Users</SelectItem>
                      <SelectItem value="medical">Medical Patients</SelectItem>
                      <SelectItem value="recreational">Recreational Users</SelectItem>
                      <SelectItem value="all">All Users</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="playlistDescription" className="text-gray-300">Playlist Description</Label>
                  <Textarea
                    id="playlistDescription"
                    value={newPlaylistData.description}
                    onChange={(e) => setNewPlaylistData({...newPlaylistData, description: e.target.value})}
                    placeholder="Describe the perfect listening experience for this strain..."
                    className="bg-gray-900 border-gray-600 text-white"
                    rows={3}
                  />
                </div>
                <Button
                  onClick={() => submitPlaylist.mutate(newPlaylistData)}
                  disabled={submitPlaylist.isPending || !newPlaylistData.strainId || !newPlaylistData.playlistName}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {submitPlaylist.isPending ? "Creating..." : "Create Playlist"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* My Content */}
          <TabsContent value="my-content" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Uploaded Strains */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Leaf className="w-5 h-5 text-green-400" />
                    My Uploaded Strains
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {uploadedStrains?.map((strain: any, index: number) => (
                    <div key={index} className="p-3 bg-gray-900 rounded-lg flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-white">{strain.name}</h4>
                        <p className="text-sm text-gray-300">{strain.type} • {strain.thc}% THC</p>
                      </div>
                      <Badge className="bg-green-600 text-white">{strain.status}</Badge>
                    </div>
                  )) || [
                    {
                      name: "Purple Punch",
                      type: "Indica", 
                      thc: "22",
                      status: "Live"
                    },
                    {
                      name: "Blue Dream",
                      type: "Sativa",
                      thc: "19", 
                      status: "Live"
                    },
                    {
                      name: "Wedding Cake",
                      type: "Hybrid",
                      thc: "25",
                      status: "Pending"
                    }
                  ].map((strain, index) => (
                    <div key={index} className="p-3 bg-gray-900 rounded-lg flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-white">{strain.name}</h4>
                        <p className="text-sm text-gray-300">{strain.type} • {strain.thc}% THC</p>
                      </div>
                      <Badge className={strain.status === "Live" ? "bg-green-600 text-white" : "bg-yellow-600 text-white"}>
                        {strain.status}
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Curated Playlists */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Music className="w-5 h-5 text-blue-400" />
                    My TerpTunes Curated Playlists
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {curatedPlaylists?.map((playlist: any, index: number) => (
                    <div key={index} className="p-3 bg-gray-900 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-white">{playlist.name}</h4>
                        <Badge className="bg-blue-600 text-white">{playlist.plays} plays</Badge>
                      </div>
                      <p className="text-sm text-gray-300">{playlist.strain} • {playlist.vibe}</p>
                    </div>
                  )) || [
                    {
                      name: "Purple Punch Chill Sessions",
                      strain: "Purple Punch",
                      vibe: "Relaxing",
                      plays: 247
                    },
                    {
                      name: "Blue Dream Energy Boost",
                      strain: "Blue Dream", 
                      vibe: "Energetic",
                      plays: 189
                    },
                    {
                      name: "Wedding Cake Social Vibes",
                      strain: "Wedding Cake",
                      vibe: "Social",
                      plays: 156
                    }
                  ].map((playlist, index) => (
                    <div key={index} className="p-3 bg-gray-900 rounded-lg border border-purple-500/20">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-white">{playlist.name}</h4>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-purple-600 text-white">24 tracks</Badge>
                          <Badge className="bg-blue-600 text-white">{playlist.plays} plays</Badge>
                        </div>
                      </div>
                      <p className="text-sm text-gray-300 mb-2">{playlist.strain} • {playlist.vibe}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-purple-400">TerpTunes Official</span>
                        <Button 
                          size="sm" 
                          className="bg-purple-600 hover:bg-purple-700 text-white h-6 px-3"
                          onClick={() => window.open("https://open.spotify.com/playlist/37i9dQZF1DXdXlbRAWwOJy", '_blank')}
                        >
                          <Play className="w-3 h-3 mr-1" />
                          Open Playlist
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Performance */}
          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <TrendingUp className="w-5 h-5 text-green-400" />
                    Strain Performance
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Purple Punch</span>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-400" />
                        <span className="text-white">4.8</span>
                      </div>
                      <span className="text-sm text-gray-300">247 reviews</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Blue Dream</span>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-400" />
                        <span className="text-white">4.6</span>
                      </div>
                      <span className="text-sm text-gray-300">189 reviews</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Wedding Cake</span>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-400" />
                        <span className="text-white">4.9</span>
                      </div>
                      <span className="text-sm text-gray-300">156 reviews</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Award className="w-5 h-5 text-blue-400" />
                    Playlist Engagement
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Total Plays</span>
                    <span className="text-xl font-bold text-white">1,247</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Average Rating</span>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-400" />
                      <span className="text-white">4.7</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Monthly Growth</span>
                    <span className="text-green-400">+23%</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default function GrowerPortalPage() {
  return (
    <ProtectedRoute 
      requiredRole="grower" 
      requiresVerification={true}
      requiresOnboarding={true}
    >
      <GrowerPortalContent />
    </ProtectedRoute>
  );
}