export interface Strain {
  id?: number;
  name: string;
  type: 'indica' | 'sativa' | 'hybrid';
  thcContent: string;
  cbdContent: string;
  description: string;
  effects: string[];
  flavors: string[];
  imageUrl?: string;
  terpenes: TerpeneProfile[];
  createdAt?: Date;
}

export interface TerpeneProfile {
  name: string;
  percentage: number;
}

export interface TerpeneInfo {
  name: string;
  effects: string[];
  description: string;
  musicalCharacteristics: string[];
  color: string;
}

export interface Playlist {
  id: number;
  userId: string;
  strainId?: number;
  spotifyPlaylistId: string;
  name: string;
  description: string;
  trackCount: number;
  duration: number;
  dominantTerpenes: string[];
  createdAt: Date;
}

export interface SpotifyTrack {
  id: string;
  name: string;
  artists: Array<{
    id: string;
    name: string;
  }>;
  album: {
    id: string;
    name: string;
    images: Array<{
      url: string;
      height: number;
      width: number;
    }>;
  };
  duration_ms: number;
  preview_url: string | null;
  external_urls: {
    spotify: string;
  };
}

export interface SpotifyPlaylist {
  id: string;
  name: string;
  description: string;
  tracks: {
    total: number;
  };
  external_urls: {
    spotify: string;
  };
  images: Array<{
    url: string;
    height: number;
    width: number;
  }>;
}

export interface UserPreferences {
  id: number;
  userId: string;
  favoriteTerpenes: string[];
  preferredGenres: string[];
  playlistDuration: number;
  explicitContent: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface StrainSearchParams {
  query?: string;
  type?: 'indica' | 'sativa' | 'hybrid';
  effects?: string[];
  terpenes?: string[];
  minThc?: number;
  maxThc?: number;
  limit?: number;
  offset?: number;
}

export interface StrainSearchResult {
  strains: Strain[];
  total: number;
  hasMore: boolean;
}

export interface User {
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
  spotifyId?: string;
  spotifyAccessToken?: string;
  spotifyRefreshToken?: string;
  createdAt?: Date;
  updatedAt?: Date;
}
