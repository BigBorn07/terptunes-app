# TerpTunes - Cannabis Strain to Music Matching Platform

## Overview

TerpTunes is a revolutionary web application that combines cannabis strain data with music recommendations. Using real terpene profiles from lab data, the platform generates personalized Spotify playlists based on the chemical composition and effects of different cannabis strains.

## Key Features

- **731 Cannabis Strains** with detailed terpene profiles
- **43,018 Lab Test Results** integrated from MaxValue and Leafly
- **Spotify Integration** for playlist generation
- **B2B Portals** for growers and dispensaries
- **Advanced Search** with filtering by type, effects, and terpenes
- **User Authentication** with role-based access control
- **Brand Ambassador Program** with loyalty rewards
- **Admin Dashboard** for platform management

## Technology Stack

### Frontend
- React 18 with TypeScript
- Wouter for routing
- TanStack Query for state management
- Tailwind CSS with shadcn/ui components
- Vite for development and build

### Backend
- Node.js with Express.js
- TypeScript with ES modules
- PostgreSQL with Drizzle ORM
- Neon serverless database

### External Integrations
- Spotify Web API
- Replit Authentication
- MaxValue lab data
- Leafly strain database

## Quick Start

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Environment Setup**
   Create a `.env` file with:
   ```bash
   DATABASE_URL=your_postgresql_url
   SPOTIFY_CLIENT_ID=your_spotify_client_id
   SPOTIFY_CLIENT_SECRET=your_spotify_client_secret
   SPOTIFY_REDIRECT_URI=your_redirect_uri
   ```

3. **Database Setup**
   ```bash
   npm run db:push
   ```

4. **Development Server**
   ```bash
   npm run dev
   ```

5. **Production Build**
   ```bash
   npm run build
   npm start
   ```

## Project Structure

```
terptunes/
├── client/              # React frontend
│   ├── src/
│   │   ├── components/  # UI components
│   │   ├── pages/       # Page components
│   │   ├── hooks/       # Custom hooks
│   │   └── lib/         # Utilities
├── server/              # Express backend
│   ├── routes/          # API routes
│   ├── services/        # Business logic
│   └── middleware/      # Express middleware
├── shared/              # Shared types and schemas
├── tests/               # Test suites
└── dist/                # Production build
```

## API Endpoints

### Authentication
- `GET /api/auth/user` - Get current user
- `GET /api/login` - Initiate login

### Strains
- `GET /api/strains` - List strains with filtering
- `GET /api/strains/:id` - Get strain details
- `POST /api/strains` - Add new strain

### Playlists
- `GET /api/playlists` - User playlists
- `POST /api/generate-playlist` - Generate from strain

### Spotify
- `GET /api/spotify/status` - Connection status
- `GET /api/spotify/connect` - OAuth flow

## Database Schema

- **users** - User accounts and preferences
- **strains** - Cannabis strain data
- **terpene_profiles** - Chemical composition data
- **playlists** - Generated Spotify playlists
- **user_strain_history** - Consumption tracking
- **brand_ambassadors** - Loyalty program data

## Deployment

The platform is optimized for cloud deployment with:
- Health check endpoints (`/health`, `/ready`, `/alive`)
- Environment variable configuration
- Production build optimization
- Database connection pooling

## Testing

- **Unit Tests**: `npm run test`
- **Integration Tests**: `npm run test:integration`
- **E2E Tests**: `npm run test:e2e`

## Documentation

- `TECHNICAL_HANDOFF.md` - Complete technical documentation
- `replit.md` - Project history and architecture
- API documentation available at `/api/docs`

## Support

For technical support or questions about the platform, refer to the comprehensive technical documentation or contact the development team.

---

**Version**: 1.0.0  
**Last Updated**: January 1, 2025  
**Status**: Production Ready