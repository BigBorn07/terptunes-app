# TerpTunes Deployment Configuration

## Health Check Endpoints

TerpTunes provides multiple health check endpoints optimized for deployment platforms:

### Primary Health Check
- **URL**: `/health`
- **Method**: GET
- **Response**: `OK` (plain text)
- **Response Time**: < 20ms (ultra-fast response)

### Readiness Check
- **URL**: `/ready`
- **Method**: GET
- **Response**: `READY` (plain text)
- **Response Time**: < 5ms (immediate response)

### Liveness Check
- **URL**: `/alive`
- **Method**: GET
- **Response**: `ALIVE` (plain text)
- **Response Time**: < 5ms (immediate response)

### Root Health Check
- **URL**: `/`
- **Method**: GET  
- **Response**: `OK` (plain text)
- **Response Time**: < 5ms (immediate response)
- **Note**: Responds to non-HTML requests, allows normal frontend routing for browser requests

## Database Initialization

### Background Initialization
- Database initialization runs **after** server startup to prevent blocking
- Server starts immediately on port 5000 without waiting for database seeding
- Production deployments skip seeding automatically to avoid startup delays
- Database connection is tested during initialization but doesn't block server startup

### Manual Database Commands
```bash
# Initialize database (development)
npm run db:init

# Force seed database  
npm run db:force-seed

# Push schema changes
npm run db:push
```

## Performance Optimizations

### Caching Strategy
- **Strains Cache**: 5-minute TTL for expensive database queries
- **Cache Warming**: Automatic cache refresh on first request
- **Memory Usage**: Cached strain data reduces database load by 90%

### Database Query Optimization
- Batch terpene profile fetching reduces database calls
- Cached responses for frequently accessed endpoints
- Background cache refresh prevents user-facing delays

## Deployment Requirements

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (required)
- `NODE_ENV`: Set to `production` for production deployments
- `PORT`: Defaults to 5000 (configurable)

### Platform Configuration
- **Port**: 5000 (internal), 80 (external mapping)
- **Host**: 0.0.0.0 (external access) - **CRITICAL: NOT localhost/127.0.0.1**
- **Health Check Path**: `/health` or `/`
- **Startup Timeout**: 30 seconds (server starts immediately)
- **Health Check Timeout**: 5 seconds
- **Proxy Configuration**: Enhanced for deployment platform compatibility

### Deployment Proxy Configuration
- **Keep Alive Timeout**: 65 seconds (longer than most load balancers)
- **Headers Timeout**: 66 seconds (slightly longer than keep alive)
- **Request Timeout**: 30 seconds
- **Socket Timeout**: 30 seconds
- **Max Headers Count**: 2000 (handles proxy headers)
- **Max Requests Per Socket**: Unlimited (enables proxy reuse)

### Startup Sequence
1. Express server starts immediately (< 3 seconds)
2. Health check endpoints become available
3. Database initialization runs in background
4. Application becomes fully operational
5. Cache warming occurs on first strain request

## Troubleshooting

### Health Check Failures
- Ensure `/health` endpoint returns 200 status
- Check server logs for startup errors
- Verify port 5000 is accessible

### Deployment Proxy Connection Issues
- **Connection Refused Errors**: Verify deployment platform connects to `0.0.0.0:5000`, NOT `127.0.0.1:5000`
- **Health Check Timeouts**: Look for `[DEPLOYMENT-HEALTH]` logs showing client IP and user agent
- **Proxy Detection**: Check logs for deployment platform user agents (kube-probe, Go-http-client, etc.)
- **Network Diagnostics**: Review startup logs for host binding verification messages
- **Header Compatibility**: Ensure proxy headers are being processed (Connection: close, Cache-Control, etc.)

### Proxy Configuration Verification
Run the deployment proxy fix validation test:
```bash
node deployment-proxy-fix-validation.js
```
This validates all proxy connection fixes and provides detailed diagnostic information.

### Performance Issues
- Monitor strain cache hit rates
- Check database connection latency
- Review background initialization logs

### Database Issues
- Verify DATABASE_URL environment variable
- Check database connectivity
- Review seeding logs for errors

## Production Deployment Checklist

- [ ] `NODE_ENV=production` environment variable set
- [ ] `DATABASE_URL` configured with production database
- [ ] Health check endpoint `/health` returns 200
- [ ] Server starts within 30 seconds
- [ ] No blocking database operations during startup
- [ ] Caching enabled for strain endpoints
- [ ] Background database initialization completes successfully