import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for auth with role-based access
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  spotifyId: varchar("spotify_id"),
  spotifyAccessToken: text("spotify_access_token"),
  spotifyRefreshToken: text("spotify_refresh_token"),
  spotifyTokenExpiry: timestamp("spotify_token_expiry"),
  
  // User role and onboarding
  userType: varchar("user_type").default("consumer"), // consumer, grower, dispensary
  verificationStatus: varchar("verification_status").default("pending"), // pending, verified, rejected
  onboardingCompleted: boolean("onboarding_completed").default(false),
  accountStatus: varchar("account_status").default("active"), // active, suspended, pending_verification
  
  // Business verification (for growers/dispensaries)
  businessName: varchar("business_name"),
  businessLicense: varchar("business_license"),
  businessAddress: text("business_address"),
  businessPhone: varchar("business_phone"),
  businessWebsite: varchar("business_website"),
  verificationDocuments: text("verification_documents").array(),
  verificationNotes: text("verification_notes"),
  verifiedAt: timestamp("verified_at"),
  verifiedBy: varchar("verified_by"),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Cannabis strains table - Enhanced with MaxValue integration fields
export const strains = pgTable("strains", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  type: varchar("type").notNull(), // indica, sativa, hybrid
  thcContent: varchar("thc_content"),
  cbdContent: varchar("cbd_content"),
  description: text("description"),
  effects: text("effects").array(), // array of effect strings
  flavors: text("flavors").array(), // array of flavor strings
  
  // MaxValue integration fields
  leaflyImageUrl: text("leafly_image_url"),
  maxvalueMatchFound: boolean("maxvalue_match_found").default(false),
  maxvalueStrainName: varchar("maxvalue_strain_name"),
  maxvalueSampleSize: integer("maxvalue_sample_size"),
  terpeneCount: integer("terpene_count").default(0),
  terpeneDiversityScore: decimal("terpene_diversity_score", { precision: 5, scale: 2 }),
  dataQualityScore: decimal("data_quality_score", { precision: 5, scale: 2 }),
  
  // Source tracking
  dataSource: varchar("data_source").default("TerpTunes"), // TerpTunes, Leafly, MaxValue, User
  verificationStatus: varchar("verification_status").default("pending"), // verified, pending, rejected
  labVerified: boolean("lab_verified").default(false),
  imageUrl: varchar("image_url"),
  source: varchar("source").default("lab"), // lab, user, api
  submittedBy: varchar("submitted_by").references(() => users.id), // user who added it
  qualityScore: decimal("quality_score", { precision: 3, scale: 2 }), // 0.0-10.0 quality rating
  brand: varchar("brand"), // cultivator/brand name (e.g., "Cookies", "Jungle Boys")
  grower: varchar("grower"), // specific grower if different from brand
  createdAt: timestamp("created_at").defaultNow(),
});

// Enhanced terpene profiles for strains with MaxValue integration
export const terpeneProfiles = pgTable("terpene_profiles", {
  id: serial("id").primaryKey(),
  strainId: integer("strain_id").references(() => strains.id),
  name: varchar("name").notNull(), // terpene compound name (e.g., "beta-Myrcene")
  percentage: decimal("percentage", { precision: 6, scale: 3 }), // precise percentage with 3 decimal places
  variance: decimal("variance", { precision: 6, scale: 3 }), // statistical variance from MaxValue
  stability: decimal("stability", { precision: 5, scale: 2 }), // stability percentage (0-100)
  source: varchar("source").default("MaxValue"), // data source: MaxValue, Leafly, User, TerpTunes
  sampleSize: integer("sample_size").default(1), // number of lab samples aggregated
  labVerified: boolean("lab_verified").default(false), // verified by professional lab
  confidenceScore: decimal("confidence_score", { precision: 3, scale: 2 }), // 0.0-1.0 confidence
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Terpene effects correlation table for scientific mapping
export const terpeneEffects = pgTable("terpene_effects", {
  id: serial("id").primaryKey(),
  compoundName: varchar("compound_name").notNull(), // e.g., "Myrcene"
  effectCategory: varchar("effect_category").notNull(), // e.g., "Relaxation", "Energy"
  correlationStrength: decimal("correlation_strength", { precision: 3, scale: 2 }), // 0.0-1.0
  researchSource: text("research_source"), // scientific study reference
  musicalCharacteristics: text("musical_characteristics").array(), // associated music genres/moods
  createdAt: timestamp("created_at").defaultNow(),
});

// User playlists
export const playlists = pgTable("playlists", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  strainId: integer("strain_id").references(() => strains.id),
  spotifyPlaylistId: varchar("spotify_playlist_id"),
  spotifyId: varchar("spotify_id"),
  spotifyUrl: varchar("spotify_url"),
  name: varchar("name").notNull(),
  description: text("description"),
  trackCount: integer("track_count").default(0),
  duration: integer("duration").default(0), // in minutes
  dominantTerpenes: jsonb("dominant_terpenes"), // array of terpene names
  primaryGenre: varchar("primary_genre"), // main musical genre (electronic, rock, etc.)
  genres: jsonb("genres"), // array of all genres in playlist
  mood: varchar("mood"), // relaxing, energetic, focused, etc.
  energy: decimal("energy", { precision: 3, scale: 2 }), // 0.0-1.0 energy level
  isPublic: boolean("is_public").default(false), // can other users discover this playlist
  playCount: integer("play_count").default(0), // how many times accessed
  likeCount: integer("like_count").default(0), // user likes
  // Mello Maestro integration fields
  isMaestroCreated: boolean("is_maestro_created").default(false), // created by Maestro's algorithm
  maestroInsights: text("maestro_insights"), // Maestro's commentary about the playlist
  terpeneStory: text("terpene_story"), // Maestro's narrative about the terpenes
  musicalJourney: jsonb("musical_journey"), // array of journey steps
  maestroScore: integer("maestro_score"), // Maestro's compatibility rating (0-100)
  complexityScore: decimal("complexity_score", { precision: 3, scale: 2 }), // musical complexity 0.0-1.0
  energyLevel: integer("energy_level"), // integer version of energy for easier queries
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Playlist likes for user engagement
export const playlistLikes = pgTable("playlist_likes", {
  id: serial("id").primaryKey(), 
  userId: varchar("user_id").references(() => users.id),
  playlistId: integer("playlist_id").references(() => playlists.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Cannabis brands/cultivators for industry relationships
export const brands = pgTable("brands", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(), // e.g., "Cookies", "Jungle Boys", "Connected"
  type: varchar("type").notNull(), // cultivator, processor, brand, dispensary
  location: varchar("location"), // state or region
  website: varchar("website"),
  description: text("description"),
  verified: boolean("verified").default(false), // verified industry partner
  contactEmail: varchar("contact_email"),
  strainCount: integer("strain_count").default(0), // number of strains in our database
  userFavorites: integer("user_favorites").default(0), // how many users marked as favorite
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Legacy table - keeping for compatibility but using new userPreferences structure

// User strain consumption tracking for brand ambassador program
export const userStrainHistory = pgTable("user_strain_history", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  strainId: integer("strain_id").references(() => strains.id),
  brandId: integer("brand_id").references(() => brands.id),
  consumedAt: timestamp("consumed_at").defaultNow(),
  rating: integer("rating"), // 1-5 star rating
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Brand ambassador status tracking
export const brandAmbassadors = pgTable("brand_ambassadors", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  brandId: integer("brand_id").references(() => brands.id),
  status: varchar("status").notNull().default("active"), // "active", "inactive", "suspended"
  qualifiedAt: timestamp("qualified_at").defaultNow(),
  totalStrains: integer("total_strains").notNull().default(0),
  ambassadorLevel: varchar("ambassador_level").default("bronze"), // "bronze", "silver", "gold", "platinum"
  exclusiveAccess: boolean("exclusive_access").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Brand exclusive rewards and content
export const brandExclusives = pgTable("brand_exclusives", {
  id: serial("id").primaryKey(),
  brandId: integer("brand_id").references(() => brands.id),
  title: varchar("title").notNull(),
  description: text("description"),
  type: varchar("type").notNull(), // "discount", "early_access", "exclusive_strain", "event_invite", "merchandise"
  value: varchar("value"), // "20%", "exclusive", etc.
  minimumLevel: varchar("minimum_level").default("bronze"), // required ambassador level
  minimumStrains: integer("minimum_strains").default(10),
  validUntil: timestamp("valid_until"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Schemas
export const insertUserSchema = createInsertSchema(users);
export const insertStrainSchema = createInsertSchema(strains);
export const insertTerpeneProfileSchema = createInsertSchema(terpeneProfiles);
export const insertPlaylistSchema = createInsertSchema(playlists);
export const insertPlaylistLikeSchema = createInsertSchema(playlistLikes);
export const insertBrandSchema = createInsertSchema(brands);
export const insertUserStrainHistorySchema = createInsertSchema(userStrainHistory);
export const insertBrandAmbassadorSchema = createInsertSchema(brandAmbassadors);
export const insertBrandExclusiveSchema = createInsertSchema(brandExclusives);

// User onboarding progress tracking
export const userOnboarding = pgTable("user_onboarding", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  step: varchar("step").notNull(), // 'user_type', 'preferences', 'verification', 'tutorial', 'completed'
  completed: boolean("completed").default(false),
  data: jsonb("data"), // store step-specific data
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// User preferences for personalized experience  
export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull().unique(),
  
  // Cannabis preferences
  favoriteStrainTypes: text("favorite_strain_types").array().default([]), // ['indica', 'sativa', 'hybrid']
  favoriteTerpenes: text("favorite_terpenes").array().default([]), // ['myrcene', 'limonene', 'pinene']
  preferredEffects: text("preferred_effects").array().default([]), // ['relaxed', 'creative', 'energetic']
  thcPreference: jsonb("thc_preference"), // { min: 15, max: 25 }
  cbdPreference: jsonb("cbd_preference"), // { min: 0, max: 10 }
  
  // Music preferences
  musicGenres: text("music_genres").array().default([]), // ['electronic', 'ambient', 'rock']
  moodStates: text("mood_states").array().default([]), // ['relaxed', 'creative', 'energetic']
  usageContext: text("usage_context").array().default([]), // ['evening wind-down', 'creative work', 'social']
  playlistDuration: integer("playlist_duration").default(60), // minutes
  explicitContent: boolean("explicit_content").default(false),
  
  // Notification preferences
  notifications: jsonb("notifications").default({
    newStrains: true,
    playlistRecommendations: true,
    weeklyInsights: false,
  }),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserOnboardingSchema = createInsertSchema(userOnboarding);
export const insertUserPreferencesSchema = createInsertSchema(userPreferences);

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type UserOnboarding = typeof userOnboarding.$inferSelect;
export type InsertUserOnboarding = typeof userOnboarding.$inferInsert;
export type UserPreferences = typeof userPreferences.$inferSelect;
export type InsertUserPreferences = typeof userPreferences.$inferInsert;
export type Strain = typeof strains.$inferSelect;
export type InsertStrain = z.infer<typeof insertStrainSchema>;
export type TerpeneProfile = typeof terpeneProfiles.$inferSelect;
export type InsertTerpeneProfile = z.infer<typeof insertTerpeneProfileSchema>;
export type Playlist = typeof playlists.$inferSelect;
export type InsertPlaylist = z.infer<typeof insertPlaylistSchema>;
export type PlaylistLike = typeof playlistLikes.$inferSelect;
export type InsertPlaylistLike = z.infer<typeof insertPlaylistLikeSchema>;
export type Brand = typeof brands.$inferSelect;
export type InsertBrand = z.infer<typeof insertBrandSchema>;
export type UserStrainHistory = typeof userStrainHistory.$inferSelect;
export type InsertUserStrainHistory = z.infer<typeof insertUserStrainHistorySchema>;
export type BrandAmbassador = typeof brandAmbassadors.$inferSelect;
export type InsertBrandAmbassador = z.infer<typeof insertBrandAmbassadorSchema>;
export type BrandExclusive = typeof brandExclusives.$inferSelect;
export type InsertBrandExclusive = z.infer<typeof insertBrandExclusiveSchema>;

// Dispensary System
export const dispensaries = pgTable("dispensaries", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull().unique(),
  location: varchar("location").notNull(),
  address: text("address"),
  phone: varchar("phone"),
  website: varchar("website"),
  hours: jsonb("hours"), // operating hours
  amenities: jsonb("amenities").default('[]'), // ["delivery", "curbside", "online_ordering"]
  verified: boolean("verified").default(false),
  rating: decimal("rating", { precision: 3, scale: 2 }).default('0.00'),
  description: text("description"),
  logo: varchar("logo"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const userDispensaryHistory = pgTable("user_dispensary_history", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  dispensaryId: integer("dispensary_id").notNull().references(() => dispensaries.id),
  visitType: varchar("visit_type").notNull(), // "purchase", "visit", "order"
  amount: decimal("amount", { precision: 10, scale: 2 }), // purchase amount
  strainsPurchased: jsonb("strains_purchased").default('[]'), // array of strain IDs
  visitDate: timestamp("visit_date").defaultNow(),
  rating: integer("rating"), // 1-5 star rating
  review: text("review"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const dispensaryAmbassadors = pgTable("dispensary_ambassadors", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  dispensaryId: integer("dispensary_id").notNull().references(() => dispensaries.id),
  totalVisits: integer("total_visits").notNull().default(0),
  totalSpent: decimal("total_spent", { precision: 10, scale: 2 }).notNull().default('0.00'),
  ambassadorLevel: varchar("ambassador_level").notNull(), // bronze, silver, gold, platinum
  qualifiedAt: timestamp("qualified_at").defaultNow(),
  exclusiveAccess: boolean("exclusive_access").default(true),
  loyaltyPoints: integer("loyalty_points").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const dispensaryExclusives = pgTable("dispensary_exclusives", {
  id: serial("id").primaryKey(),
  dispensaryId: integer("dispensary_id").notNull().references(() => dispensaries.id),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  type: varchar("type").notNull(), // discount, early_access, exclusive_strain, event_invite, loyalty_points
  value: varchar("value").notNull(), // "20%", "50 points", "exclusive"
  requiredLevel: varchar("required_level").notNull(), // bronze, silver, gold, platinum
  validUntil: timestamp("valid_until"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userFavoriteDispensaries = pgTable("user_favorite_dispensaries", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  dispensaryId: integer("dispensary_id").notNull().references(() => dispensaries.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Schema exports for dispensaries
export const insertDispensarySchema = createInsertSchema(dispensaries);
export const insertUserDispensaryHistorySchema = createInsertSchema(userDispensaryHistory);
export const insertDispensaryAmbassadorSchema = createInsertSchema(dispensaryAmbassadors);
export const insertDispensaryExclusiveSchema = createInsertSchema(dispensaryExclusives);
export const insertUserFavoriteDispensarySchema = createInsertSchema(userFavoriteDispensaries);

export type Dispensary = typeof dispensaries.$inferSelect;
export type InsertDispensary = z.infer<typeof insertDispensarySchema>;
export type UserDispensaryHistory = typeof userDispensaryHistory.$inferSelect;
export type InsertUserDispensaryHistory = z.infer<typeof insertUserDispensaryHistorySchema>;
export type DispensaryAmbassador = typeof dispensaryAmbassadors.$inferSelect;
export type InsertDispensaryAmbassador = z.infer<typeof insertDispensaryAmbassadorSchema>;
export type DispensaryExclusive = typeof dispensaryExclusives.$inferSelect;
export type InsertDispensaryExclusive = z.infer<typeof insertDispensaryExclusiveSchema>;
export type UserFavoriteDispensary = typeof userFavoriteDispensaries.$inferSelect;
export type InsertUserFavoriteDispensary = z.infer<typeof insertUserFavoriteDispensarySchema>;

// Gamification: Terpene Badge System
export const badges = pgTable("badges", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull().unique(),
  description: text("description").notNull(),
  category: varchar("category").notNull(), // terpene, discovery, social, knowledge
  icon: varchar("icon").notNull(),
  requirement: jsonb("requirement").notNull(), // badge earning criteria
  rarity: varchar("rarity").notNull(), // common, uncommon, rare, legendary
  points: integer("points").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userBadges = pgTable("user_badges", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  badgeId: integer("badge_id").notNull().references(() => badges.id),
  earnedAt: timestamp("earned_at").defaultNow(),
  progress: jsonb("progress"), // current progress toward badge
});

export const userStats = pgTable("user_stats", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id).unique(),
  level: integer("level").notNull().default(1),
  totalPoints: integer("total_points").notNull().default(0),
  strainsDiscovered: integer("strains_discovered").notNull().default(0),
  playlistsCreated: integer("playlists_created").notNull().default(0),
  terpeneKnowledge: integer("terpene_knowledge").notNull().default(0),
  socialScore: integer("social_score").notNull().default(0),
  lastActivityAt: timestamp("last_activity_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Schema exports for badges
export const insertBadgeSchema = createInsertSchema(badges);
export const insertUserBadgeSchema = createInsertSchema(userBadges);
export const insertUserStatsSchema = createInsertSchema(userStats);

export type Badge = typeof badges.$inferSelect;
export type InsertBadge = z.infer<typeof insertBadgeSchema>;
export type UserBadge = typeof userBadges.$inferSelect;
export type InsertUserBadge = z.infer<typeof insertUserBadgeSchema>;
export type UserStats = typeof userStats.$inferSelect;
export type InsertUserStats = z.infer<typeof insertUserStatsSchema>;

export type UserStrainSubmission = {
  name: string;
  type: 'indica' | 'sativa' | 'hybrid';
  thcContent?: string;
  cbdContent?: string;
  description?: string;
  effects?: string[];
  flavors?: string[];
  brand?: string;
  grower?: string;
  providedTerpenes?: Array<{ name: string; percentage: number }>;
};
